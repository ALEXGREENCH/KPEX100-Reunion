; Startup code for cc65 (NES version)
; based on code by Groepaz/Hitmen <groepaz@gmx.net>, Ullrich von Bassewitz <uz@cc65.org>

    .export _exit
    .export __STARTUP__:absolute=1      ; Mark as startup
	.import initlib
	.import push0,_main,zerobss,copydata
	.import popa
	.import _oam_clear,_pal_clear
	.import FamiToneUpdate,FamiToneSfxInit,FamiToneInit,FamiToneSampleInit

; Linker generated symbols
	.import __RAM_START__   ,__RAM_SIZE__
	.import __ROM0_START__  ,__ROM0_SIZE__
	.import __STARTUP_LOAD__,__STARTUP_RUN__,__STARTUP_SIZE__
	.import	__CODE_LOAD__   ,__CODE_RUN__   ,__CODE_SIZE__
	.import	__RODATA_LOAD__ ,__RODATA_RUN__ ,__RODATA_SIZE__

    .include "zeropage.inc"
	.include "memmap.inc"


.segment        "HEADER"

;    +--------+------+------------------------------------------+
;    | Offset | Size | Content(s)                               |
;    +--------+------+------------------------------------------+
;    |   0    |  3   | 'NES'                                    |
;    |   3    |  1   | $1A                                      |
;    |   4    |  1   | 16K PRG-ROM page count                   |
;    |   5    |  1   | 8K CHR-ROM page count                    |
;    |   6    |  1   | ROM Control Byte #1                      |
;    |        |      |   %####vTsM                              |
;    |        |      |    |  ||||+- 0=Horizontal mirroring      |
;    |        |      |    |  ||||   1=Vertical mirroring        |
;    |        |      |    |  |||+-- 1=SRAM enabled              |
;    |        |      |    |  ||+--- 1=512-byte trainer present  |
;    |        |      |    |  |+---- 1=Four-screen mirroring     |
;    |        |      |    |  |                                  |
;    |        |      |    +--+----- Mapper # (lower 4-bits)     |
;    |   7    |  1   | ROM Control Byte #2                      |
;    |        |      |   %####0000                              |
;    |        |      |    |  |                                  |
;    |        |      |    +--+----- Mapper # (upper 4-bits)     |
;    |  8-15  |  8   | $00                                      |
;    | 16-..  |      | Actual 16K PRG-ROM pages (in linear      |
;    |  ...   |      | order). If a trainer exists, it precedes |
;    |  ...   |      | the first PRG-ROM page.                  |
;    | ..-EOF |      | CHR-ROM pages (in ascending order).      |
;    +--------+------+------------------------------------------+

    .byte $4e,$45,$53,$1a	; "NES"^Z
	.byte 2	        		; ines prg  - Specifies the number of 16k prg banks.
	.byte 1               	; ines chr  - Specifies the number of 8k chr banks.
	.byte %00000000       	; ines mir  - Specifies VRAM mirroring of the banks.
	.byte %00000000       	; ines map  - Specifies the NES mapper used.
	.byte 0,0,0,0,0,0,0,0	; 8 zeroes


.segment       	"STARTUP"

start:
_exit:

    sei
    ldx #$ff
    txs
    inx
    stx PPU_MASK
    stx DMC_FREQ
    stx PPU_CTRL		;no NMI

    bit PPU_STATUS
@1:
    bit PPU_STATUS
    bpl @1

    txa
@clearRAM:
    sta $000,x
    sta $100,x
    sta $200,x
    sta $300,x
    sta $400,x
    sta $500,x
    sta $600,x
    sta $700,x
    inx
    bne @clearRAM

@clearVRAM:
	lda #$20
	sta PPU_ADDR
	lda #$00
	sta PPU_ADDR
@3:
	ldy #$40
@4:
	sta PPU_DATA
	iny
	bne @4
	inx
	bne @3

	jsr _oam_clear

    bit PPU_STATUS
@2:
    bit PPU_STATUS
    bpl @2

    jsr	zerobss
	jsr	copydata

    lda #<(__RAM_START__+__RAM_SIZE__)
    sta	sp
    lda	#>(__RAM_START__+__RAM_SIZE__)
    sta	sp+1            ; Set argument stack ptr

	jsr	initlib

	lda #%10000000
	sta <PPU_CTRL_VAR
	sta PPU_CTRL		;enable NMI
	lda #%00000110
	sta <PPU_MASK_VAR

	lda <FRAMECNT1
@wait:
	cmp <FRAMECNT1
	beq @wait

	ldx #52				;blargg's code
	ldy #24
@detectNTSC:
	dex
	bne @detectNTSC
	dey
	bne @detectNTSC

	lda PPU_STATUS
	and #$80
	sta <NTSCMODE

	lda <NTSCMODE
	jsr FamiToneInit

	;ldx #<music_dpcm
	;ldy #>music_dpcm
	;jsr FamiToneSampleInit

	ldx #<sounds_data
	ldy #>sounds_data
	jsr FamiToneSfxInit

	lda #1
	sta <RAND_SEED

	lda #0
	sta PPU_SCROLL
	sta PPU_SCROLL

	;jsr _pal_bright
	jsr _pal_clear

	jmp _main			;no parameters


nmi:
	pha
	txa
	pha
	tya
	pha

	lda <VRAMUPDATE
	bne @upd
	jmp @skipUpd

@upd:
	lda #$00
	sta PPU_OAM_ADDR
	lda #>OAM_BUF
	sta PPU_OAM_DMA

	lda #$3f
	sta PPU_ADDR
	lda #$00
	sta PPU_ADDR

	.repeat 4,I
	lda PAL_BUF+I
	;lda (PAL_PTR),y
	sta PPU_DATA
	.endrepeat

	.repeat 7,J
	lda PPU_DATA			;skip background color
	.repeat 3,I
	lda PAL_BUF+5+(J*4)+I
	;lda (PAL_PTR),y
	sta PPU_DATA
	.endrepeat
	.endrepeat

	ldx <NAME_UPD_LEN
	beq @skipUpd
	ldy #0
@updName:
	lda (NAME_UPD_ADR),y
	iny
	sta PPU_ADDR
	lda (NAME_UPD_ADR),y
	iny
	sta PPU_ADDR
	lda (NAME_UPD_ADR),y
	iny
	sta PPU_DATA
	dex
	bne @updName

@skipUpd:
	lda #0
	sta PPU_ADDR
	sta PPU_ADDR

	lda <SCROLL_X
	sta PPU_SCROLL
	lda <SCROLL_Y
	sta PPU_SCROLL
	lda <PPU_CTRL_VAR
	sta PPU_CTRL

	inc <FRAMECNT1
	inc <FRAMECNT2
	lda <FRAMECNT2
	cmp #6
	bne @skipNtsc
	lda #0
	sta <FRAMECNT2
@skipNtsc:

	jsr FamiToneUpdate

	pla
	tay
	pla
	tax
	pla

irq:
    rti


.segment "RODATA"

	.include "music.s"
sounds_data:
	.include "sounds.s"

.segment "SAMPLES"

	;.incbin "music_dpcm.bin"

.segment "VECTORS"

    .word nmi	;$fffa vblank nmi
    .word start	;$fffc reset
   	.word irq	;$fffe irq / brk


.segment "CHARS"

	.incbin "tileset.chr"
