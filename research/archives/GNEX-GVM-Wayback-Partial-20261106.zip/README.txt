Resumable public Wayback collection, PARTIAL snapshot.
collection/summary.json states which CDX scopes reached the end and which captures were verified. An indexed capture is NOT a recovered payload.
Original response bytes are in collection/objects/<SHA256-prefix>/<SHA256>. responses.jsonl records URL, UTC, status and headers. captures.jsonl records original CDX rows, digest checks and pending/mismatch/error states. membership.jsonl preserves the scope relation.
queue.sqlite3 is a consistent SQLite backup and can resume with: python tools/wayback-harvest.py collection --index --download --retry
No domain/date/status/MIME collapse was requested. Duplicate identical CDX rows share a queue task; their original raw CDX response remains intact. UTF-8 URL quoting is recorded separately from the literal CDX original. Mojibake URL variants are not silently rewritten. Redirects are preserved, never followed into today's live websites.
This is NOT a complete WARC export or proof that missing/private files were archived. Error pages and unknown digests remain unverified. No historical code is executed. Original third-party content retains its existing rights; the MIT license covers Reunion tools only.
manifest.json covers all other members, excluding itself.
