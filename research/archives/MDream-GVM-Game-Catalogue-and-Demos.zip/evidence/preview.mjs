import {createStaticServer} from '../../outputs/KPEX100-Reunion/tools/serve.mjs';
import {fileURLToPath} from 'node:url';
import {writeFileSync} from 'node:fs';
const {chromium}=await import('file:///C:/Users/Sanya/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
const file=(name)=>fileURLToPath(new URL(name,import.meta.url));
const server=createStaticServer(file('preview/'),'/');
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url='http://127.0.0.1:'+server.address().port+'/';
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-gl=angle','--use-angle=swiftshader']});
try {
const page=await browser.newPage({viewport:{width:500,height:540}});
await page.route('**/*',r=>r.request().url().startsWith(url)?r.continue():r.abort());
await page.goto(url);
await page.waitForFunction(()=>window.loaded||window.error,{},{timeout:10000});
if(await page.evaluate(()=>window.error)) throw Error(await page.evaluate(()=>window.error));
await page.waitForTimeout(3500);
await page.screenshot({path:file('moonpatrol-before.png')});
const clicks=JSON.parse(process.argv[2]||'[]');
for(const [i,point] of clicks.entries()){
 await page.mouse.click(...point);
 await page.waitForTimeout(120);
 await page.screenshot({path:file('moonpatrol-click-'+i+'.png')});
}
writeFileSync(file('moonpatrol-preview.json'),JSON.stringify({chrome:browser.version(),ruffle:'0.7.1',clicks},null,2));
} finally {await browser.close();server.close()}

