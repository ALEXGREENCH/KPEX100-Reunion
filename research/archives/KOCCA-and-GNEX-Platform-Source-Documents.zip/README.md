# GNEX platform source documents

Preserved unchanged: the 262-page KOCCA-hosted 2005 cross-platform game
research report, a Sinjisoft GNEX FAIR announcement and two historical
trade-press pages. provenance.json records original URLs, sizes, SHA-256,
source type and the exact selected-page review coverage.

The report URL was already cited by Reunion; this pass preserves its exact
PDF locally and in Git. This is not a claim of a new SDK, game, firmware or
retail hardware model. The report submission date is 2005-05-10, distinct
from the 2010 path in its current hosting URL. The anonymous company-S EVM
figure alone does not establish a shipping model or a common ABI.

Original notices and rights remain with their owners. The HTML pages are
archival data, not scripts to execute. manifest.json hashes every other
member; full ZIP CRC and every listed member hash were checked.
