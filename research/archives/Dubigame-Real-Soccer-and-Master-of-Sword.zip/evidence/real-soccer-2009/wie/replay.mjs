import { chromium } from 'playwright';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const path = (x) => fileURLToPath(new URL(x, import.meta.url));
const browser = await chromium.launch({channel:'chrome',headless:true});
const page = await browser.newPage();
const assets = {
 '/engine.js': ['text/javascript','wie_web.js'],
 '/engine.wasm': ['application/wasm','wie_web_bg.wasm'],
 '/game.zip': ['application/zip','real-soccer-2009-ktf.zip'],
};
const failed = [], consoleMessages = [];
await page.route('**/*', async (r) => {
 const url = new URL(r.request().url());
 if (url.origin !== 'http://127.0.0.1:42424') {failed.push(url.href); await r.abort();return}
 if (url.pathname === '/') return r.fulfill({contentType:'text/html',body:'<!DOCTYPE html><canvas id="screen" width="240" height="320"></canvas>'});
 const [contentType,filename]=assets[url.pathname]??[];
 if (filename) return r.fulfill({contentType,body:readFileSync(path(filename))});
 return r.fulfill({status:404,body:''});
});
page.on('pageerror',(e)=>consoleMessages.push(e.message));
page.on('console',(m)=>{if(consoleMessages.length<120)consoleMessages.push(m.type()+': '+m.text().slice(0,600));});
try {
 await page.goto('http://127.0.0.1:42424/');
 const kind = await page.evaluate(async()=>{
  const m=await import('/engine.js');
  await m.default({module_or_path:'/engine.wasm'});
  const data=new Uint8Array(await (await fetch('/game.zip')).arrayBuffer());
  window.emu=new m.WieEmulator('real-soccer-2009.zip',data,document.querySelector('canvas'),null,null,240,320);
  window.tickError=null;window.ticks=0;
  const tick=()=>{
   try {window.emu.tick();window.ticks++}catch(e){window.tickError=String(e);return}
   if(!window.emu.has_exited())requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
  return window.emu.platform_kind();
 });
 const evidence=[];
 mkdirSync(path('wie-47-match/'),{recursive:true});
 const snap=async (name)=>{
  const locator=page.locator('canvas');
  const bytes=await locator.screenshot({path:path('wie-47-match/'+name+'.png')});
  const status=await page.evaluate(()=>({ticks:window.ticks,exited:window.emu.has_exited(),error:window.tickError}));
  evidence.push({name,sha256:createHash('sha256').update(bytes).digest('hex'),...status});
  console.log(evidence.at(-1));
 };
 for (let n=1;n<=5;n++) {
  await page.waitForTimeout(n===1?3200:3500);
  await snap('wait-'+n);
 }
 for (const [i,k] of ['RIGHT','RIGHT_SOFT_KEY','OK','OK','OK','OK','OK','OK','RIGHT','OK','RIGHT_SOFT_KEY','OK'].entries()) {
  const n=i+1;
  await page.evaluate((key)=>window.emu.key_down(key), k);
  await page.waitForTimeout(70);
  await page.evaluate((key)=>window.emu.key_up(key), k);
  await page.waitForTimeout(900);
  await snap('ok-'+n);
 }
 for (let n=1;n<=3;n++) {
  await page.waitForTimeout(3800);
  await snap('post-lineup-'+n);
 }
 for (const [i,k] of ['RIGHT','OK','RIGHT','NUM0'].entries()) {
  await page.evaluate((key)=>window.emu.key_down(key),k);
  await page.waitForTimeout(225);
  await page.evaluate((key)=>window.emu.key_up(key),k);
  await page.waitForTimeout(700);
  await snap('match-key-'+(i+1));
 }
 writeFileSync(path('wie-47-match/verification.json'),JSON.stringify({kind,failed,consoleMessages,evidence},null,2)+'\n');
} finally {await browser.close()}


