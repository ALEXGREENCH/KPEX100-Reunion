# Independent local review

No blocking defect found in the reviewed historical evidence or community recovery.
The audit did not access the network, alter repository files, execute a vendor
binary, or claim that a documented profile establishes working gameplay.

- All three recovered document byte sizes, SHA-256, SHA-1 and CDX base32 SHA-1
  agree with the actual original files.
- All 78 unique PDF model pages were checked: 702 verbatim table fields, parsed
  VM families, script versions, protocols and physical/GVM geometry agree with
  the source PDF text. Unknown heights and dated conflicts remain explicit.
- All 238 workbook rows and 2,380 addressed cells agree with the BIFF8 XLS.
  Coverage is exhaustive for non-header model rows with an explicit GVM cell.
  The three supplementary GNEX rows also match.
- The 201 positive rows consist of 200 literal `O` values and one numeric zero
  for VK-100. The original worksheet header explicitly says support `0`,
  unsupported `X`; numeric zero is therefore supported by its legend. The
  remaining 37 rows are 28 `X` and 9 conditional values. A legend note could
  help readers, but the existing count is defensible.
- Both original WI-TOP ZIP CRC tests pass and their inventories match. Their
  Hellfire SGS files are byte-identical. The opcode byte is `0xba` at file
  offset `0x650`, followed by `0xff` at reported postfetch PC `0x651`. The saved
  runtime report explicitly fails at START; the audit did not rerun it.
- HiBaby.mc matches its source hashes and decodes as CP949 serial-receive
  example code, not a game. The second source remains an HTTP429 failure.
- Eight LG source archives and their eight raw images match all declared
  hashes and sizes. The raw total is 103,679,352 bytes. All 161 recorded runtime
  marker offsets point to the declared ASCII bytes. The SD7130 manual matches
  its recorded identity. The SGS negative scanner itself was not rerun.

`evidence.json` contains 3,948 passing checks, zero failures, and exact limits.
Original Korean PDF rendering still has the already documented fallback-font
limitation; no original PDF was rewritten.
