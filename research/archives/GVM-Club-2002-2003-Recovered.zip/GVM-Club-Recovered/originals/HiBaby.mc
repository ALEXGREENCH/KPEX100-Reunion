//==================================================================
//
//		HiBaby
//
//==================================================================

%{
// Header Section
#DEFINE SCRIPTVER	2			// GVM 2X
#DEFINE LCDCLASS	255			// LCD Class : Any class
#DEFINE IMAGETYPE	12			// Image Type :
#DEFINE AUDIOTYPE	255			// Audio Type : Any Type
#DEFINE VOCTYPE		255
#DEFINE SCRIPTTYPE	1			// Application Type (Network:3, Free:4, All type:8)
#DEFINE CPNAME		"MnC Global"// Script CP Name
#DEFINE SCRIPTCPID	9000		// Script CPID
#DEFINE SCRIPTID	1000		// Script ID
#DEFINE SCRIPTNAME	"HiBaby:hb1.0"// Script Name
%}

#include	"sscript.h"

#define  FALSE			0	
#define  TRUE			1	

/*
*/
string	rcvstr;
string	s;

//////////////////////////////////////////
//
void main()
{
	StrInit(rcvstr, 255);
	StrInit(s, 255);
	ClearWhite();
	DrawStr(0, 0, "�ø��� �׽�Ʈ");
	Flush();
}

void EVENT_TIMEOUT()
{
}

void EVENT_KEYPRESS()
{
}

void EVENT_RSRECEIVE()
{
	int i, ch;
	
	ClearWhite();
	MakeStr1(rcvstr, "%d byte(s) ����", swData);
	DrawStr(0, 0, rcvstr);
	
	for (i = 0; i < swData; i++)
	{
		ch = GetByte(swRsRcvBuf, i);
		PutChar(s, i, ch);
		PutChar(rcvstr, i*2, '0'+(ch >> 4));
		PutChar(rcvstr, i*2+1, '0'+(ch & 0x0F));
	}
	PutChar(s, i, '\0');
	PutChar(rcvstr, i*2, '\0');
	
	DrawStr(0, 13, s);
	DrawStr(0, 26, rcvstr);
	Flush();
}