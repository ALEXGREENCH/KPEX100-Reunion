# Independent SV400 / SDK / early GVM source review

All **2,536** current-turn checks pass. No blocking defect was found. There
were no network requests, repository mutations, vendor executable calls,
Office/macro execution, phone boot or game execution by this review. The
earlier639-source audit was not repeated.

## LG SV400 and adjacent OEMs — 1,165 checks

- Six original archives match hashes and pass fresh7-Zip integrity checks.
  KDZ decoding reproduces the complete CAB. The exact encrypted WDB header,
  footer, 153 record names/bounds and bounded zlib streams independently
  reproduce all57,947,996 extracted software bytes and saved outputs.
- Internal labels establish **SV400**, not SV4000. The eight compressed PXO
  originals and decoded representations match; five are named games and
  three are support modules. All401 validated LGLZ blocks match a freshly
  compiled retained original C reference, totaling7,106,628 decoded bytes.
  PXO4 sizes, metadata, Thumb targets and native instruction bytes agree.
- All six packaged Python tests ran and passed without skips: the malformed
  inputs were handled by the bounded Python decoder, not the unchecked C
  reference. No game was executed.
- The decoder stays in a separate GPL3-or-later kit, outside Reunion's MIT
  tools. Original GPL notice, COPYING, unchanged source, SVN attribution and
  translation/reference changes are retained. The original source has no
  named copyright line; SVN authorship is correctly qualified. This does
  not relicense the proprietary game payloads.
- GNEX MIME/URI recognition is correctly distinguished from an established
  interpreter, SGS execution or Sinjisoft authorship of the native games.

## SDK internal sources and samples — 1,122 checks

- Both original installer hashes,493 physical file records,18 INI profiles,
  43 extensionless source fragments and51 SignedSystem files agree with
  their retained bytes. Actual extraction paths remain distinct from MSI
  target declarations. The SCH-S250 branch is commented, not active code.
- All243 original MASM descriptor/name rows and83 x86 instruction records
  agree with the source binary. The dataflow proves **BA LockChatMode,
  BB SetChatMode and C4 BackToBrowser** on a one-byte emission path. The MCC
  records independently show one argument for LockChatMode/BackToBrowser;
  raw type codes are not assigned guessed meanings.
- These names justify updating the earlier uncertain Sanyo names, not a
  universal platform callback or a NOP substitution. No vendor compiler,
  assembler or installer was run. SDK sources remain historical vendor
  material; no new open licence is inferred.
- Four original SGS pairs and source/project hashes agree. All47 full-run
  PNG/RGBA hashes and four equal-start/equal-time input-versus-idle pixel
  differences were independently checked. Hellfire has the same50 resources
  and initial variable bytes as the existing catalogue build. AioloS is
  observed as a2D shooter, MGL and ring as developer demos. Four control
  frames were viewed. Catalogue count and runtime were not changed.

## Early service documents, original PPT/EMF and DD101 — 249 checks

- Six attachment sizes/SHA-256/SHA-1 match, including the original cached
  CDX digests. Both ZIP CRCs and all three original PDF members agree.
- An independent bounded CFB/FAT reader obtained the original PPT streams;
  all800 PPT records/50 text atoms and the actual zlib-compressed EMF agree.
  All173 EMF Unicode text records were decoded independently, reproducing
  every table cell at its source offset/row coordinate:26 rows,9 explicitly
  planned, all labelled2x. The faithful picture-0.png render was viewed.
- Cover2002.03 and the older master date remain separate. Historical model
  conflicts and future-release markers are retained rather than normalized.
  Ten DD101 worksheet cells and both actual ETNews HTML sources match.
  Failed KnNews access stays index-only; DD101 is not collapsed into DD100
  or DD-X10.
- UI_Example is unsigned two-word arithmetic, not a UI toolkit. The three
  integer arrays contain exactly5,890/8,192/4,097 entries with recorded
  literal extrema; they do not establish an engine or complete game.

Evidence is in evidence.json and the three group reports. Full byte hashes
and canonical semantic JSON hashes identify the reviewed final snapshots.
No firmware completeness, standalone native-game bundle, real-phone sample
execution or completed gameplay claim is established by these checks.
