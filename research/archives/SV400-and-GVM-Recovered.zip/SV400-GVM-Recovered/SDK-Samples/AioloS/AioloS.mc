///////////////////////////////////////////////////////////////////////////
// AioloS.mc
%{
	#DEFINE PLAYERVER		36
	#DEFINE LCDCLASS		255
	#DEFINE IMAGETYPE		255
	#DEFINE AUDIOTYPE		255
	#DEFINE APPTYPE		1
	#DEFINE APPCPID		2158
	#DEFINE APPID			10181
	#DEFINE APPNAME		"AioloS"
	#DEFINE COMPTYPE		0
	#DEFINE AGENTTYPE		0
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM		255
	#DEFINE DIRECTRUN		0
	#DEFINE STORETYPE		0
	#DEFINE APPVER			1
%}

// GNEX SDK�� Include������ �ִ� SScript.h�� include�Ѵ�.
#include "C:\Program Files\Sinjisoft\GNEX SDK\Include\SScript.h"
#include "title.sbm"
#include "s_unit_a.sbm"
#include "s_unit_b.sbm"
#include "M_unit.sbm"
#include "B_unit.sbm"
#include "bgstage.sbm"
#include "Asky_Effect.sbm"
#include "Map_Menu&Interface.sbm"
#include "Map_mission.sbm"
#include "Aiolos.ssd"


#define	DISPLAY_FPS
#define	DEBUG
#ifdef	DEBUG
void	TRACE1(int x, int y, int val)
{
	string	tempString;
	MakeStr1( tempString, "%d", val);
	DrawStr(x, y, tempString );
}
#endif


#define	NV_SIZE				16

#define	STEP_MOVE			4
#define	STEP_MOVE_ENEMY	2
#define	STEP_MOVE_CLOUD	2
#define	STEP_MOVE_BG		1
#define	STEP_MOVE_MISSILE	2
#define	STEP_MOVE_ITEM		2
#define	MAX_ENEMY			100
#define	MAX_FLIGHTMISSILE	10
#define	MAX_MISSILE			30
#define	MAX_BG				5
#define	MAX_CLOUD			3

#define	SPEED_ENEMY_A	4
#define	SPEED_ENEMY_B	4
#define	SPEED_ENEMY_C	4
#define	SPEED_ENEMY_D	4
#define	SPEED_ENEMY_E	4
#define	SPEED_ENEMY_F	4
#define	SPEED_ENEMY_G	1
#define	SPEED_ENEMY_H	1
#define	SPEED_ENEMY_I	1
#define	SPEED_ENEMY_J	1
#define	SPEED_ENEMY_K	1
#define	SPEED_ENEMY_L	1
#define	SPEED_ENEMY_M	1
#define	SPEED_ENEMY_N	1
#define	SPEED_ENEMY_O	1
#define	SPEED_ENEMY_P	1
#define	SPEED_ENEMY_Q	1
#define	SPEED_ENEMY_R	1

#define	SPEED_MISSILE	15
#define	SP_E_MISSILE_0	4
#define	SP_E_MISSILE_1	4
#define	SP_E_MISSILE_2	5
#define	SP_E_MISSILE_3	7

#define	HP_ENEMY_A	10
#define	HP_ENEMY_B	20
#define	HP_ENEMY_C	20
#define	HP_ENEMY_D	10
#define	HP_ENEMY_E	10
#define	HP_ENEMY_F	30
#define	HP_ENEMY_G	100
#define	HP_ENEMY_H	70
#define	HP_ENEMY_I		70
#define	HP_ENEMY_J		50
#define	HP_ENEMY_K	300
#define	HP_ENEMY_L		300
#define	HP_ENEMY_M	700
#define	HP_ENEMY_N	200
#define	HP_ENEMY_O	1000
#define	HP_ENEMY_P	2200
#define	HP_ENEMY_Q	2400
#define	HP_ENEMY_R	3000

#define	SPEED_BG	2

#define	SPECIAL_TIME	100
#define	SPECIAL_POWER	8 

#define	BONUS_SCORE		10000	// every BONUS_SCORE, will give an extra craft.
#define	MAX_FLIGHT_LIFE	5	

#define GET_X(d,r)	(Cos100(d)*r/100)
#define GET_Y(d,r)	(Sin100(d)*r/100*(-1))

#define	STORY_LEN		35
#define	STORY_DELAY		50

#define SHOW_MISSION_TIME 30

// Game State
enum {
	GS_LOGO,
	GS_MENU,
	GS_OPTION,
	GS_MAP,
	GS_STORY,
	GS_RUN,
	GS_END,
	GS_ENDING,
	GS_PAUSE
};

// Pause State
enum {
	PS_MENU,
	PS_OPTION,
	PS_GAMEINFO,
	PS_KEYINFO,
	PS_END
};

// Event State
enum {
	ES_START,
	ES_KEYPRESS,
	ES_TIMEOUT,
	ES_END
};

// Flight State
enum {
	FS_GHOST,
	FS_ACTIVATE,
	FS_ATTACKED,
	FS_DIE
};

// Flight Direction
enum {
	FD_NONE,
	FD_LEFT,
	FD_RIGHT,
	FD_UP,
	FD_DOWN,
	FD_L_UP,
	FD_R_UP,
	FD_L_DOWN,
	FD_R_DOWN
};

enum {
	FALSE,
	TRUE
};

enum {
	IT_LIFE,
	IT_POWER,
	IT_SPECIAL
};

enum {
	A1_TYPE,
	B1_TYPE,
	B2_TYPE,
	B3_TYPE,
	B4_TYPE,
	B5_TYPE,
	C1_TYPE,
	C2_TYPE,
	C3_TYPE,
	C4_TYPE,
	D1_TYPE,
	D2_TYPE,
	D3_TYPE,
	D4_TYPE,
	E1_TYPE,
	E2_TYPE,
	E3_TYPE,
	E4_TYPE,
	F1_TYPE,
	F2_TYPE,
	F3_TYPE,
	G1_TYPE,
	H1_TYPE,
	H2_TYPE,
	H3_TYPE,
	I1_TYPE,
	I2_TYPE,
	I3_TYPE,
	J1_TYPE,
	K1_TYPE,
	L1_TYPE,
	M1_TYPE,
	N1_TYPE,
	O_TYPE,
	P_TYPE,
	Q_TYPE,
	R_TYPE
};

enum {
	snd1_1,
	snd1_2,
	snd1_3,
	snd1_4,
	snd1_5,
	snd2_1,
	snd2_2,
	snd4_1,
	snd4_2,
	snd4_3,
	snd4_4,
	snd5_1,
	snd5_2,
	snd6_1,
	snd6_2,
	snd6_3,
	snd6_4,
	snd7_4,
	snd8_1,
	snd8_2,
	snd8_3
};

const string HelpText[] = {
	"����2090��...     ",
	"                  ",
	"�η��� ���ο� ��ü",
	"�������ڿ��� �߰� ",
	"�� ���Ծ� ���ʾ���",
	"����������� �̷� ",
	"����.             ",
	"��ü�������� ���� ",
	"��Ĺ(WildCat)�̶� ",
	"�� �̸����� ������",
	"���� ������ ����",
	"���� �η������� ��",
	"�� �����߸� �� �� ",
	"���뿡��������.   ",
	"                  ",
	"������ �ڱ��� ����",
	"�� ���� ���ϵ�Ĺ��",
	"Ż���Ϸ��� �پ��� ",
	"���µ��� �����Ͽ� ",
	"��. �̸� �����ϰ� ",
	"�����ϱ� ���� Ư��",
	"�⵿������ ������ ",
	"�� �Ǿ��µ� �װ���",
	"���̿÷ν���� �� ",
	"������� ���� Ư��",
	"�������۱��̴�.   ",
	"                  ",
	"���ϵ�Ĺ�� Ż���� ",
	"���� ������κ��� ",
	"�����ϰ� ���ѳ��� ",
	"�������� ������ ��",
	"ȯ�ؾ��ϴ� ������ ",
	"���� ���⿡�� ����",
	"���� �Ƿ��� �����",
	"����.��           "
};
#define	END_TEXT_LEN	22

const string EndingText[] = {
	"'���ϵ� Ĺ'�� ��ȣ",
	"�� ���� ���� ���� ",
	"������ ���̿÷ν�.",
	"�ջ��� ���� ��ü��",
	"���� ������ ����",
	"������ ���� ����  ",
	"���ϵ� ���ư��� ��",
	"��.               ",
	"                  ",
	"ġ��...           ",
	"'����� ����������",
	"���̿÷ν�.       ",
	"�ӹ��Ϸ�.'        ",
	"ġ��...           ",
	"'����� ��Ÿ.     ",
	"��ǥ��?'          ",
	"'��ǥ�� �����ϴ�.'",
	"ġ��...           ",
	"'����� ��Ÿ. �ӹ�",
	"������ �����Ѵ�.  ",
	"��ȯ�϶�.'        ",
	"'���̿÷ν�.RTB!!'"
};

const string KeyText[] = {
	"�̵�",
	"�����(4,6,2,8)",
	"����: 5",
	"��ź: 0",
	"   ���Ϸ�Ʈ ���",
	"������ * ��ư"
};

const string MissionText[] = {
	"���ϵ� Ĺ",
	"Ʈ���� �����",
	"��ǳ������ ȸ��",
	"��ǳ�� �ٶ��� ��"
};
const int MissionTextIdx[4][4] = {
	{2,4,6,9},
	{2,6,9,13},
	{2,6,10,15},
	{2,6,13,16}
};

//////////////////////////////////////////
// --------- Global Var ----------
// Environment Var.
//////////////////////////////////////////
int	NVROM[NV_SIZE];
// 0: ó�� ���࿩��  (0, 2158)
// 1: EFFECT VOLUME (0 - 10)
// 2: BGM VOLUME    (0 - 10)
// 3: ��������       (0, 1)
// 4: �̾��ϱ� stage 0 - 4, -1�̸� �̾��ϱ� ����
// 5: �̾��ϱ� frame ������� ����� �κ��� frame
// 6: �̾��ϱ� flight �� (0 - 3)
// 7: �̾��ϱ� ���ݷ��� (0 - 4)
// 8: �̾��ϱ� �������� (0, 1, [2, 3])
// 9: �̾��ϱ� ����
// 10: High Score
// 11 : ���۽� ���� �ο�� toggle
// 12 - 15 : Reserved
int	temp1, temp2, temp3, temp4;
int	SoundInplay;

//////////////////////////////////////////
// --------- Global Var ----------
// Engine Var.
//////////////////////////////////////////
int	gGameState;
int	gPauseState;
int	gGameScore;
int	gGameVolumeFX;
int	gGameVolumeBGM;
int	gGameVibrator;	//���� ����
int	gCX;
int	gCY;

//////////////////////////////////////////
// --------- Global Var ----------
// Flight Var.
//////////////////////////////////////////
int	gFlightS;		// State of Flight
int	gFlightX;		// Position X of Flight
int	gFlightY;		// Position Y of Flight
int	gFlightD;		// Direction of Flight
int	gFlightC;
int	gFlightStep;	// Graphical Step
int	gFlightMT;		// Missile Type
int	gFlightLife;	// Number of Flight

int	gFlightMissileS[MAX_FLIGHTMISSILE];
int	gFlightMissileX[MAX_FLIGHTMISSILE];
int	gFlightMissileY[MAX_FLIGHTMISSILE];
int	gFlightMissileDX[MAX_FLIGHTMISSILE];
int	gFlightMissileDY[MAX_FLIGHTMISSILE];
int 	gFlightMissileT[MAX_FLIGHTMISSILE];
int 	gFlightMissileCount;
int 	gFlightShooting;

int	gMissileS[MAX_MISSILE];
int	gMissileX[MAX_MISSILE];
int	gMissileY[MAX_MISSILE];
int	gMissileDX[MAX_MISSILE];
int	gMissileDY[MAX_MISSILE];
int 	gMissileT[MAX_MISSILE];
int 	gMissileCount;

int 	gEnemyS[MAX_ENEMY];
int 	gEnemyX[MAX_ENEMY];
int 	gEnemyY[MAX_ENEMY];
int 	gEnemyDX[MAX_ENEMY];
int 	gEnemyDY[MAX_ENEMY];
int	gEnemyT[MAX_ENEMY];		// enemy type
int	gEnemyH[MAX_ENEMY];		// enemy health
int	gEnemyC[MAX_ENEMY];
int	gEnemyCount;

int	gBGS[MAX_BG];
int	gBGX[MAX_BG];
int	gBGY[MAX_BG];
int	gBGT[MAX_BG];
int	gBGCount;

int	gCloudS[MAX_CLOUD];
int	gCloudX[MAX_CLOUD];
int	gCloudY[MAX_CLOUD];
int	gCloudDY[MAX_CLOUD];
int	gCloudT[MAX_CLOUD];
int	gCloudCount;

int	gItemS;
int	gItemX;
int	gItemY;
int	gItemT;

int	gBossState; // boss ����. 0: ���� �ƴ�, 1: ���ʹ��� 2: �ι�° ����....
int	gLogoCount;
int	gMenuCount;
int	gMapCount;
int	gOverCount;
int	gStage;
int	gStageFrame; 	// �� stage�� �������� frmae
int	gEnemyIndex;	// ������ index
int	gSpecial;		// Ư������
int	gSilentMode;	// silent mode
int	gSpecialCount;	// ��ź ����
int	gBonusFlag;

int	NOFPS;//Frame/Sec�� ���� ����?
int	gCannonDir1[16] = {10,11,12,13,14,13,12,11,10,9,8,7,6,7,8,9};//������ ��~~ �����뺯��
int	gMissileDegree[16] ={270,293,315,337,0,23,45,67,90,113,135,157,180,203,225,247};

int	gOptionIdx;
int	gPauseIdx;

int	gMenuIdx;
int	gMenuX;
int	gMenuDrawStep;
int	gSubIdx;
int	gSubCount;
int	gSubPage;

int	FontCount, WaitCount;
int	StoryLine, StoryPage, MaxStoryLine;


string gOutStr;

void main()
{
	NOFPS = 1;
	SetStartTime();

	SetBackLight(S_ON);

	gCX = swWidth / 2;
	gCY = swHeight / 2;
	gGameState = GS_LOGO;
	gPauseState= PS_MENU;
	SoundInplay = 0;
	gSilentMode = 0;
	gSpecialCount = 0;

	ReadRom();

	GameLogo(ES_START, swData);

	SetTimer(50, 1);

	#ifdef DEBUG
	//GameRun(ES_START, swData);
	#endif
}

void ReadRom()
{
	GetBytes(swRsRcvBuf, 0, gOutStr, 32);

	GetUserNV(NVROM, NV_SIZE);

	if (NVROM[0]!=2158) { // ���� �����̸�...
		ArrayToVar(NVROM, 0, 16, S_OP_SET);

		NVROM[0] = 2158;
		NVROM[1] = 5;	//EFX Volume�� 5��...
		NVROM[2] = 0;	//BGM Volume�� 0����..
		NVROM[3] = 1;	//������ on����.
		NVROM[4] = 0; //�̾��ϱ� stage
		NVROM[5] = 0;
	}

	gGameVolumeFX = NVROM[1];
	gGameVolumeBGM = NVROM[2];
	gGameVibrator = NVROM[3];
	// �� ������ ������ assign
	NVROM[6] ^= 1;	// ���۽� ���� ���� ����

	SetVolume((gGameVolumeFX ? gGameVolumeFX : gGameVolumeBGM));

	PutUserNV(NVROM, NV_SIZE);
}

void WriteRom()
{
	NVROM[0] = 2158;
	NVROM[1] = gGameVolumeFX;
	NVROM[2] = gGameVolumeBGM;
	NVROM[3] = gGameVibrator;

	PutUserNV(NVROM, NV_SIZE);
}

void EVENT_KEYPRESS()
{

	#ifdef DEBUG
	if (swData==SWAP_KEY_SND) {
		NOFPS = !NOFPS;
		SetStartTime();
	}
	#endif

	switch(gGameState)
	{
	case GS_LOGO:
		GameLogo(ES_KEYPRESS, swData);
		break;
	case GS_MENU:
		GameMenu(ES_KEYPRESS, swData);
		break;
	case GS_OPTION:
		GameOption(ES_KEYPRESS, swData);
		break;
	case GS_MAP:
		GameMap(ES_KEYPRESS, swData);
		break;
	case GS_STORY:
		GameStory(ES_KEYPRESS, swData);
		break;
	case GS_RUN:
		GameRun(ES_KEYPRESS, swData);
		break;
	case GS_ENDING:
		GameEnding(ES_KEYPRESS, swData);
		break;
	case GS_PAUSE:
		switch(gPauseState)
		{
		case PS_MENU:
			PauseMenu(ES_KEYPRESS, swData);
			break;
		case PS_OPTION:
			PauseOption(ES_KEYPRESS, swData);
			break;
		case PS_GAMEINFO:
			PauseGameinfo(ES_KEYPRESS, swData);
			break;
		case PS_KEYINFO:
			PauseKeyinfo(ES_KEYPRESS, swData);
			break;
		}

		break;
	}
}

void EVENT_TIMEOUT()
{
	switch(swData){
	case 0:
		switch(gGameState)
		{
		case GS_LOGO:
			GameLogo(ES_TIMEOUT, swData);
			break;
		case GS_MENU:
			GameMenu(ES_TIMEOUT, swData);
			break;
		case GS_OPTION:
			GameOption(ES_TIMEOUT, swData);
			break;
		case GS_MAP:
			GameMap(ES_TIMEOUT, swData);
			break;
		case GS_STORY:
			GameStory(ES_TIMEOUT, swData);
			break;
		case GS_RUN:
			GameRun(ES_TIMEOUT, swData);
			break;
		case GS_ENDING:
			GameEnding(ES_TIMEOUT, swData);
			break;
		}
		Flush();
		break;
	case 1:
		switch(gPauseState)
		{
		case PS_MENU:
			PauseMenu(ES_TIMEOUT, swData);
			break;
		case PS_OPTION:
			PauseOption(ES_TIMEOUT, swData);
			break;
		case PS_GAMEINFO:
			PauseGameinfo(ES_TIMEOUT, swData);
			break;
		case PS_KEYINFO:
			PauseKeyinfo(ES_TIMEOUT, swData);
			break;
		}
		Flush();
	
		break;

	case 2:
		StopVib();
		break;
	}

}

void EVENT_RESULT()
{
	if (swData==S_RST_SOUND_END)
		SoundInplay = 0;
}

void EVENT_END()
{
	WriteRom();
}

void PauseMenu(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gPauseState	= PS_MENU;
		gPauseIdx	= 0;

		ClearRGB(38, 43, 83);
		for (temp1=0; temp1<20; temp1++)
			CopyImage(gCX, gCY, imgMenu[temp1]);
		for (temp1=0; temp1<7; temp1++)
			CopyImageDir(gCX, gCY, imgMenu[temp1], 1);

		CopyImageEx(gCX-44, gCY-48, imgMenu[27], S_VDI_ALPHA_50PCT, 0, 0, 0);
		SetClip(gCX-26, 0, swWidth, swHeight);
		CopyImageEx(gCX-15, gCY-41, imgMenu[38], S_VDI_ALPHA_50PCT, 0, 0, 0);
		ResetClip();

		CopyImageTile(imgMenu[46], gCX-55, gCY-27, gCX+54, gCY+62, S_VDI_ALPHA_25PCT, 0, 0, 0);
		CopyImageEx(gCX-55, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_0);
		CopyImageEx(gCX+54, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_0);
		CopyImageEx(gCX-55, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_180);
		CopyImageEx(gCX+54, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_180);
		SaveLCD();
		break;
	case ES_KEYPRESS:
		switch(data)
		{
		case SWAP_KEY_OK:
		case SWAP_KEY_CLR:
		case SWAP_KEY_5:
			switch(gPauseIdx){
			case 0:
				ResetTimer1();
				gGameState = GS_RUN;
				SaveBG();
				SetTimer(50, 1);
				break;
			case 1:
				PauseOption(ES_START,data);
				break;
			case 2:
				PauseGameinfo(ES_START,data);
				break;
			case 3:
				PauseKeyinfo(ES_START,data);
				break;
			case 4://��������
				ResetTimer1();
				SetTimer(50, 1);
				GameLogo(ES_START,data);
				break;

			}
			break;
		case SWAP_KEY_UP:
			gPauseIdx = (gPauseIdx+4)%5;
			break;
		case SWAP_KEY_DOWN:
			gPauseIdx = (gPauseIdx+1)%5;
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawPauseMenu();
		break;
	case ES_END:
		break;
	}
}

void PauseOption(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gPauseState	= PS_OPTION;
		gOptionIdx	= 0;
		gMenuCount = 0;
		DrawPauseOption();
		break;
	case ES_KEYPRESS:
		switch(data)
		{
		case SWAP_KEY_OK:
		case SWAP_KEY_CLR:
		case SWAP_KEY_5:
			//rom save�ϰ� ������
			WriteRom();
			PauseMenu(ES_START, 0);
			gPauseIdx = 1;
			break;
		case SWAP_KEY_UP:
			gOptionIdx = (gOptionIdx + 2) % 3;
			if (gOptionIdx==0) {
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
			}
			else if (gOptionIdx==1) {
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
			}
			else
				StopSound();
			break;
		case SWAP_KEY_DOWN:
			gOptionIdx = (gOptionIdx + 1) % 3;
			if (gOptionIdx==0) {
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
			}
			else if (gOptionIdx==1) {
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
			}
			else
				StopSound();
			break;
		case SWAP_KEY_LEFT:
		case SWAP_KEY_1:
		case SWAP_KEY_4:
		case SWAP_KEY_7:
			if (gOptionIdx==0) {
				if (gGameVolumeFX>0)
					gGameVolumeFX -= 2;
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
			}
			else if (gOptionIdx==1) {
				if (gGameVolumeBGM>0)
					gGameVolumeBGM -= 2;
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
			}
			else {
				gGameVibrator ^= 1;
			}
			break;
		case SWAP_KEY_RIGHT:
		case SWAP_KEY_3:
		case SWAP_KEY_6:
		case SWAP_KEY_9:
			if (gOptionIdx==0) {
				if (gGameVolumeFX<10)
					gGameVolumeFX += 2;
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
				gGameVolumeBGM = 0;
			}
			else if (gOptionIdx==1) {
				if (gGameVolumeBGM<10)
					gGameVolumeBGM += 2;
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
				gGameVolumeFX = 0;
			}
			else {
				gGameVibrator ^= 1;
			}
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawPauseOption();
		break;
	case ES_END:
		break;
	}
}

void PauseGameinfo(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gPauseState	= PS_GAMEINFO;
		gMenuIdx	= 0;
		gMenuX		= 0;
		gMenuDrawStep	= 0;
		gMenuCount = 0;
		gSubIdx = 0;
		gSubCount = 0;
		gSubPage = 0;

		Play_Sound(snd2_1);
		DrawPauseGameinfo();
		break;
	case ES_KEYPRESS:
		switch(data)
		{
		case SWAP_KEY_OK:
		case SWAP_KEY_5:
		case SWAP_KEY_CLR:
			PauseMenu(ES_START, 0);
			gPauseIdx = 2;
			break;
		case SWAP_KEY_LEFT:
			if(gSubPage > 0)
				gSubPage--;
			break;
		case SWAP_KEY_RIGHT:
			if(gSubPage < 6)
				gSubPage++;
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawPauseGameinfo();
		break;
	case ES_END:
		break;
	}
}

void PauseKeyinfo(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gPauseState	= PS_KEYINFO;
		Play_Sound(snd2_1);
		DrawPauseKeyinfo();
		break;
	case ES_KEYPRESS:
		switch(data)
		{
		case SWAP_KEY_OK:
		case SWAP_KEY_5:
		case SWAP_KEY_CLR:
			PauseMenu(ES_START, 0);
			gPauseIdx = 3;
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawPauseKeyinfo();
		break;
	case ES_END:
		break;
	}
}

void DrawPauseMenu()
{
	RestoreLCD();

	CopyImageTile(imgMenu[48], gCX-51, gCY-21+(16*gPauseIdx), gCX+50, gCY-21+12+(16*gPauseIdx), S_VDI_ALPHA_50PCT, 0, 0, 0);
	SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
	DrawStr(gCX-37, gCY-20, "1. ���Ӻ���");
	DrawStr(gCX-37, gCY-20+16, "2. ȯ�漳��");
	DrawStr(gCX-37, gCY-20+32, "3. ���Ӽ���");
	DrawStr(gCX-37, gCY-20+48, "4. Ű����");
	DrawStr(gCX-37, gCY-20+64, "5. ��������");

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif
}
void DrawPauseOption()
{
	if (gMenuCount<3) {
		if (gMenuCount==0) {
			ClearRGB(38, 43, 83);
			for (temp1=0; temp1<20; temp1++)
				CopyImage(gCX, gCY, imgMenu[temp1]);
			for (temp1=0; temp1<7; temp1++)
				CopyImageDir(gCX, gCY, imgMenu[temp1], 1);
		}

		CopyImageTile(imgMenu[46], gCX-55, gCY-27, gCX+54, gCY+62, S_VDI_ALPHA_25PCT, 0, 0, 0);
		CopyImageEx(gCX-55, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_0);
		CopyImageEx(gCX+54, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_0);
		CopyImageEx(gCX-55, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_180);
		CopyImageEx(gCX+54, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_180);

		if (gMenuCount==2)
			temp1 = S_VDI_OPAQUE;
		else
			temp1 = S_VDI_ALPHA_50PCT;

		CopyImageEx(gCX-44, gCY-48, imgMenu[28], temp1, 0, 0, 0);
		SetClip(gCX-26, 0, swWidth, swHeight);
		CopyImageEx(gCX-3, gCY-41, imgMenu[39], temp1, 0, 0, 0);
		ResetClip();

		if (gMenuCount==2)
			SaveLCD();
	}
	else
		RestoreLCD();

	SetGamma(3);
	CopyImage(gCX-46, gCY-18, imgMenu[52]);
	CopyImage(gCX-46, gCY+5, imgMenu[53]);
	CopyImage(gCX-46, gCY+28, imgMenu[54]);
	
	SetGamma(0);
	switch (gOptionIdx) {
	case 0:
		CopyImage(gCX-46, gCY-18, imgMenu[52]);
		break;
	case 1:
		CopyImage(gCX-46, gCY+5, imgMenu[53]);
		break;
	case 2:
		CopyImage(gCX-46, gCY+28, imgMenu[54]);
		break;
	}
	SetGamma(3);

	CopyImage(gCX-21, gCY-14, imgMenu[56]);
	for (temp1=0; temp1<4; temp1++)
		CopyImage(gCX-9+temp1*12, gCY-14, imgMenu[57]);

	CopyImage(gCX-21, gCY+9, imgMenu[56]);
	for (temp1=0; temp1<4; temp1++)
		CopyImage(gCX-9+temp1*12, gCY+9, imgMenu[57]);

	CopyImage(gCX-21, gCY+37, imgMenu[56]);
	CopyImage(gCX-9, gCY+37, imgMenu[57]);
	CopyImage(gCX-21, gCY+29, imgMenu[63]);

	CopyImageEx(gCX+13, gCY+50, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_0);
	CopyImageEx(gCX+25, gCY+58, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_180);
	CopyImageEx(gCX+38, gCY+53, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_90);
	CopyImageEx(gCX+42, gCY+57, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_270);

	for (temp1=0; temp1<gGameVolumeFX/2; temp1++)
		CopyImage(gCX-21+temp1*12, gCY-14, imgMenu[58+temp1]);
	for (temp1=0; temp1<gGameVolumeBGM/2; temp1++)
		CopyImage(gCX-21+temp1*12, gCY+9, imgMenu[58+temp1]);
	CopyImage(gCX-9-gGameVibrator*12, gCY+37, imgMenu[58]);
	
	gMenuCount++;

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif

	
}

void DrawPauseGameinfo()
{
	RestoreLCD();

	if (gSubPage!=0)
		CopyImageDir(gCX-52, gCY+51, imgMenu[50], 0);
	if (gSubPage!=6)
		CopyImageDir(gCX+52, gCY+51, imgMenu[50], 1);

	SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
	for (temp1=0; temp1<5; temp1++)
		DrawStr(gCX-53, gCY-25+15*temp1, HelpText[gSubPage*5+temp1]);

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif


	
}
void DrawPauseKeyinfo()
{
	RestoreLCD();
	SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
	for (temp1=0; temp1<6; temp1++)
		DrawStr(gCX-53, gCY-25+15*temp1, KeyText[temp1]);

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif
	
}
void GameEnding(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gStage = 0;
		gLogoCount = 0;
		gGameState	= GS_ENDING;
//		SaveEnding();
		InitBG();
		InitCloud();

		DrawGameEnding();
		DrawCloud();
		break;
	case ES_KEYPRESS:
		GameLogo(ES_START, 0);
		break;
	case ES_TIMEOUT:
		ActivateBG();
		ActivateCloud();
		MoveBG();
		MoveCloud();
		DrawBackGround();
		DrawGameEnding();
		DrawCloud();
		
		break;
	case ES_END:
		break;
	}
}

void GameLogo(int event, int data)
{
	switch(event) {
	case ES_START:
		gLogoCount = 0;
		gGameState = GS_LOGO;
		DrawGameLogo();
		break;
	case ES_KEYPRESS:
		switch(data) {
		case SWAP_KEY_OK:
		case SWAP_KEY_5:
			GameMenu(ES_START, 0);
			break;
		}
		break;
	case ES_TIMEOUT:
		gLogoCount++;
		if (gLogoCount==15) {
			if (NVROM[11])
				PlaySound(sound1_3);
			else
				PlaySound(sound1_2);
		}
		else if (gLogoCount==40)
			PlaySound(sound1_1);
		DrawGameLogo();
		break;
	case ES_END:
		break;
	}
}


void GameMenu(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gGameState	= GS_MENU;
		gMenuIdx	= 0;
		gMenuX		= 0;
		gMenuDrawStep	= 0;
		gMenuCount = 0;
		gSubIdx = 0;
		gSubCount = 0;
		gSubPage = 0;

		Play_Sound(snd2_1);
		DrawGameMenu();
		break;
	case ES_KEYPRESS:
		switch(data)
		{
		case SWAP_KEY_OK:
		case SWAP_KEY_5:
			switch(gMenuIdx)
			{
			case 0:
				gStage = 0;
				gStageFrame = 0;
				GameStory(ES_START, 0);
				break;
			case 1:
				if (NVROM[4]>0) {
					gStage = NVROM[4];
	
					gOverCount = 0;
					gFlightLife = 3;
					gGameScore = 0;
					gSpecialCount = 3;
					gBonusFlag = 0;
	
					GameMap(ES_START, 0);
				}
				break;
			case 2:
				if (gSubIdx==0)
					gSubIdx = 1;
				else if (gSubIdx==2)
					gSubPage = 1;
				else if (gSubIdx==3)
					gSubPage = 1;
				break;
			case 3:
				gMenuCount = 0;
				GameOption(ES_START, 0);
				break;
			}
			break;
		case SWAP_KEY_CLR:
			if (gMenuIdx==2) {
				if (gSubPage>0) {
					gSubPage = 0;
				}
				else {
					gSubIdx = 0;
					GameMenu(ES_START, 0);
					gMenuIdx = 2;
				}
			}
			break;
		case SWAP_KEY_LEFT:
		case SWAP_KEY_UP:
			if (gSubIdx==0) {
				gMenuIdx = (gMenuIdx + 4) % 5;
				Play_Sound(snd2_1);
			}
			else {
				if (gSubPage==0) {
					if (gMenuIdx==2) {
						if (gSubIdx==2)
							gSubIdx = 3;
						else if (gSubIdx==3)
							gSubIdx = 2;
					}
					else if (gMenuIdx==3)
						gSubIdx = 2;//�ƴϴ�.
				}
				else {
					if (gSubPage>1)
						gSubPage--;
				}
			}
			break;
		case SWAP_KEY_RIGHT:
		case SWAP_KEY_DOWN:
			if (gSubIdx==0) {
				gMenuIdx = (gMenuIdx + 1) % 5;
				Play_Sound(snd2_1);
			}
			else {
				if (gSubPage==0) {
					if (gMenuIdx==2) {
						if (gSubIdx==2)
							gSubIdx = 3;
						else if (gSubIdx==3)
							gSubIdx = 2;
					}
					else if (gMenuIdx==3)
						gSubIdx = 2;//�ƴϴ�.
				}
				else {
					if (gSubPage<7)
						gSubPage++;
				}
			}
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawGameMenu();
		if (gSubIdx==1)
			gSubCount++;

		break;
	case ES_END:
		break;
	}
}



void GameOption(int event, int data)
{
	switch(event)
	{
	case ES_START:
		gGameState	= GS_OPTION;
		gOptionIdx	= 0;
		DrawGameOption();
		break;
	case ES_KEYPRESS:
		switch(data)
		{
		case SWAP_KEY_OK:
		case SWAP_KEY_CLR:
		case SWAP_KEY_5:
			//rom save�ϰ� ������
			WriteRom();
			GameMenu(ES_START, 0);
			gMenuIdx = 3;
			break;
		case SWAP_KEY_UP:
			gOptionIdx = (gOptionIdx + 2) % 3;
			if (gOptionIdx==0) {
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
			}
			else if (gOptionIdx==1) {
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
			}
			else
				StopSound();
			break;
		case SWAP_KEY_DOWN:
			gOptionIdx = (gOptionIdx + 1) % 3;
			if (gOptionIdx==0) {
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
			}
			else if (gOptionIdx==1) {
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
			}
			else
				StopSound();
			break;
		case SWAP_KEY_LEFT:
		case SWAP_KEY_1:
		case SWAP_KEY_4:
		case SWAP_KEY_7:
			if (gOptionIdx==0) {
				if (gGameVolumeFX>0)
					gGameVolumeFX -= 2;
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
			}
			else if (gOptionIdx==1) {
				if (gGameVolumeBGM>0)
					gGameVolumeBGM -= 2;
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
			}
			else {
				gGameVibrator ^= 1;
			}
			break;
		case SWAP_KEY_RIGHT:
		case SWAP_KEY_3:
		case SWAP_KEY_6:
		case SWAP_KEY_9:
			if (gOptionIdx==0) {
				if (gGameVolumeFX<10)
					gGameVolumeFX += 2;
				SetVolume(gGameVolumeFX);
				PlaySound(sound2_1);
				gGameVolumeBGM = 0;
			}
			else if (gOptionIdx==1) {
				if (gGameVolumeBGM<10)
					gGameVolumeBGM += 2;
				SetVolume(gGameVolumeBGM);
				PlaySound(sound2_2);
				gGameVolumeFX = 0;
			}
			else {
				gGameVibrator ^= 1;
			}
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawGameOption();
		break;
	case ES_END:
		break;
	}
}

void GameMap(int event, int data)
{
	switch(event) {
	case ES_START:
		gMapCount = 0;
		gGameState = GS_MAP;
		//if (gStageFrame>99999)
//			Play_Sound(snd5_1);
		break;
	case ES_KEYPRESS:
		switch(data) {
		case SWAP_KEY_OK:
		case SWAP_KEY_5:
			if(gMapCount<SHOW_MISSION_TIME)
				gMapCount=SHOW_MISSION_TIME;
			else
				GameRun(ES_START, 0);
				
			break;
		}
		break;
	case ES_TIMEOUT:
		DrawGameMap();
		gMapCount++;
		break;
	case ES_END:
		break;
	}
}

void GameStory(int event, int data)
{
	switch(event) {
	case ES_START:
		FontCount = 0;
		WaitCount = 0;
		StoryLine = 0;
		StoryPage = 0;
		MaxStoryLine = (swHeight-16)/15;
		gGameState = GS_STORY;
		break;
	case ES_KEYPRESS:
		switch(data) {
		case SWAP_KEY_OK:
		case SWAP_KEY_5:
			GameMap(ES_START, 0);
			break;
		}
		break;
	case ES_TIMEOUT:
		if(WaitCount == -1)
			GameMap(ES_START, 0);
		else
			DrawGameStory();
		
		break;
	case ES_END:
		break;
	}
}

void GameRun(int event, int data)
{
	switch(event) {
	case ES_START:
		gGameState = GS_RUN;

		InitStage();
		InitBG();
		InitCloud();
		InitFlight();
		InitEnemy();
		InitMissile();
		InitFlightMissile();
		InitItem();
		if (gGameVolumeBGM>0)
			Play_Sound(snd1_1);
		DrawGameRun();
		break;

	case ES_KEYPRESS:
		if (swData==SWAP_KEY_STAR) {
			gSilentMode ^= 1;
			if (gSilentMode)
				StopSound();
		}

		// stage ���۽� ó��
		if (gStageFrame<60)
			return;

		switch(data) {
		case SWAP_KEY_RELEASE:
			gFlightStep = 0;
			gFlightD = FD_NONE;
			break;
		case SWAP_KEY_LEFT:
		case SWAP_KEY_4:
			gFlightD = FD_LEFT;
			gFlightStep++;
			break;
		case SWAP_KEY_RIGHT:
		case SWAP_KEY_6:
			gFlightD = FD_RIGHT;
			gFlightStep++;
			break;
		case SWAP_KEY_UP:
		case SWAP_KEY_2:
			gFlightD = FD_UP;
			gFlightStep = 0;
			break;
		case SWAP_KEY_DOWN:
		case SWAP_KEY_8:
			gFlightD = FD_DOWN;
			gFlightStep = 0;
			break;
		case SWAP_KEY_1:
			gFlightD = FD_L_UP;
			gFlightStep++;
			break;
		case SWAP_KEY_3:
			gFlightD = FD_R_UP;
			gFlightStep++;
			break;
		case SWAP_KEY_7:
			gFlightD = FD_L_DOWN;
			gFlightStep++;
			break;
		case SWAP_KEY_9:
			gFlightD = FD_R_DOWN;
			gFlightStep++;
			break;

		case SWAP_KEY_0:
			if (gSpecialCount>0 && gSpecial==0) {
				gSpecialCount--;
				gSpecial = SPECIAL_TIME;
			}

			break;

		case SWAP_KEY_OK:
		case SWAP_KEY_5:
			if (gOverCount==0) {
				gFlightShooting ^= 1;	// toggle shooting
				if (gFlightShooting)
					Play_Sound(snd7_4);
				else {
					if (gGameVolumeBGM==0)
						StopSound();
				}
			}
			break;
		case SWAP_KEY_CLR://����޴� ȣ�� 
//			gPauseState= PS_MENU;
			ResetTimer();
			gGameState= GS_PAUSE;
			PauseMenu(ES_START,data);
			SetTimer1(50, 1);
			break;
		}
		// FS_DIE������ �������� ���Ѵ�.
		if (gFlightS == FS_DIE || (gFlightS == FS_GHOST && gFlightC < 15)) {
			gFlightStep = 0;
			gFlightD = FD_NONE;
		}

//		DrawGameRun();
		break;

	case ES_TIMEOUT:
		ActivateBG();
		ActivateCloud();
		ActivateEnemyPre();
		if (gFlightShooting && swFrame2 == 0 && gFlightS != FS_DIE)
			ActivateFlightMissile();
		MoveBG();
		MoveCloud();
		MoveEnemy();
		MoveMissile();
		MoveFlightMissile();
		MoveItem();
		if (gOverCount==0)
			MoveFlight(gFlightD);

		DrawGameRun();

		gStageFrame++;

		if (gOverCount>0)
			gOverCount++;
		if (gOverCount>180) {
			gStageFrame = 0;
			GameMenu(ES_START, 0);
		}
		break;
	}
}

void Play_Sound(int sound_num)
{
	// Silent Mode�� ���, ��&���� off��Ų��
	if (gSilentMode)
		return;

	// BGMó��
	if (gGameVolumeBGM>0 && sound_num==snd2_2)
		PlaySound(sound2_2);

	if (sound_num==-1) {
		if (gGameVibrator) {
			StartVib(1);
			SetTimer2(200, 0);
		}
		return;
	}

	if (gGameState==GS_RUN && gGameVolumeFX==0)
		return;

	switch (sound_num) {
		case snd1_1:
			PlaySound(sound1_1);
			break;
		case snd1_2:
			PlaySound(sound1_2);
			break;
		case snd1_3:
			PlaySound(sound1_3);
			break;
		case snd1_4:
			PlaySound(sound1_4);
			break;
		case snd1_5:
			PlaySound(sound1_5);
			break;
		case snd2_1:
			PlaySound(sound2_1);
			break;
		case snd2_2:
			PlaySound(sound2_2);
			break;
		case snd4_1:
			PlaySound(sound4_1);
			break;
		case snd4_2:
			PlaySound(sound4_2);
			break;
		case snd4_3:
			PlaySound(sound4_3);
			break;
		case snd4_4:
			PlaySound(sound4_4);
			break;
		case snd5_1:
			PlaySound(sound5_1);
			break;
		case snd5_2:
			PlaySound(sound5_2);
			break;
		case snd6_1:
			PlaySound(sound6_1);
			break;
		case snd6_2:
			PlaySound(sound6_2);
			break;
		case snd6_3:
			PlaySound(sound6_3);
			break;
		case snd6_4:
			PlaySound(sound6_4);
			break;
		case snd7_4:
			PlaySound(sound7_4);
			break;
		case snd8_1:
			PlaySound(sound8_1);
			break;
		case snd8_2:
			PlaySound(sound8_2);
			break;
		case snd8_3:
			PlaySound(sound8_3);
			break;
	}
	SoundInplay = 1;
}

/////////////////////////////////////////////////////////////////////////////
// Initialize Functions
/////////////////////////////////////////////////////////////////////////////

void InitFlight()
{
	// Flight Setting
	gFlightS		= FS_ACTIVATE;
	gFlightX		= gCX;
	gFlightY		= swHeight+40;
	gFlightC		= 0;
	gFlightStep		= 0;
	gFlightShooting	= FALSE;

	if (gStage == 0)
		gFlightMT = 0;
}

void InitEnemy()
{
	int i;

	gEnemyCount = 0;

	for (i = 0; i < MAX_ENEMY; i++)
	{
		gEnemyS[i]	= FS_GHOST;
		gEnemyX[i]	= 0;
		gEnemyY[i]	= 0;
		gEnemyDX[i]	= 0;
		gEnemyDY[i]	= 0;
		gEnemyT[i]	= 0;
		gEnemyH[i]	= 0;
		gEnemyC[i]	= 0;
	}
}

void InitFlightMissile()
{
	int i;

	gFlightMissileCount	= 0;

	for (i = 0; i < MAX_FLIGHTMISSILE; i++)
	{
		gFlightMissileS[i]	= FS_GHOST;
		gFlightMissileX[i]	= 0;
		gFlightMissileY[i]	= 0;
		gFlightMissileDX[i]	= 0;
		gFlightMissileDY[i]	= 0;
		gFlightMissileT[i]	= 0;
	}
}

void InitMissile()
{
	int i;

	gMissileCount	= 0;

	for (i = 0; i < MAX_MISSILE; i++)
	{
		gMissileS[i]	= FS_GHOST;
		gMissileX[i]	= 0;
		gMissileY[i]	= 0;
		gMissileDX[i]	= 0;
		gMissileDY[i]	= 0;
		gMissileT[i]	= 0;
	}
}

void InitBG()
{
	int i;

	gBGCount = 3;

	for (i = 0; i < MAX_BG; i++)
	{
		gBGS[i]		= FS_GHOST;
		gBGX[i]		= 0;
		gBGY[i]		= 0;
		gBGT[i]		= 0;
	}

	gBGS[0]		= FS_ACTIVATE;
	gBGT[0]		= 4;
	gBGX[0]		= 0;
	gBGY[0]		= swHeight-60;

	gBGS[1]		= FS_ACTIVATE;
	gBGT[1]		= 3;
	gBGX[1]		= swWidth-20;
	gBGY[1]		= swHeight-80;

	gBGS[2]		= FS_ACTIVATE;
	gBGT[2]		= 2;
	gBGX[2]		= 40;
	gBGY[2]		= swHeight-110;

	SetActiveBuffer(1);
	switch (gStage) {
	case 0:
		CopyImageTile(imgBG1[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	case 1:
		CopyImageTile(imgBG2[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	case 2:
		CopyImageTile(imgBG3[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	case 3:
		CopyImageTile(imgBG4[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	}
	SetActiveBuffer(0);
}

void SaveBG()
{
	SetActiveBuffer(1);
	switch (gStage) {
	case 0:
		CopyImageTile(imgBG1[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	case 1:
		CopyImageTile(imgBG2[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	case 2:
		CopyImageTile(imgBG3[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	case 3:
		CopyImageTile(imgBG4[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
		break;
	}
	SetActiveBuffer(0);
}

void InitCloud()
{
	int i;

	gCloudCount = 2;

	for (i = 0; i < MAX_CLOUD; i++)
	{
		gCloudS[i]		= FS_GHOST;
		gCloudX[i]		= 0;
		gCloudY[i]		= 0;
		gCloudT[i]		= 0;
		gCloudDY[i]		= 0;
	}

	gCloudS[0]		= FS_ACTIVATE;
	gCloudT[0]		= Rand(0, 3);
	gCloudX[0]		= Rand(0, swWidth);
	gCloudY[0]		= Rand(0, swHeight);
	gCloudDY[0]		= Rand(3, 6);

	gCloudS[1]		= FS_ACTIVATE;
	gCloudT[1]		= Rand(0, 3);
	gCloudX[1]		= Rand(0, swWidth);
	gCloudY[1]		= Rand(0, swHeight);
	gCloudDY[1]		= Rand(3, 7);
}

void InitItem()
{
	gItemS = FS_GHOST;
	gItemX = 0;
	gItemY = 0;
	gItemT = IT_POWER;
}

void InitStage()
{
	if (gStage == 0) {
		gOverCount = 0;
		gFlightLife = 3;
		gGameScore = 0;
		gSpecialCount = 3;
		gBonusFlag = 0;
	}

	gBossState = 0;
	gStageFrame = 0;

	// ���������� ����(!)�� stage�� �����Ѵ�.
	NVROM[4] = gStage;
	WriteRom();

	InitActive();
}

/////////////////////////////////////////////////////////////////////////////
// Manipulate Functions
/////////////////////////////////////////////////////////////////////////////
void ActivateBG()
{
	int i;

	for (i = 0; i < MAX_ENEMY; i++)
		if ((gEnemyS[i]==FS_ACTIVATE || gEnemyS[i]==FS_ATTACKED) &&
		  (gEnemyT[i]==H1_TYPE || gEnemyT[i]==H2_TYPE || gEnemyT[i]==H3_TYPE ||
			gEnemyT[i]==I1_TYPE || gEnemyT[i]==I2_TYPE || gEnemyT[i]==I3_TYPE ||
			gEnemyT[i]==J1_TYPE || gEnemyT[i]==K1_TYPE || gEnemyT[i]==M1_TYPE ||
			gEnemyT[i]==O_TYPE || gEnemyT[i]==Q_TYPE))
			return;

	for (i = 0; i < MAX_BG; i++)
	{
		if (gBGCount > 3)	break;
		if (gBGS[i] == FS_GHOST)
		{
			gBGS[i]	= FS_ACTIVATE;

			switch (gStage) {
			case 0: // stage 1
				gBGT[i]	= Rand(1, 5);
	
				switch(gBGT[i]) {
				case 1:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -30;
					break;
				case 2:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -30;
					break;
				case 3:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -30;
					break;
				case 4:
					if (RandRatio(50))
						gBGX[i]		= Rand(swWidth-1, swWidth*3/2);
					else
						gBGX[i]		= Rand(-swWidth/2, 0);
					gBGY[i]		= -30;
					break;
				}
				break;
			case 1: // stage 2
				// 4 type(����)�� ��� i �� 0�϶��� ���(���ϴ� layer)
				if (i==0)
					gBGT[i]	= Rand(1, 5);
				else
					gBGT[i]	= Rand(1, 4);

				switch(gBGT[i]) {
				case 1:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -50;
					break;
				case 2:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -50;
					break;
				case 3:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -50;
					break;
				case 4:
					gBGX[i]		= gCX+Rand(-20, 20);
					gBGY[i]		= -50;
					break;
				}
				break;
			case 2: // stage 3
				// 1, 2 type(���ƽý�)�� ��� i �� 0�϶��� ���(���ϴ� layer)
				if (i==0)
					gBGT[i]	= Rand(1, 4);
				else
					gBGT[i]	= Rand(3, 4);

				switch(gBGT[i]) {
				case 1:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -50;
					break;
				case 2:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -50;
					break;
				case 3:
					gBGX[i]		= Rand(-20, swWidth+20);
					gBGY[i]		= -50;
					break;
				}
				break;
			case 3: // stage 4
				gBGT[i] = Rand(1, 4);
				gBGX[i] = Rand(-20, swWidth+20);
				gBGY[i] = -50;
				break;
			}
			gBGCount++;
			break;
		}
	}
}
void ActivateCloud()
{
	int i;

	for (i = 0; i < MAX_CLOUD; i++)
	{
		if (gCloudCount > 3)	break;
		if (gCloudS[i] == FS_GHOST)
		{
			gCloudS[i]	= FS_ACTIVATE;
			gCloudY[i]	= -30;
			gCloudT[i]	= Rand(0, 3);

			switch(gCloudT[i])
			{
			case 0:
				gCloudX[i]		= Rand(0, swWidth);
				gCloudDY[i]		= Rand(4, 10);
				break;

			case 1:
				gCloudX[i]		= Rand(0, swWidth);
				gCloudDY[i]		= Rand(5, 8);
				break;

			case 2:
				gCloudX[i]		= Rand(0, swWidth);
				gCloudDY[i]		= Rand(4, 7);
				break;
			}

			gCloudCount++;
			break;
		}
	}
}


int actTime[5][100];
int actCount;

void InitActive()
{
	actCount = 0;
	actTime[0][0] = 90;
	actTime[0][1] = actTime[0][0] + 40;
	actTime[0][2] = actTime[0][1] + 30;
	actTime[0][3] = actTime[0][2] + 30;
	actTime[0][4] = actTime[0][3] + 5;
	actTime[0][5] = actTime[0][4] + 25;
	actTime[0][6] = actTime[0][5] + 5;
	actTime[0][7] = actTime[0][6] + 25;
	actTime[0][8] = actTime[0][7] + 30;
	actTime[0][9] = actTime[0][8] + 30;
	actTime[0][10] = actTime[0][9] + 15;
	actTime[0][11] = actTime[0][10] + 15;
	actTime[0][12] = actTime[0][11] + 30;
	actTime[0][13] = actTime[0][12] + 30;
	actTime[0][14] = actTime[0][13] + 30;
	actTime[0][15] = actTime[0][14] + 40;
	actTime[0][16] = actTime[0][15] + 30;
	actTime[0][17] = actTime[0][16] + 30;
	actTime[0][18] = actTime[0][17] + 30;
	actTime[0][19] = actTime[0][18] + 30;
	actTime[0][20] = actTime[0][19] + 30;
	actTime[0][21] = actTime[0][20] + 30;
	actTime[0][22] = actTime[0][21] + 60;
	actTime[0][23] = actTime[0][22] + 40;
	actTime[0][24] = actTime[0][23] + 50;
	actTime[0][25] = actTime[0][24] + 40;
	actTime[0][26] = actTime[0][25] + 50;
	actTime[0][27] = actTime[0][26] + 40;
	actTime[0][28] = actTime[0][27] + 30;
	actTime[0][29] = actTime[0][28] + 60;
	actTime[0][30] = actTime[0][29] + 40;
	actTime[0][31] = actTime[0][30] + 65;
	actTime[0][32] = actTime[0][31] + 60;
	actTime[0][33] = actTime[0][32] + 60;
	actTime[0][34] = actTime[0][33] + 50;
	actTime[0][35] = actTime[0][34] + 40;
	actTime[0][36] = actTime[0][35] + 40;
	actTime[0][37] = actTime[0][36] + 50;
	actTime[0][38] = actTime[0][37] + 40;
	actTime[0][39] = actTime[0][38] + 160;
	actTime[0][40] = -1;


	actTime[1][0] = 90;
	actTime[1][1] = actTime[1][0] + 40;
	actTime[1][2] = actTime[1][1] + 5;
	actTime[1][3] = actTime[1][2] + 5;
	actTime[1][4] = actTime[1][3] + 30;
	actTime[1][5] = actTime[1][4] + 20;
	actTime[1][6] = actTime[1][5] + 5;
	actTime[1][7] = actTime[1][6] + 30;
	actTime[1][8] = actTime[1][7] + 5;
	actTime[1][9] = actTime[1][8] + 5;
	actTime[1][10] = actTime[1][9] + 30;
	actTime[1][11] = actTime[1][10] + 5;
	actTime[1][12] = actTime[1][11] + 5;
	actTime[1][13] = actTime[1][12] + 30;
	actTime[1][14] = actTime[1][13] + 15;
	actTime[1][15] = actTime[1][14] + 15;
	actTime[1][16] = actTime[1][15] + 30;
	actTime[1][17] = actTime[1][16] + 40;
	actTime[1][18] = actTime[1][17] + 5;
	actTime[1][19] = actTime[1][18] + 5;
	actTime[1][20] = actTime[1][19] + 30;
	actTime[1][21] = actTime[1][20] + 5;
	actTime[1][22] = actTime[1][21] + 5;
	actTime[1][23] = actTime[1][22] + 40;
	actTime[1][24] = actTime[1][23] + 40;
	actTime[1][25] = actTime[1][24] + 40;
	actTime[1][26] = actTime[1][25] + 30;
	actTime[1][27] = actTime[1][26] + 5;
	actTime[1][28] = actTime[1][27] + 5;
	actTime[1][29] = actTime[1][28] + 20;
	actTime[1][30] = actTime[1][29] + 5;
	actTime[1][31] = actTime[1][30] + 30;
	actTime[1][32] = actTime[1][31] + 90;
	actTime[1][33] = actTime[1][32] + 40;
	actTime[1][34] = actTime[1][33] + 20;
	actTime[1][35] = actTime[1][34] + 50;
	actTime[1][36] = actTime[1][35] + 25;
	actTime[1][37] = actTime[1][36] + 25;
	actTime[1][38] = actTime[1][37] + 40;
	actTime[1][39] = actTime[1][38] + 10;
	actTime[1][40] = actTime[1][39] + 10;
	actTime[1][41] = actTime[1][40] + 40;
	actTime[1][42] = actTime[1][41] + 40;
	actTime[1][43] = actTime[1][42] + 5;
	actTime[1][44] = actTime[1][43] + 5;
	actTime[1][45] = actTime[1][44] + 40;
	actTime[1][46] = actTime[1][45] + 5;
	actTime[1][47] = actTime[1][46] + 5;
	actTime[1][48] = actTime[1][47] + 40;
	actTime[1][49] = actTime[1][48] + 80;
	actTime[1][50] = actTime[1][49] + 60;
	actTime[1][51] = actTime[1][50] + 40;
	actTime[1][52] = actTime[1][51] + 40;
	actTime[1][53] = actTime[1][52] + 180;
	actTime[1][54] = -1;


	actTime[2][0] = 80;
	actTime[2][1] = actTime[2][0] + 10;
	actTime[2][2] = actTime[2][1] + 20;
	actTime[2][3] = actTime[2][2] + 30;
	actTime[2][4] = actTime[2][3] + 15;
	actTime[2][5] = actTime[2][4] + 20;
	actTime[2][6] = actTime[2][5] + 20;
	actTime[2][7] = actTime[2][6] + 40;
	actTime[2][8] = actTime[2][7] + 50;
	actTime[2][9] = actTime[2][8] + 40;
	actTime[2][10] = actTime[2][9] + 50;
	actTime[2][11] = actTime[2][10] + 40;
	actTime[2][12] = actTime[2][11] + 35;
	actTime[2][13] = actTime[2][12] + 30;
	actTime[2][14] = actTime[2][13] + 30;
	actTime[2][15] = actTime[2][14] + 15;
	actTime[2][16] = actTime[2][15] + 20;
	actTime[2][17] = actTime[2][16] + 30;
	actTime[2][18] = actTime[2][17] + 30;
	actTime[2][19] = actTime[2][18] + 30;
	actTime[2][20] = actTime[2][19] + 15;
	actTime[2][21] = actTime[2][20] + 15;
	actTime[2][22] = actTime[2][21] + 40;
	actTime[2][23] = actTime[2][22] + 15;
	actTime[2][24] = actTime[2][23] + 30;
	actTime[2][25] = actTime[2][24] + 30;
	actTime[2][26] = actTime[2][25] + 20;
	actTime[2][27] = actTime[2][26] + 30;
	actTime[2][28] = actTime[2][27] + 100;
	actTime[2][29] = actTime[2][28] + 40;
	actTime[2][30] = actTime[2][29] + 40;
	actTime[2][31] = actTime[2][30] + 30;
	actTime[2][32] = actTime[2][31] + 20;
	actTime[2][33] = actTime[2][32] + 30;
	actTime[2][34] = actTime[2][33] + 20;
	actTime[2][35] = actTime[2][34] + 15;
	actTime[2][36] = actTime[2][35] + 40;
	actTime[2][37] = actTime[2][36] + 15;
	actTime[2][38] = actTime[2][37] + 15;
	actTime[2][39] = actTime[2][38] + 15;
	actTime[2][40] = actTime[2][39] + 140;
	actTime[2][41] = -1;


	actTime[3][0] = 90;
	actTime[3][1] = actTime[3][0] + 20;
	actTime[3][2] = actTime[3][1] + 20;
	actTime[3][3] = actTime[3][2] + 20;
	actTime[3][4] = actTime[3][3] + 5;
	actTime[3][5] = actTime[3][4] + 5;
	actTime[3][6] = actTime[3][5] + 20;
	actTime[3][7] = actTime[3][6] + 5;
	actTime[3][8] = actTime[3][7] + 30;
	actTime[3][9] = actTime[3][8] + 20;
	actTime[3][10] = actTime[3][9] + 30;
	actTime[3][11] = actTime[3][10] + 20;
	actTime[3][12] = actTime[3][11] + 15;
	actTime[3][13] = actTime[3][12] + 30;
	actTime[3][14] = actTime[3][13] + 30;
	actTime[3][15] = actTime[3][14] + 20;
	actTime[3][16] = actTime[3][15] + 20;
	actTime[3][17] = actTime[3][16] + 40;
	actTime[3][18] = actTime[3][17] + 5;
	actTime[3][19] = actTime[3][18] + 5;
	actTime[3][20] = actTime[3][19] + 5;
	actTime[3][21] = actTime[3][20] + 5;
	actTime[3][22] = actTime[3][21] + 10;
	actTime[3][23] = actTime[3][22] + 5;
	actTime[3][24] = actTime[3][23] + 30;
	actTime[3][25] = actTime[3][24] + 30;
	actTime[3][26] = actTime[3][25] + 30;
	actTime[3][27] = actTime[3][26] + 5;
	actTime[3][28] = actTime[3][27] + 5;
	actTime[3][29] = actTime[3][28] + 20;
	actTime[3][30] = actTime[3][29] + 5;
	actTime[3][31] = actTime[3][30] + 5;
	actTime[3][32] = actTime[3][31] + 30;
	actTime[3][33] = actTime[3][32] + 30;
	actTime[3][34] = actTime[3][33] + 20;
	actTime[3][35] = actTime[3][34] + 30;
	actTime[3][36] = actTime[3][35] + 10;
	actTime[3][37] = actTime[3][36] + 10;
	actTime[3][38] = actTime[3][37] + 10;
	actTime[3][39] = actTime[3][38] + 10;
	actTime[3][40] = actTime[3][39] + 30;
	actTime[3][41] = actTime[3][40] + 5;
	actTime[3][42] = actTime[3][41] + 20;
	actTime[3][43] = actTime[3][42] + 5;
	actTime[3][44] = actTime[3][43] + 40;
	actTime[3][45] = actTime[3][44] + 30;
	actTime[3][46] = actTime[3][45] + 30;
	actTime[3][47] = actTime[3][46] + 40;
	actTime[3][48] = actTime[3][47] + 20;
	actTime[3][49] = actTime[3][48] + 40;
	actTime[3][50] = actTime[3][49] + 30;
	actTime[3][51] = actTime[3][50] + 20;
	actTime[3][52] = actTime[3][51] + 30;
	actTime[3][53] = actTime[3][52] + 5;
	actTime[3][54] = actTime[3][53] + 5;
	actTime[3][55] = actTime[3][54] + 30;
	actTime[3][56] = actTime[3][55] + 20;
	actTime[3][57] = actTime[3][56] + 30;
	actTime[3][58] = actTime[3][57] + 10;
	actTime[3][59] = actTime[3][58] + 10;
	actTime[3][60] = actTime[3][59] + 150;
 	actTime[3][61] = -1;


}

void ActivateEnemyPre()
{
	if(actTime[gStage][actCount] == -1){
		actCount = 0;
		return;
	}
	if(gStageFrame == actTime[gStage][actCount]){
		ActivateEnemy();
		actCount++;
	}
}

void ActivateEnemy()
{
	int i, type, n=-999;

	switch (gStage) {
	case 0:	// stage 1
		switch (actCount) {

		case 0:
			ActivateEachEnemy(A1_TYPE, swWidth/6, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*2, -15);
			break;
		case 1:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, -15);
			break;
		case 2:
			ActivateEachEnemy(B2_TYPE, swWidth/2, n);
			ActivateEachEnemy(B2_TYPE, swWidth/2-20, -20);
			ActivateEachEnemy(B2_TYPE, swWidth/2+20, -20);
			break;
		case 3:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 4:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 5:
			ActivateEachEnemy(B5_TYPE, n, n);
			break;
		case 6:
			ActivateEachEnemy(B5_TYPE, n, n);
			break;
		case 7:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 8:
			ActivateEachEnemy(C3_TYPE, swWidth/2-10, n);
			ActivateEachEnemy(C4_TYPE, swWidth/2+10, n);
			ActivateEachEnemy(C3_TYPE, swWidth/2-10, -20);
			ActivateEachEnemy(C4_TYPE, swWidth/2+10, -20);
			break;
		case 9:
			ActivateEachEnemy(B1_TYPE, n, n);
			break;
		case 10:
			ActivateEachEnemy(B3_TYPE, n, n);
			break;

		case 11:
			ActivateEachEnemy(I1_TYPE, swWidth/4*1, n);
			break;
		case 12:
			ActivateEachEnemy(I1_TYPE, swWidth/4*3, n);
			break;
		case 13:
			ActivateEachEnemy(I1_TYPE, swWidth/6*2, n);
			ActivateEachEnemy(I1_TYPE, swWidth/6*4, n);
			break;
		case 14:
			ActivateEachEnemy(I2_TYPE, -10, n);
			break;
		case 15:
			ActivateEachEnemy(I3_TYPE, swWidth+10, n);
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 16:
			ActivateEachEnemy(C4_TYPE, n, n);
			break;
		case 17:
			ActivateEachEnemy(C3_TYPE, n, n);
			break;
		case 18:
			ActivateEachEnemy(G1_TYPE, n, n);
			break;
		case 19:
			ActivateEachEnemy(A1_TYPE, swWidth/6*1, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, n);
			break;
		case 20:
			ActivateEachEnemy(I1_TYPE, swWidth/4*3, n);
			break;
		case 21:
			ActivateEachEnemy(K1_TYPE, swWidth/3*1, n);
			break;
		case 22:
			ActivateEachEnemy(A1_TYPE, swWidth/5*3, -10);
			ActivateEachEnemy(A1_TYPE, swWidth/5*4, n);
			break;
		case 23:
			ActivateEachEnemy(B1_TYPE, n, n);
			break;
		case 24:
			ActivateEachEnemy(B3_TYPE, n, n);
			break;
		case 25:
			ActivateEachEnemy(C3_TYPE, swWidth/2-10, n);
			ActivateEachEnemy(C4_TYPE, swWidth/2+10, n);
			ActivateEachEnemy(C3_TYPE, swWidth/2-10, -20);
			ActivateEachEnemy(C4_TYPE, swWidth/2+10, -20);
			break;
		case 26:
			ActivateEachEnemy(B2_TYPE, swWidth/2, n);
			ActivateEachEnemy(B2_TYPE, swWidth/2-20, -20);
			ActivateEachEnemy(B2_TYPE, swWidth/2+20, -20);
			break;
		case 27:
			ActivateEachEnemy(G1_TYPE, swWidth/3*1, n);
			break;
		case 28:
			ActivateEachEnemy(G1_TYPE, swWidth/3*2, n);
			break;
		case 29:
			ActivateEachEnemy(G1_TYPE, swWidth/6*2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, -15);
			break;
		case 30:
			ActivateEachEnemy(G1_TYPE, swWidth/3*1, n);
			break;
		case 31:
			ActivateEachEnemy(K1_TYPE, swWidth/6*4, n);
			ActivateEachEnemy(I1_TYPE, swWidth/6*1, n);
			break;
		case 32:
			ActivateEachEnemy(A1_TYPE, swWidth/5*1, n);
			ActivateEachEnemy(A1_TYPE, swWidth/5*2, -20);
			ActivateEachEnemy(A1_TYPE, swWidth/5*3, -40);
			ActivateEachEnemy(A1_TYPE, swWidth/5*4, -60);
			break;
		case 33:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			break;
		case 34:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			break;
		case 35:
			ActivateEachEnemy(A1_TYPE, swWidth/6, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*2, -15);
			break;
		case 36:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, -15);
			break;
		case 37:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 38:
			ActivateEachEnemy(B2_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(B2_TYPE, swWidth/6*4, -15);
			break;

		case 39:
			for (temp1=0; temp1<MAX_ENEMY; temp1++)
				gEnemyS[temp1] =  FS_GHOST;;

			//��������
			gBossState = 1; // 1������
			gEnemyS[0]	= FS_ACTIVATE;
			gEnemyC[0]	= 0;
			gEnemyX[0]	= gCX;
			gEnemyY[0]	= -40;
			gEnemyDX[0] = 0;
			gEnemyT[0]	= O_TYPE;
			gEnemyDY[0]	= 0;
			gEnemyH[0]	= HP_ENEMY_O;
			break;

		}
		break;
	case 1:	// stage 2
		switch (actCount) {
		case 0:
			ActivateEachEnemy(A1_TYPE, swWidth/5, -45);
			ActivateEachEnemy(A1_TYPE, swWidth/5*2, -30);
			ActivateEachEnemy(A1_TYPE, swWidth/5*3, -15);
			ActivateEachEnemy(A1_TYPE, swWidth/5*4, n);
			break;
		case 1:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 2:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 3:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 4:
			ActivateEachEnemy(G1_TYPE, n, n);
			break;
		case 5:
			ActivateEachEnemy(C3_TYPE, swWidth/4*3, n);
			break;
		case 6:
			ActivateEachEnemy(C3_TYPE, swWidth/4*3, n);
			break;
		case 7:
			ActivateEachEnemy(D3_TYPE, n, n);
			break;
		case 8:
			ActivateEachEnemy(D3_TYPE, n, n);
			break;
		case 9:
			ActivateEachEnemy(D3_TYPE, n, n);
			break;
		case 10:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 11:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 12:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 13:
			ActivateEachEnemy(H3_TYPE, swWidth/4, n);
			break;
		case 14:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 15:
			ActivateEachEnemy(H3_TYPE, swWidth/4*3, n);
			break;
		case 16:
			ActivateEachEnemy(H3_TYPE, swWidth/4*1, n);
			ActivateEachEnemy(H3_TYPE, swWidth/4*2, n);
			ActivateEachEnemy(H3_TYPE, swWidth/4*3, n);
			break;
		case 17:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 18:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 19:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 20:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 21:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 22:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 23:
			ActivateEachEnemy(H3_TYPE, swWidth/4*1, -30);
			ActivateEachEnemy(H3_TYPE, swWidth/4*1, n);
			break;
		case 24:
			ActivateEachEnemy(H3_TYPE, swWidth/4*3, -30);
			ActivateEachEnemy(H3_TYPE, swWidth/4*3, n);
			break;
		case 25:
			ActivateEachEnemy(A1_TYPE, swWidth/2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/2-20, -20);
			ActivateEachEnemy(A1_TYPE, swWidth/2+20, -20);
			break;
		case 26:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 27:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 28:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 29:
			ActivateEachEnemy(C3_TYPE, swWidth/5*4, n);
			break;
		case 30:
			ActivateEachEnemy(C3_TYPE, swWidth/5*4, n);
			break;
		case 31:
			ActivateEachEnemy(L1_TYPE, n, n);
			break;
		case 32:
			ActivateEachEnemy(A1_TYPE, swWidth/4*3, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*3-20, -20);
			ActivateEachEnemy(A1_TYPE, swWidth/4*3+20, -20);
			ActivateEachEnemy(A1_TYPE, swWidth/4*1, -60);
			ActivateEachEnemy(A1_TYPE, swWidth/4*1-20, -80);
			ActivateEachEnemy(A1_TYPE, swWidth/4*1+20, -80);
			break;
		case 33:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 34:
			ActivateEachEnemy(B2_TYPE, swWidth/5*1, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5*1, -20);
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, -20);
			break;
		case 35:
			ActivateEachEnemy(H1_TYPE, swWidth/5*1, n);
			ActivateEachEnemy(H2_TYPE, swWidth/5*4, n);
			break;
		case 36:
			ActivateEachEnemy(H1_TYPE, swWidth/5*1, n);
			ActivateEachEnemy(H2_TYPE, swWidth/5*4, n);
			break;
		case 37:
			ActivateEachEnemy(H1_TYPE, swWidth/5*1, n);
			ActivateEachEnemy(H2_TYPE, swWidth/5*4, n);
			break;
		case 38:
			ActivateEachEnemy(H3_TYPE, swWidth/4*1, n);
			break;
		case 39:
			ActivateEachEnemy(H3_TYPE, swWidth/4*2, n);
			break;
		case 40:
			ActivateEachEnemy(H3_TYPE, swWidth/4*3, n);
			break;
		case 41:
			ActivateEachEnemy(G1_TYPE, swWidth/4*3, n);
			ActivateEachEnemy(G1_TYPE, swWidth/4, -60);
			break;
		case 42:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 43:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 44:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 45:
			ActivateEachEnemy(D4_TYPE, n, n);
			break;
		case 46:
			ActivateEachEnemy(D4_TYPE, n, n);
			break;
		case 47:
			ActivateEachEnemy(D4_TYPE, n, n);
			break;
		case 48:
			ActivateEachEnemy(M1_TYPE, n, n);
			break;
		case 49:
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, -20);
			break;
		case 50:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 51:
			ActivateEachEnemy(F1_TYPE, swWidth/4*1, n);
			ActivateEachEnemy(F1_TYPE, swWidth/4*2, n);
			ActivateEachEnemy(F1_TYPE, swWidth/4*3, n);
			break;
		case 52:
			ActivateEachEnemy(C1_TYPE, n, n);
			ActivateEachEnemy(C2_TYPE, n, n);
			ActivateEachEnemy(C3_TYPE, n, n);
			ActivateEachEnemy(C4_TYPE, n, n);
//			ActivateEachEnemy(A1_TYPE, swWidth/5, -45);
//			ActivateEachEnemy(A1_TYPE, swWidth/5*2, -30);
//			ActivateEachEnemy(A1_TYPE, swWidth/5*3, -15);
//			ActivateEachEnemy(A1_TYPE, swWidth/5*4, n);
			break;
		case 53:
			for (temp1=0; temp1<MAX_ENEMY; temp1++)
				gEnemyS[temp1] =  FS_GHOST;;

			//��������
			gBossState = 1; // 1������
			gEnemyS[0]	= FS_ACTIVATE;
			gEnemyC[0]	= 0;
			gEnemyX[0]	= swWidth/2;
			gEnemyY[0]	= -30;
			gEnemyDX[0] = 0;
			gEnemyT[0]	= Q_TYPE;
			gEnemyDY[0]	= 0;
			gEnemyH[0]	= HP_ENEMY_Q;
			break;

		}
		break;
	case 2:	// stage 3
		switch (actCount) {
		case 0:
			ActivateEachEnemy(F1_TYPE, swWidth/5*3, n);
			ActivateEachEnemy(F1_TYPE, swWidth/5*4, n);
			break;
		case 1:
			ActivateEachEnemy(F1_TYPE, swWidth/5, n);
			ActivateEachEnemy(F1_TYPE, swWidth/5*2, n);
			break;
		case 2:
			ActivateEachEnemy(F2_TYPE, n, n);
			ActivateEachEnemy(F3_TYPE, n, n);
			break;
		case 3:
			ActivateEachEnemy(A1_TYPE, swWidth/6, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*2, -15);
			break;
		case 4:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, -15);
			break;
		case 5:
			ActivateEachEnemy(A1_TYPE, swWidth/4, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*3, n);
			break;
		case 6:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 7:
			ActivateEachEnemy(L1_TYPE, n, n);
			break;
		case 8:
			ActivateEachEnemy(J1_TYPE, swWidth/6*1, n);
			ActivateEachEnemy(J1_TYPE, swWidth/6*2, n);
			break;
		case 9:
			ActivateEachEnemy(F1_TYPE, swWidth/5, n);
			ActivateEachEnemy(F1_TYPE, swWidth/5*2, n);
			break;
		case 10:
			ActivateEachEnemy(J1_TYPE, swWidth/8*1, n);
			ActivateEachEnemy(J1_TYPE, swWidth/8*2, -15);
			ActivateEachEnemy(J1_TYPE, swWidth/8*3, -30);
			break;
		case 11:
			ActivateEachEnemy(J1_TYPE, swWidth/8*5, -30);
			ActivateEachEnemy(J1_TYPE, swWidth/8*6, -15);
			ActivateEachEnemy(J1_TYPE, swWidth/8*7, n);
			break;
		case 12:
			ActivateEachEnemy(B2_TYPE, swWidth/2-30, n);
			ActivateEachEnemy(B2_TYPE, swWidth/2-30-20, -20);
			ActivateEachEnemy(B2_TYPE, swWidth/2-30+20, -20);
			break;
		case 13:
			ActivateEachEnemy(G1_TYPE, n, n);
			break;
		case 14:
			ActivateEachEnemy(B5_TYPE, n, n);
			break;
		case 15:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 16:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 17:
			ActivateEachEnemy(H1_TYPE, n, swHeight-20);
			ActivateEachEnemy(H1_TYPE, n, swHeight);
			ActivateEachEnemy(H1_TYPE, n, swHeight +20);
			break;
		case 18:
			ActivateEachEnemy(H3_TYPE, 20, n);
			ActivateEachEnemy(H3_TYPE, 60, n);
			ActivateEachEnemy(H3_TYPE, 80, n);
			break;
		case 19:
			ActivateEachEnemy(H3_TYPE, swWidth/2, n);
			break;
		case 20:
			ActivateEachEnemy(H3_TYPE, swWidth/2+20, n);
			break;
		case 21:
			ActivateEachEnemy(H3_TYPE, swWidth/2-20, n);
			break;
		case 22:
			ActivateEachEnemy(F1_TYPE, swWidth/5, n);
			break;
		case 23:
			ActivateEachEnemy(F1_TYPE, swWidth/2, n);
			break;
		case 24:
			ActivateEachEnemy(H2_TYPE, n, swHeight-20);
			ActivateEachEnemy(H2_TYPE, n, swHeight);
			ActivateEachEnemy(H2_TYPE, n, swHeight +20);
			break;
		case 25:
			ActivateEachEnemy(B2_TYPE, swWidth/2-30, n);
			ActivateEachEnemy(B2_TYPE, swWidth/2-30-20, -20);
			ActivateEachEnemy(B2_TYPE, swWidth/2-30+20, -20);
			break;
		case 26:
			ActivateEachEnemy(G1_TYPE, n, n);
			break;
		case 27:
			ActivateEachEnemy(M1_TYPE, n, n);
			break;
		case 28:
			ActivateEachEnemy(F1_TYPE, swWidth/6*1, n);
			ActivateEachEnemy(F1_TYPE, swWidth/6*3, -15);
			break;
		case 29:
			ActivateEachEnemy(F1_TYPE, swWidth/6*4, n);
			break;
		case 30:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, -15);
			break;
		case 31:
			ActivateEachEnemy(A1_TYPE, swWidth/4, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*3, n);
			break;
		case 32:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 33:
			ActivateEachEnemy(F1_TYPE, swWidth/2, n);
			break;
		case 34:
			ActivateEachEnemy(F1_TYPE, swWidth/6*4, n);
			break;
		case 35:
			ActivateEachEnemy(F1_TYPE, swWidth/2, n);
			break;
		case 36:
			ActivateEachEnemy(A1_TYPE, swWidth/6, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*2, -15);
			break;
		case 37:
			ActivateEachEnemy(F1_TYPE, swWidth/2, n);
			break;
		case 38:
			ActivateEachEnemy(J1_TYPE, swWidth/6*5, n);
			break;
		case 39:
			ActivateEachEnemy(J1_TYPE, swWidth/6, n);
			break;
		case 40:
			for (temp1=0; temp1<MAX_ENEMY; temp1++)
				gEnemyS[temp1] =  FS_GHOST;;

			//��������
			gBossState = 1; // 1������
			gEnemyS[0]	= FS_ACTIVATE;
			gEnemyC[0]	= 0;
			gEnemyX[0]	= gCX;
			gEnemyY[0]	= -40;
			gEnemyDX[0] = 0;
			gEnemyT[0]	= P_TYPE;
			gEnemyDY[0]	= 0;
			gEnemyH[0]	= HP_ENEMY_P;
			break;
		}
		break;

	case 3:	// stage 4
		switch (actCount) {
		case 0:
			ActivateEachEnemy(B2_TYPE, swWidth/2-20, n);
			ActivateEachEnemy(B2_TYPE, swWidth/2-20-20, -20);
			ActivateEachEnemy(B2_TYPE, swWidth/2-20+20, -20);
			break;
		case 1:
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, -15);
			break;
		case 2:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 3:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 4:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 5:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 6:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 7:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 8:
			ActivateEachEnemy(C3_TYPE, swWidth/2-10, n);
			ActivateEachEnemy(C4_TYPE, swWidth/2+10, n);
			ActivateEachEnemy(C3_TYPE, swWidth/2-10, -20);
			ActivateEachEnemy(C4_TYPE, swWidth/2+10, -20);
			break;
		case 9:
			ActivateEachEnemy(G1_TYPE, n, n);
			break;
		case 10:
			ActivateEachEnemy(A1_TYPE, swWidth/5, -45);
			ActivateEachEnemy(A1_TYPE, swWidth/5*2, -30);
			ActivateEachEnemy(A1_TYPE, swWidth/5*3, -15);
			ActivateEachEnemy(A1_TYPE, swWidth/5*4, n);
			break;
		case 11:
			ActivateEachEnemy(F1_TYPE, swWidth/5*2, n);
			ActivateEachEnemy(F1_TYPE, swWidth/5*3, n);
			break;
		case 12:
			ActivateEachEnemy(F2_TYPE, n, n);
			ActivateEachEnemy(F3_TYPE, n, n);
			break;
		case 13:
			ActivateEachEnemy(L1_TYPE, n, n);
			break;
		case 14:
			ActivateEachEnemy(B2_TYPE, swWidth/5, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5, -20);
			break;
		case 15:
			ActivateEachEnemy(A1_TYPE, swWidth/2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/2-20, -20);
			ActivateEachEnemy(A1_TYPE, swWidth/2+20, -20);
			break;
		case 16:
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, -20);
			break;
		case 17:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 18:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 19:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 20:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 21:
			ActivateEachEnemy(E3_TYPE, n, n);
			break;
		case 22:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 23:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 24:
			ActivateEachEnemy(G1_TYPE, swWidth/4, n);
			break;
		case 25:
			ActivateEachEnemy(G1_TYPE, swWidth/4*3, n);
			break;
		case 26:
			ActivateEachEnemy(D3_TYPE, n, n);
			break;
		case 27:
			ActivateEachEnemy(D3_TYPE, n, n);
			break;
		case 28:
			ActivateEachEnemy(D3_TYPE, n, n);
			break;
		case 29:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 30:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 31:
			ActivateEachEnemy(D1_TYPE, n, n);
			break;
		case 32:
			ActivateEachEnemy(A1_TYPE, swWidth/6, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*2, -15);
			break;
		case 33:
			ActivateEachEnemy(A1_TYPE, swWidth/6*5, n);
			ActivateEachEnemy(A1_TYPE, swWidth/6*4, -15);
			break;
		case 34:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 35:
			ActivateEachEnemy(F1_TYPE, swWidth/6*4, n);
			break;
		case 36:
			ActivateEachEnemy(F1_TYPE, swWidth/6*2, n);
			break;
		case 37:
			ActivateEachEnemy(F1_TYPE, swWidth/6*3, n);
			break;
		case 38:
			ActivateEachEnemy(F1_TYPE, swWidth/6*5, n);
			break;
		case 39:
			ActivateEachEnemy(F1_TYPE, swWidth/6*1, n);
			break;
		case 40:
			ActivateEachEnemy(B5_TYPE, n, n);
			break;
		case 41:
			ActivateEachEnemy(B5_TYPE, n, n);
			break;
		case 42:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 43:
			ActivateEachEnemy(B4_TYPE, n, n);
			break;
		case 44:
			ActivateEachEnemy(G1_TYPE, swWidth/4*2, n);
			break;
		case 45:
			ActivateEachEnemy(G1_TYPE, swWidth/4*3, n);
			break;
		case 46:
			ActivateEachEnemy(G1_TYPE, swWidth/4*1, n);
			break;
		case 47:
			ActivateEachEnemy(A1_TYPE, swWidth/4*1, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/4*3, n);
			break;
		case 48:
			ActivateEachEnemy(C1_TYPE, n, n);
			ActivateEachEnemy(C2_TYPE, n, n);
			ActivateEachEnemy(C3_TYPE, n, n);
			ActivateEachEnemy(C4_TYPE, n, n);
			break;
		case 49:
			ActivateEachEnemy(L1_TYPE, n, n);
			break;
		case 50:
			ActivateEachEnemy(C4_TYPE, swWidth/5, n);
			ActivateEachEnemy(C4_TYPE, swWidth/5, -20);
			break;
		case 51:
			ActivateEachEnemy(A1_TYPE, swWidth/2, n);
			ActivateEachEnemy(A1_TYPE, swWidth/2-20, -20);
			ActivateEachEnemy(A1_TYPE, swWidth/2+20, -20);
			break;
		case 52:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 53:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 54:
			ActivateEachEnemy(E4_TYPE, n, n);
			break;
		case 55:
			ActivateEachEnemy(N1_TYPE, n, n);
			break;
		case 56:
			ActivateEachEnemy(G1_TYPE, n, n);
			break;
		case 57:
			ActivateEachEnemy(F1_TYPE, swWidth/2, n);
			break;
		case 58:
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5*4, -20);
			break;
		case 59:
			ActivateEachEnemy(B2_TYPE, swWidth/5*1, n);
			ActivateEachEnemy(B2_TYPE, swWidth/5*1, -20);
			break;
		case 60:
			for (temp1=0; temp1<MAX_ENEMY; temp1++)
				gEnemyS[temp1] =  FS_GHOST;;

			//��������
			gBossState = 1; // 1������
			gEnemyS[0]	= FS_ACTIVATE;
			gEnemyC[0]	= 0;
			gEnemyX[0]	= gCX;
			gEnemyY[0]	= -40;
			gEnemyDX[0] = 0;
			gEnemyT[0]	= R_TYPE;
			gEnemyDY[0]	= 0;
			gEnemyH[0]	= HP_ENEMY_R;
			break;



		}
		break;
	}
}

void ActivateEachEnemy(int type, int x, int y)
{
	int n = -999;

	if (gEnemyS[gEnemyIndex] != FS_GHOST)
		return;

	gEnemyS[gEnemyIndex]	= FS_ACTIVATE;
	gEnemyT[gEnemyIndex]	= type;
	gEnemyC[gEnemyIndex]	= 0;
	if (x == n)
		gEnemyX[gEnemyIndex] = gCX;
	else
		gEnemyX[gEnemyIndex] = x;

	if (y == n)
		gEnemyY[gEnemyIndex] = 0;
	else
		gEnemyY[gEnemyIndex] = y;

	switch(gEnemyT[gEnemyIndex]) {
		case A1_TYPE:
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_A;
			gEnemyH[gEnemyIndex] = HP_ENEMY_A;
			break;
		case B1_TYPE:
		case B2_TYPE:
		case B3_TYPE:
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_B;
			gEnemyH[gEnemyIndex] = HP_ENEMY_B;
			if (gEnemyT[gEnemyIndex]==B1_TYPE)
				gEnemyDX[gEnemyIndex] = -gEnemyDY[gEnemyIndex]/2;
			else if (gEnemyT[gEnemyIndex]==B2_TYPE)
				gEnemyDX[gEnemyIndex] = 0;
			else
				gEnemyDX[gEnemyIndex] = gEnemyDY[gEnemyIndex]/2;
			break;
		case B4_TYPE:
			gEnemyX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_B;
			gEnemyH[gEnemyIndex] = HP_ENEMY_B;
			gEnemyDX[gEnemyIndex] = ((swWidth-gEnemyX[gEnemyIndex])*4/3)/(gEnemyDY[gEnemyIndex]*25/10);
			break;
		case B5_TYPE:
			gEnemyX[gEnemyIndex] = swWidth;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_B;
			gEnemyH[gEnemyIndex] = HP_ENEMY_B;
			gEnemyDX[gEnemyIndex] = -(gEnemyX[gEnemyIndex]*4/3)/(gEnemyDY[gEnemyIndex]*25/10);
			break;
		case C1_TYPE:
			gEnemyX[gEnemyIndex] = gCX;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_C;
			gEnemyH[gEnemyIndex] = HP_ENEMY_C;
			gEnemyDX[gEnemyIndex] = -(gEnemyX[gEnemyIndex]*4/3)/(gEnemyDY[gEnemyIndex]*25/10);
			break;
		case C2_TYPE:
			gEnemyX[gEnemyIndex] = gCX;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_C;
			gEnemyH[gEnemyIndex] = HP_ENEMY_C;
			gEnemyDX[gEnemyIndex] = ((swWidth-gEnemyX[gEnemyIndex])*4/3)/(gEnemyDY[gEnemyIndex]*25/10);
			break;
		case C3_TYPE:
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_C;
			gEnemyH[gEnemyIndex] = HP_ENEMY_C;
			gEnemyDX[gEnemyIndex] = -gEnemyDY[gEnemyIndex]*gEnemyY[gEnemyIndex]*2/swHeight;
			break;
		case C4_TYPE:
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_C;
			gEnemyH[gEnemyIndex] = HP_ENEMY_C;
			gEnemyDX[gEnemyIndex] = gEnemyDY[gEnemyIndex]*gEnemyY[gEnemyIndex]*2/swHeight;
			break;
		case D1_TYPE:
			gEnemyX[gEnemyIndex] = 0;
			gEnemyY[gEnemyIndex] = gCY;
			gEnemyDX[gEnemyIndex] = SPEED_ENEMY_D;
			gEnemyH[gEnemyIndex] = HP_ENEMY_D;
			gEnemyDY[gEnemyIndex] = -((gEnemyY[gEnemyIndex])*4/3)/(gEnemyDX[gEnemyIndex]*25/10);
			break;
		case D2_TYPE:
			gEnemyX[gEnemyIndex] = swWidth;
			gEnemyY[gEnemyIndex] = gCY;
			gEnemyDX[gEnemyIndex] = -SPEED_ENEMY_D;
			gEnemyH[gEnemyIndex] = HP_ENEMY_D;
			gEnemyDY[gEnemyIndex] = ((gEnemyY[gEnemyIndex])*4/3)/(gEnemyDX[gEnemyIndex]*25/10);
			break;
		case D3_TYPE:
			gEnemyX[gEnemyIndex] = 0;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDX[gEnemyIndex] = SPEED_ENEMY_D;
			gEnemyH[gEnemyIndex] = HP_ENEMY_D;
			gEnemyDY[gEnemyIndex] = ((gCY-gEnemyY[gEnemyIndex])*4/3)/(gEnemyDX[gEnemyIndex]*25/10);
			break;
		case D4_TYPE:
			gEnemyX[gEnemyIndex] = swWidth;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDX[gEnemyIndex] = -SPEED_ENEMY_D;
			gEnemyH[gEnemyIndex] = HP_ENEMY_D;
			gEnemyDY[gEnemyIndex] = -((gCY-gEnemyY[gEnemyIndex])*4/3)/(gEnemyDX[gEnemyIndex]*25/10);
			break;
		case E1_TYPE:
			gEnemyX[gEnemyIndex] = 0;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_E;
			gEnemyH[gEnemyIndex] = HP_ENEMY_E;
			gEnemyDX[gEnemyIndex] = gEnemyDY[gEnemyIndex]*gEnemyY[gEnemyIndex]*3/swHeight;
			break;
		case E2_TYPE:
			gEnemyX[gEnemyIndex] = swWidth;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_E;
			gEnemyH[gEnemyIndex] = HP_ENEMY_E;
			gEnemyDX[gEnemyIndex] = -gEnemyDY[gEnemyIndex]*gEnemyY[gEnemyIndex]*3/swHeight;
			break;
		case E3_TYPE:
			gEnemyX[gEnemyIndex] = 0;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_E;
			gEnemyH[gEnemyIndex] = HP_ENEMY_E;
			gEnemyDX[gEnemyIndex] = (swWidth-gEnemyX[gEnemyIndex])/(gEnemyDY[gEnemyIndex]*25/10);
			break;
		case E4_TYPE:
			gEnemyX[gEnemyIndex] = swWidth;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_E;
			gEnemyH[gEnemyIndex] = HP_ENEMY_E;
			gEnemyDX[gEnemyIndex] = -gEnemyX[gEnemyIndex]/(gEnemyDY[gEnemyIndex]*25/10);
			break;
		case F1_TYPE:
		case F2_TYPE:
		case F3_TYPE:
			if (gEnemyT[gEnemyIndex]==F2_TYPE)
				gEnemyX[gEnemyIndex] = 20;
			else if (gEnemyT[gEnemyIndex]==F3_TYPE)
				gEnemyX[gEnemyIndex] = swWidth-20;
			gEnemyY[gEnemyIndex] = 0;
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_F;
			gEnemyH[gEnemyIndex] = HP_ENEMY_F;
			break;
		case G1_TYPE:
			gEnemyY[gEnemyIndex] = -10;
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_G;
			gEnemyH[gEnemyIndex] = HP_ENEMY_G;
			break;
		case H1_TYPE:
			gEnemyX[gEnemyIndex] = -15;
			gEnemyDX[gEnemyIndex] = SPEED_ENEMY_H;
			gEnemyDY[gEnemyIndex] = SPEED_BG;
			gEnemyH[gEnemyIndex] = HP_ENEMY_H;
			break;
		case H2_TYPE:
			gEnemyX[gEnemyIndex] = swWidth+15;
			gEnemyDX[gEnemyIndex] = -SPEED_ENEMY_H;
			gEnemyDY[gEnemyIndex] = SPEED_BG;
			gEnemyH[gEnemyIndex] = HP_ENEMY_H;
			break;
		case H3_TYPE:
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_BG;
			gEnemyH[gEnemyIndex] = HP_ENEMY_H;
			break;
		case I1_TYPE:
			gEnemyY[gEnemyIndex] = -20;
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_BG;
			gEnemyH[gEnemyIndex] = HP_ENEMY_I;
			break;
		case I2_TYPE:
			gEnemyDX[gEnemyIndex] = SPEED_ENEMY_I;
			gEnemyDY[gEnemyIndex] = SPEED_BG;
			gEnemyH[gEnemyIndex] = HP_ENEMY_I;
			break;
		case I3_TYPE:
			gEnemyDX[gEnemyIndex] = -SPEED_ENEMY_I;
			gEnemyDY[gEnemyIndex] = SPEED_BG;
			gEnemyH[gEnemyIndex] = HP_ENEMY_I;
			break;
		case J1_TYPE:
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_J;
			gEnemyH[gEnemyIndex] = HP_ENEMY_J;
			break;
		case K1_TYPE:
			gEnemyY[gEnemyIndex] = -100;
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_K;
			gEnemyH[gEnemyIndex] = HP_ENEMY_K;
			break;
		case L1_TYPE:
			gEnemyY[gEnemyIndex] = -30;
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_L;
			gEnemyH[gEnemyIndex] = HP_ENEMY_L;
			break;
		case M1_TYPE:
			gEnemyY[gEnemyIndex] = -30;
			gEnemyDX[gEnemyIndex] = 0;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_M;
			gEnemyH[gEnemyIndex] = HP_ENEMY_M;
			break;
		case N1_TYPE:
			gEnemyDX[gEnemyIndex] = 1;
			gEnemyDY[gEnemyIndex] = SPEED_ENEMY_N;
			gEnemyH[gEnemyIndex] = HP_ENEMY_N;
			break;
	}

	gEnemyCount++;

	if (++gEnemyIndex==MAX_ENEMY)
		gEnemyIndex = 0;

}

void ActivateFlightMissile()
{
	int i;

	for (i = 0; i < MAX_FLIGHTMISSILE; i++)
	{
		if (gFlightMissileS[i] != FS_ACTIVATE)
		{
			gFlightMissileS[i]	= FS_ACTIVATE;
			gFlightMissileX[i]	= gFlightX-1;
			gFlightMissileY[i]	= gFlightY-1;
			gFlightMissileDX[i]	= 0;
			gFlightMissileDY[i]	= -SPEED_MISSILE;
			gFlightMissileT[i]	= gFlightMT;
			gFlightMissileCount++;
			break;
		}
	}
}

void ActivateMissile(int x, int y, int type, int dx, int dy)
{
	int i;

	for (i = 0; i < MAX_MISSILE; i++)
	{
		if (gMissileS[i] != FS_ACTIVATE)
		{
			gMissileS[i]	= FS_ACTIVATE;
			gMissileT[i]	= type;
			gMissileX[i]	= x;
			gMissileY[i]	= y;
			gMissileDX[i]	= dx;
			gMissileDY[i]	= dy;
			gMissileCount++;
			break;
		}
	}
}

void ActivateItem(int x, int y, int type)
{
	gItemS = FS_ACTIVATE;
	gItemX = x;
	gItemY = y;
	gItemT = type;
}

void MoveFlight(int dir)
{
	int i;

	if (gFlightS == FS_DIE)
	{
		gFlightMT = 0;

		if (++gFlightC > 14)
		{
			gFlightLife--;

			gFlightLife=3;
			if (gFlightLife>0) {
				gFlightS = FS_GHOST;
				gFlightX = gCX;
				gFlightY = swHeight+30;
				gFlightC	= 0;
				gFlightStep	= 0;
				if (gSpecialCount<3)
					gSpecialCount = 3;
			}
			else {
				Play_Sound(snd5_2);
				gOverCount = 1;
				gFlightX = gCX;
				gFlightY = swHeight+30;
				return;
			}
		}
		if (gFlightC==1)
			Play_Sound(snd4_4);

		Play_Sound(-1);//�����϶�
	}
	else if (gFlightS == FS_GHOST)
	{
		if (++gFlightC < 15) {
			if (gFlightC == 5)
				Play_Sound(snd6_4);
			gFlightY = swHeight+30-gFlightC*5;
		}
		else if (gFlightC > 52) {//����Ʈ �ð�
			gFlightS = FS_ACTIVATE;
			gFlightC = 0;
		}
	}

	// stage ���۽� ó��
	if (gStageFrame<60) {
		if (gStageFrame<21) {
			gFlightD = FD_UP;
			gFlightY -= (20-gStageFrame)*3/4;
		}
		else if (gStageFrame<23) {
			gFlightD = FD_NONE;
		}
		else if (gStageFrame<60) {
			gFlightY += 2;
		}
		return;
	}
	else if (gStageFrame==60) {
		if (gGameVolumeBGM>0)
			Play_Sound(snd2_2);
	}

	// stage ���� ó��
	if (gStageFrame>99999) {
		gFlightShooting = 0;
		gSpecial = 0;
		gFlightD = FD_UP;
		if ((swHeight-gFlightY)/10 > 0)
			gFlightY -= (swHeight-gFlightY)/10;
		else
			gFlightY -= 1;

		if (gFlightY<-300) {
			gFlightD = FD_NONE;
//			Play_Sound(snd5_1);
			GameMap(ES_START, swData);
		}
		return;
	}

	switch(dir)
	{
	case FD_LEFT:
	case FD_L_UP:
	case FD_L_DOWN:
		if (gFlightX - STEP_MOVE > 0) {
			if (gFlightStep < 10)
				gFlightStep+=1;

			for (i = 0; i < MAX_ENEMY; i++) {
				if (gEnemyS[i] != FS_GHOST)
					gEnemyX[i] += STEP_MOVE_ENEMY;
			}

			for (i = 0; i < MAX_MISSILE; i++) {
				if (gMissileS[i] != FS_GHOST)
					gMissileX[i] += STEP_MOVE_MISSILE;
			}

			for (i = 0; i < MAX_BG; i++)
				gBGX[i] += STEP_MOVE_BG;

			for (i = 0; i < MAX_CLOUD; i++)
				gCloudX[i] += STEP_MOVE_CLOUD;

			if (gItemS != FS_GHOST)
				gItemX += STEP_MOVE_ITEM;

			gFlightX -= STEP_MOVE;
		}

		if (dir==FD_L_UP) {
			if (gFlightY >= STEP_MOVE)
				gFlightY -= STEP_MOVE;
		}
		else if (dir==FD_L_DOWN) {
			if (gFlightY + STEP_MOVE < swHeight)
				gFlightY += STEP_MOVE;
		}

		break;
	case FD_RIGHT:
	case FD_R_UP:
	case FD_R_DOWN:
		if (gFlightX + STEP_MOVE < swWidth) {
			if (gFlightStep < 10)
				gFlightStep+=1;

			for (i = 0; i < MAX_ENEMY; i++) {
				if (gEnemyS[i] != FS_GHOST)
					gEnemyX[i] -= STEP_MOVE_ENEMY;
			}

			for (i = 0; i < MAX_MISSILE; i++) {
				if (gMissileS[i] != FS_GHOST)
					gMissileX[i] -= STEP_MOVE_MISSILE;
			}

			for (i = 0; i < MAX_BG; i++)
				gBGX[i] -= STEP_MOVE_BG;

			for (i = 0; i < MAX_CLOUD; i++)
				gCloudX[i] -= STEP_MOVE_CLOUD;

			if (gItemS != FS_GHOST)
				gItemX -= STEP_MOVE_ITEM;

			gFlightX += STEP_MOVE;
		}

		if (dir==FD_R_UP) {
			if (gFlightY >= STEP_MOVE)
				gFlightY -= STEP_MOVE;
		}
		else if (dir==FD_R_DOWN) {
			if (gFlightY + STEP_MOVE < swHeight)
				gFlightY += STEP_MOVE;
		}
		break;
	case FD_UP:
		if (gFlightY >= STEP_MOVE)
			gFlightY -= STEP_MOVE;
		break;
	case FD_DOWN:
		if (gFlightY + STEP_MOVE < swHeight)
			gFlightY += STEP_MOVE;
		break;
	}
}
#define MISSILE_END	40
void MoveEnemy()
{
	int i,Y_offset;

	for (i = 0; i < MAX_ENEMY; i++)
	{
		if (gEnemyS[i] != FS_GHOST)
		{
			switch(gEnemyS[i])
			{
			case FS_ATTACKED:
				if (gEnemyH[i] > 0) {
					gEnemyS[i] = FS_ACTIVATE;
				}
				else {
					if (gBossState>0) { //���� �����̸� ���� �ʰ� ���� ����� �̵�
						switch(gStage) {
						case 0:
							if (gBossState==1) {
								gEnemyY[i] -= 100;
								gEnemyH[i] = HP_ENEMY_O;
								Play_Sound(snd4_1);

								//drawing offset �� spot�̵�
								//bossü�� ȸ��
								//
							}
							else if (gBossState==2) {
								gEnemyY[i] -= 150;
								gEnemyH[i] = HP_ENEMY_O;
								////�����ְ� �� ��Ʈ���� stage ���� �غ�
								Play_Sound(snd4_1);
								if (gStageFrame < 99970)
									gStageFrame = 99970;
							}
							break;
						case 1:
							if (gBossState==1) {
								gEnemyH[i] = HP_ENEMY_P;
								////�����ְ� �� ��Ʈ���� stage ���� �غ�
								Play_Sound(snd4_1);
								if (gStageFrame < 99970)
									gStageFrame = 99970;
							}
							break;
						case 2:
							if (gBossState==1) {
								gEnemyH[i] = HP_ENEMY_Q;
								////�����ְ� �� ��Ʈ���� stage ���� �غ�
								Play_Sound(snd4_1);
								if (gStageFrame < 99970)
									gStageFrame = 99970;
							}
							break;
						case 3:
							if (gBossState==1) {
								gEnemyH[i] = HP_ENEMY_R;
								////�����ְ� �� ��Ʈ���� stage ���� �غ�
								Play_Sound(snd4_1);
								if (gStageFrame < 99970)
									gStageFrame = 99970;
							}
							break;
						}
						gEnemyS[i] = FS_ACTIVATE;
						gBossState++;
					}
					else {
						gEnemyS[i] = FS_DIE;
						gGameScore += (gEnemyT[i]+1) * 10;
						if (gEnemyT[i]<D1_TYPE)
							Play_Sound(snd4_3);
						else if (gEnemyT[i]<G1_TYPE)
							Play_Sound(snd4_2);
						else
							Play_Sound(snd4_1);
						if (gGameScore >= (gBonusFlag+1)*BONUS_SCORE) {
							Play_Sound(snd8_2);//���ʽ� ���� �Ҹ��� ����
							if (gFlightLife<MAX_FLIGHT_LIFE)
								gFlightLife++;
							gBonusFlag++;
						}
					}
				}
				break;
			case FS_DIE:
				if(gEnemyT[i] == K1_TYPE || gEnemyT[i] == L1_TYPE || gEnemyT[i] == M1_TYPE){
					if (++gEnemyC[i] > 14) {
						gEnemyS[i] = FS_GHOST;
						gEnemyCount--;
					}
				}
				else{
					if (++gEnemyC[i] > 4) {
						if (gEnemyT[i] == N1_TYPE && gItemS != FS_ACTIVATE)
							if (RandRatio(60))
								ActivateItem(gEnemyX[i], gEnemyY[i], IT_POWER);
							else
								ActivateItem(gEnemyX[i], gEnemyY[i], IT_SPECIAL);
						gEnemyS[i] = FS_GHOST;
						gEnemyCount--;
					}
				}
				break;
			}

			switch(gEnemyT[i])
			{
			case A1_TYPE:
				break;
			case B1_TYPE:
			case B2_TYPE:
			case B3_TYPE:
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case B4_TYPE:
				if (gEnemyY[i] < gCY) {
					if (gEnemyDY[i]==0)
						gEnemyDY[i] = 1;
					gEnemyDX[i] = ((swWidth-gEnemyX[i])*4/3)/(gEnemyDY[i]*25/10);
				}
				else {
					gEnemyDX[i] = -(gEnemyDY[i]*(gEnemyY[i]-swHeight/3)*3/swHeight);
				}
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case B5_TYPE:
				if (gEnemyY[i] < gCY) {
					if (gEnemyDY[i]==0)
						gEnemyDY[i] = 1;
					gEnemyDX[i] = -(gEnemyX[i]*4/3)/(gEnemyDY[i]*25/10);
				}
				else {
					gEnemyDX[i] = gEnemyDY[i]*(gEnemyY[i]-swHeight/3)*3/swHeight;
				}
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case C1_TYPE:
				if (gEnemyY[i] < gCY) {
					if (gEnemyDY[i]==0)
						gEnemyDY[i] = 1;
					gEnemyDX[i] = -(gEnemyX[i]*4/3)/(gEnemyDY[i]*25/10);
				}
				else {
					gEnemyDX[i] = gEnemyDY[i]*(gEnemyY[i]-swHeight/2)*3/swHeight;
				}
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case C2_TYPE:
				if (gEnemyY[i] < gCY) {
					if (gEnemyDY[i]==0)
						gEnemyDY[i] = 1;
					gEnemyDX[i] = ((swWidth-gEnemyX[i])*4/3)/(gEnemyDY[i]*25/10);
				}
				else {
					gEnemyDX[i] = -(gEnemyDY[i]*(gEnemyY[i]-swHeight/2)*3/swHeight);
				}
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case C3_TYPE:
				gEnemyDX[i] = -gEnemyDY[i]*gEnemyY[i]*2/swHeight;
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case C4_TYPE:
				gEnemyDX[i] = gEnemyDY[i]*gEnemyY[i]*2/swHeight;
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case D1_TYPE:
				if (gEnemyX[i] < gCX) {
					if (gEnemyDX[i]==0)
						gEnemyDX[i] = 1;
					gEnemyDY[i] = -((gEnemyY[i])*4/3)/(gEnemyDX[i]*25/10);
				}
				else {
					gEnemyDY[i] = (gEnemyDX[i]*(gEnemyX[i]-swWidth/2)*3/swWidth);
				}
				if (swFrame % 30 == 0 && RandRatio(30)){
					if(gStage > 2){
						RotateCannon(gEnemyX[i],gEnemyY[i],D1_TYPE);
						ActivateMissile(gEnemyX[i], gEnemyY[i], 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}else{
						ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 7);
					}
				}
				break;
			case D2_TYPE:
				if (gEnemyX[i] > gCX) {
					if (gEnemyDX[i]==0)
						gEnemyDX[i] = 1;
					gEnemyDY[i] = ((gEnemyY[i])*4/3)/(gEnemyDX[i]*25/10);
				}
				else {
					gEnemyDY[i] = (gEnemyDX[i]*(gEnemyX[i]-swWidth/2)*3/swWidth);
				}
				if (swFrame % 30 == 0 && RandRatio(30)){
					if(gStage > 2){
						RotateCannon(gEnemyX[i],gEnemyY[i],D1_TYPE);
						ActivateMissile(gEnemyX[i], gEnemyY[i], 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}else{
						ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 7);
					}
				}
				break;
			case D3_TYPE:
				if (gEnemyX[i] < gCX) {
					if (gEnemyDX[i]==0)
						gEnemyDX[i] = 1;
					gEnemyDY[i] = ((gCY-gEnemyY[i])*4/3)/(gEnemyDX[i]*25/10);
				}
				else {
					gEnemyDY[i] = -(gEnemyDX[i]*(gEnemyX[i]-swWidth/2)*3/swWidth);
				}
				if (swFrame % 30 == 0 && RandRatio(30)){
					if(gStage > 2){
						RotateCannon(gEnemyX[i],gEnemyY[i],D1_TYPE);
						ActivateMissile(gEnemyX[i], gEnemyY[i], 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}else{
						ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 7);
					}
				}
				break;
			case D4_TYPE:
				if (gEnemyX[i] > gCX) {
					if (gEnemyDX[i]==0)
						gEnemyDX[i] = 1;
					gEnemyDY[i] = -((gCY-gEnemyY[i])*4/3)/(gEnemyDX[i]*25/10);
				}
				else {
					gEnemyDY[i] = -(gEnemyDX[i]*(gEnemyX[i]-swWidth/2)*3/swWidth);
				}
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case E1_TYPE:
				gEnemyDX[i] = gEnemyDY[i]*gEnemyY[i]*3/swHeight;
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case E2_TYPE:
				gEnemyDX[i] = -gEnemyDY[i]*gEnemyY[i]*3/swHeight;
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case E3_TYPE:
				if (gEnemyDY[i]==0)
					gEnemyDY[i] = 1;
				gEnemyDX[i] = (swWidth-gEnemyX[i])/(gEnemyDY[i]*25/10);
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case E4_TYPE:
				if (gEnemyDY[i]==0)
					gEnemyDY[i] = 1;
				gEnemyDX[i] = -gEnemyX[i]/(gEnemyDY[i]*25/10);
				if (swFrame%30==0 && Rand(0, 3))
					ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 5);
				break;
			case F1_TYPE:
				if (gEnemyDY[i]>0 && gEnemyY[i]>swHeight-40)
					gEnemyDY[i] = -gEnemyDY[i];
				if(swHeight-MISSILE_END+10 > gEnemyY[i]){
					if(gStage > 1){
						if (swFrame % 20 == 0 && RandRatio(40)){
							RotateCannon(gEnemyX[i],gEnemyY[i],F1_TYPE);
							ActivateMissile(gEnemyX[i], gEnemyY[i], 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						}
					}else{
						if (swFrame % 30 == 0 && RandRatio(25)){
							ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 7);
						}
					}
				}


				break;
			case F2_TYPE:
				if (gEnemyDY[i]>0 && gEnemyY[i]>swHeight-40) {
					gEnemyDY[i] = 0;
					gEnemyDX[i] = SPEED_ENEMY_F;
				}
				else if (gEnemyDY[i]==0) {
					if (gEnemyX[i]>swWidth-20) {
						gEnemyDX[i] = 0;
						gEnemyDY[i] = -SPEED_ENEMY_F;
					}
				}

				if(swHeight-MISSILE_END+10 > gEnemyY[i]){
					if(gStage > 1){
						if (swFrame % 30 == 0 && RandRatio(50)){
							RotateCannon(gEnemyX[i],gEnemyY[i],F1_TYPE);
							ActivateMissile(gEnemyX[i], gEnemyY[i], 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						}
					}else{
						if (swFrame % 30 == 0 && RandRatio(25)){
							ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 7);
						}
					}
				}
				break;
			case F3_TYPE:
				if (gEnemyDY[i]>0 && gEnemyY[i]>swHeight-40) {
					gEnemyDY[i] = 0;
					gEnemyDX[i] = -SPEED_ENEMY_F;
				}
				else if (gEnemyDY[i]==0) {
					if (gEnemyX[i]<20) {
						gEnemyDX[i] = 0;
						gEnemyDY[i] = -SPEED_ENEMY_F;
					}
				}

				if(swHeight-MISSILE_END+10 > gEnemyY[i]){
					if(gStage > 1){
						if (swFrame % 25 == 0 && RandRatio(40)){
							RotateCannon(gEnemyX[i],gEnemyY[i],F1_TYPE);
							ActivateMissile(gEnemyX[i], gEnemyY[i], 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						}
					}else{
						if (swFrame % 30 == 0 && RandRatio(25)){
							ActivateMissile(gEnemyX[i], gEnemyY[i], 0, 0, 7);
						}
					}
				}
				break;
			case G1_TYPE:
				if (swFrame % 30 == 0 && Rand(0 , 3)) {
					ActivateMissile(gEnemyX[i]-14,	gEnemyY[i], 1, 0, 5);
					ActivateMissile(gEnemyX[i]+14,	gEnemyY[i], 1, 0, 5);
				}
				if (gEnemyX[i] < 20) {
					gEnemyDX[i] = Rand(0, 2);
				}
				else if (gEnemyX[i] > swWidth-20) {
					gEnemyDX[i] = -Rand(0, 2);
				}
				else {
					if (RandRatio(20))
						gEnemyDX[i] = Rand(-1, 2);
				}
				break;
			case H1_TYPE:
				if (swFrame % 50 == 0 && RandRatio(30)) {
					if(swHeight-MISSILE_END > gEnemyY[i]){
						RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(gMissileDegree[temp4], 13), gEnemyY[i]+GET_Y(gMissileDegree[temp4], 13), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
				}
				if (gEnemyX[i] < 30) {
					gEnemyDX[i] = SPEED_ENEMY_H;
				}
				else {
					gEnemyDX[i] = 0;
				}
				break;
			case H2_TYPE:
				if (swFrame % 40 == 0 && RandRatio(30)) {
					if(swHeight-MISSILE_END > gEnemyY[i]){
						RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(gMissileDegree[temp4], 13), gEnemyY[i]+GET_Y(gMissileDegree[temp4], 13), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
				}
				if (gEnemyX[i] > swWidth-30) {
					gEnemyDX[i] = -SPEED_ENEMY_H;
				}
				else {
					gEnemyDX[i] = 0;
				}
				break;
			case H3_TYPE:
				if(gStage > 1){
					if (swFrame % 40 == 0 && RandRatio(40)) {
						if(swHeight-MISSILE_END > gEnemyY[i]){
							RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
							ActivateMissile(gEnemyX[i]+GET_X(gMissileDegree[temp4], 13), gEnemyY[i]+GET_Y(gMissileDegree[temp4], 13), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						}
					}
				}else{
					if (swFrame % 60 == 0 && RandRatio(40)) {
						if(swHeight-MISSILE_END > gEnemyY[i]){
							RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
							ActivateMissile(gEnemyX[i]+GET_X(gMissileDegree[temp4], 13), gEnemyY[i]+GET_Y(gMissileDegree[temp4], 13), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						}
					}
				}
				break;
			case I1_TYPE:
			case I2_TYPE:
			case I3_TYPE:
				if (swFrame%54==0 && RandRatio(35)) {
					if(swHeight-MISSILE_END > gEnemyY[i]){
						RotateCannon(gEnemyX[i],gEnemyY[i],I1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(gMissileDegree[temp4], 10), gEnemyY[i]+GET_Y(gMissileDegree[temp4], 10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
				}
				break;
			case J1_TYPE:
				if (swFrame%71==0 && RandRatio(30)) {
					if(swHeight-MISSILE_END > gEnemyY[i]){
						RotateCannon(gEnemyX[i],gEnemyY[i],J1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+20)%360), 10), gEnemyY[i]+GET_Y(((gMissileDegree[temp4]+20)%360), 10), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+340)%360 ), 10), gEnemyY[i]+GET_Y(((gMissileDegree[temp4]+340)%360),10), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
				}
				break;
			case K1_TYPE:
				if (swFrame % 30 == 0 && RandRatio(30)) {
					if(swHeight-MISSILE_END + 10> gEnemyY[i]+60){
						RotateCannon(gEnemyX[i],gEnemyY[i]+60,K1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+10)%360), 16), gEnemyY[i]+60+GET_Y(((gMissileDegree[temp4]+10)%360), 16), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+350)%360 ), 16), gEnemyY[i]+60+GET_Y(((gMissileDegree[temp4]+350)%360),16), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
					}
				}
				if (swFrame % 35 == 0 && RandRatio(23)) {
					if(swHeight-MISSILE_END + 10 > gEnemyY[i]+40){
						RotateCannon(gEnemyX[i],gEnemyY[i]+40,K1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+10)%360), 16), gEnemyY[i]+40+GET_Y(((gMissileDegree[temp4]+10)%360), 16), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+350)%360 ), 16), gEnemyY[i]+40+GET_Y(((gMissileDegree[temp4]+350)%360),16), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
					}
				}
				if (swFrame % 25 == 0 && RandRatio(35)) {
					if(swHeight-MISSILE_END + 10 > gEnemyY[i]-25){
						RotateCannon(gEnemyX[i],gEnemyY[i]-25,K1_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+10)%360), 16), gEnemyY[i]-25+GET_Y(((gMissileDegree[temp4]+10)%360), 16), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+350)%360 ), 16), gEnemyY[i]-25+GET_Y(((gMissileDegree[temp4]+350)%360),16), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
					}
				}
				if(swFrame%3 == 0)
					gEnemyDY[i] = 0;
				else
					gEnemyDY[i] = SPEED_ENEMY_K;
				break;
			case L1_TYPE:
				if (swFrame % 30 == 0 && RandRatio(50)) {
					if(swHeight-MISSILE_END-10 > gEnemyY[i]+17){
						ActivateMissile(gEnemyX[i]+GET_X(225, 16), gEnemyY[i]+17+GET_Y(225, 16), 2, GET_X(225, SP_E_MISSILE_1),GET_Y(225, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(247, 16), gEnemyY[i]+17+GET_Y(247, 16), 2, GET_X(247, SP_E_MISSILE_1),GET_Y(247, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(270, 16), gEnemyY[i]+17+GET_Y(270, 16), 2, GET_X(270, SP_E_MISSILE_1),GET_Y(270, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(293, 16), gEnemyY[i]+17+GET_Y(293, 16), 2, GET_X(293, SP_E_MISSILE_1),GET_Y(293, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(315, 16), gEnemyY[i]+17+GET_Y(315, 16), 2, GET_X(315, SP_E_MISSILE_1),GET_Y(315, SP_E_MISSILE_1));
					}
				}
				if (gEnemyX[i] < 20) {
					gEnemyDX[i] = Rand(0, 2);
				}
				else if (gEnemyX[i] > swWidth-20) {
					gEnemyDX[i] = -Rand(0, 2);
				}
				else {
					if (RandRatio(20))
						gEnemyDX[i] = Rand(-1, 2);
				}
				break;
			case M1_TYPE:
				if (swFrame % 3 == 0) {
					ActivateMissile(gEnemyX[i], gEnemyY[i]-18, 1, GET_X(gMissileDegree[(swFrame/3)%16], SP_E_MISSILE_1),GET_Y(gMissileDegree[(swFrame/3)%16], SP_E_MISSILE_1));
				}
				if (swFrame % 20 == 0 && RandRatio(25)) {
					RotateCannon(gEnemyX[i],gEnemyY[i]+2,M1_TYPE);
					ActivateMissile(gEnemyX[i], gEnemyY[i]-8, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					ActivateMissile(gEnemyX[i], gEnemyY[i]+2, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					ActivateMissile(gEnemyX[i], gEnemyY[i]+12, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
				}
				//���� frame�� ������ ������ �������� �� ���
				if (gEnemyY[i] < 20) {
					gEnemyDY[i] = Rand(1, SPEED_ENEMY_M+1);
				}
				else if (gEnemyY[i] > swHeight-50) {
					gEnemyDY[i] = -Rand(1, SPEED_ENEMY_M+1);
				}
				switch (gStage) {
				case 0: // stage 1 --------  ù�ǿ��� ��ũ�� ����.
					if (gStageFrame>actTime[0][0])
						gEnemyDY[i] = SPEED_ENEMY_M;
					break;
				case 1: // stage 2
					if (gStageFrame>actTime[1][52])
						gEnemyDY[i] = SPEED_ENEMY_M;
					break;
				case 2: // stage 3
					if (gStageFrame>actTime[2][33])
						gEnemyDY[i] = SPEED_ENEMY_M;
					break;
				}
				break;
			case N1_TYPE:
				if (swFrame % 30 == 0 && RandRatio(25)) {
					if(swHeight-MISSILE_END+10 > gEnemyY[i]-25){
						ActivateMissile(gEnemyX[i]-4, gEnemyY[i]+7, 1, -2, 5);
						ActivateMissile(gEnemyX[i], 	gEnemyY[i]+7, 1, 0, 5);
						ActivateMissile(gEnemyX[i]+4, gEnemyY[i]+7, 1, 2, 5);
					}
				}
				if (gEnemyX[i] < 30) {
					gEnemyDX[i] = 1;
				}
				else if (gEnemyX[i] > swWidth - 30) {
					gEnemyDX[i] = -1;
				}
				break;
			case O_TYPE:
				if (gBossState==1)
					Y_offset = 0;
				else if (gBossState==2)
					Y_offset = 100;
				else if (gBossState==3)
					Y_offset = 250;
			
				if (gBossState==1) {
					if (swFrame % 20 == 0 && RandRatio(30)) {
						RotateCannon(gEnemyX[i],gEnemyY[i]-29+Y_offset, O_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+10)%360 ), 30), gEnemyY[i]+Y_offset-29+GET_Y(((gMissileDegree[temp4]+10)%360),30), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X( gMissileDegree[temp4], 30), gEnemyY[i]+Y_offset-29+GET_Y(gMissileDegree[temp4],30), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+350)%360 ), 30), gEnemyY[i]+Y_offset-29+GET_Y(((gMissileDegree[temp4]+350)%360),30), 2, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
					}
					if (swFrame % 15 == 0 && RandRatio(25)) {
						RotateCannon(gEnemyX[i],gEnemyY[i]+Y_offset-64, O_TYPE);
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+10)%360 ), 30), gEnemyY[i]+Y_offset-64+GET_Y(((gMissileDegree[temp4]+10)%360),30), 1, GET_X(((gMissileDegree[temp4]+15)%360), SP_E_MISSILE_0),GET_Y(((gMissileDegree[temp4]+15)%360), SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]+GET_X( gMissileDegree[temp4], 30), gEnemyY[i]+Y_offset-64+GET_Y(gMissileDegree[temp4],30), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]+GET_X(( (gMissileDegree[temp4]+350)%360 ), 30), gEnemyY[i]+Y_offset-64+GET_Y(((gMissileDegree[temp4]+350)%360),30), 1, GET_X(((gMissileDegree[temp4]+345)%360), SP_E_MISSILE_0),GET_Y(((gMissileDegree[temp4]+345)%360), SP_E_MISSILE_0));
					}
				}
				else if (gBossState==2) {
					if (swFrame % 20 == 0 && RandRatio(30)) {

						RotateCannon(gEnemyX[i]-21,gEnemyY[i]+Y_offset-104, O_TYPE);
						ActivateMissile(gEnemyX[i]-21+GET_X(( (gMissileDegree[temp4]+10)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+10)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]-21+GET_X(( (gMissileDegree[temp4]+350)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+350)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 20 == 0 && RandRatio(30)) {
						RotateCannon(gEnemyX[i]+22,gEnemyY[i]+Y_offset-104, O_TYPE);
						ActivateMissile(gEnemyX[i]+22+GET_X(( (gMissileDegree[temp4]+10)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+10)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]+22+GET_X(( (gMissileDegree[temp4]+350)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+350)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 25 == 0 && RandRatio(35)) {

						RotateCannon(gEnemyX[i]-21,gEnemyY[i]+Y_offset-138, O_TYPE);
						ActivateMissile(gEnemyX[i]-21+GET_X(( (gMissileDegree[temp4]+10)%360 ), 10), gEnemyY[i]+Y_offset-138+GET_Y(((gMissileDegree[temp4]+10)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]-21+GET_X(( (gMissileDegree[temp4]+350)%360 ), 10), gEnemyY[i]+Y_offset-138+GET_Y(((gMissileDegree[temp4]+350)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 25 == 0 && RandRatio(35)) {
						RotateCannon(gEnemyX[i]+22,gEnemyY[i]+Y_offset-138, O_TYPE);
						ActivateMissile(gEnemyX[i]+22+GET_X(( (gMissileDegree[temp4]+10)%360 ), 10), gEnemyY[i]+Y_offset-138+GET_Y(((gMissileDegree[temp4]+10)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]+22+GET_X(( (gMissileDegree[temp4]+350)%360 ), 10), gEnemyY[i]+Y_offset-138+GET_Y(((gMissileDegree[temp4]+350)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 30 == 0 && RandRatio(35)) {
						RotateCannon(gEnemyX[i]-21,gEnemyY[i]+Y_offset-160, O_TYPE);
						ActivateMissile(gEnemyX[i]-21+GET_X(( (gMissileDegree[temp4]+10)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+10)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]-21+GET_X(( (gMissileDegree[temp4]+350)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+350)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 30 == 0 && RandRatio(35)) {
						RotateCannon(gEnemyX[i]+22,gEnemyY[i]+Y_offset-160, O_TYPE);
						ActivateMissile(gEnemyX[i]+22+GET_X(( (gMissileDegree[temp4]+10)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+10)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						ActivateMissile(gEnemyX[i]+22+GET_X(( (gMissileDegree[temp4]+350)%360 ), 10), gEnemyY[i]+Y_offset-104+GET_Y(((gMissileDegree[temp4]+350)%360),10), 1, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
				}

				if (gEnemyX[i] < 20) {
					gEnemyDX[i] = SPEED_ENEMY_O;
				}
				else if (gEnemyX[i] > swWidth-20) {
					gEnemyDX[i] = -SPEED_ENEMY_O;
				}
				else {
					if (RandRatio(20))
						gEnemyDX[i] = Rand(-SPEED_ENEMY_O, SPEED_ENEMY_O+1);
				}
//gEnemyDX[i] = 0;//////////
				if (gBossState==1) {
					if (gEnemyY[i]<64)
						gEnemyY[i] += 1;
				}
				else if (gBossState==2) {
					if (gEnemyY[i]<69)
						gEnemyY[i] += 1;
				}
				else if (gBossState==3) {
					if (gEnemyY[i]<swHeight+10)
						gEnemyY[i] += 1;
				}
				break;
			case P_TYPE:
				if (gBossState==1) {
					if ((swFrame+20) % 40 == 0 && Rand(0 , 3)) {
						ActivateMissile(gEnemyX[i]+GET_X(203, 16), gEnemyY[i]+9+GET_Y(203, 16), 1, GET_X(203, SP_E_MISSILE_1),GET_Y(203, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(225, 16), gEnemyY[i]+9+GET_Y(225, 16), 1, GET_X(225, SP_E_MISSILE_1),GET_Y(225, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(247, 16), gEnemyY[i]+9+GET_Y(247, 16), 1, GET_X(247, SP_E_MISSILE_1),GET_Y(247, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(270, 16), gEnemyY[i]+9+GET_Y(270, 16), 1, GET_X(270, SP_E_MISSILE_1),GET_Y(270, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(293, 16), gEnemyY[i]+9+GET_Y(293, 16), 1, GET_X(293, SP_E_MISSILE_1),GET_Y(293, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(315, 16), gEnemyY[i]+9+GET_Y(315, 16), 1, GET_X(315, SP_E_MISSILE_1),GET_Y(315, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+GET_X(337, 16), gEnemyY[i]+9+GET_Y(337, 16), 1, GET_X(337, SP_E_MISSILE_1),GET_Y(337, SP_E_MISSILE_1));
					}
					if (swFrame % 40 == 0) {
						ActivateMissile(gEnemyX[i]+22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
						ActivateMissile(gEnemyX[i]-22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
					}
					if ((swFrame+2) % 40 == 0) {
						ActivateMissile(gEnemyX[i]+22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
						ActivateMissile(gEnemyX[i]-22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
					}
					if ((swFrame+4) % 40 == 0) {
						ActivateMissile(gEnemyX[i]+22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
						ActivateMissile(gEnemyX[i]-22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
					}
					if ((swFrame+6) % 40 == 0) {
						ActivateMissile(gEnemyX[i]+22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
						ActivateMissile(gEnemyX[i]-22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
					}
					if ((swFrame+8) % 40 == 0) {
						ActivateMissile(gEnemyX[i]+22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
						ActivateMissile(gEnemyX[i]-22, gEnemyY[i]+30, 4, 0, SP_E_MISSILE_2);
					}

					if (swFrame % 35 == 0 && RandRatio(30)) {
						RotateCannon(gEnemyX[i]+10, gEnemyY[i]+20, P_TYPE);
						ActivateMissile(gEnemyX[i]+10, gEnemyY[i]+20, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 25 == 0 && RandRatio(20)) {
						RotateCannon(gEnemyX[i]-10, gEnemyY[i]+20, P_TYPE);
						ActivateMissile(gEnemyX[i]-10, gEnemyY[i]+20, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}

				}

				if(gBossState==1){
					if (gEnemyY[i]+30 > swHeight -80) {
						gEnemyDY[i] = -1;
//						gEnemyY -= 3;
					}
					else if (gEnemyY[i] < 50) {
						gEnemyDY[i] = 1;
					}
					else {
						gEnemyDY[i] = Rand(-1, 2);
					}
					
					if (gEnemyX[i] < 20) {
						gEnemyDX[i] = Rand(0, SPEED_ENEMY_P+1);
					}
					else if (gEnemyX[i] > swWidth-20) {
						gEnemyDX[i] = -Rand(0, SPEED_ENEMY_P+1);
					}
					else {
						if (RandRatio(20))
							gEnemyDX[i] = Rand(-SPEED_ENEMY_P, SPEED_ENEMY_P+1);
					}
				}
				else{
					gEnemyDX[i] = 0;
					gEnemyDY[i] = 2;
				}
				break;
			case Q_TYPE:
				if (gBossState==1) {
					if (swFrame % 50 == 0 && RandRatio(40)) {
						ActivateMissile(gEnemyX[i]+21, gEnemyY[i]+4, 3, GET_X(225, SP_E_MISSILE_1),GET_Y(225, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+21, gEnemyY[i]+4, 3, GET_X(270, SP_E_MISSILE_1),GET_Y(270, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]+21, gEnemyY[i]+4, 3, GET_X(315, SP_E_MISSILE_1),GET_Y(315, SP_E_MISSILE_1));
					}
					if (swFrame % 50 == 0 && RandRatio(40)) {
						ActivateMissile(gEnemyX[i]-21, gEnemyY[i]+4, 3, GET_X(225, SP_E_MISSILE_1),GET_Y(225, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]-21, gEnemyY[i]+4, 3, GET_X(270, SP_E_MISSILE_1),GET_Y(270, SP_E_MISSILE_1));
						ActivateMissile(gEnemyX[i]-21, gEnemyY[i]+4, 3, GET_X(315, SP_E_MISSILE_1),GET_Y(315, SP_E_MISSILE_1));
					}
					if (swFrame % 60 == 0 && RandRatio(70)) {
						ActivateMissile(gEnemyX[i]+5, gEnemyY[i]+24, 4, 0, SP_E_MISSILE_3);
						ActivateMissile(gEnemyX[i]-5, gEnemyY[i]+24, 4, 0, SP_E_MISSILE_3);
					}
					if ((swFrame+2) % 60 == 0 && RandRatio(70)) {
						ActivateMissile(gEnemyX[i]+5, gEnemyY[i]+24, 4, 0, SP_E_MISSILE_3);
						ActivateMissile(gEnemyX[i]-5, gEnemyY[i]+24, 4, 0, SP_E_MISSILE_3);
					}

					if (swFrame % 25 == 0 && RandRatio(40)) {
						RotateCannon(gEnemyX[i]+21, gEnemyY[i]-6, P_TYPE);
						ActivateMissile(gEnemyX[i]+21, gEnemyY[i]-6, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 25 == 0 && RandRatio(45)) {
						RotateCannon(gEnemyX[i]-21, gEnemyY[i]-6, P_TYPE);
						ActivateMissile(gEnemyX[i]-21, gEnemyY[i]-6, 0, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}

				}

				if(gBossState==1){
					if (gEnemyY[i]+30 > swHeight -80) {
//						gEnemyDY[i] = -1;
						gEnemyDY[i] = Rand(-2, 2);
//						gEnemyY -= 3;
					}
					else if (gEnemyY[i] < 50) {
						gEnemyDY[i] = 1;
					}
					else {
						gEnemyDY[i] = Rand(-1, 2);
					}
				}
				else{
					gEnemyDX[i] = 0;
					gEnemyDY[i] = 2;
				}
				break;
			case R_TYPE:
				if (gBossState==1) {
					if (swFrame % 30 == 0 && Rand(0 , 3)) {
						ActivateMissile(gEnemyX[i]+GET_X(203, 16), gEnemyY[i]+40+GET_Y(203, 16), 3, GET_X(203, SP_E_MISSILE_2),GET_Y(203, SP_E_MISSILE_2));
						ActivateMissile(gEnemyX[i]+GET_X(225, 16), gEnemyY[i]+40+GET_Y(225, 16), 3, GET_X(225, SP_E_MISSILE_2),GET_Y(225, SP_E_MISSILE_2));
						ActivateMissile(gEnemyX[i]+GET_X(247, 16), gEnemyY[i]+40+GET_Y(247, 16), 3, GET_X(247, SP_E_MISSILE_2),GET_Y(247, SP_E_MISSILE_2));
						ActivateMissile(gEnemyX[i]+GET_X(270, 16), gEnemyY[i]+40+GET_Y(270, 16), 3, GET_X(270, SP_E_MISSILE_2),GET_Y(270, SP_E_MISSILE_2));
						ActivateMissile(gEnemyX[i]+GET_X(293, 16), gEnemyY[i]+40+GET_Y(293, 16), 3, GET_X(293, SP_E_MISSILE_2),GET_Y(293, SP_E_MISSILE_2));
						ActivateMissile(gEnemyX[i]+GET_X(315, 16), gEnemyY[i]+40+GET_Y(315, 16), 3, GET_X(315, SP_E_MISSILE_2),GET_Y(315, SP_E_MISSILE_2));
						ActivateMissile(gEnemyX[i]+GET_X(337, 16), gEnemyY[i]+40+GET_Y(337, 16), 3, GET_X(337, SP_E_MISSILE_2),GET_Y(337, SP_E_MISSILE_2));
					}
					if (swFrame % 4 == 0) {
						ActivateMissile(gEnemyX[i], gEnemyY[i]-18, 2, GET_X(gMissileDegree[(swFrame/3)%16], SP_E_MISSILE_0),GET_Y(gMissileDegree[(swFrame/3)%16], SP_E_MISSILE_0));
					}
//					if (swFrame % 50 == 0 && RandRatio(50)) {
//						ActivateMissile(gEnemyX[i], gEnemyY[i]+65, 5, 0, SP_E_MISSILE_2);
//					}

					if (swFrame % 15 == 0 && RandRatio(50)) {
						RotateCannon(gEnemyX[i]+24, gEnemyY[i]+10, P_TYPE);
						ActivateMissile(gEnemyX[i]+24, gEnemyY[i]+10, 3, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
						RotateCannon(gEnemyX[i]-24, gEnemyY[i]+10, P_TYPE);
						ActivateMissile(gEnemyX[i]-24, gEnemyY[i]+10, 3, GET_X(gMissileDegree[temp4], SP_E_MISSILE_0),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_0));
					}
					if (swFrame % 15 == 0 && RandRatio(50)) {
						RotateCannon(gEnemyX[i]+43, gEnemyY[i]+15, P_TYPE);
						ActivateMissile(gEnemyX[i]+43, gEnemyY[i]+15, 3, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
						RotateCannon(gEnemyX[i]-43, gEnemyY[i]+15, P_TYPE);
						ActivateMissile(gEnemyX[i]-43, gEnemyY[i]+15, 3, GET_X(gMissileDegree[temp4], SP_E_MISSILE_1),GET_Y(gMissileDegree[temp4], SP_E_MISSILE_1));
					}

				}

				if(gBossState==1){
					if (gEnemyY[i]+40 > swHeight -100) {
						gEnemyDY[i] = Rand(-2, 2);
//						gEnemyY -= 3;
					}
					else if (gEnemyY[i] < 50) {
						gEnemyDY[i] = 1;
					}
					else {
						gEnemyDY[i] = Rand(-1, 2);
					}
					
					if (gEnemyX[i] < 20) {
						gEnemyDX[i] = Rand(0, SPEED_ENEMY_P+1);
					}
					else if (gEnemyX[i] > swWidth-20) {
						gEnemyDX[i] = -Rand(0, SPEED_ENEMY_P+1);
					}
					else {
						if (RandRatio(20))
							gEnemyDX[i] = Rand(-SPEED_ENEMY_P, SPEED_ENEMY_P+1);
					}
				}
				else{
					gEnemyDX[i] = 0;
					gEnemyDY[i] = 2;
				}
				break;
			}

			gEnemyX[i] += gEnemyDX[i];
			gEnemyY[i] += gEnemyDY[i];
			if (gEnemyY[i] > swHeight+100 || gEnemyY[i] < -110 || gEnemyX[i] > swWidth+100 || gEnemyX[i] < -100)
			{
				gEnemyS[i] = FS_GHOST;
				gEnemyCount--;
			}
		}
	}
}

void MoveFlightMissile()
{
	int i, j;

	for (i = 0; i < MAX_FLIGHTMISSILE; i++) {
		if (gFlightMissileS[i] == FS_ACTIVATE) {
			gFlightMissileX[i] += gFlightMissileDX[i];
			gFlightMissileY[i] += gFlightMissileDY[i];

			if (gFlightMissileY[i] < 0) {
				gFlightMissileS[i] = FS_GHOST;
				gFlightMissileCount--;
				continue;
			}

			for (j = 0; j < MAX_ENEMY; j++) {
				if (gEnemyS[j] == FS_ACTIVATE && HitCheck(gFlightMissileX[i], gEnemyX[j], 12+gFlightMissileT[i]) && HitCheck(gFlightMissileY[i], gEnemyY[j], 12+gFlightMissileT[i])) {
					gEnemyS[j] = FS_ATTACKED;
					gFlightMissileS[i] = FS_GHOST;
					gEnemyH[j] -= (10+(gFlightMissileT[i]*2));
					gFlightMissileCount--;
				}
			}
		}
	}

	if (gSpecial>0 && gSpecial<SPECIAL_TIME-6) {
		for (j = 0; j < MAX_ENEMY; j++) {
			if (gEnemyS[j] == FS_ACTIVATE && HitCheck(gFlightX, gEnemyX[j], 26) && gEnemyY[j]<gFlightY && gEnemyY[j]>0) {
				gEnemyS[j] = FS_ATTACKED;
				gEnemyH[j] -= SPECIAL_POWER;
			}
		}
	}
}

void MoveMissile()
{
	int i, j;

	if (gSpecial>0 && gSpecial<SPECIAL_TIME-6) {
		for (i = 0; i < MAX_MISSILE; i++) {
			gMissileS[i] = FS_GHOST;
			gMissileCount = 0;
		}
	}
	else {
		for (i = 0; i < MAX_MISSILE; i++) {
			if (gMissileS[i] == FS_ACTIVATE) {
				gMissileX[i] += gMissileDX[i];
				gMissileY[i] += gMissileDY[i];
				if (gMissileY[i] < 0 || gMissileY[i] > swHeight || gMissileX[i] < -20 || gMissileX[i] > swWidth+20) {
					gMissileS[i] = FS_GHOST;
					gMissileCount--;
					continue;
				}
			switch(gMissileT[i])
			{
			case 0:
			case 1:
			case 2:
			case 3:
				if (gFlightS == FS_ACTIVATE && HitCheck(gMissileX[i], gFlightX, 7) && HitCheck(gMissileY[i], gFlightY, 7)) {
					gFlightS = FS_DIE;
					gMissileS[i] = FS_GHOST;
					gMissileCount--;
					gSpecial = 0;
				}
				break;
			case 4:
				if (gFlightS == FS_ACTIVATE && HitCheck(gMissileX[i], gFlightX, 9) && HitCheck(gMissileY[i], gFlightY, 9)) {
					gFlightS = FS_DIE;
					gMissileS[i] = FS_GHOST;
					gMissileCount--;
					gSpecial = 0;
				}
				break;
			case 5:
				if (gFlightS == FS_ACTIVATE && HitCheck(gMissileX[i], gFlightX, 15) && HitCheck(gMissileY[i], gFlightY, 15)) {
					gFlightS = FS_DIE;
					gMissileS[i] = FS_GHOST;
					gMissileCount--;
					gSpecial = 0;
				}
				break;
			}
			}
		}
	}
}

void MoveBG()
{
	int i;

	for (i = 0; i < MAX_BG; i++)
	{
		if (gBGS[i] == FS_ACTIVATE)
		{
			gBGY[i] += SPEED_BG;

			if (gBGY[i] > swHeight+30)
			{
				gBGS[i] = FS_GHOST;
				gBGCount--;
			}
		}
	}
}

void MoveCloud()
{
	int i;

	for (i = 0; i < MAX_CLOUD; i++)
	{
		if (gCloudS[i] == FS_ACTIVATE)
		{
			gCloudY[i] += gCloudDY[i];

			if (gCloudY[i] > swHeight+60)
			{
				gCloudS[i] = FS_GHOST;
				gCloudCount--;
			}
		}
	}
}

void MoveItem()
{
	if (gItemS == FS_ACTIVATE)
	{
		gItemY += 1;

		if (gFlightS != FS_DIE && HitCheck(gItemX, gFlightX, 10) && HitCheck(gItemY, gFlightY, 10))
		{
			if (gItemT==IT_POWER) {
				Play_Sound(snd8_1);
				if (gFlightMT < 4)
					gFlightMT++;
			}
			else if (gItemT==IT_SPECIAL) {
				Play_Sound(snd8_3);
				if (gSpecialCount < 9)
					gSpecialCount++;
			}
		
			gItemS = FS_GHOST;
			gMissileCount--;
		}

		if (gItemY > swHeight+10)
		{
			gItemS = FS_GHOST;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// Drawing State Functions
/////////////////////////////////////////////////////////////////////////////
const int offset[] = {
	5, -2, 2, -1
};

void DrawGameLogo()
{
	if (gLogoCount>0)
		RestoreLCD();

	if (gLogoCount<5) {
		if (gLogoCount==0) {
			Clear(3);
			CopyImage(gCX, gCY, ImgLogo[0]);
			CopyImage(gCX, gCY, ImgLogo[1]);
			SaveLCD();
		}
	}
	else if (gLogoCount<15) {
		for (temp1=2; temp1<4; temp1++)
			CopyImage(gCX, (gLogoCount-5)*gCY/10, ImgLogo[temp1]);

		for (temp1=4; temp1<6; temp1++)
			CopyImage(gCX, swHeight-(gLogoCount-5)*gCY/10, ImgLogo[temp1]);
	}
	else if (gLogoCount<16) {
		for (temp1=6; temp1<10; temp1++)
			CopyImage(gCX, gCY, ImgLogo[temp1]);
	}
	else if (gLogoCount<24) {
		Clear(3);
		for (temp1=0; temp1<2; temp1++)
			CopyImage(gCX, gCY+offset[(gLogoCount-16)/2], ImgLogo[temp1]);
		for (temp1=6; temp1<10; temp1++)
			CopyImage(gCX, gCY+offset[(gLogoCount-16)/2], ImgLogo[temp1]);
	}
	else if (gLogoCount<28) {
		for (temp1=6; temp1<10; temp1++)
			CopyImage(gCX, gCY, ImgLogo[temp1]);
	}
	else if (gLogoCount<38) {
		for (temp1=6; temp1<10; temp1++)
			CopyImage(gCX, gCY-(gLogoCount-27)*37/10, ImgLogo[temp1]);
	}
	else {
		for (temp1=6; temp1<10; temp1++)
			CopyImage(gCX, gCY-37, ImgLogo[temp1]);
		if ((gLogoCount-38)%15<9)
			CopyImage(gCX, gCY, ImgLogo[10]);
		CopyImage(gCX, gCY, ImgLogo[11]);
	}

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif

	
}

void DrawGameMap()
{
	string tempstr;
	if (gMapCount==0) {
		ClearRGB(0, 179, 0);
		for (temp1=0; temp1<3; temp1++)
			CopyImage(gCX, gCY, imgMap[temp1]);
		SetImageAlpha(S_VDI_ALPHA_25PCT);
		for (temp1=0; temp1<22; temp1++)
			CopyImage(gCX-85+temp1*8, gCY-14, imgMap[3]);
		for (temp1=0; temp1<10; temp1++)
			CopyImage(gCX, gCY-10+temp1*8, imgMap[4]);
		SetColor(109);
		SetImageAlpha(S_VDI_OPAQUE);
		FillRectEx(gCX-88, gCY-55, gCX+87, gCY-22, S_VDI_ALPHA_25PCT);

		if(gStageFrame==0)// ù���� ��� missin ���� ���� �����ش�
			gMapCount=SHOW_MISSION_TIME+1;

		SaveLCD();
	}
	else
		RestoreLCD();


	if (gMapCount<10) {// mission clear
		CopyImage(gCX, gCY, imgMap[6]);
		CopyImage(gCX, gCY, imgMap[gStage+7]);
		switch (gStage) {
			case 0:
				CopyImage(gCX+54, gCY+23, imgMap[12]);
				break;
			case 1:
				CopyImage(gCX+22, gCY+7, imgMap[12]);
				break;
			case 2:
				CopyImage(gCX-42, gCY+7, imgMap[12]);
				break;
			case 3:
				CopyImage(gCX-34, gCY+39, imgMap[12]);
				break;
			case 4:
				CopyImage(gCX+6, gCY+47, imgMap[12]);
				break;
		}
	}
	else if (gMapCount<SHOW_MISSION_TIME) {
		CopyImage(gCX, gCY, imgMap[5]);
		switch (gStage) {
			case 0:
				CopyImage(gCX+54, gCY+23, imgDie[gMapCount%8/2]);
				break;
			case 1:
				CopyImage(gCX+22, gCY+7, imgDie[gMapCount%8/2]);
				break;
			case 2:
				CopyImage(gCX-42, gCY+7, imgDie[gMapCount%8/2]);
				break;
			case 3:
				CopyImage(gCX-34, gCY+39, imgDie[gMapCount%8/2]);
				break;
			case 4:
				CopyImage(gCX+6, gCY+47, imgDie[gMapCount%8/2]);
				break;
		}
	}
	else if (gMapCount==SHOW_MISSION_TIME){// stage ����
		gStageFrame = 0;
//		gMapCount = 0;
		gStage++;
		if(gStage == 4){
			gStage = 0;
			InitStage();
			GameEnding(ES_START, 0);
		}
		else{
			InitStage();
		}
	}
	else if (gMapCount<SHOW_MISSION_TIME*3){// mission ����
		CopyImage(gCX, gCY, imgMap[6]);
		CopyImage(gCX, gCY, imgMap[gStage+7]);
		temp3 = (gMapCount-SHOW_MISSION_TIME)/5;
		if(gMapCount%3 == 0 && temp3 <= 3){
			switch(Rand(0, 3)){
			case 0:
				Play_Sound(snd6_1);
				break;
			case 1:
				Play_Sound(snd6_2);
				break;
			case 2:
				Play_Sound(snd6_3);
				break;
			}
		}
		if(temp3 > 3)
			temp3 = 3;
		StrSub(tempstr, MissionText[gStage], 0, MissionTextIdx[gStage][temp3]);
		temp3 = StrLen(MissionText[gStage])/2*6;
		SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
		DrawStr(gCX-temp3, gCY-40, tempstr);
		if ((gMapCount-SHOW_MISSION_TIME)%8/4) {
			switch (gStage) {
			case 0:
				CopyImage(gCX+54, gCY+23, imgMap[12]);
				break;
			case 1:
				CopyImage(gCX+22, gCY+7, imgMap[12]);
				break;
			case 2:
				CopyImage(gCX-42, gCY+7, imgMap[12]);
				break;
			case 3:
				CopyImage(gCX-34, gCY+39, imgMap[12]);
				break;
			case 4:
				CopyImage(gCX+6, gCY+47, imgMap[12]);
				break;
			}
		}
	}
	else{// game run
		GameRun(ES_START, 0);
	}
	
}

void DrawGameMenu()
{
	if (gMenuCount==0) {
		ClearRGB(38, 43, 83);
		for (temp1=0; temp1<20; temp1++)
			CopyImage(gCX, gCY, imgMenu[temp1]);
		for (temp1=0; temp1<7; temp1++)
			CopyImageDir(gCX, gCY, imgMenu[temp1], 1);
		SaveLCD();
	}
	else
		RestoreLCD();


	switch (gSubIdx) {
	case 0: // �Ϲ� �޴�����
		for (temp1=0; temp1<3; temp1++)
			if (RandRatio(gMenuCount*5))
				CopyImage(gCX-36+temp1*27, gCY-41, imgMenu[temp1+20]);
		for (temp1=0; temp1<2; temp1++)
			if (RandRatio(gMenuCount*5))
				CopyImage(gCX-22+temp1*27, gCY-14, imgMenu[temp1+23]);

		if (gMenuCount>20)
			for (temp1=0; temp1<30; temp1++)
				CopyImage(gCX-60+temp1*4, gCY+19, imgMenu[30]);

		if (gMenuCount>20) {
			if (gMenuIdx<3)
				CopyImage(gCX-36+gMenuIdx*27, gCY-41, imgMenu[gMenuIdx+25]);
			else
				CopyImage(gCX-22+(gMenuIdx-3)*27, gCY-14, imgMenu[gMenuIdx+25]);

			if (gMenuIdx==1) { // �̾��ϱⰡ stage 1�����϶� disable��Ų��
				if (NVROM[4]<1)
					SetGamma(4);
				CopyImage(gCX, gCY+29, imgMenu[gMenuIdx+31]);
				CopyImage(gCX, gCY+43, imgMenu[gMenuIdx+36]);
				CopyImage(gCX, gCY+56, imgMenu[gMenuIdx+41]);
				SetGamma(3);
			}
			else {
				CopyImage(gCX, gCY+29, imgMenu[gMenuIdx+31]);
				CopyImage(gCX, gCY+43, imgMenu[gMenuIdx+36]);
				CopyImage(gCX, gCY+56, imgMenu[gMenuIdx+41]);
			}
		}
		break;
	case 1: // Help �غ� ��.
		if (gSubCount==2)
			temp1 = S_VDI_OPAQUE;
		else
			temp1 = S_VDI_ALPHA_50PCT;

		CopyImageEx(gCX-44, gCY-48, imgMenu[27], temp1, 0, 0, 0);
		SetClip(gCX-26, 0, swWidth, swHeight);
		CopyImageEx(gCX-15, gCY-41, imgMenu[38], temp1, 0, 0, 0);
		ResetClip();

		CopyImageTile(imgMenu[46], gCX-55, gCY-27, gCX+54, gCY+62, S_VDI_ALPHA_25PCT, 0, 0, 0);
		CopyImageEx(gCX-55, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_0);
		CopyImageEx(gCX+54, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_0);
		CopyImageEx(gCX-55, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_180);
		CopyImageEx(gCX+54, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_180);
		SaveLCD();
		if (gSubCount==2)
			gSubIdx = 2;
		break;
	case 2: // Help ���Ӽ��� ����
		if (gSubPage==0) {
			CopyImageTile(imgMenu[48], gCX-51, gCY-1, gCX+50, gCY+11, S_VDI_ALPHA_50PCT, 0, 0, 0);

			SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
			DrawStr(gCX-37, gCY, "1. ���� ����");
			DrawStr(gCX-37, gCY+23, "2. Ű ����");
		}
		else {
			if (gSubPage!=1)
				CopyImageDir(gCX-52, gCY+51, imgMenu[50], 0);
			if (gSubPage!=7)
				CopyImageDir(gCX+52, gCY+51, imgMenu[50], 1);
			SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
			for (temp1=0; temp1<5; temp1++)
				DrawStr(gCX-53, gCY-25+15*temp1, HelpText[(gSubPage-1)*5+temp1]);
		}
		break;
	case 3: // Help Ű���� ����
		if (gSubPage==0) {
			CopyImageTile(imgMenu[48], gCX-51, gCY+22, gCX+50, gCY+34, S_VDI_ALPHA_50PCT, 0, 0, 0);

			SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
			DrawStr(gCX-37, gCY, "1. ���� ����");
			DrawStr(gCX-37, gCY+23, "2. Ű ����");
		}
		else {
			SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
			for (temp1=0; temp1<6; temp1++)
				DrawStr(gCX-53, gCY-25+15*temp1, KeyText[temp1]);
			CopyImage(gCX-52, gCY+33, imgMenu[51]);
		}
		break;
	}

	gMenuCount++;

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif


	
}

void DrawGameOption()
{
	if (gMenuCount<3) {
		if (gMenuCount==0) {
			ClearRGB(38, 43, 83);
			for (temp1=0; temp1<20; temp1++)
				CopyImage(gCX, gCY, imgMenu[temp1]);
			for (temp1=0; temp1<7; temp1++)
				CopyImageDir(gCX, gCY, imgMenu[temp1], 1);
		}

		CopyImageTile(imgMenu[46], gCX-55, gCY-27, gCX+54, gCY+62, S_VDI_ALPHA_25PCT, 0, 0, 0);
		CopyImageEx(gCX-55, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_0);
		CopyImageEx(gCX+54, gCY-27, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_0);
		CopyImageEx(gCX-55, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_MIRROR, S_VDI_ROTATE_180);
		CopyImageEx(gCX+54, gCY+62, imgMenu[47], S_VDI_OPAQUE, 0, S_DIR_NORMAL, S_VDI_ROTATE_180);

		if (gMenuCount==2)
			temp1 = S_VDI_OPAQUE;
		else
			temp1 = S_VDI_ALPHA_50PCT;

		CopyImageEx(gCX-44, gCY-48, imgMenu[28], temp1, 0, 0, 0);
		SetClip(gCX-26, 0, swWidth, swHeight);
		CopyImageEx(gCX-3, gCY-41, imgMenu[39], temp1, 0, 0, 0);
		ResetClip();

		if (gMenuCount==2)
			SaveLCD();
	}
	else
		RestoreLCD();

	SetGamma(3);
	CopyImage(gCX-46, gCY-18, imgMenu[52]);
	CopyImage(gCX-46, gCY+5, imgMenu[53]);
	CopyImage(gCX-46, gCY+28, imgMenu[54]);
	
	SetGamma(0);
	switch (gOptionIdx) {
	case 0:
		CopyImage(gCX-46, gCY-18, imgMenu[52]);
		break;
	case 1:
		CopyImage(gCX-46, gCY+5, imgMenu[53]);
		break;
	case 2:
		CopyImage(gCX-46, gCY+28, imgMenu[54]);
		break;
	}
	SetGamma(3);

	CopyImage(gCX-21, gCY-14, imgMenu[56]);
	for (temp1=0; temp1<4; temp1++)
		CopyImage(gCX-9+temp1*12, gCY-14, imgMenu[57]);

	CopyImage(gCX-21, gCY+9, imgMenu[56]);
	for (temp1=0; temp1<4; temp1++)
		CopyImage(gCX-9+temp1*12, gCY+9, imgMenu[57]);

	CopyImage(gCX-21, gCY+37, imgMenu[56]);
	CopyImage(gCX-9, gCY+37, imgMenu[57]);
	CopyImage(gCX-21, gCY+29, imgMenu[63]);

	CopyImageEx(gCX+13, gCY+50, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_0);
	CopyImageEx(gCX+25, gCY+58, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_180);
	CopyImageEx(gCX+38, gCY+53, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_90);
	CopyImageEx(gCX+42, gCY+57, imgMenu[50], 0, 0, S_DIR_NORMAL, S_VDI_ROTATE_270);

	for (temp1=0; temp1<gGameVolumeFX/2; temp1++)
		CopyImage(gCX-21+temp1*12, gCY-14, imgMenu[58+temp1]);
	for (temp1=0; temp1<gGameVolumeBGM/2; temp1++)
		CopyImage(gCX-21+temp1*12, gCY+9, imgMenu[58+temp1]);
	CopyImage(gCX-9-gGameVibrator*12, gCY+37, imgMenu[58]);
	
	gMenuCount++;

	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif

	
}


void DrawGameStory()
{
	// ������ �̵� �����
	if (WaitCount>0) {
		WaitCount--;
		return;
	}

	// ������ ������ �׸��� ���� �����·� ����.
	if (StoryLine+StoryPage==STORY_LEN) {
		WaitCount = STORY_DELAY;
		StoryLine++;
		return;
	} // ������������ �����°� ������ state�� �ٲ۴�.
	else if (StoryLine+StoryPage>STORY_LEN) {
		WaitCount = -1;
		return;
	}
		
	if (StoryLine==0)
		ClearRGB(38, 48, 83);
	else
		RestoreLCD();
	
	if (FontCount==0) {
		SetFontType(S_FONT_HUGE_DOUBLE, S_WHITE, S_BLACK, S_ALIGN_CENTER);
		DrawStr(swWidth/2, 8+StoryLine*15-10, HelpText[StoryLine+StoryPage])	;
	}
	else if (FontCount==1) {
		SetFontType(S_FONT_DOUBLE, S_WHITE, S_BLACK, S_ALIGN_CENTER);
		DrawStr(swWidth/2, 8+StoryLine*15-6, HelpText[StoryLine+StoryPage])	;
	}
	else if (FontCount==2) {
		SetFontType(S_FONT_HUGE, S_WHITE, S_BLACK, S_ALIGN_CENTER);
		DrawStr(swWidth/2, 8+StoryLine*15-2, HelpText[StoryLine+StoryPage])	;
	}
	else {
		SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_CENTER);
		DrawStr(swWidth/2, 8+StoryLine*15, HelpText[StoryLine+StoryPage])	;
		SaveLCD();
	}

	if (++FontCount==4) {
		if (StoryLine<MaxStoryLine)
			StoryLine++;
		else {
			WaitCount = STORY_DELAY;
			StoryLine = 0;
			StoryPage += (MaxStoryLine+1);
		}
		FontCount = 0;
	}
	
}

void DrawGameRun()
{
	Clear(0);
//	Trace4("%d %d %d %d ", gOverCount, 0, 0, 0);

	DrawBackGround();
	//DrawCloud();
	DrawEnemys();
	if (gOverCount==0) {
		DrawFlightMissile();
		DrawFlight();
	}
	DrawMissile();
	DrawItem();
	DrawCloud();//��ġ����
	DrawScore();

	if (gOverCount>0) {
		if (gOverCount<20) {
			for (temp1=0; temp1<gOverCount/2; temp1++)
				CopyImageEx(gCX, gCY, imgMenu[49], S_VDI_ALPHA_25PCT, 0, 0, 0);
		}
		else {
			CopyImage(gCX, gCY, imgMenu[49]);
		}
	}
	
	#ifdef DISPLAY_FPS
	num_frame++;	// Get FPS
	etime = GetEllapsedTime();	// Get FPS
	DrawFPS();	// Get FPS
	#endif

	
}

/////////////////////////////////////////////////////////////////////////////
// Drawing Object Functions
/////////////////////////////////////////////////////////////////////////////

void DrawBackGround()
{
	int i;

	CopyLCD(1); // RestoreLCD();

	switch (gStage) {
	case 0: //stage 1
		for (i = 0; i < MAX_BG; i++)
			if (gBGS[i] == FS_ACTIVATE)
				CopyImage(gBGX[i], gBGY[i], imgBG1[gBGT[i]]);
		break;
	case 1: //stage 2
		for (i = 0; i < MAX_BG; i++)
			if (gBGS[i] == FS_ACTIVATE) {
				switch (gBGT[i]) {
				case 1:
					CopyImage(gBGX[i], gBGY[i], imgBG2[2]);
					CopyImage(gBGX[i], gBGY[i], imgBG2[1]);
					break;
				case 2:
					CopyImage(gBGX[i]+10, gBGY[i]+10, imgBG2[2]);
					CopyImage(gBGX[i], gBGY[i], imgBG2[2]);
					CopyImage(gBGX[i]+10, gBGY[i]+10, imgBG2[1]);
					CopyImage(gBGX[i], gBGY[i], imgBG2[1]);
					break;
				case 3:
					CopyImage(gBGX[i]+10, gBGY[i]-10, imgBG2[2]);
					CopyImage(gBGX[i]+10, gBGY[i]+10, imgBG2[2]);
					CopyImage(gBGX[i], gBGY[i], imgBG2[2]);
					CopyImage(gBGX[i]+10, gBGY[i]-10, imgBG2[1]);
					CopyImage(gBGX[i]+10, gBGY[i]+10, imgBG2[1]);
					CopyImage(gBGX[i], gBGY[i], imgBG2[1]);
					break;
				case 4:
					for (temp1=0; temp1<5; temp1++)
						CopyImage(gBGX[i], gBGY[i], imgBG2[temp1+9]);
					CopyImage(gBGX[i]-11, gBGY[i]-12, imgBG2[3]);
					CopyImage(gBGX[i]+17, gBGY[i]+11, imgBG2[3]);
					CopyImage(gBGX[i]+19, gBGY[i]-5, imgBG2[4]);
					CopyImage(gBGX[i]-19, gBGY[i]-34, imgBG2[4]);
					CopyImage(gBGX[i]-34, gBGY[i]-31, imgBG2[5]);
					CopyImage(gBGX[i]+6, gBGY[i]-50, imgBG2[5]);
					CopyImage(gBGX[i]+26, gBGY[i]-47, imgBG2[6]);
					CopyImage(gBGX[i]-7, gBGY[i]+7, imgBG2[6]);
					CopyImage(gBGX[i]+23, gBGY[i]-23, imgBG2[7]);
					CopyImage(gBGX[i]-28, gBGY[i]-28, imgBG2[7]);
					CopyImage(gBGX[i]+23, gBGY[i]-48, imgBG2[8]);
					CopyImage(gBGX[i]-8, gBGY[i]-2, imgBG2[8]);
					CopyImage(gBGX[i]+7, gBGY[i]+28, imgBG2[8]);
					break;
				}
			}
		break;
	case 2: //stage 3
		for (i = 0; i < MAX_BG; i++)
			if (gBGS[i] == FS_ACTIVATE) {
				switch (gBGT[i]) {
				case 1:
					CopyImage(gBGX[i], gBGY[i], imgBG3[4]);
					CopyImage(gBGX[i], gBGY[i], imgBG3[5]);
					CopyImage(gBGX[i]-30, gBGY[i]-40, imgBG3[1]);
					CopyImage(gBGX[i]-6, gBGY[i]-46, imgBG3[2]);
					CopyImage(gBGX[i]+15, gBGY[i]-33, imgBG3[3]);
					break;
				case 2:
					CopyImageDir(gBGX[i], gBGY[i], imgBG3[4], 1);
					CopyImageDir(gBGX[i], gBGY[i], imgBG3[5], 1);
					CopyImageDir(gBGX[i]+30, gBGY[i]-40, imgBG3[1], 1);
					CopyImageDir(gBGX[i]+6, gBGY[i]-46, imgBG3[2], 1);
					CopyImageDir(gBGX[i]-15, gBGY[i]-33, imgBG3[3], 1);
					break;
				case 3:
					CopyImage(gBGX[i], gBGY[i], imgBG3[1]);
					break;
				}
			}
		break;
	case 3: //stage 4
		for (i = 0; i < MAX_BG; i++)
			if (gBGS[i] == FS_ACTIVATE) {
				switch (gBGT[i]) {
				case 1:
					CopyImage(gBGX[i], gBGY[i], imgCloudS[0]);
					CopyImage(gBGX[i]-7, gBGY[i]-5, imgCloudS[0]);
					CopyImage(gBGX[i]+8, gBGY[i]+3, imgCloudS[0]);
					CopyImage(gBGX[i]-2, gBGY[i]-6, imgCloudS[0]);
					CopyImage(gBGX[i]+7, gBGY[i]-5, imgCloudS[0]);
					break;
				case 2:
					CopyImage(gBGX[i], gBGY[i], imgCloudS[1]);
					CopyImage(gBGX[i]-20, gBGY[i]-20, imgCloudS[1]);
					CopyImage(gBGX[i]+10, gBGY[i]-30, imgCloudS[0]);
					CopyImage(gBGX[i]-25, gBGY[i]+20, imgCloudS[0]);
					break;
				case 3:
					CopyImage(gBGX[i], gBGY[i], imgCloudS[2]);
					CopyImage(gBGX[i]-20, gBGY[i]-20, imgCloudS[2]);
					CopyImage(gBGX[i]+10, gBGY[i]-30, imgCloudS[0]);
					CopyImage(gBGX[i]-25, gBGY[i]+20, imgCloudS[0]);
					break;
				}
			}
		break;
	}
}



void DrawCloud()
{
	int i;

	for (i = 0; i < MAX_CLOUD; i++) {
		if (gCloudS[i] == FS_ACTIVATE) {
			SetImageAlpha(S_VDI_ALPHA_50PCT);
			CopyImage(gCloudX[i], gCloudY[i], imgCloudS[gCloudT[i]]);
		}
	}

	SetImageAlpha(S_VDI_OPAQUE);
}

#define IMG_INDEX_FLIGHT_DLEFT	0
#define IMG_INDEX_FLIGHT_LLEFT	1
#define IMG_INDEX_FLIGHT_STAND	2
#define IMG_INDEX_FLIGHT_LRIGHT	3
#define IMG_INDEX_FLIGHT_DRIGHT	4

void DrawFlight()
{
	for (temp1=0; temp1<gFlightLife-1; temp1++)
		CopyImageEx(swWidth-8-temp1*10, swHeight-10, imgMenu[64], S_VDI_ALPHA_75PCT, 0, 0, 0);
	
	CopyImageEx(2, swHeight-13, imgMenu[65], S_VDI_ALPHA_75PCT, 0, 0, 0);	
	CopyImageEx(28, swHeight-9, imgNumber[gSpecialCount], S_VDI_ALPHA_75PCT, 0, 0, 0);	

	switch(gFlightS)
	{
	case FS_ACTIVATE:
	case FS_GHOST:
		if (gFlightC > 0) {
			if (swFrame%4>>1)
				temp1 = S_VDI_ALPHA_25PCT;
			else
				temp1 = S_VDI_ALPHA_50PCT;
		}
		else {
			temp1 = S_VDI_OPAQUE;
		}

		if (gFlightS==FS_ACTIVATE && gSpecial>0 && gSpecial<SPECIAL_TIME-6) {
			switch(gFlightD) {
				case FD_NONE:
				case FD_DOWN:
					CopyImage(gFlightX, gFlightY, imgSpecial[IMG_INDEX_FLIGHT_STAND+16]);
					break;
				case FD_UP:
					CopyImage(gFlightX, gFlightY, imgSpecial[IMG_INDEX_FLIGHT_STAND+16]);
					break;
				case FD_LEFT:
				case FD_L_UP:
				case FD_L_DOWN:
					if (gFlightStep < 10)
						CopyImage(gFlightX, gFlightY, imgSpecial[IMG_INDEX_FLIGHT_LLEFT+16]);
					else
						CopyImage(gFlightX, gFlightY, imgSpecial[IMG_INDEX_FLIGHT_DLEFT+16]);
					break;
				case FD_RIGHT:
				case FD_R_UP:
				case FD_R_DOWN:
					if (gFlightStep < 10)
						CopyImage(gFlightX, gFlightY, imgSpecial[IMG_INDEX_FLIGHT_LRIGHT+16]);
					else
						CopyImage(gFlightX, gFlightY, imgSpecial[IMG_INDEX_FLIGHT_DRIGHT+16]);
					break;
			}
		}

		switch(gFlightD)
		{
		case FD_NONE:
		case FD_DOWN:
			CopyImageEx(gFlightX, gFlightY, imgFlight[IMG_INDEX_FLIGHT_STAND], temp1, 0, 0, 0);
			CopyImage(gFlightX, gFlightY+15, imgFlameS[swFrame3]);
			break;

		case FD_UP:
			CopyImageEx(gFlightX, gFlightY, imgFlight[IMG_INDEX_FLIGHT_STAND], temp1, 0, 0, 0);
			CopyImage(gFlightX, gFlightY+20, imgFlameL[swFrame3]);
			break;

		case FD_LEFT:
		case FD_L_UP:
		case FD_L_DOWN:
			if (gFlightStep < 10)
				CopyImageEx(gFlightX, gFlightY, imgFlight[IMG_INDEX_FLIGHT_LLEFT], temp1, 0, 0, 0);
			else
				CopyImageEx(gFlightX, gFlightY, imgFlight[IMG_INDEX_FLIGHT_DLEFT], temp1, 0, 0, 0);
			CopyImage(gFlightX, gFlightY+15, imgFlameS[swFrame3]);
			if (gFlightD==FD_L_UP)
				CopyImage(gFlightX, gFlightY+20, imgFlameL[swFrame3]);
			else
				CopyImage(gFlightX, gFlightY+15, imgFlameS[swFrame3]);
			break;

		case FD_RIGHT:
		case FD_R_UP:
		case FD_R_DOWN:
			if (gFlightStep < 10)
				CopyImageEx(gFlightX, gFlightY, imgFlight[IMG_INDEX_FLIGHT_LRIGHT], temp1, 0, 0, 0);
			else
				CopyImageEx(gFlightX, gFlightY, imgFlight[IMG_INDEX_FLIGHT_DRIGHT], temp1, 0, 0, 0);
			if (gFlightD==FD_R_UP)
				CopyImage(gFlightX, gFlightY+20, imgFlameL[swFrame3]);
			else
				CopyImage(gFlightX, gFlightY+15, imgFlameS[swFrame3]);
			break;
		}
		break;

	case FS_DIE:
		CopyImage(gFlightX, gFlightY, imgDie[gFlightC/2]);
		break;
	}
}
void SaveEnding()
{
	int i;

	gBGCount = 3;

	for (i = 0; i < MAX_BG; i++)
	{
		gBGS[i]		= FS_GHOST;
		gBGX[i]		= 0;
		gBGY[i]		= 0;
		gBGT[i]		= 0;
	}

	gBGS[0]		= FS_ACTIVATE;
	gBGT[0]		= 4;
	gBGX[0]		= 0;
	gBGY[0]		= swHeight-60;

	gBGS[1]		= FS_ACTIVATE;
	gBGT[1]		= 3;
	gBGX[1]		= swWidth-20;
	gBGY[1]		= swHeight-80;

	gBGS[2]		= FS_ACTIVATE;
	gBGT[2]		= 2;
	gBGX[2]		= 40;
	gBGY[2]		= swHeight-110;

	SetActiveBuffer(1);
	CopyImageTile(imgBG3[0], 0, 0, swWidth, swHeight, 0, 0, 0, 0);
	SetActiveBuffer(0);

}

void ActivateEnding()
{
	int i;

	for (i = 0; i < MAX_BG; i++)
	{
		if (gBGCount > 3)	break;
		if (gBGS[i] == FS_GHOST)
		{
			gBGS[i]	= FS_ACTIVATE;

			// 1, 2 type(���ƽý�)�� ��� i �� 0�϶��� ���(���ϴ� layer)
			if (i==0)
				gBGT[i]	= Rand(1, 4);
			else
				gBGT[i]	= Rand(3, 4);

			switch(gBGT[i]) {
			case 1:
				gBGX[i]		= Rand(-20, swWidth+20);
				gBGY[i]		= -50;
				break;
			case 2:
				gBGX[i]		= Rand(-20, swWidth+20);
				gBGY[i]		= -50;
				break;
			case 3:
				gBGX[i]		= Rand(-20, swWidth+20);
				gBGY[i]		= -50;
				break;
			}
			gBGCount++;
		}
	}
}
void MoveEnding()
{
	int i;

	for (i = 0; i < MAX_BG; i++)
	{
		if (gBGS[i] == FS_ACTIVATE)
		{
			gBGY[i] += SPEED_BG;

			if (gBGY[i] > swHeight+30)
			{
				gBGS[i] = FS_GHOST;
				gBGCount--;
			}
		}
	}
}

void DrawGameEnding()
{
	int i,t;
	t = gLogoCount/10;

	SetFontType(S_FONT_LARGE, S_WHITE, S_BLACK, S_ALIGN_LEFT);
	for(i = 0; i < END_TEXT_LEN; i++){
		DrawStr(10, swHeight +10- gLogoCount + 15*i, EndingText[i]);
	}
	gLogoCount++;
	if(gLogoCount > 800 && gLogoCount < 1500){
		CopyImage(swWidth/2, swHeight/2, imgMenu[49]);
	}
	else if(gLogoCount >= 1500){
		GameLogo(ES_START, 0);
	}


}

void RotateCannon(int x, int y,int type)
{
	int tx,ty;
	tx = gFlightX - x;
	ty = gFlightY - y;

	temp3 = 1;// ���� �̹��� ����
	if (ty>0) {
		temp4 = tx*100/ty;
		if (temp4<=-150)
			temp3 = 13;
		else if (-150<temp4 && temp4<=-67)
			temp3 = 14;
		else if (-67<temp4 && temp4<=-20)
			temp3 = 15;
		else if (-20<temp4 && temp4<=20)
			temp3 = 0;
		else if (20<temp4 && temp4<=67)
			temp3 = 1;
		else if (67<temp4 && temp4<=150)
			temp3 = 2;
		else if (temp4>150)
			temp3 = 3;
	}
	else if (ty<0) {
		temp4 = -tx*100/ty;
		if (temp4<=-150)
			temp3 = 11;
		else if (-150<temp4 && temp4<=-67)
			temp3 = 10;
		else if (-67<temp4 && temp4<=-20)
			temp3 = 9;
		else if (-20<temp4 && temp4<=20)
			temp3 = 8;
		else if (20<temp4 && temp4<=67)
			temp3 = 7;
		else if (67<temp4 && temp4<=150)
			temp3 = 6;
		else if (temp4>150)
			temp3 = 5;
	}
	else if (ty==0) {
		if (tx<0)
			temp3 = 12;
		else if (tx>0)
			temp3 = 4;
		else
			temp3 = 0;
	}

	if(type == O_TYPE){
		//���ν�ºκ��� ����.
		temp4 = temp3;
		temp3 = gCannonDir1[temp3];
	}
	else{
		temp4 = temp3;
	}
	//temp3:���Ź���
	//temp4:�̻��Ϲ���
}


int rot[4] = {S_VDI_ROTATE_0,S_VDI_ROTATE_270,S_VDI_ROTATE_180,S_VDI_ROTATE_90};
void DrawEnemyImage(int x, int y, int type, int idx)
{
	switch(type) {
	case A1_TYPE:
		CopyImageEx (x, y, imgEnemyA[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case B1_TYPE:
	case B2_TYPE:
	case B3_TYPE:
	case B4_TYPE:
	case B5_TYPE:
		CopyImageEx (x, y, imgEnemyB[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case C1_TYPE:
	case C2_TYPE:
	case C3_TYPE:
	case C4_TYPE:
		CopyImageEx (x, y, imgEnemyC[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case D1_TYPE:
	case D2_TYPE:
	case D3_TYPE:
	case D4_TYPE:
		CopyImageEx (x, y, imgEnemyD[idx%4], 0, 0, 0, rot[idx/4]);
		break;

	case E1_TYPE:
	case E2_TYPE:
	case E3_TYPE:
	case E4_TYPE:
		CopyImage(x, y, imgEnemyE[swFrame%8]);
		break;

	case F1_TYPE:
	case F2_TYPE:
	case F3_TYPE:
		if (swFrame2)
			CopyImageEx (x, y, imgEnemyF[idx%4], 0, 0, 0, rot[idx/4]);
		else
			CopyImageEx (x, y, imgEnemyFadd[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case H1_TYPE:
	case H2_TYPE:
	case H3_TYPE:
		CopyImageEx (x, y, imgEnemyHadd[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case I1_TYPE:
	case I2_TYPE:
	case I3_TYPE:
		CopyImageEx (x, y, imgEnemyIadd[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case J1_TYPE:
		CopyImageEx (x, y, imgEnemyJ[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	case K1_TYPE:
		CopyImageEx (x, y, imgEnemyKadd[idx%4], 0, 0, 0, rot[idx/4]);
		break;
	}


}
void DrawEnemy(int i)
{
	int Y_offset;
	switch(gEnemyS[i]) {
	case FS_ACTIVATE:
	case FS_ATTACKED:
		if (gEnemyS[i]==FS_ATTACKED)
			SetGamma(1);

		temp1 = 1;// ���� �̹��� ����
		if (gEnemyDY[i]>0) {
			temp2 = gEnemyDX[i]*100/gEnemyDY[i];
			if (temp2<=-150)
				temp1 = 13;
			else if (-150<temp2 && temp2<=-67)
				temp1 = 14;
			else if (-67<temp2 && temp2<=-20)
				temp1 = 15;
			else if (-20<temp2 && temp2<=20)
				temp1 = 0;
			else if (20<temp2 && temp2<=67)
				temp1 = 1;
			else if (67<temp2 && temp2<=150)
				temp1 = 2;
			else if (temp2>150)
				temp1 = 3;
		}
		else if (gEnemyDY[i]<0) {
			temp2 = -gEnemyDX[i]*100/gEnemyDY[i];
			if (temp2<=-150)
				temp1 = 11;
			else if (-150<temp2 && temp2<=-67)
				temp1 = 10;
			else if (-67<temp2 && temp2<=-20)
				temp1 = 9;
			else if (-20<temp2 && temp2<=20)
				temp1 = 8;
			else if (20<temp2 && temp2<=67)
				temp1 = 7;
			else if (67<temp2 && temp2<=150)
				temp1 = 6;
			else if (temp2>150)
				temp1 = 5;
		}
		else if (gEnemyDY[i]==0) {
			if (gEnemyDX[i]<0)
				temp1 = 12;
			else if (gEnemyDX[i]>0)
				temp1 = 4;
			else
				temp1 = 0;
		}

		switch (gEnemyT[i]) {
		case A1_TYPE:
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], A1_TYPE, temp1);
			break;
		case B1_TYPE:
		case B2_TYPE:
		case B3_TYPE:
		case B4_TYPE:
		case B5_TYPE:
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], B1_TYPE, temp1);
			break;
		case C1_TYPE:
		case C2_TYPE:
		case C3_TYPE:
		case C4_TYPE:
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], C1_TYPE, temp1);
			break;
		case D1_TYPE:
		case D2_TYPE:
		case D3_TYPE:
		case D4_TYPE:
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], D1_TYPE, temp1);
			break;
		case E1_TYPE:
		case E2_TYPE:
		case E3_TYPE:
		case E4_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyE[swFrame%8]);
			break;
		case F1_TYPE:
		case F2_TYPE:
		case F3_TYPE:
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], F1_TYPE, temp1);
			break;
		case G1_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyG[0]);
			break;
		case H1_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyH[1]);
			RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], H1_TYPE, temp3);
			break;
		case H2_TYPE:
			CopyImageEx (gEnemyX[i], gEnemyY[i], imgEnemyH[1], 0, 0, 0, S_VDI_ROTATE_180);
			RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], H1_TYPE, temp3);
			break;
		case H3_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyH[0]);
			RotateCannon(gEnemyX[i],gEnemyY[i],H1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], H1_TYPE, temp3);
			break;
		case I1_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyI[0]);
			RotateCannon(gEnemyX[i],gEnemyY[i],I1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], I1_TYPE, temp3);
			break;
		case I2_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyI[1]);
			RotateCannon(gEnemyX[i],gEnemyY[i],I1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], I1_TYPE, temp3);
			break;
		case I3_TYPE:
			CopyImageEx (gEnemyX[i], gEnemyY[i], imgEnemyI[1], 0, 0, 0, S_VDI_ROTATE_180);
			RotateCannon(gEnemyX[i],gEnemyY[i],I1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], I1_TYPE, temp3);
			break;
		case J1_TYPE:
			RotateCannon(gEnemyX[i],gEnemyY[i],J1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i], J1_TYPE, temp3);
			break;
		case K1_TYPE:
			SetGamma(3);
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyK[0]);
			if (gEnemyS[i]==FS_ATTACKED)
				SetGamma(2);
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyK[1]);
			RotateCannon(gEnemyX[i],gEnemyY[i]+60,K1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i]+60, K1_TYPE, temp3);

			RotateCannon(gEnemyX[i],gEnemyY[i]+40,K1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i]+40, K1_TYPE, temp3);

			RotateCannon(gEnemyX[i],gEnemyY[i]-25,K1_TYPE);
			DrawEnemyImage(gEnemyX[i], gEnemyY[i]-25, K1_TYPE, temp3);
			break;
		case L1_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyL[0]);
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyL[1]);
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyL[2]);
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyL[3]);
			break;
		case M1_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyM[0]);
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyM[1]);
			if (gEnemyDY[i]!=0 && swFrame2)
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyM[2]);
			break;
		case N1_TYPE:
			CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyN[0]);
			break;
		case O_TYPE://stage 1 boss
			if (gBossState==1)
				Y_offset = 0;
			else if (gBossState==2)
				Y_offset = 100;
			else if (gBossState==3)
				Y_offset = 250;

			SetGamma(3);
			CopyImage(gEnemyX[i], gEnemyY[i]-200+Y_offset, imgEnemyO[0]);
			CopyImage(gEnemyX[i], gEnemyY[i]-200+Y_offset, imgEnemyO[1]);
			CopyImage(gEnemyX[i], gEnemyY[i]+Y_offset, imgEnemyO[2]);
			CopyImage(gEnemyX[i], gEnemyY[i]+Y_offset, imgEnemyO[3]);
			CopyImage(gEnemyX[i], gEnemyY[i]-200+Y_offset, imgEnemyO[4]);

			if (gBossState==2 && gEnemyS[i]==FS_ATTACKED)
				SetGamma(2);
			CopyImage(gEnemyX[i], gEnemyY[i]-200+Y_offset, imgEnemyO[5]);
			
			RotateCannon(gEnemyX[i]-21,gEnemyY[i]-104+Y_offset,O_TYPE);
			CopyImage(gEnemyX[i]-21, gEnemyY[i]-104+Y_offset, imgEnemyO[temp3+9]);

			RotateCannon(gEnemyX[i]+22,gEnemyY[i]-104+Y_offset,O_TYPE);
			CopyImage(gEnemyX[i]+22, gEnemyY[i]-104+Y_offset, imgEnemyO[temp3+9]);

			RotateCannon(gEnemyX[i]-21,gEnemyY[i]-138+Y_offset,O_TYPE);
			CopyImage(gEnemyX[i]-21, gEnemyY[i]-138+Y_offset, imgEnemyO[temp3+9]);

			RotateCannon(gEnemyX[i]+22,gEnemyY[i]-138+Y_offset,O_TYPE);
			CopyImage(gEnemyX[i]+22, gEnemyY[i]-138+Y_offset, imgEnemyO[temp3+9]);

			RotateCannon(gEnemyX[i]-21,gEnemyY[i]-160+Y_offset,O_TYPE);
			CopyImage(gEnemyX[i]-21, gEnemyY[i]-160+Y_offset, imgEnemyO[temp3+9]);

			RotateCannon(gEnemyX[i]+22,gEnemyY[i]-160+Y_offset,O_TYPE);
			CopyImage(gEnemyX[i]+22, gEnemyY[i]-160+Y_offset, imgEnemyO[temp3+9]);
			SetGamma(3);

			if (gBossState==1) {
				if (gEnemyS[i]==FS_ATTACKED)
					SetGamma(2);
				RotateCannon(gEnemyX[i],gEnemyY[i]-29+Y_offset,O_TYPE);
				CopyImage(gEnemyX[i], gEnemyY[i]-29+Y_offset, imgEnemyO[temp3]);
				RotateCannon(gEnemyX[i],gEnemyY[i]-64+Y_offset,O_TYPE);
				CopyImage(gEnemyX[i], gEnemyY[i]-64+Y_offset, imgEnemyO[temp3]);
			}
			else if (gBossState==2) {
				CopyImage(gEnemyX[i], gEnemyY[i]-64+Y_offset, imgEnemyO[24]);
				CopyImage(gEnemyX[i], gEnemyY[i]-29+Y_offset, imgEnemyO[24]);
				if (++gEnemyC[i] < 5) {
					CopyImage(gEnemyX[i], gEnemyY[i]-64+Y_offset, imgDie[3+gEnemyC[i]]);
					CopyImage(gEnemyX[i], gEnemyY[i]-29+Y_offset, imgDie[3+gEnemyC[i]]);
				}
			}
			else if (gBossState==3) {
				if (gEnemyY[i]<swHeight+10) {
					for (temp1=0; temp1<8; temp1++)
						CopyImage(gEnemyX[0]+Rand(-20, 20), gEnemyY[0]+Rand(0, swHeight), imgDieL[Rand(0, 7)]);
				}
			}
			break;
		case P_TYPE://stage 2 boss
			if (gBossState==1) {
				if (gEnemyS[i]==FS_ATTACKED)
					SetGamma(2);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyP[0]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyP[1]);
				SetGamma(3);
			}
			else if (gBossState==2) {
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyP[0]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyP[1]);
				if (gEnemyY[i]<swHeight+10) {
					for (temp1=0; temp1<8; temp1++)
						CopyImage(gEnemyX[0]+Rand(-20, 20), gEnemyY[0]+Rand(-20,20), imgDieL[Rand(0, 7)]);
				}
			}
			break;
		case Q_TYPE://stage 3 boss
			if (gBossState==1) {
				if (gEnemyS[i]==FS_ATTACKED)
					SetGamma(2);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyQ[0]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyQ[1]);
				SetGamma(3);
			}
			else if (gBossState==2) {
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyQ[0]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyQ[1]);
				if (gEnemyY[i]<swHeight+10) {
					for (temp1=0; temp1<8; temp1++)
						CopyImage(gEnemyX[0]+Rand(-20, 20), gEnemyY[0]+Rand(-20,20), imgDieL[Rand(0, 7)]);
				}
			}
			break;
		case R_TYPE://stage 4 boss
			if (gBossState==1) {
				if (gEnemyS[i]==FS_ATTACKED)
					SetGamma(2);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[0]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[1]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[2]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[3]);
				SetGamma(3);
			}
			else if (gBossState==2) {
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[0]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[1]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[2]);
				CopyImage(gEnemyX[i], gEnemyY[i], imgEnemyR[3]);
				if (gEnemyY[i]<swHeight+10) {
					for (temp1=0; temp1<8; temp1++)
						CopyImage(gEnemyX[0]+Rand(-20, 20), gEnemyY[0]+Rand(-20,20), imgDieL[Rand(0, 7)]);
				}
			}
			break;
		}
		SetGamma(3);
		break;

	case FS_DIE:
		if(gEnemyT[i] == K1_TYPE || gEnemyT[i] == L1_TYPE || gEnemyT[i] == M1_TYPE){
			temp3 = gEnemyC[i]/2;
			if(temp3 > 6)
				temp3 = 6;
			if (gEnemyT[i]==K1_TYPE) {
				CopyImage(gEnemyX[i], gEnemyY[i]-30, imgDieL[temp3]);
				CopyImage(gEnemyX[i], gEnemyY[i]+30, imgDieL[temp3]);
			}
			else if (gEnemyT[i]==L1_TYPE) {
				CopyImage(gEnemyX[i], gEnemyY[i], imgDieL[temp3]);

			}
			else if (gEnemyT[i]==M1_TYPE) {
				CopyImage(gEnemyX[i], gEnemyY[i], imgDieL[temp3]);
			}
		}
		else{
			if (gEnemyT[i]<G1_TYPE)
				CopyImage(gEnemyX[i], gEnemyY[i], imgDie[gEnemyC[i]]);
			else
				CopyImage(gEnemyX[i], gEnemyY[i], imgDie[3+gEnemyC[i]]);
		}
		break;
	}
}


void DrawEnemys()
{
	int i;

	for (i = 0; i < MAX_ENEMY; i++)
	{
		if(gEnemyT[i] == K1_TYPE || gEnemyT[i] == I1_TYPE || gEnemyT[i] == I2_TYPE || gEnemyT[i] == I2_TYPE || gEnemyT[i] == J1_TYPE
				|| gEnemyT[i] ==H1_TYPE || gEnemyT[i] ==H2_TYPE || gEnemyT[i] ==H3_TYPE || gEnemyT[i] == M1_TYPE)
			DrawEnemy(i);
	}
	for (i = 0; i < MAX_ENEMY; i++)
	{
		if(!(gEnemyT[i] == K1_TYPE || gEnemyT[i] == I1_TYPE || gEnemyT[i] == I2_TYPE || gEnemyT[i] == I2_TYPE || gEnemyT[i] == J1_TYPE
				|| gEnemyT[i] ==H1_TYPE || gEnemyT[i] ==H2_TYPE || gEnemyT[i] ==H3_TYPE || gEnemyT[i] == M1_TYPE))
			DrawEnemy(i);
	}
}

void DrawFlightMissile()
{
	int i;

	for (i = 0; i < MAX_FLIGHTMISSILE; i++)
	{
		if (gFlightMissileS[i] == FS_ACTIVATE)
		{
			CopyImage(gFlightMissileX[i], gFlightMissileY[i], imgFlightMissile[gFlightMissileT[i]*3+(i%4==3?1:i%4)]);
		}
	}

	SetImageAlpha(S_VDI_ALPHA_75PCT);
	if (gSpecial>SPECIAL_TIME-2) {
		gFlightShooting = 0;
		CopyImage(gFlightX, gFlightY, imgSpecial[2]);
	}
	else if (gSpecial>SPECIAL_TIME-4)
		CopyImage(gFlightX, gFlightY, imgSpecial[3]);
	else if (gSpecial>SPECIAL_TIME-6)
		CopyImage(gFlightX, gFlightY, imgSpecial[11]);
	else if (gSpecial>0) {
		for (temp1=0;temp1<=gFlightY/22;temp1++)
			CopyImage(gFlightX, gFlightY-temp1*22+(gSpecial%6)/2*5, imgSpecial[13]);
		if(swFrame % 4 < 2)
			CopyImage(gFlightX, gFlightY, imgSpecial[12]);
		else
			CopyImage(gFlightX, gFlightY, imgSpecial[21]);
		if (gSpecial==1)
			gFlightShooting = 1;
	}
	SetImageAlpha(S_VDI_OPAQUE);

	if (gSpecial>0)
		gSpecial--;
}

void DrawMissile()
{
	int i;

	for (i = 0; i < MAX_MISSILE; i++)
	{
		if (gMissileS[i] == FS_ACTIVATE)
		{
			switch(gMissileT[i])
			{
			case 0:
				CopyImage(gMissileX[i], gMissileY[i], imgMissileA[swFrame%5]);
				break;
			case 1:
				CopyImage(gMissileX[i], gMissileY[i], imgMissileB);
				break;
			case 2:
				CopyImage(gMissileX[i], gMissileY[i], imgMissileC);
				break;
			case 3:
				CopyImage(gMissileX[i], gMissileY[i], imgMissileD);
				break;
			case 4:
				CopyImage(gMissileX[i], gMissileY[i], imgMissileE);
				break;
			case 5:
				CopyImage(gMissileX[i], gMissileY[i], imgMissileF);
				break;
			}
		}
	}
}

void DrawItem()
{
	if (gItemS == FS_ACTIVATE)
	{
		if (gItemT==IT_POWER)
			CopyImage(gItemX, gItemY, imgItem[swFrame%4/2]);
		else
			CopyImage(gItemX, gItemY, imgItem[swFrame%4/2+4]);
	}
}

void DrawScore()
{
	CopyImage( 5, 5, imgNumber[(gGameScore/1000000)%10]);
	CopyImage(15, 5, imgNumber[(gGameScore/100000)%10]);
	CopyImage(25, 5, imgNumber[(gGameScore/10000)%10]);
	CopyImage(35, 5, imgNumber[(gGameScore/1000)%10]);
	CopyImage(45, 5, imgNumber[(gGameScore/100)%10]);
	CopyImage(55, 5, imgNumber[(gGameScore/10)%10]);
	CopyImage(65, 5, imgNumber[(gGameScore/1)%10]);
	
	if (gSilentMode)
		CopyImageEx(swWidth-16, 2, imgMenu[51], S_VDI_ALPHA_75PCT, 0, 0, 0);
}

#ifdef DISPLAY_FPS
	int	start_time;
	int	fps10;
	int etime;
	int num_frame;

	void SetStartTime()
	{
		int	time[4];

		GetTime(time);
		start_time = time[1]*60 + time[2];
		num_frame = 0;
	}

	int GetEllapsedTime()
	{
		int	time[4];
		int ctime, etime;

		GetTime(time);
		ctime = time[1]*60 + time[2];
		etime = ctime - start_time;

		if (etime < 0)
			etime += 3600;

		return etime;
	}

	void DrawFPS()
	{
		if (NOFPS)
			return;

		if (etime != 0)	// Get FPS
			fps10 = num_frame*10/etime;	// Get FPS
		else	// Get FPS
			fps10 = -1;	// Get FPS

		SetFontType(S_FONT_MEDIUM,S_WHITE,S_BLACK,S_ALIGN_RIGHT);
		MakeStr3(gOutStr, "F: %d FPS: %d.%d", num_frame, fps10/10, fps10%10);
		DrawStrSolid(swWidth, 1, gOutStr);
	}
#endif
