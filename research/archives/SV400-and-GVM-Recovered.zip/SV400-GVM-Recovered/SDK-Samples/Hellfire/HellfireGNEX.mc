//==============================================================================
//
//	SINJISOFT GAME
//
//	FILE NAME
//		HellfireGNEX.mc
//
//	DESCRIPTION
//		GNEX SDK Sample Program
//
//	REFERENCES
//		SWAP SDK Users Guide
//
//	Copyright (C) 2000 by SINJISOFT. All Rights Reserved.
//
//	HISTORY
//		2000. 8. 7  Version 1.00 Release
//
//==============================================================================

// Header Section
#ifdef _GVM
%{
	#DEFINE SCRIPTVER	2
	#DEFINE LCDCLASS	255
	#DEFINE IMAGETYPE	12
	#DEFINE AUDIOTYPE	255
	#DEFINE SCRIPTTYPE	1
	#DEFINE SCRIPTCPID	100
	#DEFINE SCRIPTID	2
	#DEFINE SCRIPTNAME	"Hellfire"
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM	255
%}
#else
%{
	#DEFINE PLAYERVER		4
	#DEFINE LCDCLASS	255
	#DEFINE IMAGETYPE	12
	#DEFINE AUDIOTYPE	255
	#DEFINE APPTYPE		1
	#DEFINE APPCPID		100
	#DEFINE APPID		2
	#DEFINE APPVER		256
	#DEFINE APPNAME		"Hellfire_GNEX"
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM	255
%}
#endif

#include <SScript.h>
#include "hellfire_gray.sbm"
#include "hellfire_bzr.ssd"
#include "Hellfire_Ma.ssd"

// Game state
#define	HE_LOGO				0
#define	HE_READY			1
#define	HE_RUN				2
#define	HE_CLEAR			3
#define	HE_OVER				4

#define ENEMYNONE		99
#define ENEMY1			0
#define ENEMY2			1
#define ENEMY3			2
#define ENEMY4			3
#define ENEMY5			4
#define ENEMY6			5
#define ENEMYBOSS		6
#define ENEMYBOOM		7

int	hfState;								// Game state

int	hfScore;							// Score
int	hsDist;								// Stage distance
int	hsLife;								// //Player life
int	hfShadowTime;						// Shadow mode

int	objShipX;
int	objShipY;

int	shotWing;
int	hfShotSize;						// Active shot size
int	hfActiveEShotSize;					// Active enemy shot size
int	hfEShotDelay;						// Enemy shot delay

int	SetBlastState;
int	SetBlastX;
int	SetBlastY;
int	HitLEIndex;
int	HitLEX;
int	HitLEY;
int	ShipHCheckX;
int	ShipHCheckY;
int	ShipHCheckRx;
int	ShipHCheckRy;
int	MakeEShotS;
int	MakeEShotX;
int	MakeEShotY;

int	objShotS[3];			
int	objShotX[3];			
int	objShotY[3];			

int	objEnemyS[5];			
int	objEnemyX[5];			
int	objEnemyY[5];			
int	objEnemyDx[5];			
int	objEnemyDy[5];			
int	objEnemyL[5];			

int	objEShotS[4];	
int	objEShotX[4];	
int	objEShotY[4];	

int	objBlastS[3];			
int	objBlastX[3];			
int	objBlastY[3];			
int	objBlastDx[3];			
int	objBlastDy[3];			

// Weapon start position from ship
int weaponStartY[3];

// Small enemy appear time(modular50) per stage
int senemyAppearTime[4];
int temp;
string OutString = "             ";	// ��¿�

///////////////////////////////////////////////////////////////////////////////
//	Global game control
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//	Start game variable
//
void StartHellfireGame()
{
	int i;

	hfScore = 0;			// Reset score
	hsLife = 5;				// Reset life

// ���� �ʱⰪ���� ó��
	shotWing = 0;
	hfShotSize = 0;						// Active shot size

	weaponStartY[0] = -5;
	weaponStartY[1] = 5;
	weaponStartY[2] = 0;
// bug fix : 2001.06.11 weaponStartY[3] = 0; ==> weaponStartY[2] = 0;

	senemyAppearTime[0] = 10;
	senemyAppearTime[1] = 15;
	senemyAppearTime[2] = 20;
	senemyAppearTime[3] = 25;

	// Global initialize
	hsDist = 0;
	hfShadowTime = 0;

	// Hellfire init
	objShipX = -10;
	objShipY = 25;

	// Hellfire shot init
	hfShotSize = 0;

	for (i = 0; i < 3; i++)
		objShotS[i] = 0;

	// Enemy init
	for (i = 0; i < 5; i++)
		objEnemyS[i] = 12;

	// Enemy shot init
	hfActiveEShotSize = 0;
	hfEShotDelay = 5;

	for (i = 0; i < 4; i++)
		objEShotS[i] = 3;

	// Blast init
	for (i = 0; i < 3; i++)
		objBlastS[i] = 0;
}

///////////////////////////////////////////////////////////////////////////////
//	Utilities
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//	Set blast object
//
static void SetBlast()
{
	int i;

	i = Rand(0, 2);

	for (i = 0; i < 3; i++) {
		if (objBlastS[i] = 0)
			break;
	}

  // 2001.06.11 ���� : Out of Array
	if ( i >= 3 )
		return;
		
	objBlastS[i] = SetBlastState;
	objBlastX[i] = SetBlastX;
	objBlastY[i] = SetBlastY;
}

///////////////////////////////////////////////////////////////////////////////
//	Battle ship control
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//	Launch ship shot
//
static void MakeShipShot()
{
	int i;

	// �߻�� ���ⰹ�� ����Ȯ��
	if (hfShotSize >= 3)	
		return;

	// objShot���� ��� ���ϴ� �׸� ã��
	for (i = 0; i < 3; i++) {
		if (objShotS[i] == 0) {

			// �߻�ó��
			objShotS[i] = 1;			// state = ���� �� ����
			objShotX[i] = objShipX;
			objShotY[i] = objShipY + weaponStartY[shotWing];

			PlaySound(HellSnd[1]);
			PlaySound(HellMa1[1]);
			shotWing = 1 - shotWing;
			hfShotSize++;
			break;
		}
	}
}

static void HitLargeEnemy()
{
	// Decrease enemy life
	objEnemyL[HitLEIndex]--;

	if (objEnemyL[HitLEIndex] == 0) {

		hfScore += 10;
		objEnemyS[HitLEIndex] = 11;
		objEnemyDx[HitLEIndex] = 3;	// Blast image HitLEIndex

		// Stage clear
		if (hfState == HE_RUN)
			hfState = HE_CLEAR;
	}
	else {
		SetBlastState = 2;
		SetBlastX = (HitLEX + objEnemyX[HitLEIndex])/2;
		SetBlastY = HitLEY;
		SetBlast();
	}
}

static void MoveShipShot()
{
	int i;
	int j;
	int k;
	int flag_done = 0;

	for (i = 0; i < 3; i++) {

		if (objShotS[i] == 0)
			continue;

		// Move
		objShotX[i] += 8;
		
		////////////////////////////////
		// Hit check
		////////////////////////////////

		for (j = 0; j < 5; j++) {

			if (objEnemyS[j] >= 11)
				continue;

			k = 0;
      flag_done = 0;
      
			////////////////////////////////
			// Hit small enemy
			////////////////////////////////

			if (objEnemyS[j] <= 5 &&
				 objEnemyX[j] >= objShotX[i]-9 &&
				 objEnemyX[j] <= objShotX[i]+9 &&
				 objEnemyY[j] >= objShotY[i]-6 &&
				 objEnemyY[j] <= objShotY[i]+6 )
			{
				hfScore += 2;
				objEnemyS[j] = 11;
				objEnemyDx[j] = 4;	// Blast image index
				k = 1;
			}

			////////////////////////////////
			// Hit large enemy
			////////////////////////////////

			else if (6 <= objEnemyS[j] && objEnemyS[j] <= 10 &&
					 objEnemyS[j] <= 10 &&
					 objEnemyX[j] >= objShotX[i]-16 &&
					 objEnemyX[j] <= objShotX[i]+16 &&
					 objEnemyY[j] >= objShotY[i]-13 &&
					 objEnemyY[j] <= objShotY[i]+13 )
			{
				HitLEIndex = j;
				HitLEX = objShotX[i];
				HitLEY = objShotY[i];
				HitLargeEnemy();
				k = 1;
			}

			if (k) {
				PlaySound(HellSnd[4]);
				PlaySound(HellMa1[4]);
				// Remove shot
				objShotS[i] = 0;
				hfShotSize--;
				//goto skip;
			  flag_done = 1;	
			}

      if (flag_done) continue;
			
		} //end of for

    if (flag_done) continue;

		// Out of range
		if (objShotX[i] > swWidth) {
			objShotS[i] = 0;
			hfShotSize--;
		}
//skip: ;
	}//end of for
}

///////////////////////////////////////////////////////////////////////////////
//	Battle ship crushed by enemy / enemy shot
//
static int ShipHitCheck()
{
	if (hfShadowTime > 0 || hfState != HE_RUN)
		return 0;

	// Hit body
	if ( ShipHCheckX >= objShipX-ShipHCheckRx + 7 &&
		 ShipHCheckX <= objShipX+ShipHCheckRx + 7 &&
		 ShipHCheckY >= objShipY-ShipHCheckRy + 2 &&
		 ShipHCheckY <= objShipY+ShipHCheckRy + 2) {

		PlaySound(HellSnd[2]);
		PlaySound(HellMa1[2]);
		StartVib(1);

		SetBlastState = 3;
		SetBlastX = objShipX;
		SetBlastY = objShipY;
		SetBlast();

		if (hsLife > 0) {
			hsLife--;
			hfShadowTime = 30;
		}
		else {
			hfState = HE_OVER;
		}
		return 1;
	}

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//	Enemy control
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//	Move enemy shot & hit check
//
static void MoveEShot()
{
	int i;

	if (hfEShotDelay > 0)
		hfEShotDelay--;

	for (i = 0; i < 4; i++) {

		if (objEShotS[i] == 3 || objEShotS[i] == 2)
			continue;

		objEShotX[i] -= 4;

		// Out of sight
		if (objEShotX[i] < 0) {
			hfActiveEShotSize--;
			objEShotS[i] = 3;
		}

		// Hit check
		ShipHCheckX = objEShotX[i];
		ShipHCheckY = objEShotY[i];
		ShipHCheckRx = 3;
		ShipHCheckRy = 3;
		if (ShipHitCheck()) {
			hfActiveEShotSize--;
			objEShotS[i] = 3;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
//	Move enemy shot
//
static void MakeEShot()
{
	int i;

	for (i = 0; i < 4; i++) {
		if (objEShotS[i] == 3) {

			PlaySound(HellSnd[3]);
			PlaySound(HellMa1[3]);

			hfActiveEShotSize++;
			hfEShotDelay = 5;
			objEShotS[i] = MakeEShotS;
			objEShotX[i] = MakeEShotX;
			objEShotY[i] = MakeEShotY;
			break;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
//	Move enemy
//
static void MoveEnemy()
{
	int i;

	for (i = 0; i < 5; i++) {

		// Move small enemy
		if (objEnemyS[i] <= 5) {
			objEnemyX[i] += objEnemyDx[i];

			// Disappear
			if (objEnemyX[i] < -10)
				objEnemyS[i] = 12;

			// Enemy shot
			if (hfEShotDelay == 0 &&
				Rand(0,20) && 
				hfActiveEShotSize < 4 - 1 &&
				objEnemyX[i] > 48) 
			{
				MakeEShotS = 0;
				MakeEShotX = objEnemyX[i];
				MakeEShotY = objEnemyY[i];
				MakeEShot();
			}

			// Ship crush check
			ShipHCheckX = objEnemyX[i];
			ShipHCheckY = objEnemyY[i];
			ShipHCheckRx = 9;
			ShipHCheckRy = 6;
			if (ShipHitCheck()) {
				objEnemyS[i] = 11;
				objEnemyDx[i] = 4;	// Blast image index
			}
		}

		// Move large enemy
		else if (objEnemyS[i] <= 10) {
			objEnemyX[i] += objEnemyDx[i];
			objEnemyY[i] += objEnemyDy[i];

			// Turn
			if (objEnemyY[i] < 12)
				objEnemyDy[i] = 1;
			else if (objEnemyY[i] >= 51)
				objEnemyDy[i] = -1;

			if (objEnemyX[i] < 48)
				objEnemyDx[i] = 1;
			else if (objEnemyX[i] > 96)
				objEnemyDx[i] = -1;

			// Enemy shot
			if (hfEShotDelay == 0 && Rand(0,70))
			{
				MakeEShotS = 1;
				MakeEShotX = objEnemyX[i];
				MakeEShotY = objEnemyY[i];
				MakeEShot();
			}

			// Ship crush check
			ShipHCheckX = objEnemyX[i];
			ShipHCheckY = objEnemyY[i];
			ShipHCheckRx = 16;
			ShipHCheckRy = 13;
			if (ShipHitCheck()) {
				HitLEIndex = i;
				HitLEX = objShipX;
				HitLEY = objShipY;
				HitLargeEnemy();
			}
		}

		// Blast
		else if (objEnemyS[i] == 11) {
			if (objEnemyDx[i] > 0)
				objEnemyDx[i] --;
			else
				objEnemyS[i] = 12;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
//	Move enemy
//
static void MakeNewEnemy()
{
	int i;
	int j;

	// Make small enemy
	for (i = 0; i < 4; i++) {

		if (senemyAppearTime[i] == hsDist%25)

			for (j = 0; j < 5; j++) {
				if (objEnemyS[j] == 12) {

					objEnemyS[j] = (hsDist/25)%6;
					objEnemyX[j] = 104;
					objEnemyDx[j] = -3;
					objEnemyY[j] = Rand(10, swHeight - 10);
					objEnemyDy[j] = 0;

					// Life
					objEnemyL[j] = 1;
					break;
				}
			}
	}

	// Make large enemy
	if (hsDist == 125)

		for (i = 0; i < 5; i++) {
			if (objEnemyS[i] == 12) {

				objEnemyS[i] = 6;
				objEnemyX[i] = 112;
				objEnemyDx[i] = -1;
				objEnemyY[i] = Rand(10, 40);
				if (objEnemyY[i] < 25)
					objEnemyDy[i] = -1;
				else
					objEnemyDy[i] = 1;

				// Life
				objEnemyL[i] = 20;
				break;
			}
		}
}

///////////////////////////////////////////////////////////////////////////////
//	Draw game screen
//
void DrawHellfireGame()
{
	int i;

	ClearWhite();

	// Advance distance
	if (hsDist < 130)
		hsDist++;

	// Draw status
	MakeStr3( OutString, "%d H%d %dKM",	hfScore, hsLife, (130 - hsDist)/5);
	DrawStr ( 10, 0, OutString );

	// Draw enemy
	for (i = 0; i < 5; i++) {
		if (objEnemyS[i] < 11)
			CopyImage(objEnemyX[i], objEnemyY[i], ImgEnemy[objEnemyS[i]*3 + swFrame3]);	
		else if (objEnemyS[i] == 11)
			CopyImage(objEnemyX[i], objEnemyY[i], ImgBoom[objEnemyDx[i]]);
	}

	// Draw ship
	if (hfShadowTime > 0)
		hfShadowTime--;
	if (hfShadowTime%2 == 0) {
		CopyImage(objShipX, objShipY, ImgHell[swFrame3]);
	}

	// Draw enemy shot
	for (i = 0; i < 4; i++) {
		switch (objEShotS[i]) {
		case 0:		CopyImage(objEShotX[i], objEShotY[i], ImgEShot);		break;
		case 1:		CopyImage(objEShotX[i], objEShotY[i], ImgEMissile[swFrame3]);	break;
		case 2:		CopyImage(objEShotX[i], objEShotY[i], ImgBoom[0]);		break;
		}
	}

	// Draw ship shot
	for (i = 0; i < 3; i++) {
		if (objShotS[i] == 1)
			CopyImage(objShotX[i], objShotY[i], ImgShot);
	}

	// Draw blast
	for (i = 0; i < 3; i++)
		if (objBlastS[i] > 0) {
			objBlastS[i]--;
			CopyImage(objBlastX[i], objBlastY[i], ImgBoom[objBlastS[i]]);
		}

	Flush();
}

///////////////////////////////////////////////////////////////////////////////
//	Hellfire game
//
void main () {
	// Init and Start Game
	StartHellfireGame();

	hfState = HE_LOGO;			// Reset state

	PlaySound(HellSnd[0]);		// //Play ThemeSong
	PlaySound(HellMa1[0]);
	SetTimer(300, 1);
	//LockChatMode(0);			// GNEX don't support this api anymore.
}

void EVENT_TIMEOUT () {
	switch (hfState) {

	case HE_LOGO:
		ClearWhite();
		CopyImage(swWidth/2, 4, ImgHellLogo[3]);
		CopyImage(Rand(swWidth/2, swWidth/2 + 1), Rand(swHeight/2, swHeight/2 + 2), ImgHellLogo[swFrame3]);
		Flush();
		break;

	case HE_READY:
		if (objShipX >= 20) {	// Take off
			hfState = HE_RUN;
			break;
		}
		objShipX += 6;
		DrawHellfireGame();
		break;

	case HE_RUN:
		MoveShipShot();
		MakeNewEnemy();
		MoveEnemy();
		MoveEShot();
		DrawHellfireGame();
		break;

	case HE_CLEAR:
		if (objShipX >= 96) {	// Take off
			hfState = HE_LOGO;
			PlaySound(HellSnd[0]);
			PlaySound(HellMa1[0]);
			break;
		}
		objShipX += 6;
		MoveShipShot();
		MoveEnemy();
		MoveEShot();
		DrawHellfireGame();
		break;

	case HE_OVER:
		if (objShipY >= 51) {
			hfState = HE_LOGO;	// Show score board
			PlaySound(HellSnd[0]);
			PlaySound(HellMa1[0]);
			break;
		}
		// Crushed ship
		objShipY += 2;
		MoveShipShot();
		MoveEnemy();
		MoveEShot();
		if (swFrame2 == 0) {
			SetBlastState = 3;
			SetBlastX = objShipX;
			SetBlastY = objShipY;
			SetBlast();
		}
		DrawHellfireGame();
		break;
	}
}

void EVENT_KEYPRESS () {
	switch (hfState) {
	case HE_LOGO:
		StartHellfireGame();
		hfState = HE_READY;
		break;

	case HE_RUN:
		switch ( swData ) {
			case 0x03:  MakeShipShot();												break;
			case 0x01:	if (objShipY >= 10)					objShipY -= 6;	break;
			case 0x07:	if (objShipY <= swHeight - 10 )		objShipY += 6;	break;
			case 0x04:	if (objShipX >= 15)					objShipX -= 6;	break;
			case 0x05:	if (objShipX <= swWidth - 15)		objShipX += 6;	break;
		}
	}
}