//==============================================================================
//
//	FILE NAME
//		MglTestGNEX.mc
//
//	DESCRIPTION
//		GNEX SDK Sample Program
//
//	Copyright (C) 2002 by SINJISOFT. All Rights Reserved.
//
//==============================================================================

// Header Section
#ifdef _GVM
%{
	#DEFINE SCRIPTVER	2
	#DEFINE LCDCLASS	255
	#DEFINE IMAGETYPE	12
	#DEFINE AUDIOTYPE	255
	#DEFINE SCRIPTTYPE	1
	#DEFINE SCRIPTCPID	100
	#DEFINE SCRIPTID	1
	#DEFINE SCRIPTNAME	"MglTest"
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM	255
%}
#else
%{
	#DEFINE PLAYERVER	4
	#DEFINE LCDCLASS	255
	#DEFINE IMAGETYPE	12
	#DEFINE AUDIOTYPE	255
	#DEFINE CARRIERTYPE	1
	#DEFINE APPTYPE		1
	#DEFINE APPCPID		100
	#DEFINE APPID		1
	#DEFINE APPNAME		"MglTest_GNEX"
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM	255
%}
#endif

#include <SScript.h>

#include "image\gray.sbm"
#include "image\color.sbm"
#include "image\tc.sbm"

#include "image\City.sbm"

string	strBitName[] = {
	"L/OK/R=MOV C=BACK U/D=GR1",
	"L/OK/R=MOV C=BACK U/D=GR2",
	"L/OK/R=MOV C=BACK U/D=GR4", 
	
	"L/OK/R=MOV C=BACK U/D=CR1",
	"L/OK/R=MOV C=BACK U/D=CR2",
	"L/OK/R=MOV C=BACK U/D=CR4",
	"L/OK/R=MOV C=BACK U/D=CR8", 
	
	"L/OK/R=MOV C=BACK U/D=TC1",
	"L/OK/R=MOV C=BACK U/D=TC2",
	"L/OK/R=MOV C=BACK U/D=TC4",
	"L/OK/R=MOV C=BACK U/D=TC8"
};

int		back, img;
int 	clip, gamma;
int		alpha, zoom, mirror, rotate;
int		x, y, dx;

extern 	int a;
extern	string str;

#define	MARGIN	30
#define	STEP	2

void Initialize()
{
	x = swWidth/2;
	y = swHeight/2 + 10;
	dx = STEP;
	
	back = 1;
	img = 0;
	clip = 0;
	gamma = 3;
	alpha = 0;
	zoom = 0;
	mirror = 0;
	rotate = 0;
	
#ifdef _GVM
	SetStrType(S_FONT_SMALL, S_WHITE, S_BLACK, S_ALIGN_CENTER);
#else
	SetFontType(S_FONT_SMALL, S_WHITE, S_BLACK, S_ALIGN_CENTER);
#endif
}

void Draw()
{
	RestoreLCD();
	
	if (clip == 1)
		SetClip(20, 40, swWidth - 21, swHeight - 21);
	SetGamma(gamma);

	switch (img)
	{
	case  0: 
#ifdef _GVM
		CopyImage(x, y, gray1);	
#else
		CopyImageEx(x, y, gray1, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  1: 
#ifdef _GVM
		CopyImage(x, y, gray2);	
#else
		CopyImageEx(x, y, gray2, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  2: 
#ifdef _GVM
		CopyImage(x, y, gray4);	
#else
		CopyImageEx(x, y, gray4, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  3: 
#ifdef _GVM
		CopyImage(x, y, color1);	
#else
		CopyImageEx(x, y, color1, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  4: 
#ifdef _GVM
		CopyImage(x, y, color2);	
#else
		CopyImageEx(x, y, color2, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  5: 
#ifdef _GVM
		CopyImage(x, y, color4);	
#else
		CopyImageEx(x, y, color4, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  6: 
#ifdef _GVM
		CopyImage(x, y, color8);	
#else
		CopyImageEx(x, y, color8, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  7: 
#ifdef _GVM
		CopyImage(x, y, tc1);	
#else
		CopyImageEx(x, y, tc1, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  8: 
#ifdef _GVM
		CopyImage(x, y, tc2);	
#else
		CopyImageEx(x, y, tc2, alpha, zoom, mirror, rotate);	
#endif
		break;

	case  9: 
#ifdef _GVM
		CopyImage(x, y, tc4);	
#else
		CopyImageEx(x, y, tc4, alpha, zoom, mirror, rotate);	
#endif
		break;

	case 10: 
#ifdef _GVM
		CopyImage(x, y, tc8);	
#else
		CopyImageEx(x, y, tc8, alpha, zoom, mirror, rotate);	
#endif
		break;

	}
	
	SetGamma(3);
	ResetClip();
	SetClip(0, 0, swWidth - 1, swHeight - 1);

	Flush();
}

extern int E_Func1( int a, int b );

void KeyPress(int key)
{
	string	str;

	switch (key)
	{
		case SWAP_KEY_LEFT:		if (dx > -20)	dx -= 2;	break;
		case SWAP_KEY_RIGHT:	if (dx < 20)	dx += 2;	break;
		case SWAP_KEY_OK:		x = swWidth/2;	dx = 0;		break;
		
		case SWAP_KEY_UP:		img = (img + 1)%11;			break;
		case SWAP_KEY_DOWN:		img = (img + 10)%11;		break;

		case SWAP_KEY_CLR:		back = 1 - back;			break;
					
		case SWAP_KEY_1:		clip = 1 - clip;			break;
		case SWAP_KEY_2:		gamma = (gamma + 1)%7;		break;
		case SWAP_KEY_3:		mirror = 1 - mirror;		break;
		case SWAP_KEY_4:		zoom = 1 - zoom;			break;
		case SWAP_KEY_5:		alpha = (alpha + 1)%6;		break;
		case SWAP_KEY_6:		rotate = (rotate + 1)%4;	break;
	}

#ifdef _GVM
	Clear(21);
#else
	ClearRGB(0, 129, 159);	
#endif

	if (clip == 1)
		SetClip(20, 40, swWidth - 21, swHeight - 21);
	if (back)		
#ifdef _GVM
		CopyImage(swWidth/2, swHeight/2, city);
#else
		CopyImageEx(swWidth/2, swHeight/2, city, 0, 0, 0, 0);
#endif
	ResetClip();
		
	DrawStrSolid(swWidth/2, 2, strBitName[img]);
	MakeStr3(str, "1=CLIP %d 2=GAMMA %d 3=MIRROR %d", clip, gamma, mirror);
	DrawStrSolid(swWidth/2, 10, str);
	MakeStr3(str, "4=ZOOM %d 5=ALPHA %d 6=ROTATE %d", zoom, alpha, rotate);
	DrawStrSolid(swWidth/2, 18, str);
	
	SaveLCD();
}

void Timeout_0()
{
	x += dx;
	
	if (x < -MARGIN)
	{
		x = swWidth + MARGIN;
		y = swHeight/2 + Rand(-30, 30);
	}
	else if (x > swWidth + MARGIN)
	{
		x = -MARGIN;
		y = swHeight/2 + Rand(0, 20);
	}
}

void main()
{
	Initialize();
	KeyPress(0);
	Draw();
	
	SetTimer(200, 1);
}		

void EVENT_TIMEOUT()
{
	Timeout_0();
	Draw();
}
	
void EVENT_KEYPRESS()
{	
	KeyPress(swData);
}