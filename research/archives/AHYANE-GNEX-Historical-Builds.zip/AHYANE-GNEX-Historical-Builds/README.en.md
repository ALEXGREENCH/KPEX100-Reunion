# AHYANE — historical GNEX builds

This preserves **13 distinct SGS builds of one project**, not 13 separate games:
six `bin/ahyane.sgs` versions with `COMPTYPE 2` and seven earlier
`bin/integral.sgs` versions with `COMPTYPE 0`. All recovered binaries are
**GNEX v4**. No bytes or headers were patched, replaced or rebuilt.

Primary source: [kosooyoul/gnex-dating-simulation-game](https://github.com/kosooyoul/gnex-dating-simulation-game).
History snapshot: `8cc4e441eb7c5d3a63c78fe2d2a9a7e1a4fc3517`, branch `master`, 31 commits.
`manifest.json` maps every SGS to a full commit, original path, Git blob SHA-1,
size, SHA-256 and CRC32. Filename prefixes are abbreviated commits, not inferred
compilation dates.

## Contents

- `builds/`: 13 unchanged SGS files, retaining historical basenames after a commit prefix.
- `history/gnex-dating-simulation-game.bundle`: a standard Git bundle of the complete public master history, preserving the author's sources, resources and tools. It contains Git objects/ref, not local Git configuration, hooks, credentials or research worktree files.
- `source-provenance.json`: provenance, static inspection, limited prior runtime observations and a compression-format clue.

Restore the source history with Git:

```sh
git clone history/gnex-dating-simulation-game.bundle ahyane-sources
```

This restores files/history; it is not an instruction to run historical software.
The original history contains Visual Basic map/event editors, including `.ex_`
binaries. They were not executed during preservation. Modern Windows usability,
project buildability and editor functionality are untested.

## Current Reunion status

The strict static parser accepts seven `COMPTYPE 0` containers. Layout acceptance
does not establish gameplay. An earlier coordinating research pass observed the
`dcc55fcf` build's title menu; its scenario ended `idle` after 219 events.
Held-key Continue navigation reached a black gameplay screen. Full playability
is unconfirmed, and this observation is not extended to all earlier versions.

The six `COMPTYPE 2` builds are rejected by the current strict parser snapshot.
This is **not a corruption claim**. In the latest stored build, `f40efc1f`, a
zlib stream at byte 80,050 reaches EOF and expands to 751,472 bytes, equal to
`831522 - 80050`, leaving one unused `FF` byte. This is a format clue, not a
working startup decoder. No reconstructed or "fixed" SGS is included.

`src/main.mc` contains an `_GVM` conditional declaring `SCRIPTVER 2`.
**No compiled GVM2 build was recovered in this set.** A source branch does not
substitute for a compiled binary.

The outer ZIP CRC and every manifested file hash were checked after clean
extraction. The packaged Git bundle was restored into a new bare repository and
passed Git fsck. All 13 SGS files were byte-compared with `git show commit:path`
from both the primary clone and the restored history. No game or historical
tool was executed or compiled by the packaging pass. Temporary URLs, research
environment configuration, saved states and raw execution traces are excluded.

Historical materials retain their original rights. The Reunion license does not
automatically relicense the author's repository.
