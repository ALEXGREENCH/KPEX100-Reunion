%{
// Header Section
#DEFINE SCRIPTVER		1					// script version
#DEFINE LCDCLASS		255				// ��� LCD ũ�� ����
#DEFINE IMAGETYPE		255			// image type	( BW : 1, 4GRAY : 2 )
#DEFINE AUDIOTYPE		255			// buzzer:1
#DEFINE VOCTYPE			255
#DEFINE SCRIPTTYPE		1				// script type	( StandAlone )
#DEFINE SCRIPTCPID		100			// script cp id
#DEFINE SCRIPTID		75					// script id
#DEFINE SCRIPTNAME	    "Test"		// script name
%}

#include "sscript.h"
#include "Test.sbm"		// �̹���
#include "Test.ssd"		// ����

void Init()
{
	
}

void main()
{
	
}

void EVENT_KEYPRESS()
{
	
}

void EVENT_TIMEOUT()
{
	
}
