# Sinjisoft GNEX Zone handset cards

Preserved 2026-11-05: 52 anonymous public Sinjisoft handset-card HTML payloads,
plus the linked handset inventory HTML and navigation SWF. All 54 source payloads
match the historical Wayback CDX SHA1 digest. Raw sources are unchanged.

The 52 paths were already known: 36 technical profiles were newly read; 13 prior
exact raw cards were reused locally; 3 older replay wrappers were replaced by
their exact raw captures. These are not 52 newly discovered devices or games.

manifest.json records original/capture URLs, dates, bytes, CDX SHA1, SHA256 and
parsed facts. Fixed ZIP timestamps are packaging metadata, not source dates.
HTML may refer to omitted website images/styles: this is source preservation,
not a functional offline website mirror. The SWF is site navigation, not a game.
No source code, Flash, handset firmware, downloaded executables or callbacks ran.

Source anomalies are retained: unknown DD-600 height; SCH-X230 176x149 versus
physical 120x160; SCH-V330 128x178 versus SDK skin 176x178; S2 AUDIOTYPE 5 with MA5;
PG-S5000 AUDIOTYPE 64 with MA3; SCH-S140 650K label. Runtime labels such as GVM4X
must not be reinterpreted as an extracted SGS file-header version.

Historical materials retain their original rights; the Reunion MIT licence
does not relicense these vendor pages. Provenance is supplied for preservation.
