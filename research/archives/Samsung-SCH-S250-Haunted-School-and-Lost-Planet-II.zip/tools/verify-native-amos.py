import argparse
from hashlib import sha256
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import (
    UC_ARM_REG_R0,
    UC_ARM_REG_R1,
    UC_ARM_REG_R2,
    UC_ARM_REG_PC,
    UC_ARM_REG_SP,
    UC_ARM_REG_LR,
)
from struct import unpack
from zipfile import ZipFile
from pathlib import Path
import json

parser = argparse.ArgumentParser(
    description="Compare expanded Amos resources with the original decoder"
)
parser.add_argument("rom", type=Path)
parser.add_argument("resources", type=Path)
args = parser.parse_args()
with args.rom.open("rb") as source:
    B = source.read(19_300_353)
if (
    len(B) != 19_300_352
    or sha256(B).hexdigest()
    != "ea94aac903d463a943423d4b1e682da4de0c9010f41e06a9aaa0dedefa6fad7b"
):
    parser.error("Unexpected SCH-S250 YD01 ROM size or SHA-256")
m = Uc(UC_ARCH_ARM, UC_MODE_ARM)
m.mem_map(0, 0x2000000)
m.mem_write(0, B[0x8000 : 0x8000 + 0x1000000])
allocator = 0x2EC4EA - 0x8000
output = 0x1A00000
ret = 0xFF0000
record = 0x1D00000


def allocate(uc, address, size, userdata):
    uc.reg_write(UC_ARM_REG_R0, output)
    uc.reg_write(UC_ARM_REG_PC, uc.reg_read(UC_ARM_REG_LR))


m.hook_add(UC_HOOK_CODE, allocate, begin=allocator, end=allocator)
with ZipFile(args.resources) as z:
    report = json.loads(z.read("resources.json"))
    for pack in report["packs"]:
        for row in pack["members"]:
            start = row["storedOffset"]
            size = row["expanded"]["bytes"]
            m.mem_write(record, b"\0" * 4)
            m.mem_write(output, b"\xa5" * (size + 8))
            for r, v in (
                (UC_ARM_REG_SP, 0x1FF0000),
                (UC_ARM_REG_LR, ret | 1),
                (UC_ARM_REG_R0, record),
                (UC_ARM_REG_R1, start - 0x8000),
                (UC_ARM_REG_R2, size),
            ):
                m.reg_write(r, v)
            m.emu_start((0x2EC73C - 0x8000) | 1, ret, count=30_000_000)
            assert m.reg_read(UC_ARM_REG_PC) == ret, row["path"]
            assert unpack("<I", m.mem_read(record, 4))[0] == output, row["path"]
            assert bytes(m.mem_read(output, size)) == z.read(row["path"]), row["path"]
            assert bytes(m.mem_read(output + size, 8)) == b"\xa5" * 8, row["path"]
        print(pack["game"], pack["group"], len(pack["members"]), flush=True)
