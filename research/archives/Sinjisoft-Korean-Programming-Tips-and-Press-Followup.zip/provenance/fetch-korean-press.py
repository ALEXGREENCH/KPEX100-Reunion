from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

root = Path(__file__).resolve().parent / 'korean-press'
root.mkdir(exist_ok=True)
targets = [
    ('gnex-launch-2003', 'https://www.inews24.com/view/93095'),
    ('touch-gnex-2008', 'https://www.etnews.com/200809090112'),
    ('gvm-seminar-2001', 'https://www.etnews.com/200101050031'),
    ('sinjisoft-profile-2005', 'https://www.inews24.com/view/179367'),
]
for label, url in targets:
    receipt_path = root / (label + '.receipt.json')
    if receipt_path.exists():
        continue
    receipt = {'label': label, 'url': url, 'utc': datetime.now(timezone.utc).isoformat(),
               'classification': 'Contemporary Korean publisher reporting; not a company-issued release or an SDK binary.'}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'KPEX100-Reunion-preservation/1.0', 'Accept-Encoding': 'identity'})
        try:
            response = urllib.request.urlopen(request, timeout=25)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            body = response.read(16 * 1024 * 1024 + 1)
            assert len(body) <= 16 * 1024 * 1024
            receipt.update(status=response.status, finalUrl=response.url, headers=list(response.headers.items()))
        path = root / (label + '.response')
        path.write_bytes(body)
        receipt.update(path=path.name, bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    except OSError as error:
        receipt.update(status=0, error=str(error))
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', 'utf8')
    print(label, receipt['status'], receipt.get('bytes'), flush=True)
    time.sleep(1)
