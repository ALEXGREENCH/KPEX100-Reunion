Sinjisoft Korean developer notices and contemporary Korean reporting.
2026-11-07 preservation pass. Originals remain byte-for-byte unchanged.

Ten company-authored board2 notices are selected from the frozen Pass5 queue:
78 programming tips,93 service overview,155 seminar,193 service guide errata,
202 LoadMedia error handling,330 ImageMaster2 reissue,368 Mobile C study4,
543 command-line compiler,560 compiler diagnostics,629 Wi-Top download test.
CDX SHA1 and body SHA256 were checked for all ten. UTF-8 text is separate.
These are curated downloaded pages, not ten newly recovered SDK binaries.

Four newly retrieved public HTML articles are original publisher reporting
from iNews24 and ETNews. They are not company-issued press releases. Their
date of publication differs from the receipt UTC. HTTP headers, source URL,
length and SHA256 accompany each original. Full HTML includes site furniture;
it is preserved as received. No referenced application or download was obtained.

The offline search index covers all verified HTTP200 HTML in the frozen queue,
including forms, reprints, spam and historical HTTP200 error pages. Lossy
decoding is explicitly recorded; the raw snapshot remains authoritative.
No HTML JavaScript, historical forms or vendor executable was executed.
Early GNEX SDK1.20/1.40 and the standalone phone player remain unrecovered.
Original third-party rights remain; MIT applies to Reunion tools only.
manifest.json excludes itself and gives every other member CRC32 and SHA256.
