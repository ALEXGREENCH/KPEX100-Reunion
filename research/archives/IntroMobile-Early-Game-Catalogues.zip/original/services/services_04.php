<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>IntroMobile - Solution & Services</TITLE>
<META content="text/html; charset=euc-kr" http-equiv=content-type>
<style type="text/css">
<!--
BODY {
	scrollbar-face-color: #F0F0F0;
	scrollbar-shadow-color: gray;
	scrollbar-highlight-color: #ffffff;
	scrollbar-3dlight-color: #F0F0F0;
	scrollbar-darkshadow-color: #ffffff;
	scrollbar-track-color: #F0F0F0;
	scrollbar-arrow-color: #666666
}
.aa {LINE-HEIGHT: 17px}
-->
</style>

<SCRIPT language=JavaScript>
<!--
experience="0";
browserName = navigator.appName;
browserVer = parseInt(navigator.appVersion);
if (browserVer >= 2)
	version = "n3"; 
else version = "x";

if (version == "n3"){ 
	switch1on = new Image(); switch1on.src = "/images/L_menu01_on.gif"; switch1off = new Image(); switch1off.src = "/images/L_menu01.gif";
	switch2on = new Image(); switch2on.src = "/images/L_menu02_on.gif"; switch2off = new Image(); switch2off.src = "/images/L_menu02.gif";
	switch3on = new Image(); switch3on.src = "/images/L_menu03_on.gif"; switch3off = new Image(); switch3off.src = "/images/L_menu03.gif";
	switch4on = new Image(); switch4on.src = "/images/L_menu04_on.gif"; switch4off = new Image(); switch4off.src = "/images/L_menu04.gif";
	switch5on = new Image(); switch5on.src = "/images/L_menu06_on.gif"; switch5off = new Image(); switch5off.src = "/images/L_menu06.gif";
	switch6on = new Image(); switch6on.src = "/images/top_on.gif"; switch6off = new Image(); switch6off.src = "/images/top.gif";
}
function img_act(imgName){
	if(version == "n3"){
		imgOn = eval(imgName + "on.src");
		document [imgName].src = imgOn;
	}
}
function img_inact(imgName){
	if(version == "n3"){
		imgOff = eval(imgName + "off.src");
		document [imgName].src = imgOff;
	}
}

function MM_swapImgRestore() { //v3.0
	var i,x,a=document.MM_sr;
	for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
	var d=document;
	if(d.images){ 
		if(!d.MM_p) d.MM_p=new Array();
		var i,j=d.MM_p.length,a=MM_preloadImages.arguments;
		for(i=0; i<a.length; i++)
	
		if (a[i].indexOf("#")!=0){
			d.MM_p[j]=new Image;
			d.MM_p[j++].src=a[i];
		}
	}
}

function MM_swapImage() { //v3.0
	var i,j=0,x,a=MM_swapImage.arguments;
	document.MM_sr=new Array;
	for(i=0;i<(a.length-2);i+=3)
	
	if ((x=MM_findObj(a[i]))!=null){
		document.MM_sr[j++]=x;
		if(!x.oSrc) x.oSrc=x.src;
		x.src=a[i+2];
	}
}
//-->
</SCRIPT>

<SCRIPT language=JavaScript>
<!--
<!-- Hide from illiterate browsers  
var pong;
function setPage(n){
	location.href = n
}

function openWin(){
	winObj = window.open("../comming.htm", "winName", "width=300,height=150,top=250,left=330");
}
//  -->
function MM_findObj(n, d) { //v4.0
	var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length){
		d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);
	}
	if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
	for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
	if(!x && document.getElementById) x=document.getElementById(n); return x;
}
//-->
</SCRIPT>

<SCRIPT language=JavaScript>
<!--
function namosw_exchange_src(){
	str = namosw_exchange_src.arguments[0];
	str = (navigator.appName == 'Netscape') ? 'document.' + str : 'document.all.' + str;
	img = eval(str);

	if (img) {
		if (img.ori_src == null) {
			img.ori_src = img.src;
			img.src = namosw_exchange_src.arguments[1];
		} else {
			var temp = img.src;
			img.src = img.ori_src;
			img.ori_src = temp;
		}
	}
}

function namosw_preload_img(){ 
	var img_list = namosw_preload_img.arguments;
	if (document.preloadlist == null) 
	document.preloadlist = new Array();
	var top = document.preloadlist.length;

	for (var i=0; i < img_list.length; i++) {
		document.preloadlist[top+i] = new Image;
		document.preloadlist[top+i].src = img_list[i];
	} 
}
//-->
</SCRIPT>
</HEAD>


<BODY aLink=#ff9000 bgColor=white leftMargin=0 link=#0084d4 onload="MM_preloadImages('/images/more_on.gif','/images/news_list_on.gif','/services/images/abs_02on.gif','/services/images/abs_03on.gif','/services/images/abs_04on.gif','/services/images/abs_05on.gif','/services/images/abs_06on.gif','/services/images/abs_07on.gif','/images/L_menu01_on.gif','/images/L_menu02_on.gif','/images/L_menu03_on.gif','/images/L_menu07_on.gif','/images/L_menu04_on.gif','/images/L_menu06_on.gif'); namosw_preload_img('images/ser_01on.gif', 'images/ser_02on.gif', 'images/ser_03on.gif', 'images/ser_06on.gif')" text=#777777 topMargin=0 vLink=#0084d4 marginheight="0" marginwidth="0">

<TABLE border=0 cellPadding=0 cellSpacing=0 width=751>
<TBODY>
<TR>

<!--�����޴�����-->
	<td bgcolor="#DFDFDF"><img src="/images/space.gif" width="1" height="1"></td>
	<td width="151" background="/images/left_bg.jpg" valign="top"><img src="/images/title02.gif" width="151" height="18"><br><img src="/images/left_em.jpg" width="151" height="10"><br>

	<!--���� ž�޴�-->
		<a href="/news/news_02.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('L_menu01','','/images/L_menu01_on.gif',1)"><img name="L_menu01" border="0" src="/images/L_menu01.gif" width="135" height="18"></a><br>
	<!--		<a href="/standard/standard.html" onmouseover="img_act('switch2'); return true;" onmouseout="img_inact('switch2')"><img src="/images/L_menu02.gif" width="135" height="18" border="0" name="switch2"></a><br>
		<a href="/solution/solution.html" onmouseover="img_act('switch3'); return true;" onmouseout="img_inact('switch3')"><img src="/images/L_menu03.gif" width="135" height="32" border="0" name="switch3"></a><br> -->
		<a href="/glossary/glossary.htm" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image67','','/images/L_menu07_on.gif',1)"><img name="/Image67" border="0" src="/images/L_menu07_off.gif" width="135" height="18"></a><br>
	<!--		<a href="/trends/trends.html" onmouseover="img_act('switch4'); return true;" onmouseout="img_inact('switch4')"><img src="/images/L_menu04.gif" width="135" height="18" border="0" name="switch4"></a><br> -->
		<a href="/infor/infor.html" onmouseover="img_act('switch5'); return true;" onmouseout="img_inact('switch5')"><img src="/images/L_menu06.gif" width="135" height="18" border="0" name="switch5"></a><br><br>
		<img src="/images/title06.gif" width="151" height="18"><img src="/images/left_em.jpg" width="151" height="10"><br>

	<!--���� �Ʒ��޴�-->
		<TABLE border=0 cellPadding=0 cellSpacing=0 width=141>
		<TBODY>
		<TR>
			<TD><IMG height=1 src="/images/space.gif" width=10></TD>
			<TD>
				<A href="/solution_new/mextendmedia/extendmedia_overview.php">
				<IMG border=0 height=41 src="/images/s_img02.gif" width=129><BR>
				<FONT color=#0084d4 face=Verdana,Arial size=1>
				<U>Compatible with 3GPP & WAP standards</U></FONT></A><BR><IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/solution_new/intropad/intropad_overview.php">
				<IMG border=0 height=41 src="/images/S_img08.gif" width=129><BR>
				<FONT color=#0084d4 face=Verdana,Arial size=1><U>Mobile Idle Mode Management Solution</U></FONT></A><BR>
				<IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/solution_new/motionworks/motionworks_overview.php">
				<IMG border=0 height=41 src="/images/banner_motionworks.gif" width=129><BR>
				<FONT color=#0084d4 face=Verdana,Arial size=1><U>Mutimedia Contents Composing & Editing Solution</U></FONT></A><BR>
				<IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/im_cpmtm/imc_01.htm"><IMG border=0 height=41 src="/images/imc_banner.gif" width=129><BR>
				<FONT color=#0084d4 face=Verdana,Arial size=1><U>Real-time IOD Server Solution</U></FONT></A><BR>
				<IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/solution_new/mforce/mforce_overview.php">
				<IMG border=0 height=41 src="/images/banner_mfroce.gif" width=129><BR>
				<FONT color=#0084d4 face=Verdana,Arial size=1><U>Mobile Extended System Integration Solution</U></FONT></A><BR>
				<IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/solution_new/madworks/madworks_overview.php"><IMG border=0 height=41 src="/images/im_banner.gif" width=129><BR><FONT color=#0084d4 face=Verdana,Arial size=1><U>Mobile Marketing & Advertising Solution</U></FONT></A><BR><IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/solution_new/mbizwares/mbizwares_overview.php"><IMG border=0 height=41 src="/images/banner_mbizwares.gif" width=129><BR><FONT color=#0084d4 face=Verdana,Arial size=1><U>Comprehensive Enterprise scale Platform</U></FONT></A><BR><IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<A href="/solution_new/airmode/airmode_overview.php"><IMG border=0 height=41 src="/images/banner_airmode.gif" width=129><BR><FONT color=#0084d4 face=Verdana,Arial size=1><U>SMS/EMS/MMS Generating Core Solution</U></FONT></A><BR><IMG border=0 height=13 src="/images/space.gif" width=1><BR>
				<IMG height=26 src="/images/s_img_1.gif" width=129>

			</TD>
		</TR>
		</TBODY>
		</TABLE><BR><BR><BR>

	</td>
<!--�����޴���-->

	<TD vAlign=top> <img src="images/space.gif" width="3" height="1" border="0"><font size="1" face="Arial, Helvetica, sans-serif"><a href="/maink.phtml">Home</a></font> <img src="../images/arrow.gif" width="13" height="7" border="0"><font size="1" face="Arial, Helvetica, sans-serif"><a href="../services/services.php">Solution &amp; Service</a></font> <img src="../images/arrow.gif" width="13" height="7" border="0"><font size="1" face="Arial, Helvetica, sans-serif">Solution</font><br><img src="images/tit_serv.gif" width="598" height="56" border="0"><br>
	
		<TABLE border=0 cellPadding=0 cellSpacing=0 width=598>
		<TBODY>
		<TR>
          <TD background=images/tit_em.jpg colSpan=3><IMG height=10 
            src="" width=1></TD></TR>
        <TR>
          <TD>
            <P><IMG border=0 height=1 src="images/space.gif" 
            width=10></P></TD>
          <TD width=578> 
            <P><IMG border=0 height=1 src="images/space.gif" width=578><BR>
            <table width="512" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="134"><img border=0 height=25 src="images/head_se04.gif" width=134></td>
                <td width="131"><img border=0 height=25 src="images/dot.gif" width=131></td>
                <td width="54"><a href="../services/services.php" onMouseOut="MM_swapImgRestore(); namosw_exchange_src('Image28')" onMouseOver="namosw_exchange_src('Image28', 'images/ser_01on.gif')"><img border=0 height=25 name=Image28 src="images/ser_01off.gif" width=54></a></td>
                <td width="41"> <a href="../services/services_02.php" onMouseOut="MM_swapImgRestore(); namosw_exchange_src('Image29')" onMouseOver="namosw_exchange_src('Image29', 'images/ser_02on.gif')"><img border=0 height=25 name=Image29 src="images/ser_02off.gif" width=41></a></td>
                <td width="32"> <a href="../services/services_03.php" onMouseOut="MM_swapImgRestore(); namosw_exchange_src('Image30')" onMouseOver="namosw_exchange_src('Image30', 'images/ser_03on.gif')"><img border=0 name=Image30 src="images/ser_03off.gif"></a></td>
                <td width="55"> <img border=0 height=25 name=Image31 src="images/ser_04on.gif" width=55></td>
                <td width="46"> <a href="../services/services_05.php" onMouseOut="MM_swapImgRestore(); namosw_exchange_src('Image32')" onMouseOver="namosw_exchange_src('Image32', 'images/ser_05on.gif')"><img border=0 height=25 name=Image32 src="images/ser_05off.gif" width=46></a></td>
                <td width="19"> <a href="/services/services_06.php" onMouseOut="MM_swapImgRestore(); namosw_exchange_src('Image33')" onMouseOver="namosw_exchange_src('Image33', 'images/ser_06on.gif')"><img border=0 name=Image33 src="images/ser_06off.gif"></a></td>
              </tr>
            </table>
            
            <TABLE border=0 cellPadding=0 cellSpacing=0 width=579>
				<TBODY>
				<TR>
                <TD colSpan=2>
                  <P><BR><BR><BR><IMG border=0 height=25 
                  src="images/dot.gif" width=65><IMG border=0 
                  height=26 src="images/h_solu.gif" 
              width=407></P></TD></TR>
              <TR>
                <TD width=50>
                  <P>&nbsp;</P></TD>
                <TD width=482>
                  <DIV align=left>
                  <TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
                    <TBODY>
                    <TR>
                      <TD width="7%">
                        <P>&nbsp;</P></TD>
                      <TD width="93%">
                        <P><BR></P></TD></TR>
                    <TR>
                      <TD width="7%">
                        <P>&nbsp;</P></TD>
                      <TD width="93%">
                        <TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
                          <TBODY>
                          <TR>
                            <TD colSpan=2 vAlign=top width=420>
                              <TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
                                <TBODY>
                                <TR>
                                <TD vAlign=top width="65%">
                                <P><A href="/solution_new/mextendmedia/extendmedia_overview.php"><FONT 
                                face=����,Arial size=2><B>MMS Solution - mExtendMedia<SUP>TM</SUP></B></FONT></A><BR><BR><FONT 
                                face=����,Arial size=2>...3GPP, WAP ���� Global Standard 
                                ����</FONT><BR><FONT 
                                face=����,Arial size=2>...Embedded Client�� �پ��� VM ���(J2ME,<br>
                                &nbsp;&nbsp;&nbsp;BREW ��) Client ���� </FONT><BR><FONT 
                                face=����,Arial size=2>...�پ���  Device Interface�� ��Ʈ��ũ ��������<br>
                                &nbsp;&nbsp;&nbsp;����</FONT><BR><FONT 
                                face=����,Arial size=2>...Single Client, Multi-Function ����</FONT><br>
                                <FONT 
                                face=����,Arial size=2>...�پ��� Media Format(MPEG, SMIL ��) ����</FONT><BR><FONT 
                                face=����,Arial size=2>...Plug-In & Module ��� Architecture</FONT><BR><FONT 
                                face=����,Arial size=2>...Graphic Editing, ASP �ַ�� ����/ 3GPP<br>
                                &nbsp;&nbsp;&nbsp;SMIL Composer ���</FONT><BR>
                                <FONT 
                                face=����,Arial size=2>...Phone to Web/Web to Phone ������ ���� <br>
                                &nbsp;&nbsp;&nbsp;���� ����</FONT><BR><BR></P></TD>
                                <TD align=right width="35%">
                                <P>
                                <OBJECT 
                                classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                                codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=4,0,2,0 
                                height=137 width=137><PARAM NAME="movie" VALUE="/flash/02_k.swf"><PARAM NAME="quality" VALUE="high">
								<embed src="/flash/02_k.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                                type="application/x-shockwave-flash" width="137" 
                                height="137"></embed></OBJECT>
                                </P></TD></TR></TBODY></TABLE></TD></TR>
                          <TR>
                            <TD colSpan=2 width=420>
                              <P><IMG border=0 height=1 
                              src="images/bar_sol.gif" 
                            width=417></P></TD></TR>
                          <TR>
                            <TD colSpan=2 vAlign=top width=420>
                              <TABLE border=0 cellPadding=0 cellSpacing=0 
                              width="100%">
                                <TBODY>
                                <TR>
									<TD width=284>&nbsp;</TD>
									<TD width=136>&nbsp;</TD></TR>
                                <TR>
                                <TD vAlign=top width="65%">
                                <P><A href="/solution_new/intropad/intropad_overview.php"><FONT 
                                face=����,Arial size=2><B>IntroPAD<SUP>TM</SUP></B></font></A><FONT 
                                face=����,Arial size=2> 
                                [����Ư�����]</FONT><BR><BR><FONT face=����,Arial 
                                size=2>...�ܸ��� �����(Idle Mode)ȭ�� �̿�</FONT><BR><FONT 
                                face=����,Arial size=2>...�� ȭ�鿡 ���� ������ ���� 
                                ����</FONT><BR><FONT face=����,Arial 
                                size=2>������� ���� ����(Information Broad<br>
                                &nbsp;&nbsp;&nbsp;Casting) Push Marketing<br>
                                ���ֹ��� ����ȭ ���� ����(IOD Request)<br>
                                &nbsp;&nbsp;&nbsp;Pull Marketing<br>
                                ��Target ���� ����  </FONT><BR><FONT 
                                face=����,Arial size=2>...VM(Java, BREW) ��ݰ� ������ Ŭ���̾�Ʈ<br>
                                &nbsp;&nbsp;&nbsp;����</FONT><BR><BR></P></TD>
                                <TD align=right width="35%">
                                <P>
                                <OBJECT 
                                classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                                codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0 
                                height=137 width=137><PARAM NAME="movie" VALUE="/flash/intropad_k.swf"><PARAM NAME="quality" VALUE="high">
                                																																							<embed 
                                src="/flash/intropad_k.swf" quality=high 
                                pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                                type="application/x-shockwave-flash" width="137" 
                                height="137"></embed>
                                												</OBJECT></P></TD></TR></TBODY></TABLE></TD></TR>
                          <TR>
                            <TD colSpan=2 width=420>
                              <P><IMG border=0 height=1 
                              src="images/bar_sol.gif" 
                            width=417></P></TD></TR>
                          <TR>
                            <TD width=284>&nbsp;</TD>
                            <TD width=136>&nbsp;</TD></TR>
                          <TR>
                                <TD width="66%">
                                <P><A href="/solution_new/motionworks/motionworks_overview.php"><FONT 
                                face=����,Arial size=2><B>MotionWorks<SUP>TM</SUP></B></FONT></A><BR><BR><FONT 
                                face=����,Arial size=2>...��Ƽ�̵�� ������ ���� ����/ ���� 
                                �ַ��</FONT><BR><FONT face=����,Arial 
                                size=2>...������ ������ ����/���� �޴� ����</FONT><BR><FONT 
                                face=����,Arial size=2>...�޴��� ȯ�濡 ����ȭ�� ��� ���� 
                                ����</FONT><BR><FONT face=����,Arial 
                                size=2>...������ ���� (����/����)</FONT><BR><FONT face=����,Arial 
                                size=2>...M-Book, M-Card ���� �پ��� ��Ƽ�̵�� ����<br>
                                &nbsp;&nbsp;&nbsp;���� ����</FONT><BR><BR></P></TD>
                                <TD vAlign=top width="34%">
                                <P>
                                <OBJECT 
                                classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                                codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0 
                                height=120 width=129><PARAM NAME="movie" VALUE="/flash/motionworks.swf"><PARAM NAME="quality" VALUE="high">
                                																																							<embed 
                                src="/flash/motionworks.swf" quality=high 
                                pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                                type="application/x-shockwave-flash" width="129" 
                                height="120"></embed></OBJECT></P></TD></TR>
                          <TR>
                            <TD colSpan=2 width=420>
                              <P><IMG border=0 height=1 src="images/bar_sol.gif" width=417></P></TD></TR>
                          <TR>
                            <TD width=284>&nbsp;</TD>
                            <TD width=136>&nbsp;</TD></TR>
                          <TR>
                            <TD width=284>
                              <P><A href="/im_cpmtm/imc_01.htm"><FONT 
                              face=����,Arial size=2><B>InfoLinx<SUP>TM</SUP></B></FONT></A><BR><BR><FONT 
                              face=����,Arial size=2>...Realtime����� ���� �ǽð� ���� 
                              ����</FONT><BR><FONT face=����,Arial size=2>...�پ��ϰ� 
                              ǥ��ȭ�� �������̽� ����</FONT><BR><FONT face=����,Arial 
                              size=2>...������ GUI ȯ���� ���� �� ��� ���</FONT><BR><FONT 
                              face=����,Arial size=2>...��뷮, �ʰ����� �������� �ý��� 
                              ����</FONT><BR><FONT face=����,Arial size=2>...SMS, 
                              VM, WAP Push �� �پ��� ȯ�� ����</FONT><BR><BR></P></TD>
                            <TD width=136 align=center><A href="/im_cpmtm/imc_01.htm"><IMG border=0 height=102 src="images/ani2.gif" width=121></A></TD></TR>
                          <TR>
                                <TD colSpan=2>
                                <P><IMG border=0 height=1 
                                src="images/bar_sol.gif" 
                                width=417></P></TD></TR>
                                <TR>
                                <TD colSpan=2>&nbsp; </TD></TR>
                                <TR>
                                <TD vAlign=top width="66%">
                                <P><A 
                                href="/mforce/mforce_overview.php"><FONT 
                                face=����,Arial size=2><B>mForce<SUP>TM</SUP></B></FONT></A><BR><BR><FONT 
                                face=����,Arial size=2>...Mobile ����� ������ SFA /FFA 
                                �ַ��</FONT><BR><FONT face=����,Arial 
                                size=2>...��� ���� e-Business �� ��/�������� �Ⱓ<br>
                                &nbsp;&nbsp;&nbsp;�ý��۰� ����</FONT><BR><FONT face=����,Arial 
                                size=2>...�ǽð� ���� ���ް� �������� ���� ȿ��ȭ �ش�ȭ</FONT><BR><FONT 
                                face=����,Arial size=2>...���� Ȯ��� ����� Ȯ�밡 ���� �л� ����</FONT>
                                <BR><FONT face=����,Arial size=2>...���� ���� �ý��� ����</FONT><BR><BR></P></TD>
                                <TD width="35%">
                                <P>
                                <OBJECT 
                                classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                                codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0 
                                height=137 width=137><PARAM NAME="movie" VALUE="/flash/mforce.swf"><PARAM NAME="quality" VALUE="high">
                                																																							<embed 
                                src="/flash/mforce.swf" quality=high 
                                pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                                type="application/x-shockwave-flash" width="137" 
                                height="137"></embed></OBJECT></P></TD></TR>
                          <TR>
                            <TD colSpan=2 width=420>
                              <P><IMG border=0 height=1 
                              src="images/bar_sol.gif" 
                            width=417></P></TD></TR>
                          <TR>
                            <TD width=284>&nbsp;</TD>
                            <TD width=136>&nbsp;</TD></TR>
                          <TR>
                            <TD width=284>
                              <P><A 
                              href="/solution_new/madworks/madworks_overview.php"><FONT 
                              face=����,Arial size=2><B>mADWorks<SUP>TM</SUP></B></FONT></A><BR><BR><FONT 
                              face=����,Arial size=2>...One To One Targeting 
                              Marketing & Advertising</FONT><BR><FONT face=����,Arial 
                              size=2>...���� ǥ���� �������� �ַ��</FONT><BR><FONT 
                              face=����,Arial size=2>...������ ����������"AD Wizard" 
                              ����</FONT><BR><FONT face=����,Arial size=2>...�̹���,������ �� �پ��� 
                              ������ü ����</FONT><BR><FONT face=����,Arial 
                              size=2>...�������̰� ������ ����ȿ�� �м� Tool ����</FONT><BR><FONT face=����,Arial 
                              size=2>...LBS, CBS ���� ��ġ ��� ����� ���� ����</FONT><BR><BR></P></TD>
                            <TD width=136>
                              <P align=right>
                              <OBJECT 
                              classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                              codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=4,0,2,0 
                              height=137 width=137><PARAM NAME="movie" VALUE="/flash/01_sub.swf"><PARAM NAME="quality" VALUE="high">
                              																																	<embed 
                              src="/flash/01_sub.swf" quality=high 
                              pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                              type="application/x-shockwave-flash" width="137" 
                              height="137"></embed></OBJECT></P></TD></TR>
                          <TR>
                                <TD colSpan=2 vAlign=top><IMG border=0 height=1 src="images/bar_sol.gif" width=417></TD></TR>
                                <TR>
                                <TD colSpan=2 height=5 
                                vAlign=top>&nbsp;</TD></TR>
                                <TR>
                                <TD width="66%">
                                <P><A 
                                href="/solution_new/mbizwares/mbizwares_overview.php"><FONT 
                                face=����,Arial 
                                size=2><B>mBizWares<SUP>TM</sup></b></font></A><BR><BR><FONT 
                                face=����,Arial size=2>...������ ���� ���� ���� 
                                �ַ��</FONT><BR><FONT face=����,Arial 
                                size=2>...�ǽð����� ���� ��Ż �ڵ� ��������</FONT><BR><FONT face=����,Arial 
                                size=2>...ME/WAP/PDA �� �پ��� ����� 
                                �÷����� ����<br> </FONT><FONT 
                                face=����,Arial size=2>...���� ��Ż ���� �� ����</FONT><BR><FONT face=����,Arial 
                                size=2>...���� ��Ż Ʈ���� ������ �湮�� ��� ����</FONT><BR><FONT face=����,Arial 
                                size=2>...Application ���� ����(ä��, �޽���, ����,����,<br>
                                &nbsp;&nbsp;&nbsp;�˻� ��)</FONT><BR>
                                <FONT face=����,Arial 
                                size=2>...Ÿ ����� �÷����� ����/Ȯ�� ����(XML<br>
                                &nbsp;&nbsp;&nbsp;Contents Converter, SMS, MMS, VM ��) </FONT><BR><BR></P></TD>
                                
                              <TD width="34%"> 
                                <P><a href="/solution_new/mbizwares/mbizwares_overview.php"><img src="images/mbizwares.gif" width="137" height="137" border="0"></a></P>                                
                              </TD></TR>
                          <TR>
                            <TD colSpan=2><IMG border=0 height=1 src="images/bar_sol.gif" width=417></TD></TR>
                          <TR>
                            <TD colspan="2">&nbsp;</TD>
                          </TR>
                          <TR>
                            <TD colSpan=2 vAlign=top width=420>
                              <TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
                                <TBODY>
                                <TR>
                                <TD width="66%">
                                <P><A 
                                href="/airmode/airmode_overview.php"><FONT 
                                face=����,Arial size=2><B>AirMode<SUP>TM</SUP></B></FONT></A><BR><BR><FONT 
                                face=����,Arial size=2>...ȿ������ ����� �޽���(SMS)���� 
                                �ַ��</FONT><BR><FONT face=����,Arial size=2>...�ʰ��� ���۰� ���� 
                                �߼� ������ ���� </FONT><BR><FONT 
                                face=����,Arial size=2>...�߼� ���� �� ���� ȸ���� 
                                ������ Ȯ��</FONT><BR><FONT face=����,Arial 
                                size=2>...�߼� ���� ��� �м� �� ������ ���� ���<br>
                                &nbsp;&nbsp;&nbsp;& Report ����</FONT><BR><FONT 
                                face=����,Arial size=2>...Interactive Mobile Service ���� 
                                ����</FONT><BR><FONT 
                                face=����,Arial size=2>...�پ��� ����� ȯ�� ����  
                                ����</FONT><BR><BR></P></TD>
                                <TD vAlign=top width="34%">
                                <P>
                                <OBJECT 
                                classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                                codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0 
                                height=120 width=150><PARAM NAME="movie" VALUE="/flash/airmode.swf"><PARAM NAME="quality" VALUE="high">
                                																																							<embed 
                                src="/flash/airmode.swf" quality=high 
                                pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                                type="application/x-shockwave-flash" width="150" 
                                height="120"></embed></OBJECT></P></TD></TR>
                          <TR>
                            <TD colSpan=2><IMG border=0 height=1 
                              src="images/bar_sol.gif" 
                          width=417></TD></TR>
                          <TR>
                            <TD colspan="2">&nbsp;</TD>
                          </TR>
                          <TR>
                             <TD width="66%">
                                <P><A 
                                href="/airmessagenger/airmessaging_overview.htm"><FONT 
                                face=����,Arial size=2><B>AirMessenger<SUP>TM</sup></b></font></A><BR><BR><FONT 
                                face=����,Arial size=2>...������ ������ Mobile Messaging 
                                Solution.</FONT><BR><FONT face=����,Arial 
                                size=2>...������ �����޽��� 
                                (ICQ,MSN,..etc)����<BR>&nbsp;&nbsp;&nbsp;��ȣ������ ���� 
                                ȣȯ�� ����</FONT><BR><FONT face=����,Arial 
                                size=2>...Intranet�� �׷����� ���� 
                                ����</FONT><BR><BR></P></TD>
                                <TD width="34%">
                                <P>
                                <OBJECT 
                                classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 
                                codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0 
                                height=120 width=150><PARAM NAME="movie" VALUE="/flash/airmessenger_2.swf"><PARAM NAME="quality" VALUE="high">
                                																																							<embed 
                                src="/flash/airmessenger_2.swf" quality=high 
                                pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" 
                                type="application/x-shockwave-flash" width="150" 
                                height="120"></embed></OBJECT></P></TD></TR>                        
                                
                                
                                </TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV></TD></TR></TBODY></TABLE><p></P></TD>

			<TD width=588><P><IMG border=0 height=1 src="images/space.gif" 
            width=10></P></TD>
		</TR>
		</TBODY>
		</TABLE>
		
	<P><BR><IMG border=0 height=42 src="images/sub_copyright.gif" useMap=#email width=598><BR></P></TD>
	<TD bgColor=#dedede vAlign=top><P><IMG border=0 height=1 src="" width=1></P></TD>
</TR>
<TR>
    <TD bgColor=#dedede colSpan=3><P><IMG border=0 height=1 src="" width=1></P></TD>
    <TD></TD>
</TR>
</TBODY>
</TABLE>

<MAP name=email>
	<AREA alt=e-mail coords=416,3,497,18 href="mailto:intromobile@intromobile.com" shape=RECT title=e-mail>
</MAP>

</BODY>
</HTML>
