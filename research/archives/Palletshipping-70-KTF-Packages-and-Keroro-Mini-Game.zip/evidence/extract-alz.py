from pathlib import Path, PurePosixPath
from struct import unpack_from
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
from zlib import crc32, decompressobj
import argparse
import json
from hashlib import sha256

parser = argparse.ArgumentParser(description="Extract the verified Tteokbokki Tycoon 3 ALZ to a ZIP.")
parser.add_argument("original", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

def identity(data):
    return dict(bytes=len(data), sha256=sha256(data).hexdigest(), crc32=f"{crc32(data):08x}")



p=args.original
b=p.read_bytes()
assert b[:8]==b'ALZ\x01\x0a\x00\x00\x00'
i=8
files={}
manifest=[]
while b[i:i+4]==b'BLZ\x01':
    n, attr, stamp, flags, _ = unpack_from('<HBIBB', b,i+4)
    i+=13
    w={0x10:1,0x20:2,0x40:4}[flags]
    method=b[i]
    assert method==2
    check=unpack_from('<I',b,i+2)[0]
    i+=6
    csize=int.from_bytes(b[i:i+w],'little');i+=w
    usize=int.from_bytes(b[i:i+w],'little');i+=w
    assert 0<n<=512 and 0<usize<16*1024**2 and i+n+csize<=len(b)
    name=b[i:i+n].decode('cp949',errors='strict')
    path=PurePosixPath(name)
    assert not path.is_absolute() and not '..' in path.parts and '\\' not in name and name not in files
    i+=n
    d=decompressobj(-15)
    raw=d.decompress(b[i:i+csize],usize+1)
    assert d.eof and not d.unused_data and not d.unconsumed_tail and len(raw)==usize and crc32(raw)==check
    manifest.append(dict(path=name,method='raw deflate',compressedBytes=csize,compressedOffset=i,**identity(raw)))
    files[name]=raw
    i+=csize
assert len(files)==5 and b[i:]==b'CLZ\x01'+bytes(8)+b'CLZ\x02\r\n'
out=args.output
with ZipFile(out,'x') as z:
    for name,raw in files.items():
        info=ZipInfo(name)
        info.compress_type=ZIP_DEFLATED
        z.writestr(info,raw,compresslevel=6)
with ZipFile(out) as z:
    assert z.testzip() is None
    assert all(z.read(n)==raw for n,raw in files.items())

print(json.dumps(manifest, ensure_ascii=False, indent=2))
