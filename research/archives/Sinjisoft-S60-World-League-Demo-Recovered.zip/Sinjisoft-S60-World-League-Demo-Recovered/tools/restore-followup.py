from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent.parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sis=load('sis',root/'tools/extract-old-sis.py');sgs=load('sgs',root/'tools/scan-firmware-games.py')
out=Path(sys.argv[1]).resolve()
assert not out.exists();out.mkdir(parents=True)
for row in json.loads((root/'provenance.json').read_text('utf-8'))['packages']:
 raw=(root/row['originalSisPath']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['originalSisSha256']
 manifest,files=sis.parse_sis(raw);dest=out/row['id'];sis.write_outputs(dest,manifest,files)
 app=(dest/Path(row['appPath']).name).read_bytes();assert hashlib.sha256(app).hexdigest()==row['appSha256']
 hits=[h for h in sgs.scan_bytes(app)['containers'] if h['source_offset']==row['sgsOffsetInApp']]
 assert len(hits)==1;hit=hits[0];blob=app[hit['source_offset']:hit['source_offset']+hit['extracted_bytes']]
 assert hashlib.sha256(blob).hexdigest()==row['sgsSha256'];(out/(row['id']+'.sgs')).write_bytes(blob)
print('Restored 2 packages and original SGS slices, no native vendor execution')
