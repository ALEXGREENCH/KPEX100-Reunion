from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve()
manifest=json.loads((root/'manifest.json').read_text('utf-8'))
assert {str(p.relative_to(root)).replace(chr(92),'/') for p in root.rglob('*') if p.is_file()}=={r['path'] for r in manifest['files']}|{'manifest.json'}
for row in manifest['files']:
 p=(root/row['path']).resolve(); assert p.is_relative_to(root)
 b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print('Verified',len(manifest['files']),'manifest files')
