Kingston 2.12: key-state and long-hold probes

These are Reunion's source code and static replay results, not a replacement
firmware. The original Kingston ROM is not included.

The GetKeyState result is a software mask, not a new ADC reading. The original
common-release path clears bit zero. After autorepeat, the isolated GNEX-mode
ADC translation can omit the release event even though the raw key is 255.

The --release-fix experiment changes five ARM words only inside Unicorn's test
memory. Boot and physical-player behavior with that experiment are untested.
It does not create a flashable image and is not enabled in Reunion's player.
All 12 experimental cases preserve the original press/repeat traces.
Sample counts are not measurements of physical time or FPS.

Requirements: Python 3.11 or newer, pip install unicorn.
From the extracted directory:
python tools/probe-kingston-adc.py /path/to/Kingston-2.12.rom --output original.json
python tools/probe-kingston-adc.py /path/to/Kingston-2.12.rom --release-fix --output experiment.json
The tool requires original firmware SHA-256:
743d0b9a377dc6a3f0a80b7816cee575ad2f8249643876367c4bfaac54ddd19a

Original report and tool revisions:
https://github.com/ALEXGREENCH/KPEX100-Reunion/commit/7b1774c596486aa95dcd12a7a38dd5887cfa5b62
https://github.com/ALEXGREENCH/KPEX100-Reunion/commit/1fd9f0e5028a1e8279b5ae9068946d3003a9e90e
