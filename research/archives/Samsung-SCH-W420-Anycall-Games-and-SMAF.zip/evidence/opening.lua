aram.start()
aram.step(180)
aram.screenshot("opening.png")
