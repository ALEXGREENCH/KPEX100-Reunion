aram.start()
aram.step(600)
aram.tap("ok", 3)
aram.step(230)
aram.tap("ok", 3)
aram.step(230)
aram.tap("ok", 3)
aram.step(230)
aram.tap("ok", 3)
aram.step(230)
aram.screenshot("before.png")
aram.tap("ok", 3)
aram.step(30)
aram.screenshot("after.png")

aram.tap("ok", 3)
aram.step(100)
aram.tap("ok", 3)
aram.step(100)
aram.tap("ok", 3)
aram.step(150)
aram.screenshot("intro.png")
aram.tap("hash", 3)
aram.step(180)
aram.screenshot("after-skip.png")
for i=1,8 do
 aram.tap("ok", 3)
 aram.step(90)
 aram.screenshot("scene-"..i..".png")
end

aram.step(240)
for i=1,7 do
 aram.tap("ok", 3)
 aram.step(100)
 aram.screenshot("next-"..i..".png")
end

for i=1,24 do
 aram.tap("ok", 3)
 aram.step(85)
 if i % 4 == 0 then aram.screenshot("town-"..i..".png") end
end
aram.screenshot("before-walk.png")
aram.tap("left", 28)
aram.step(16)
aram.step(29)
aram.step(16)
aram.screenshot("after-up.png")
