Petris background cache: original Kingston 2.12 verification

Unpack into a full Reunion checkout. The production firmware is supplied separately
by that checkout. Node.js 22 or newer is required. Use a NEW or EMPTY output folder.

Native neutral-frame measurement:
node tools/replay-petris-state.mjs --state tools/research/title-cache.reunion-state --sgs tools/research/cache-after.sgs --output NEW_OUTPUT --mode timing
Use --mode grid for the 12 independent 80 ms Play pulse branches.
For the previous launcher use title-before.reunion-state and cache-before.sgs.

Direct 891-frame diagnostic (guest-frame inputs; not a native keyboard test):
node tools/replay-petris-frames.mjs tools/research/diagnostic-after.sgs NEW_OUTPUT
Use diagnostic-before.sgs for the previous renderer.
Diagnostic SGS files are measurement programs and are not playable launchers.

Fresh original-firmware menu boot and gameplay:
node tools/replay-petris-native.mjs --sgs tools/research/cache-after.sgs --output NEW_OUTPUT

The states originate from actual original-menu/FAT16 launches on emulated ARM.
They contain original Kingston executable/data and Petris ROM bytes; their original
rights are separate from the Reunion MIT code. No firmware patch or invented API
result is used. Hardware clock time is modeled; these are not physical FPS results.

Petris by bbbbbr: CC BY-NC-SA 4.0 Game Gear branch. Original ROM, license and
upstream source archive are preserved in demos/gg/petris. See THIRD_PARTY.md.
ROM hash: 2de507b5708cc66020a700e3f4674216cb3374fc5d39369da86221bb34a07ba9
Kingston 2.12: 743d0b9a377dc6a3f0a80b7816cee575ad2f8249643876367c4bfaac54ddd19a

See doc/petris-background-cache.md and validation/petris-background-cache.json.
The fixed pulse grid delivers 10/12 pairs in BOTH variants, at different phases.
It establishes neither a failure probability nor guaranteed delivery of all taps.
