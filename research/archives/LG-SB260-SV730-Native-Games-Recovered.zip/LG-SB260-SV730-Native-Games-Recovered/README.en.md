# LG SB260 / SV730 PXO modules and linked FreeKick Flash payload

This bundle preserves 14 original WDB module records and their 14 decoded
copies from public LG service packages. These are **native PXO**, not SGS
or Java games. They are not part of Reunion's SGS library. Native phone
execution, full loader compatibility and playability have not been tested.

## Contents and evidence

- **SB260004_00:** Game, BrainTeaser, Dart, Fishing, FreeKick, HomerunDerby,
  SudokuCafe, VSticks, ZooZooClub2, WIPISKT and WIPISKTSub PXO modules.
- **SV730906_00:** Game, MingleMangle and SudokuCafe PXO modules.
- `original/`: exact extracted WDB bytes, unchanged.
- `decoded/`: 11 LGLZ-decoded PXO4 modules and three already uncompressed
  PXO1 files. Original and decoded PXO1 copies are byte-identical.
- `flash-payload/`: only manifest-listed FreeKick SWF and 11 `.wav`-named sound files whose relation
  is supported by a literal path in PXO and matching sound names in SWF.
  This is static dependency evidence, not a gameplay test.

Despite their `.wav` filenames, these sounds are SMAF/MMMD containers,
not RIFF/WAVE. Names and bytes remain unchanged. Declared MMMD file lengths
and three top-level chunk boundaries per file were checked; the final two
bytes are retained without claiming internal checksum validation. Audio
was not decoded or played.

Fourteen modules do not mean fourteen standalone games. The two `Game.pxo`
files are game interfaces/menus; WIPISKT files are platform-associated
modules/stubs. The small FreeKick PXO launches a separate Flash SWF by an
explicit path; execution is untested and no Flash engine is integrated in
GNEX/Reunion. Filenames do
not establish official English titles, completeness, Sinjisoft authorship
or distinct games. The two SudokuCafe files are distinct model builds.

Each decoded PXO has a matching declared length and bounded observed
initialized ranges. Raw descriptor words, zero-fill declarations and
uninterpreted tail ranges are retained. The complete loader ABI and runtime
address mapping remain unproven. All 649 LGLZ blocks were replayed with
end markers, FF padding, framing and decoded-byte equality checked.

No structurally valid SGS was found in the selected decoded modules by the
bounded scanner. Zero hits do not exclude unknown packing or fragments.
Service packages are not claimed to be complete phone flash or user
download storage. Whole BIN/WDB/KDZ/CAB, service programs, vendor DLL,
private EFS and user data are excluded. No original phone program, SWF
or vendor DLL was executed during recovery.

## Public sources and hashes

- [SB260004.7z](https://archive.sunderland93.ru/Firmwares/LG/SB260/SB260004.7z)
- [SV730906_00.7z](https://archive.sunderland93.ru/Firmwares/LG/SV730/SV730906_00.7z)

`manifest.json` records every file's size, SHA-256 and calculated CRC32;
source archive and intermediate container hashes; exact WDB compressed
`[start, endExclusive)` spans; LGLZ framing; and observed PXO bounds.
Declared 7z member CRCs were checked. CAB did not expose per-file declared
CRCs for WDB/DLL, so these are explicitly calculated values. Selected WDB
records were independently decrypted/decompressed again and compared with
the preserved originals, checking exact size, zlib EOF and no trailing data.

## Verify a clean extraction

Python 3.10+ is sufficient; verification uses only the standard library.
Run from the extracted bundle's root:

```console
python -B gpl-tools/verify-bundle.py
```

This checks every size/hash/CRC, detects extra files, replays 11 LGLZ
decodings, compares three PXO1 files and checks all 14 PXO descriptors.
The included static SWF parser also replays 3,856 tag boundaries, movie
headers, selected MMI operands and all 11 exact sound-stem references.
It does not execute recovered phone code. The manifest is excluded from
its own hash table; the complete ZIP hash and verification receipt cover it.

## Reproduce the static extraction

Use 7-Zip, Python and PyCryptodome, with new output directories. Download
the public service archives separately; they are unnecessary for checking
the supplied extracted bundle. Do not run their vendor DLL or programs.

Use [kdz_decrypt_encrypt revision
9dbbf74](https://github.com/michaelwright235/kdz_decrypt_encrypt/tree/9dbbf74f01ab515b8e4161e710ae193ca1a16c49).
The used `kdz.py` SHA-256 is
`35e7b8e4c5009948791ebc97880a7cba5b3ed801bb6175adb3d4b7f9c1ac2b4f`.
That external script is not bundled or relicensed here. Use Reunion's
[WDB extractor at commit
7fe8f3f](https://github.com/ALEXGREENCH/KPEX100-Reunion/blob/7fe8f3f56432588bef6a2b649a0cb0c1d286673e/tools/unpack-lg-wdb.py).
It reads the companion DLL as data without loading it.

```console
python -m pip install pycryptodome
7z x SB260004.7z -oSB260-kdz
python kdz.py -d -o SB260.cab SB260-kdz/SB260004_00.kdz
7z t SB260.cab
7z x SB260.cab -oSB260-cab
python unpack-lg-wdb.py SB260-cab/SB260004.wdb "SB260-cab/SB260(0.0.1.3).dll" SB260-files
python gpl-tools/decode-lglz.py SB260-files/MODULE/C/Game_BrainTeaser.pxo BrainTeaser-decoded.pxo
```

Replace `kdz.py` and `unpack-lg-wdb.py` with paths to the exact source
versions above. For SV730 substitute `SV730906_00.7z`, `SV730906_00.kdz`,
`SV730906.wdb`, and `SV730.dll`. Its three selected PXO1 files need no LGLZ
step: preserve their existing bytes. The manifest gives exact relative
names and spans, including the separately attributed FreeKick resources.
The bounded LGLZ CLI refuses to overwrite its output.

Run the static Flash checker separately, writing its output outside the bundle:

```console
python -B gpl-tools/check-swf-static.py flash-payload/sb260/BUILTIN/Flash/ui/Game/FreeKick.swf ../FreeKick-check.json
```

## Separate code and data licensing

`gpl-tools/` is separate from Reunion's MIT sources. It is distributed under
**GPL-3.0-or-later**, with full `COPYING.txt`, original `lglz.cpp/.h`, modified
C reference source, bounded Python translation and source provenance.
The exact Google Code source archive URL, member and hashes are recorded.
The historical C comparison covered 401 blocks in eight earlier modules;
this bundle's 649 blocks were replayed using the bounded Python decoder.
The unsafe C reference is retained as research source; the verifier neither
compiles nor calls it. No compiled decoder or vendor DLL is included.

Decoder GPL does not automatically license the original LG PXO/SWF/WAV
data or grant rights to them. Payload rights are separate; neither the
tool GPL nor Reunion MIT is presented as the payload licence.
