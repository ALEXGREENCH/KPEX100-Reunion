# SPDX-License-Identifier: GPL-3.0-or-later
"""Verify this data bundle without running phone code (Python standard library)."""
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys
import zlib

sys.dont_write_bytecode = True


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(root):
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    listed = set()
    for record in manifest["files"]:
        path = PurePosixPath(record["path"])
        if path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
            raise ValueError("Unsafe manifest path")
        if str(path) in listed:
            raise ValueError("Duplicate manifest path")
        listed.add(str(path))
        target = root.joinpath(*path.parts)
        if target.is_symlink() or not target.is_file():
            raise ValueError(f"Missing ordinary file: {path}")
        data = target.read_bytes()
        actual = (len(data), hashlib.sha256(data).hexdigest(), f"{zlib.crc32(data):08x}")
        expected = (record["bytes"], record["sha256"], record["crc32"])
        if actual != expected:
            raise ValueError(f"Hash/size/CRC mismatch: {path}")
    actual_paths = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    if actual_paths != listed | {"manifest.json"}:
        raise ValueError("Unexpected or missing files")
    decoder = load("bounded_lglz", root / "gpl-tools/decode-lglz.py")
    bounds = load("pxo_bounds", root / "gpl-tools/pxo-bounds.py")
    blocks = 0
    for module in manifest["modules"]:
        original = (root / module["originalFile"]).read_bytes()
        decoded = (root / module["decodedFile"]).read_bytes()
        if module["containerFormat"] == "LGLZ-framed PXO4":
            actual, framing = decoder.unpack(original)
            if actual != decoded or framing != module["lglzBlocks"]:
                raise ValueError("LGLZ output or block framing differs")
            blocks += len(framing)
        elif original != decoded or original[:4] != b"PXO1":
            raise ValueError("Uncompressed PXO1 was altered")
        if bounds.describe(decoded) != module["pxoBounds"]:
            raise ValueError("PXO bounds differ")
    if len(manifest["modules"]) != 14 or blocks != 649:
        raise ValueError("Unexpected module/block counts")
    swf = load("swf_static", root / "gpl-tools/check-swf-static.py")
    actual = swf.inspect(root / "flash-payload/sb260/BUILTIN/Flash/ui/Game/FreeKick.swf")
    expected = json.loads((root / "evidence/freekick-swf-structure.json").read_text(encoding="utf-8"))
    if actual["source"]["sha256"] != expected["source"]["sha256"]:
        raise ValueError("SWF source hash differs")
    for key in ("recursiveTagCount", "topLevelTagCount", "defineSpriteCount"):
        if actual["structure"][key] != expected["structure"][key]:
            raise ValueError("SWF tag counts differ")
    if actual["compression"]["actualUncompressedBytes"] != expected["zlib"]["actualUncompressedFileBytes"]:
        raise ValueError("SWF uncompressed length differs")
    for key in ("widthPixels", "heightPixels", "frameRate", "frameCount"):
        if actual["movieHeader"][key] != expected["movieHeader"][key]:
            raise ValueError("SWF movie header differs")
    expected_sounds = {Path(row["path"]).name: row for row in expected["resources"] if row["path"].endswith(".wav")}
    if len(actual["sameDirectorySoundFiles"]) != 11 or len(expected_sounds) != 11:
        raise ValueError("Unexpected sound file count")
    for sound in actual["sameDirectorySoundFiles"]:
        row = expected_sounds[sound["name"]]
        if sound["sha256"] != row["sha256"] or sound["exactStemOffsets"] != row["stemOffsetsInUncompressedSwf"] or not sound["containerLengthExact"]:
            raise ValueError("Sound hash, exact stem references or MMMD length differs")
    if len(actual["mmiAdapterEvidence"]) != 1 or actual["mmiAdapterEvidence"][0]["characterId"] != 600:
        raise ValueError("MMI class evidence differs")
    functions = actual["mmiAdapterEvidence"][0]["selectedFunctions"]
    if {row["precedingPush"][-1] for row in functions} != {"startSound", "startVolSound"}:
        raise ValueError("MMI selected functions differ")
    for function in functions:
        name = function["precedingPush"][-1]
        if function["bodyOffset"] != expected["mmiAdapterEvidence"][name]["bodyOffset"] or function["bodyBytes"] != expected["mmiAdapterEvidence"][name]["bodyBytes"]:
            raise ValueError("MMI function bounds differ")
    return {
        "passed": True,
        "manifestedFiles": len(listed),
        "nativeModules": 14,
        "pxoDataFiles": 28,
        "flashResourceFiles": len(manifest["flashResources"]),
        "decodedPxo4": 11,
        "uncompressedPxo1": 3,
        "lglzBlocksReplayed": blocks,
        "pxoBoundsVerified": 14,
        "swfRecursiveTagBoundsReplayed": actual["structure"]["recursiveTagCount"],
        "soundStemReferencesVerified": len(expected_sounds),
        "phoneCodeExecuted": False,
    }


if __name__ == "__main__":
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
    print(json.dumps(verify(root), ensure_ascii=False, indent=2))
