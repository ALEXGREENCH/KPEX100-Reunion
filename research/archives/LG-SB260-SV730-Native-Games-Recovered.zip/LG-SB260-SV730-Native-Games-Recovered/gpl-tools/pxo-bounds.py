# SPDX-License-Identifier: GPL-3.0-or-later
"""Static bounds recorded from preserved PXO1/PXO4 headers; no execution."""
import struct


def describe(data):
    if not 48 <= len(data) <= 64 * 1024 * 1024 or data[:4] not in (b"PXO1", b"PXO4"):
        raise ValueError("Unsupported bounded PXO container")
    words = list(struct.unpack_from("<12I", data))
    if words[2] != len(data):
        raise ValueError("PXO header length mismatch")
    metadata = words[3]
    descriptor_bytes = 32 if data[:4] == b"PXO4" else 28
    if not 48 <= metadata <= len(data) - descriptor_bytes:
        raise ValueError("PXO descriptor outside file")
    descriptor = list(struct.unpack_from("<8I" if descriptor_bytes == 32 else "<7I", data, metadata))
    if descriptor_bytes == 32:
        ro_bytes = descriptor[1]
        if not descriptor[2] <= descriptor[3] == descriptor[4] <= descriptor[5]:
            raise ValueError("PXO4 declared data/zero-fill pairs are unordered")
        rw_bytes = descriptor[3] - descriptor[2]
        zero_fill = {"base": descriptor[4], "endExclusive": descriptor[5], "bytes": descriptor[5] - descriptor[4]}
        entry_indices = (6, 7)
    else:
        ro_bytes, rw_bytes = descriptor[:2]
        if descriptor[2] != ro_bytes + rw_bytes or descriptor[4] != ro_bytes:
            raise ValueError("PXO1 relative data declarations disagree")
        zero_fill = {"relativeBase": descriptor[2], "bytes": descriptor[3]}
        entry_indices = (5, 6)
    ro_end = metadata + ro_bytes
    image_end = ro_end + rw_bytes
    if not metadata + descriptor_bytes <= ro_end <= image_end <= len(data):
        raise ValueError("PXO declared initialized ranges outside file")
    if descriptor_bytes == 32 and words[11] != image_end:
        raise ValueError("PXO4 header initialized-end field differs from descriptor")
    entries = []
    for index in entry_indices:
        value = descriptor[index]
        file_offset = metadata + (value & ~1)
        entries.append(
            {
                "descriptorWord": index,
                "value": value,
                "thumbBit": bool(value & 1),
                "candidateFileOffset": file_offset,
                "insideInitializedSegment1": metadata + descriptor_bytes <= file_offset < ro_end,
            }
        )
    return {
        "format": data[:4].decode("ascii"),
        "declaredFileBytes": words[2],
        "actualFileBytes": len(data),
        "headerWords": words,
        "descriptorOffset": metadata,
        "descriptorWords": descriptor,
        "descriptorRange": {"start": metadata, "endExclusive": metadata + descriptor_bytes, "bytes": descriptor_bytes},
        "initializedSegment1": {"start": metadata, "endExclusive": ro_end, "bytes": ro_bytes},
        "initializedSegment2": {"start": ro_end, "endExclusive": image_end, "bytes": rw_bytes},
        "zeroFillDeclaration": zero_fill,
        "remainingTailRange": {"start": image_end, "endExclusive": len(data), "bytes": len(data) - image_end},
        "candidateNativeEntries": entries,
        "boundsVerified": True,
        "headerInitializedEndCrossCheck": {"headerWord": 11, "value": words[11], "matchesInitializedEnd": True} if descriptor_bytes == 32 else None,
        "limits": "Numeric initialized ranges and zero-fill declarations follow the observed PXO1/PXO4 layout. They are commonly RO/RW/BSS-like, but full loader semantics and runtime mappings are not established. The descriptor itself is inside initialized segment1. Tail bytes are preserved uninterpreted; no native execution is claimed.",
    }
