# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded scratch translation of LGUI lglz.cpp; GPL-3.0-or-later.

Reference: https://storage.googleapis.com/google-code-archive-source/v2/code.google.com/lgui/source-archive.zip
Retained source: work/lg-kdz-extractor-research/pxo-source/lglz.cpp
Do not copy this derived decoder into the MIT repository without preserving its licence.
No vendor code is executed. Each observed SV400 block has a four-byte length word.
"""
import argparse
from pathlib import Path
import stat
import struct

MAX_BYTES = 64 * 1024 * 1024


def decode_block(data, capacity):
    position = 0
    control = 0x80000000
    previous_distance = None
    out = bytearray()

    def take(count):
        nonlocal position
        if count < 0 or position + count > len(data):
            raise ValueError('truncated input')
        value = data[position:position + count]
        position += count
        return value

    def bit():
        nonlocal control
        low = 0
        if not control & 0x7fffffff:
            low = control >> 31
            control = int.from_bytes(take(4), 'little')
        result = control >> 31
        control = ((control << 1) + low) & 0xffffffff
        return result

    def literal(count):
        if count > capacity - len(out):
            raise ValueError('literal exceeds output bound')
        out.extend(take(count))

    def copy(distance, count):
        if not distance or distance > len(out) or count > capacity - len(out):
            raise ValueError('invalid back-reference')
        for _ in range(count):
            out.append(out[-distance])

    while True:
        count = 1
        while bit():
            literal(count)
            if bit():
                literal(count)
            count <<= 1
            if count > MAX_BYTES:
                raise ValueError('literal run overflow')
        token = take(1)[0]
        if token & 0x80:
            distance = ((token << 8) | take(1)[0]) & 0x7fff
            if not distance:
                return bytes(out), position
            previous_distance = distance
            copy(distance, 3)
        elif not token:
            distance = previous_distance
            copy(distance, 3)
        else:
            distance = token if token < 0x10 else (token << 1) - 0x10
            copy(distance, 2)
        count = 1
        while bit():
            copy(distance, count)
            if bit():
                copy(distance, count)
            count <<= 1
            if count > MAX_BYTES:
                raise ValueError('match run overflow')


def unpack(raw):
    if len(raw) < 12 or len(raw) > MAX_BYTES:
        raise ValueError('truncated file')
    total = struct.unpack_from('<I', raw)[0]
    if not 48 <= total <= MAX_BYTES:
        raise ValueError('invalid total')
    parts = []
    blocks = []
    done = 0
    for offset in range(0, len(raw), 8192):
        chunk = raw[offset:offset + 8192]
        if len(chunk) < 8:
            raise ValueError('truncated block')
        declared = struct.unpack_from('<I', chunk)[0]
        capacity = total - done if offset == 0 else declared
        if not 1 <= capacity <= total - done:
            raise ValueError('invalid block output size')
        decoded, consumed = decode_block(chunk[4:], capacity)
        if offset and len(decoded) != declared:
            raise ValueError('block size mismatch')
        padding = chunk[4 + consumed:]
        if any(value != 255 for value in padding):
            raise ValueError('non-FF trailing data')
        parts.append(decoded)
        done += len(decoded)
        blocks.append({'offset': offset, 'stored_bytes': len(chunk), 'declared': declared,
                       'decoded_bytes': len(decoded), 'stream_bytes': consumed,
                       'trailing_ff_bytes': len(padding), 'end_marker_verified': True})
    result = b''.join(parts)
    if done != total or result[:4] != b'PXO4' or struct.unpack_from('<I', result, 8)[0] != total:
        raise ValueError('PXO4 header or total mismatch')
    return result, blocks


def write_output(source, target):
    source, target = Path(source), Path(target)
    if target.exists() or target.is_symlink():
        raise ValueError('output already exists')
    info = source.stat()
    if not stat.S_ISREG(info.st_mode) or not 12 <= info.st_size <= MAX_BYTES:
        raise ValueError('input is not a bounded regular file')
    with source.open('rb') as stream:
        raw = stream.read(MAX_BYTES + 1)
    decoded, blocks = unpack(raw)
    # Validation completes before creating the target; exclusive open rejects races.
    with target.open('xb') as stream:
        stream.write(decoded)
    return len(decoded), len(blocks)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    try:
        size, count = write_output(args.input, args.output)
    except (OSError, ValueError, struct.error) as error:
        parser.exit(1, str(error) + '\n')
    print(f'PXO4: {size} decoded bytes, {count} validated LGLZ blocks')
