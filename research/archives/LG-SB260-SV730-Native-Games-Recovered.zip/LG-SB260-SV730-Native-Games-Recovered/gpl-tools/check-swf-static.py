# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded SWF framing/AVM1 operand inspection. Never executes movie code.

Usage: python check-swf-static.py INPUT.swf OUTPUT.json
Written for this preservation task; no third-party source fragments used.
"""

from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import struct
import zlib


def need(condition, message):
    if not condition:
        raise ValueError(message)


def u16(data, pos):
    return struct.unpack_from("<H", data, pos)[0]


def string(data, pos, end):
    stop = data.find(b"\0", pos, end)
    need(stop >= 0, "Unterminated string")
    return data[pos:stop].decode("utf-8", "replace"), stop + 1


def inspect(source):
    raw = source.read_bytes()
    need(len(raw) >= 8, "Short SWF header")
    signature = raw[:3]
    need(signature in (b"CWS", b"FWS"), "Only CWS/FWS supported")
    size = struct.unpack_from("<I", raw, 4)[0]
    need(8 <= size <= 16_000_000, "Declared size outside bounded range")
    if signature == b"CWS":
        decoder = zlib.decompressobj()
        body = decoder.decompress(raw[8:], size - 8 + 1)
        need(not decoder.unconsumed_tail, "Decoded size exceeds bound")
        body += decoder.flush()
        need(decoder.eof, "Incomplete zlib stream")
        need(not decoder.unused_data, "Trailing data after zlib EOF")
        need(not decoder.unconsumed_tail, "Unconsumed compressed input")
    else:
        body = raw[8:]
    need(len(body) + 8 == size, "FileLength mismatch")
    data = b"FWS" + raw[3:8] + body

    def bits(pos, amount):
        need(pos + amount <= len(body) * 8, "Truncated RECT")
        result = 0
        for bit in range(pos, pos + amount):
            result = (result << 1) | ((body[bit // 8] >> (7 - bit % 8)) & 1)
        return result

    nbits = bits(0, 5)
    need(1 <= nbits <= 31, "Invalid RECT width")
    rect = []
    for index in range(4):
        value = bits(5 + index * nbits, nbits)
        if value & (1 << (nbits - 1)):
            value -= 1 << nbits
        rect.append(value)
    header_bytes = (5 + 4 * nbits + 7) // 8
    rate, frames = struct.unpack_from("<HH", body, header_bytes)
    tags_start = 8 + header_bytes + 4
    tags = []
    sprites = []

    def walk(start, end, depth, sprite=None):
        need(depth <= 32, "Sprite nesting exceeds bound")
        pos, actual_frames = start, 0
        while pos < end:
            need(pos + 2 <= end, "Truncated tag header")
            head = u16(data, pos)
            code, length, header = head >> 6, head & 63, 2
            if length == 63:
                need(pos + 6 <= end, "Truncated extended tag header")
                length, header = struct.unpack_from("<I", data, pos + 2)[0], 6
            payload, stop = pos + header, pos + header + length
            need(stop <= end, "Tag extends beyond enclosing range")
            tag = dict(code=code, offset=pos, payloadOffset=payload,
                       payloadBytes=length, end=stop, depth=depth, parentSprite=sprite)
            tags.append(tag)
            actual_frames += code == 1
            if code == 39:
                need(length >= 4, "Short DefineSprite")
                identity, declared_frames = struct.unpack_from("<HH", data, payload)
                sprite_frames = walk(payload + 4, stop, depth + 1, identity)
                need(sprite_frames == declared_frames, "Sprite frame count mismatch")
                sprites.append(dict(id=identity, declaredFrames=declared_frames,
                                    actualShowFrameTags=sprite_frames, endExact=True))
            pos = stop
            if code == 0:
                need(length == 0 and pos == end, "End is nonempty or not at range EOF")
                return actual_frames
        raise ValueError("Missing End tag")

    need(walk(tags_start, len(data), 0) == frames, "Movie frame count mismatch")
    histogram = Counter(tag["code"] for tag in tags)
    exports = {}
    for tag in tags:
        if tag["code"] != 56:
            continue
        pos, end = tag["payloadOffset"], tag["end"]
        need(pos + 2 <= end, "Short ExportAssets")
        amount, pos = u16(data, pos), pos + 2
        for _ in range(amount):
            need(pos + 2 <= end, "Short exported character ID")
            identity, pos = u16(data, pos), pos + 2
            name_offset = pos
            name, pos = string(data, pos, end)
            exports[identity] = dict(name=name, nameOffset=name_offset,
                                     tagOffset=tag["offset"])
        need(pos == end, "Trailing ExportAssets payload")

    def push_values(payload, pool):
        pos, values = 0, []
        while pos < len(payload):
            kind, pos = payload[pos], pos + 1
            amount = {1: 4, 2: 0, 3: 0, 4: 1, 5: 1, 6: 8, 7: 4, 8: 1, 9: 2}.get(kind)
            if kind == 0:
                value, pos = string(payload, pos, len(payload))
            else:
                need(amount is not None and pos + amount <= len(payload), "Invalid Push")
                value = {"kind": kind, "raw": payload[pos:pos + amount].hex()}
                if kind in (8, 9):
                    index = payload[pos] if kind == 8 else u16(payload, pos)
                    need(index < len(pool), "ConstantPool index out of range")
                    value = pool[index]
                elif kind == 4:
                    value = {"register": payload[pos]}
                pos += amount
            values.append(value)
        return values

    def actions(start, end, inherited_pool, depth=0):
        need(depth <= 32, "Function nesting exceeds bound")
        pos, pool, rows = start, inherited_pool[:], []
        while pos < end:
            begin, opcode = pos, data[pos]
            pos += 1
            length = 0
            if opcode >= 0x80:
                need(pos + 2 <= end, "Short AVM1 action header")
                length, pos = u16(data, pos), pos + 2
            stop = pos + length
            need(stop <= end, "AVM1 action exceeds containing range")
            payload = data[pos:stop]
            row = dict(offset=begin, opcodeHex=hex(opcode), payloadBytes=length)
            if opcode == 0x88:
                need(len(payload) >= 2, "Short ConstantPool")
                amount, cursor, pool = u16(payload, 0), 2, []
                for _ in range(amount):
                    value, cursor = string(payload, cursor, len(payload))
                    pool.append(value)
                need(cursor == len(payload), "Trailing ConstantPool bytes")
                row["constants"] = pool[:]
            elif opcode == 0x96:
                row["push"] = push_values(payload, pool)
            elif opcode in (0x8E, 0x9B):
                name, cursor = string(payload, 0, len(payload))
                need(cursor + 2 <= len(payload), "Short function header")
                amount, cursor = u16(payload, cursor), cursor + 2
                if opcode == 0x8E:
                    need(cursor + 3 <= len(payload), "Short Function2 header")
                    cursor += 3
                params = []
                for _ in range(amount):
                    register = None
                    if opcode == 0x8E:
                        need(cursor < len(payload), "Short parameter register")
                        register, cursor = payload[cursor], cursor + 1
                    param, cursor = string(payload, cursor, len(payload))
                    params.append(dict(name=param, register=register))
                need(cursor + 2 == len(payload), "Unexpected function header size")
                code_size = u16(payload, cursor)
                need(stop + code_size <= end, "Function body exceeds action range")
                row.update(name=name, parameters=params, bodyOffset=stop, bodyBytes=code_size)
                if rows and "push" in rows[-1]:
                    row["precedingPush"] = rows[-1]["push"]
                row["actions"] = actions(stop, stop + code_size, pool, depth + 1)
                stop += code_size
            rows.append(row)
            pos = stop
            if opcode == 0:
                need(pos == end, "Trailing bytes after AVM1 End")
        return rows

    mmi = []
    for tag in tags:
        if tag["code"] != 59:
            continue
        need(tag["payloadBytes"] >= 2, "Short DoInitAction")
        identity = u16(data, tag["payloadOffset"])
        exported = exports.get(identity, {})
        if exported.get("name") != "__Packages.MMI":
            continue
        parsed = actions(tag["payloadOffset"] + 2, tag["end"], [])
        selected = []
        for row in parsed:
            if row.get("precedingPush", [])[-1:] in (["startSound"], ["startVolSound"]):
                selected.append(row)
        mmi.append(dict(characterId=identity, export=exported,
                        doInitActionTagOffset=tag["offset"], selectedFunctions=selected))

    sounds = []
    sound_dir = source.parent / "sound"
    if sound_dir.is_dir():
        for sound in sorted(sound_dir.glob("*.wav")):
            value = sound.read_bytes()
            stem = sound.stem.encode("ascii") + b"\0"
            offsets, pos = [], 0
            while True:
                pos = data.find(stem, pos)
                if pos < 0:
                    break
                offsets.append(pos)
                pos += 1
            item = dict(name=sound.name, bytes=len(value),
                        sha256=hashlib.sha256(value).hexdigest(),
                        exactStemOffsets=offsets, first12BytesHex=value[:12].hex())
            if len(value) >= 12 and value[:4] == b"MMMD":
                declared = struct.unpack_from(">I", value, 4)[0]
                item.update(containerSignature="MMMD", firstChunk=value[8:12].decode("ascii", "replace"),
                            declaredContainerBytes=declared, containerLengthExact=declared + 8 == len(value),
                            extensionOnly=".wav; not a RIFF/WAVE format claim")
            sounds.append(item)

    return dict(
        source=dict(name=source.name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                    signature=signature.decode(), swfVersion=raw[3]),
        compression=dict(fileLength=size, actualUncompressedBytes=len(data), exactLength=True,
                         zlibEofExact=True if signature == b"CWS" else None, trailingBytes=0),
        movieHeader=dict(rectNbits=nbits, rectTwips=rect,
                         widthPixels=(rect[1] - rect[0]) / 20,
                         heightPixels=(rect[3] - rect[2]) / 20,
                         frameRateFixed8Raw=rate, frameRate=rate / 256, frameCount=frames),
        structure=dict(allTagBoundsValid=True, allEndTagsExact=True, allFrameCountsExact=True,
                       recursiveTagCount=len(tags), topLevelTagCount=sum(t["depth"] == 0 for t in tags),
                       defineSpriteCount=len(sprites), tagCounts={str(k): v for k, v in sorted(histogram.items())}),
        languageEvidence=dict(avm1DoActionTags=histogram[12], avm1DoInitActionTags=histogram[59],
                              avm2DoABCTags=histogram[82], avm2DeprecatedDoABCTags=histogram[72]),
        mmiAdapterEvidence=mmi, sameDirectorySoundFiles=sounds,
        limits=["No movie, ActionScript, native callback or audio was executed.",
                "Tag framing and selected MMI AVM1 operands only; not complete SWF semantic validation.",
                "Container version and AVM1 encoding do not identify source ActionScript 1 versus 2 or exact Flash Lite runtime.",
                "Same-directory filenames/stems do not prove host directory resolution, audibility or runtime completeness."],
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = inspect(args.input)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", "utf-8")


if __name__ == "__main__":
    main()
