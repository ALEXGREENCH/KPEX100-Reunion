// Host comparison only: decompressor subset; uintptr_t fixes 32-bit pointer casts. GPL-3.0-or-later.
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define MIN(a, b)	(a < b) ? a : b

#define MAX(a, b)	(a > b) ? a : b

#ifdef DEBUG
#define FLUSH \
	{ \
		field = (field << (32 - field_size)); \
		*((unsigned int *) ctrl) = field; \
		printf("CTRL:0x%X\n", field); \
	}
#else
#define FLUSH \
	{ \
		field = (field << (32 - field_size)); \
		*((unsigned int *) ctrl) = field; \
	}
#endif
#define PUT_BIT(a) \
	{ \
		if(field_size == 32) \
		{ \
			FLUSH	ctrl = out; \
			out += 4; \
			field = 0; \
			field_size = 0; \
		} \
		field = (field << 1) | (a & 0x1); \
		field_size++; \
	}

#define UNROLL(a)	{ while(a != 0) { PUT_BIT(a) a = (a >> 1); PUT_BIT(a) a = (a >> 1); } PUT_BIT(0); }
#define RESERVED	16
#define MIN_SIZE	4
#define COPY \
	{ \
		*(out++) = *(in++); \
	}

#define COPY2 \
	{ \
		*(out++) = *((char *) out_copy); \
		out_copy++; \
	}
#ifdef _DEBUG
#define GET_BIT \
	{ \
		tmp = 0; \
		if(((control) & 0x7FFFFFFF) == 0) \
		{ \
			tmp = control >> 31; \
			data = in; \
			control = (data[0]) | (data[1] << 8) | (data[2] << 16) | (data[3] << 24); \
			printf("Control:0x%X\n", control); \
			in = in + 4; \
		} \
		bit = ((control & 0x80000000) != 0); \
		control = (control << 1) + tmp; \
	}
#else
#define GET_BIT \
	{ \
		tmp = 0; \
		if(((control) & 0x7FFFFFFF) == 0) \
		{ \
			tmp = control >> 31; \
			data = in; \
			control = (data[0]) | (data[1] << 8) | (data[2] << 16) | (data[3] << 24); \
			in = in + 4; \
		} \
		bit = ((control & 0x80000000) != 0); \
		control = (control << 1) + tmp; \
	}
#endif
#define CHECK_BIT	(bit != 0)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */

__declspec(dllexport) int decompress(const unsigned char *in, unsigned char *out)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	unsigned char		*out_save = out;
	const unsigned char *data;
	unsigned int		control = 0x80000000;
	unsigned int		tmp;
	unsigned int		bit;
	unsigned int		offset;
	uintptr_t		out_copy;
	unsigned int		i;
	unsigned int		j;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	while(1)
	{
		i = 1;
		GET_BIT;
		while(CHECK_BIT)
		{
			for(j = 0; j < i; j++)
			{
				COPY;
			}

			GET_BIT;
			if(CHECK_BIT)
			{
				for(j = 0; j < i; j++)
				{
					COPY;
				}
			}

			i = (i << 1);

			GET_BIT;
		}

		out_copy = *(in++);

		if(out_copy & 0x80)
		{
			out_copy = *(in++) | (out_copy << 8);
			out_copy &= 0x7FFF;

			if(out_copy != 0)
			{
				offset = out_copy;
				out_copy = (uintptr_t) out - out_copy;
				COPY2;
				COPY2;
				COPY2;
			}
			else
				return out - out_save;	// Return reading size
		}
		else
		{
			if(out_copy == 0)
			{
				out_copy = (uintptr_t) out - offset;
				COPY2;
				COPY2;
				COPY2;
			}
			else
			{
				if(out_copy >= 0x10)
				{
					out_copy = (out_copy << 1) - 0x10;
				}

				out_copy = (uintptr_t) out - out_copy;
				COPY2;
				COPY2;
			}
		}

		i = 1;
		GET_BIT;
		while(CHECK_BIT)
		{
			for(j = 0; j < i; j++)
			{
				COPY2;
			}

			GET_BIT;
			if(CHECK_BIT)
			{
				for(j = 0; j < i; j++)
				{
					COPY2;
				}
			}

			i = (i << 1);
			GET_BIT;
		}
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
