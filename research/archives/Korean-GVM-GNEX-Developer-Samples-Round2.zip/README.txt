# GVM/GNEX developer samples recovered from public Korean blogs

Recovered 2026-11-05. Three unchanged SGS examples; zero new game claims.

- RANKING: original GVM1X/SGSv1 ranking client, 1338 bytes. Source explicitly maps SCRIPTVER1 to GVM1X. Menu-only replay succeeds; no ranking server or network request was run.
- middle_exam: GNEX4/12154-byte image-display assignment, moving character/background. No score, goal or loss condition established.
- middle_test: GNEX4/4142-byte character-movement example with original MobileC/project/resources. The source has a conditional GVM2 branch; the recovered compiled file is GNEX4 only.

Original public sources:
https://blog.naver.com/milkclub/60004692030
https://blog.naver.com/novakjh/30030168332
https://blog.naver.com/novakjh/30030318941

The originals/ ZIPs and standalone SGS preserve the exact downloaded bytes. sgs/ contains convenient unchanged copies of SGS members from those original ZIPs. Full source file hashes, ZIP CRC checks, payload layouts, provenance and paired input/control results are in research/curated-developer-samples-round2.json. Original third-party files retain their original rights; the Reunion MIT licence does not relicense them.

Replay using a separately cloned KPEX100-Reunion repository with its included Kingston2.12 ROM:

node tools/replay-sgs.mjs --file /path/to/bundle/sgs/ranking.sgs /path/to/bundle/replays/ranking-actions.json /path/to/output-ranking
node tools/replay-sgs.mjs --file /path/to/bundle/originals/middle_exam-novakjh.sgs /path/to/bundle/replays/sample-actions.json /path/to/output-image
node tools/replay-sgs.mjs --file /path/to/bundle/sgs/middle_test.sgs /path/to/bundle/replays/sample-actions.json /path/to/output-character

Paired controls preserve virtual deadlines while omitting test keys. All six original interpreter runs ended idle/error-null. They verify displayed output and local input, not full network services, audio, saves or commercial-game playthroughs. Network server C, rankdb.o and all vendor executables were only preserved/read statically.
