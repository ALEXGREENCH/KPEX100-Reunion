# Sinjisoft Mobile C Library Function Reference 311

Original PDF supplied by the user URL and previously downloaded from Daum.
The PDF bytes are unchanged. The storage filename is assigned by Reunion.
The cover and change log identify MCC-API-301-311; the copyright page still
uses MCC-API-301-310. That source inconsistency is retained.

This is the older 2007 reference requested by the user, not the different
API313 document inside later SDKs. See provenance.json for source URL,
length, SHA-256 and retrieval limits. No new download or signature
verification is claimed by this packaging pass. The original document
retains its own rights; Reunion's MIT licence does not relicense it.

manifest.json hashes every other member. Verify whole ZIP CRC and each
listed length/SHA-256 without opening or executing vendor software.
