Petris on original Kingston 2.12: native replay

This archive preserves one full original-firmware menu boot and short-input
sequence on emulated ARM. The firmware read the unmodified 32 KiB Petris ROM
through its FAT16 file path. Native key callbacks and their release events
are recorded alongside LCD frames and sprite positions.

Run from a full Reunion checkout with its original assets:
node tools/replay-petris-native.mjs --output /path/to/empty-directory
The archive alone does not contain the ARM backend or Kingston firmware.
It includes the original Petris cartridge, upstream source archive, replay
tool and launcher source for this scenario.

Each RGBA frame is 220 x 176, four bytes per pixel, row-major. PNG copies
preserve the same full LCD pixels. The native receipt gives RGBA SHA-256;
manifest.json records sizes and hashes for all archived files.

Right moves the active sprite one eight-pixel cell. Select changes its
rotation pattern. Game-stage held and pending masks return to zero.
The Down sample moves it lower; acceleration is not measured against a
neutral control. Neighboring ARM sampling boundaries can give different
guest frames, so this trace is not a strict cross-version input golden.
The original firmware's missing long-hold release after autorepeat remains
a separate known issue. No experimental ARM release patch is enabled.
Modeled time is not a physical-player FPS measurement. GG audio is absent.

Reunion code: MIT (REUNION-LICENSE.txt).
Petris by bbbbbr, Game Gear 1.1 beta, 2021:
https://bbbbbr.itch.io/petris
https://github.com/bbbbbr/Petris/tree/97fa9f03f5c0fa84810da0632679481d8e0b71d1
Screenshots derive from that unchanged ROM; see PETRIS-LICENSE.txt
(Game Gear branch: CC BY-NC-SA 4.0). Preserved upstream source archive:
https://github.com/ALEXGREENCH/KPEX100-Reunion/blob/main/demos/gg/petris/upstream-source.zip
SHA-256: 9a33e8900830f03daab3da0e9f6a9dae3279562a101ba142f29a89701829e04a
