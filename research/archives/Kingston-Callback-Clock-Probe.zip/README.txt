Reunion: original Kingston 2.12 callback clock probe.
Unpack into a full Reunion checkout, then run:
node tools/probe-kingston-callback-clock.mjs --output NEW.json
Original firmware is not included. Modeled ARM time is not a physical hardware measurement.
All package files are Reunion MIT code and generated observations. See doc/kingston-callback-clock.md.
