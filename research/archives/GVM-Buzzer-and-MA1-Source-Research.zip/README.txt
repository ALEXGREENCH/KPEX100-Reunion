GVM buzzer and MA1 source research, 6–7 November 2026.

Received mirror PDF: Yamaha MA-1C LSI-4MU757B2, April 2000. There are 43
manufacturer pages and one appended distributor page, 44 total. Received bytes
are unchanged. URL, status, UTC, headers, size and SHA-256 are preserved.
This differs from the 2004 B3 edition shown in another search result.
Washington returned an HTML identity-provider chooser; it is kept as a failed
PDF retrieval. No login was attempted. Six specified PDF pages were visually
reviewed; text and page boxes were extracted from all 44 pages.

Three unchanged SDK extracts match previously published archive members.
All ten sound initializers from Hellfire_Bzr.ssd and Hellfire_Ma1.ssd match
the corresponding WI-TOP SGS resources exactly. This comparison does not
establish identity of the entire game build.

The isolated x86 buzzer-loop reference intercepts Beep, wait and stop calls;
no Windows program or physical speaker runs. Eight vectors cover five original
resources, all 37 notes and rest at durations 0/1/255, empty input and the native
high-byte terminator. Event frequencies and timing match the reference.
Square-wave PCM approximates the SDK speaker; no exact phone sound is claimed.
Raw MA1 remains unsupported and is not replaced with buzzer tones.

The WAVE is derived from existing game content, not another recovered original.
Existing third-party rights remain; MIT covers new Reunion code.
manifest.json covers every other member.
