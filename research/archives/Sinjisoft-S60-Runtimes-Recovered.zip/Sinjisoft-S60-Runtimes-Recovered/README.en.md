# Preserved Symbian S60 GNEX applications and runtimes

This preservation bundle, dated 5 November 2026, contains seven previously
recovered packages: complete SIS installers, every extracted payload and separate
SGS slices. Recovered SIS and payload bytes were not patched or recompiled.

Each package is a native Symbian E32 `.app` containing a GNEX runtime and an
embedded SGS v4 game. GNEX interprets Mobile C bytecode. These applications are
not full-phone, CPU or Symbian OS emulators. Seven APP files do not establish
seven distinct VM implementations.

Static analysis of Storm identified its SGS copy and ordinary START dispatch;
the loader size agrees with the validated SGS boundary. EPOC headers and
`Powered by GNEX` / `GNEX EXCEPTION` strings were checked in the preserved APPs.
Historical sources describe S60 releases, but each recovered third-party SIS has
not been authenticated against the original Handango installer. Some filenames
identify repacks and are preserved as found. No unofficial-emulator status is
asserted for these runtimes.

## Contents

| Application | SIS header version | UID | SGS bytes |
| --- | --- | --- | ---: |
| Aiolos Fighter | 1.03 | `10272e3d` | 270,080 |
| Pocket Baseball 2 / 포켓야구2 | 1.03 | `10272e44` | 162,384 |
| Pocket Golf | 1.03 | `10272e46` | 326,528 |
| World League 2005 Soccer | 1.03 | `10272e3e` | 172,604 |
| Bounce! Rubberball Story | 1.03 | `10272e3f` | 169,388 |
| Storm of Silence Demo | 1.00 | `10275469` | 128,690 |
| Waterski | 1.00 | `1027546a` | 147,636 |

Versions come from numeric SIS fields, not archive filenames or website dates.
Storm is a demo. Waterski 1.00 is not represented as version 1.03.

- `original-sis/<id>/`: complete recovered SIS files with original archive member names.
- `extracted/<id>/`: all SIS records without byte changes, including APP and any
  AIF/RSC, WAV/MID and other resources. Each extraction manifest retains target
  install paths, compressed record offsets, sizes and hashes.
- `derived-sgs/`: byte-identical slices of APP files at the validated offsets and
  lengths. They are extracted derivatives, not separate original distributions.
- `manifest.json`: public source URLs, exact archive members, UID/body CRCs,
  every file hash, SGS offsets and observed GNEX markers.
- `tools/`: Reunion's own static extraction and verification utilities.

## Verify after extraction

Python 3.11 or newer is sufficient. From the extracted bundle root:

```sh
python tools/verify-preservation.py
```

The verifier checks every size, SHA-256 and CRC32, decodes all seven SIS files
again and compares every extracted payload. It also verifies each SGS against
its source APP slice. It does not execute any original application. The external
ZIP hash and clean-extraction result are in a separate verification receipt.

Example static re-extraction into a new directory:

```sh
python tools/extract-old-sis.py original-sis/storm-of-silence-demo-s60/stormofsilencedemo.sis storm-fresh
```

## Evidence and limits

This operation performs static preservation. No native SIS/APP was installed or
executed. A successful SGS replay in Reunion uses Kingston 2.12 and does not
demonstrate that the Symbian wrapper boots. Running an APP requires a compatible
Symbian OS and its APIs, which this bundle does not provide. External WAV/MIDI
files are preserved but are not connected to Reunion's SGS playback. Full game
completion, persistence and equivalence of all S60 APIs remain unverified.

CRCs and hashes verify integrity of the recovered bytes, not publisher-signature
authenticity. SIS signatures have not been authenticated. The MIT license under
`tools/` applies only to Reunion's original utility code, not to games, native
runtimes or third-party resources. Phone memory images, private EFS data, the
9 GB S60 archive, the 2 GB solid folder and temporary decoded streams are omitted.

Sources and research: [Reunion](https://github.com/ALEXGREENCH/KPEX100-Reunion),
[2010 SIS collection](https://www.pc-freak.net/archives/2010/01/22/download_nokia_sis_ultimate_pack_games/index.html), [Dertz](https://archive.org/details/dertz-part-5-s-z), [S60 collection](https://archive.org/details/largest-j2me-and-symbian-collection).
Exact public archive/member URLs and hashes are in the manifest. Source URLs
describe provenance; their continued availability is not asserted.
