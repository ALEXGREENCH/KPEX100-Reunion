"""Read-only verification of the recovered S60 preservation bundle."""
from pathlib import Path, PurePosixPath
import hashlib
import importlib.util
import json
import sys
import zlib

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def safe_path(name):
    parts = PurePosixPath(name).parts
    if not parts or name.startswith("/") or "\\" in name:
        raise ValueError("Unsafe manifest path")
    if any(part in (".", "..") or ":" in part for part in parts):
        raise ValueError("Unsafe manifest path")
    target = ROOT.joinpath(*parts)
    if not target.resolve().is_relative_to(ROOT) or target.is_symlink():
        raise ValueError("Manifest path escapes the bundle")
    return target


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
assert manifest["schema"] == 1
assert len(manifest["files"]) < 1024
assert sum(item["bytes"] for item in manifest["files"]) < 256 * 1024 * 1024
expected_names = {item["path"] for item in manifest["files"]} | {"manifest.json"}
actual_names = {
    path.relative_to(ROOT).as_posix()
    for path in ROOT.rglob("*")
    if path.is_file() and "__pycache__" not in path.parts
}
assert actual_names == expected_names, "Unexpected or missing bundle files"
for item in manifest["files"]:
    path = safe_path(item["path"])
    assert path.is_file() and path.stat().st_size == item["bytes"], item["path"]
    raw = path.read_bytes()
    assert sha256(raw) == item["sha256"], item["path"]
    assert f"{zlib.crc32(raw):08x}" == item["crc32"], item["path"]

spec = importlib.util.spec_from_file_location(
    "extract_old_sis", ROOT / "tools/extract-old-sis.py"
)
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
payloads = 0
for package in manifest["packages"]:
    sis = safe_path(package["installer"]["path"]).read_bytes()
    parsed, outputs = extractor.parse_sis(sis)
    assert parsed["uid_crc_verified"] and parsed["body_crc_verified"]
    assert parsed["version_major"] == package["installer"]["versionMajor"]
    assert parsed["version_minor"] == package["installer"]["versionMinor"]
    assert len(outputs) == package["extractedFiles"]
    destination = safe_path(package["extractedDirectory"])
    for name, raw in outputs:
        assert (destination / name).read_bytes() == raw, (package["id"], name)
        payloads += 1
    app = safe_path(package["application"]["path"]).read_bytes()
    derived = package["derivedSgs"]
    raw = safe_path(derived["path"]).read_bytes()
    start = derived["sourceAppOffset"]
    assert app[start : start + len(raw)] == raw
    assert sha256(raw) == derived["sha256"]

print(
    json.dumps(
        {
            "ok": True,
            "manifestedFiles": len(manifest["files"]),
            "packages": len(manifest["packages"]),
            "sisUidAndBodyCrcPassed": len(manifest["packages"]),
            "extractedPayloadsEqualToFreshSisDecode": payloads,
            "embeddedSgsSlicesVerified": len(manifest["packages"]),
            "nativeApplicationExecuted": False,
        }
    )
)
