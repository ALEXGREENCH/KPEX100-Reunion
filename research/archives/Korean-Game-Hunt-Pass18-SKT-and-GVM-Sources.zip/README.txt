Korean game acquisition / GVM source preservation pass18, 2026-11-07.

73 unchanged game ZIPs from72 public SKT posts on Palletshipping; all496 listed
posts inventoried across17 pages. All73 game packages contain Java classes.
No SGS found, no JVM added to Reunion. Other operators were not exhaustively
acquired. Five supplementary unchanged attachments include two GVM developer
sources, one project WAV, an unrelated KTF game package, and an already known
modified GVM2X executable. Do not count these as new recovered SGS games.

Every input original SHA256/size, every recursive ZIP/JAR member CRC/size/SHA256
and all plain/XOR A5 SGS version-byte offsets statically checked. All76 existing
SGS detected as positive controls. No vendor or guest software executed.
No generic compression/encryption decoder is claimed by a zero scan result.

Original HTTP bodies include shells, index snippets, HTTP401 and404 responses.
Each has its own UTC/status/hash/URL receipt; HTTP200 is not proof of content.
Phone GNEX player and .hack epilogue remain unrecovered. A public exact GVM
category list confirms all9 Brewgames posts match the previous acquisition.
Four selected Wayback CWS files retain verified CDX SHA1/SHA256/provenance;
static zlib length checks/ASCII link candidates only. No Flash execution.

To repeat the audit, extract into a separate directory without merging any
older outputs, then run Python3.11+ with a full Reunion checkout path:
python audit-archives.py --repo /path/to/Reunion --output NEW_FILE.json
Original game/firmware collection is needed for the76 positive controls.
Reports have current UTC and the exact source-tool hash from that checkout.
This archive retains a snapshot under reproduction/tools/ as provenance.

JSONL records are LF-delimited. Literal U+0085 bytes in nine Naver header
strings must not be split with Python str.splitlines(). Fixed own collectors
and two regression tests are included. Actual78 cache resumes used no network
and rehashed every original; sources.json and downloaded bodies stayed exact.

Original notices and historical rights remain with their owners. Reunion MIT
covers its own tools, not historical games, resources, vendor code or documents.
manifest.json checks all other direct ZIP members; its own hash is excluded.
