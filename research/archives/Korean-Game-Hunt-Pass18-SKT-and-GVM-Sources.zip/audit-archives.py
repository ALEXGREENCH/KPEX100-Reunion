"""Audit preserved ZIP/JAR bytes; never run a guest or extract archive paths.

Run from this directory with --repo pointing to a full Reunion checkout.
The identical source-download folders are also included in the research ZIP.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import zipfile


BASE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
args = argparse.ArgumentParser(description=__doc__)
args.add_argument("--repo", type=Path, required=True)
args.add_argument("--output", type=Path, required=True)
opts = args.parse_args()
assert not opts.output.exists()
repo = opts.repo.resolve()
spec = importlib.util.spec_from_file_location(
    "scanner", repo / "tools/scan-firmware-games.py"
)
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
scanned = {}
expanded = 0
rows = []


def inspect(body, name, depth=0):
    global expanded
    expanded += len(body)
    if expanded > 512 * 1024 * 1024 or len(body) > 64 * 1024 * 1024:
        raise ValueError("Audit byte bound exceeded")
    key = sha(body)
    row = {
        "path": name,
        "bytes": len(body),
        "sha256": key,
        "signatureHex": body[:16].hex(),
    }
    # Java magic alone is recorded, with class version; no JVM execution implied.
    if body.startswith(b"\xca\xfe\xba\xbe") and len(body) >= 8:
        minor, major = struct.unpack(">HH", body[4:8])
        row["javaClassVersion"] = {"major": major, "minor": minor}
    if key not in scanned:
        scanned[key] = scanner.scan_bytes(body)
    scan = scanned[key]
    row["candidateOffsetsTested"] = scan["candidate_offsets_tested"]
    row["sgsContainers"] = scan["containers"]
    if zipfile.is_zipfile(io.BytesIO(body)):
        if depth >= 4:
            raise ValueError("Archive depth bound exceeded")
        with zipfile.ZipFile(io.BytesIO(body)) as archive:
            members = archive.infolist()
            if len(members) > 20000 or any(
                m.file_size > 64 * 1024 * 1024 for m in members
            ):
                raise ValueError("ZIP member bound exceeded")
            children = []
            for member in members:
                data = archive.read(member)  # zipfile verifies each member CRC.
                child = inspect(data, member.filename, depth + 1)
                child["zipCrc32"] = f"{member.CRC:08x}"
                child["directory"] = member.is_dir()
                children.append(child)
            row["zipCrcPassed"] = True
            row["members"] = children
    return row


for folder in ["pallet-first-downloads", "pallet-rest-downloads", "attachments"]:
    root = BASE / folder
    sources = json.loads((root / "sources.json").read_text("utf8"))
    # JSONL is LF-delimited; HTTP header strings may contain literal U+0085.
    receipts = [
        json.loads(line)
        for line in (root / "receipts.jsonl").read_text("utf8").split("\n")
        if line
    ]
    assert len(receipts) == len(sources)
    for source, receipt in zip(sources, receipts):
        assert receipt == source["receipt"]
        if receipt.get("status") != 200 or receipt.get("complete") is not True:
            raise ValueError("Incomplete attachment response")
        body = (root / receipt["path"]).read_bytes()
        assert len(body) == receipt["bytes"] and sha(body) == receipt["sha256"]
        inspected = inspect(body, receipt["path"])
        row = {
            "folder": folder,
            "sourcePage": source["sourcePage"],
            "downloadUrl": source["url"],
            "retrievedUtc": receipt["retrievedUtc"],
            "inspection": inspected,
        }
        rows.append(row)
        print(
            json.dumps({"folder": folder, "done": len(rows), "bytes": len(body)}),
            flush=True,
        )


def flatten(row):
    yield row
    for child in row.get("members", []):
        yield from flatten(child)


flat = [member for row in rows for member in flatten(row["inspection"])]
controls = scanner.check_controls(
    json.loads((repo / "web/data/catalog.json").read_text("utf8"))
)
report = {
    "schema": 1,
    "checkedUtc": datetime.now(timezone.utc).isoformat(),
    "scope": "Every supplied original download and every recursively decoded ZIP/JAR member. Every version-byte offset scanned, plain and XOR A5; no vendor executable or Java class executed. No proprietary compression decoder is implied.",
    "scannerSha256": sha((repo / "tools/scan-firmware-games.py").read_bytes()),
    "rows": rows,
    "positiveControls": controls,
    "counts": {
        "downloads": len(rows),
        "downloadBytes": sum(r["inspection"]["bytes"] for r in rows),
        "inspectedOccurrences": len(flat),
        "uniqueScannedBodies": len(scanned),
        "expandedOccurrenceBytes": expanded,
        "zipContainers": sum("members" in r for r in flat),
        "javaClassOccurrences": sum("javaClassVersion" in r for r in flat),
        "sgsNamedMembers": sum(r["path"].lower().endswith(".sgs") for r in flat),
        "sgsContainers": sum(len(r["sgsContainers"]) for r in flat),
        "candidateOffsetsTestedUnique": sum(
            r["candidate_offsets_tested"] for r in scanned.values()
        ),
        "fileExtensions": dict(Counter(Path(r["path"]).suffix.lower() for r in flat)),
    },
}
opts.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", "utf8")
print(json.dumps(report["counts"]))
