Tall narrow palette image batches and Battle Armor validation. 2026-11-07 MSK.

Production ROM shortcut now also accepts ordinary image batches with row widths
32..127 and >=4096 remaining pixels, subject to all original bounds, alias,
palette, stride, bit alignment, ARM state and work-budget guards. Short single
rows and small sprites remain native. ROM and SGS are unchanged; this download
contains own tools/reports plus two reviewed game screenshots, not new games.

Three alternating old/current pairs use actual baseline source 357ec3567af43df237802286687938e59a280c98.
Initial paired warmup is excluded. All six result fingerprints match. The
summary contains measured medians; these are host guest-call times, NOT FPS.
Eight additional default benchmark fingerprints match old/current; their single
timings had concurrent host activity and are NOT used as speedup evidence.

Two exact/guarded seeded tests compare every operation over 600000 virtual ms
after the respective prelude, with checkpoints every 100 operations. Compare
scope is precise in each JSON: variables, descriptors, used stack, visible
pixels, VM PC, input, timers, syscalls and serialized saves, not all allocated RAM.
Native helper tests independently compare registers/CPSR, stack, pixel buffers,
source/palette bytes and block clock including exact threshold and budget cases.

The original action plan ends in Garage with current native key releases. The
new plan exits Garage into the base. The two included frames were visually
reviewed and their decoded pixel hashes match both runtimes' prelude frames.
Neither frame establishes active combat. The 125-second Chrome UI test reached
base menus; exact HTTP response hashes bind it to the current runtime and games.
No reported random freeze was reproduced or claimed fixed. No full playthrough,
physical-controller test, physical-device timing or cycle-exact claim is made.

Input sequences, unchanged original identities, host details and all source
hashes are retained. manifest.json covers all other members with size/SHA256/CRC.
MIT applies to Reunion tools; original third-party material retains its rights.
