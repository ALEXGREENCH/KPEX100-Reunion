import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const baseline=new URL('../reunion-release-pass3-20261106/fresh-clone/',import.meta.url);
const candidate=new URL('../../outputs/KPEX100-Reunion/',import.meta.url);
const runs=[];
for(let i=0;i<3;i++){
 for(const label of i%2===0?['baseline','candidate']:['candidate','baseline']){
  const root=label==='baseline'?baseline:candidate;
  const output=new URL(`alternating-${i}-${label}.json`,import.meta.url);
  assert.equal(fs.existsSync(output),false);
  const tool=new URL('tools/benchmark-web.mjs',root);
  process.argv=[process.execPath,tool.pathname,'--games','battle-armor','--prelude',new URL('validation/kingston-naver-replays/battle-armor.json',root).pathname.replace(/^\/([A-Z]:)/,'$1'),'--runs','1','--frames','180','--warmups',i===0?'1':'0','--execution','guarded','--output',output.pathname.replace(/^\/([A-Z]:)/,'$1')];
  await import(tool.href+`?round=${i}`);
  const report=JSON.parse(fs.readFileSync(output));assert.equal(report.passed,true);
  runs.push({label,round:i,report:output.pathname.split('/').at(-1),measurement:report.games[0].guarded[0],romSha256:report.romSha256,gameSha256:report.games[0].gameSha256});
 }
}
const expected=JSON.stringify(runs[0].measurement.result);
for(const r of runs)assert.equal(JSON.stringify(r.measurement.result),expected);
const median=values=>values.sort((a,b)=>a-b)[1];
const old=median(runs.filter(r=>r.label==='baseline').map(r=>r.measurement.guestMs));
const current=median(runs.filter(r=>r.label==='candidate').map(r=>r.measurement.guestMs));
const hash=b=>createHash('sha256').update(b).digest('hex');
const result={ok:true,baselineCommit:'357ec3567af43df237802286687938e59a280c98',methodology:'One Node process, two actual source roots. Three alternating pairs of the same original Battle Armor prelude + 180 explicit benchmark frames; initial paired warmup excluded. Result fingerprints match across all six measured runs. Guest-call host work only, not browser FPS. Other heavy test processes completed before this pass; network collector remained active.',runs:runs.map(({measurement,...r})=>({...r,guestMs:measurement.guestMs,nativeHelpers:measurement.nativeHelpers,resultSha256:hash(Buffer.from(JSON.stringify(measurement.result)))})),baselineMedianMs:old,candidateMedianMs:current,speedup:old/current,workReductionPercent:(1-current/old)*100,runtimeSourceSha256:hash(fs.readFileSync(new URL('web/engine/rom-accelerators.js',candidate)))};
fs.writeFileSync(new URL('alternating-summary.json',import.meta.url),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({ok:true,baselineMedianMs:old,candidateMedianMs:current,speedup:result.speedup,workReductionPercent:result.workReductionPercent}));
