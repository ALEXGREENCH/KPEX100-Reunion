from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
import zlib
from PIL import Image

base=Path(__file__).resolve().parent
repo=base.parent.parent/'outputs/KPEX100-Reunion'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda r:(json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode()
benchmark=read(base/'alternating-summary.json');assert benchmark['ok']
assert sha((repo/'web/engine/rom-accelerators.js').read_bytes())==benchmark['runtimeSourceSha256']
stressNames=['final-battle-differential-12345.json','lf-garage-exit-differential-67890.json']
stresses=[read(base/n) for n in stressNames]
for r in stresses:
 assert r['comparisons']==[{'id':'battle-armor','matches':True}]
 assert all(s['status']=='idle' and s['virtualMs']-s['preludeEndMs']==600000 for s in r['results'])
 for n,h in r['runtimeSourceSha256'].items():assert sha((repo/'web/engine'/n).read_bytes())==h
 assert sha((repo/r['options']['prelude']).read_bytes())==r['preludeSha256']
browser=read(base/'browser-final.json');assert browser['ok'] and browser['wallMs']>=125000
assert not browser['errors'] and not browser['sourceErrors'] and len(browser['fetchedSources'])==7
for n,r in browser['fetchedSources'].items():
 body=(repo/'web'/n).read_bytes();assert len(body)==r['bytes'] and sha(body)==r['sha256']
old=read(base/'baseline-eight-benchmark.json');current=read(base/'final-eight-benchmark.json')
assert len(old['games'])==len(current['games'])==8
for a,b in zip(old['games'],current['games']):
 assert a['id']==b['id'] and a['guarded'][0]['result']==b['guarded'][0]['result']
for r in benchmark['runs']:
 case=read(base/r['report']);assert case['games'][0]['guarded'][0]['matches']
 assert case['romSha256']==r['romSha256'] and case['games'][0]['gameSha256']==r['gameSha256']
frames=[]
for name,label,stress in [
 ('garage-exit-v2-replay/battle-armor-52-tick5.png','Original action plan ends in Garage',stresses[0]),
 ('garage-exit-v2-replay/battle-armor-62-tick12.png','New action plan exits Garage into the base; not combat',stresses[1])]:
 p=base/name;im=Image.open(p).convert('RGBA');digest=sha(im.tobytes())
 assert all(r['preludeFrameSha256']==digest for r in stress['results'])
 frames.append({'path':name,'review':label,'pngSha256':sha(p.read_bytes()),'rgbaSha256':digest,'size':list(im.size)})
entries={}
for name in [*stressNames,'browser-final.json','browser-final.png','alternating-summary.json','benchmark-alternating.mjs','baseline-eight-benchmark.json','final-eight-benchmark.json','integration.log','package-results.py']:
 entries['validation/'+name]=(base/name).read_bytes()
for r in benchmark['runs']:entries['validation/'+r['report']]=(base/r['report']).read_bytes()
for r in frames:entries['frames/'+Path(r['path']).name]=(base/r['path']).read_bytes()
entries['validation/reviewed-scenes.json']=js(frames)
for name in ['web/engine/rom-accelerators.js','tools/stress-kpex.mjs','tools/browser-gameplay-check.mjs','tools/benchmark-web.mjs','tools/replay-sgs.mjs','tests/rom-accelerators.test.mjs','validation/kingston-naver-replays/battle-armor.json','validation/kingston-naver-replays/battle-armor-garage-exit.json','LICENSE']:
 entries[name]=(repo/name).read_bytes()
entries['README.txt']=b'''Tall narrow palette image batches and Battle Armor validation. 2026-11-07 MSK.

Production ROM shortcut now also accepts ordinary image batches with row widths
32..127 and >=4096 remaining pixels, subject to all original bounds, alias,
palette, stride, bit alignment, ARM state and work-budget guards. Short single
rows and small sprites remain native. ROM and SGS are unchanged; this download
contains own tools/reports plus two reviewed game screenshots, not new games.

Three alternating old/current pairs use actual baseline source 357ec3567af43df237802286687938e59a280c98.
Initial paired warmup is excluded. All six result fingerprints match. The
summary contains measured medians; these are host guest-call times, NOT FPS.
Eight additional default benchmark fingerprints match old/current; their single
timings had concurrent host activity and are NOT used as speedup evidence.

Two exact/guarded seeded tests compare every operation over 600000 virtual ms
after the respective prelude, with checkpoints every 100 operations. Compare
scope is precise in each JSON: variables, descriptors, used stack, visible
pixels, VM PC, input, timers, syscalls and serialized saves, not all allocated RAM.
Native helper tests independently compare registers/CPSR, stack, pixel buffers,
source/palette bytes and block clock including exact threshold and budget cases.

The original action plan ends in Garage with current native key releases. The
new plan exits Garage into the base. The two included frames were visually
reviewed and their decoded pixel hashes match both runtimes' prelude frames.
Neither frame establishes active combat. The 125-second Chrome UI test reached
base menus; exact HTTP response hashes bind it to the current runtime and games.
No reported random freeze was reproduced or claimed fixed. No full playthrough,
physical-controller test, physical-device timing or cycle-exact claim is made.

Input sequences, unchanged original identities, host details and all source
hashes are retained. manifest.json covers all other members with size/SHA256/CRC.
MIT applies to Reunion tools; original third-party material retains its rights.
'''
manifest=[{'path':n,'bytes':len(b),'sha256':sha(b),'crc32':f'{zlib.crc32(b):08x}'} for n,b in sorted(entries.items())]
entries['manifest.json']=js({'schema':1,'selfExcluded':True,'files':manifest})
out=repo/'research/archives/Battle-Armor-Narrow-Palette-Batches-and-Verification.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for r in manifest:
  body=z.read(r['path']);assert len(body)==r['bytes'] and sha(body)==r['sha256'] and f'{zlib.crc32(body):08x}'==r['crc32']
report={'schema':1,'verifiedUtc':datetime.now(timezone.utc).isoformat(),'archive':out.name,'archiveBytes':out.stat().st_size,'archiveSha256':sha(out.read_bytes()),'members':len(entries),'manifestMembersVerified':len(manifest),'crcPassed':True,'benchmark':benchmark,'differentialRuns':[{'seed':r['options']['seed'],'preludeSha256':r['preludeSha256'],'scope':r['comparisonScope'],'results':r['results'],'comparisons':r['comparisons']} for r in stresses],'reviewedScenes':frames,'browser':{k:v for k,v in browser.items() if k not in ['status','keys','frameTimes']},'browserKeyOperations':len(browser['keys']),'eightGameFingerprintsMatch':True,'unitTests':60,'integrationTests':88,'limits':'No random freeze reproduced or claimed fixed; reviewed preludes are garage/base, not verified active combat. Host guest-work benchmark, not browser FPS.'}
(repo/'validation/narrow-palette-performance.json').write_bytes(js(report))
print(json.dumps({k:report[k] for k in ['archiveBytes','archiveSha256','members','manifestMembersVerified','crcPassed','limits']}))
