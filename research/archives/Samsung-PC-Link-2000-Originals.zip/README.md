# Samsung PC Link 2000: exact official downloads

Two unchanged files fetched directly from Samsung's download server using paths
listed for SCH-S250 in the official support page:
- 20040522093239625_PCLink2000.zip (contains PCLink2000_040331.exe);
- 20041105154319859_PCLink2000kor_040831.exe (ZIP SFX containing
  PCLink2000kor_XH31A.exe).

The original support HTML and linked download UI JS preserve the source paths.
All five support-page download receipts are retained, including three manuals
which are in the separate SCH-S250 firmware/manual bundle, not in this ZIP.
Downloaded byte lengths match Samsung's listed values; hashes are locally
computed identities, not publisher-provided signatures.

These are synchronization/support tools, NOT GNEX SDKs or emulators. No installer
was launched. Static ZIP/SFX -> Microsoft CAB -> InstallShield inspection only.
Both outer ZIPs and Microsoft CABs passed 7-Zip tests. Full InstallShield testing
of build040331 returned1 with support-file failures; full internal integrity of
that build is NOT established. BuildXH31A's full test returned0. The exact older
download is retained with this limitation, not silently repaired or replaced.

Four named application groups from each installer were separately extracted with
successful tool exits: 248 files / 58,870,667 bytes scanned for plain/XOR-A5
SGS v1/v2/v4/v36, zero hits. That scan excludes MDAC/installer-engine groups.
A first all-group extraction hit Windows path limits; its partial output is not
counted as complete. GVM in LinkCore.dll at0x4cc02 is in bitmap-like data, not
accepted as a protocol/runtime marker. No download/upload compatibility tested.

audit/ preserves inventories and full test logs. No vendor executable was run.
Original rights/notices remain with the source; Reunion MIT does not relicense
historical software. manifest.json hashes every other member.
