Samsung Anycall Land ADS, preserved from
https://m.blog.naver.com/sendei333/222605737137

The four files under original/ are byte-identical to the public attachments.
Original Korean filenames, retrieval dates and checksums are in sources/.
The original game ZIP contains 82 MBIN records (69 distinct bodies).
Some files have modified headers. No historic Windows executable or game
was run. Derived help pages are extracted from the original ADSLoader CHM.

Inspect the ZIP with Python 3.11 or newer:
python tools/inspect-anycall-mbin.py original/Anycall-Land-games.zip --output mbin-report.json
