# Classic EPOC SIS format reference

Unchanged author document: SIS File Format, Alexander Thoukydides,
version1.19,19-Nov-2024. The original copyright/license notice and the
complete GNU Free Documentation License1.1 are embedded in the HTML.
No changes were made to the document and no extra conditions are imposed.

`originals/sis-format.html` is91323 exact bytes from author repository
`thoukydides/riscos-psifs`, path `docs/sis.html`. It was received via the
public GitHub connector after an earlier direct-site TLS timeout. UTF-8
re-encoding was verified against the immutable Git blob identity:

Git blob SHA1:9404399da0d7dbbe10283cdbcb7c95e9360ac0c7
File SHA256:796a8a5f3e8a1e15e906481754ec5cab90dec0610e960ca68c91ffe2245837c8

The source API URL and transport details are in `provenance.json`.
The author's canonical document is:
https://www.thouky.co.uk/software/psifs/sis.html

`review/pass9-sis-spec-review.json` is a separate research note about
classic SIS control records, not a changed edition of the author document.
It distinguishes documented layouts, derived properties and proposed
forensic all-branch extraction behavior. No installer conditions were
evaluated, no vendor code run, and no corpus rescan or parser edit occurred.
No SIS9 format, GNEX runtime or new game recovery is claimed here.

The author's older implementation files were inspected locally, but are
not included: they do not implement the EPOC6 control records under review.
`manifest.json` covers every other ZIP member. All member CRCs and a clean
extraction's file hashes were independently reread after packaging.
