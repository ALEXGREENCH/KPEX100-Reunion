# Samsung WinCE device source check

Preserved as received on 2026-11-05 for KPEX100 Reunion research.

This is a source/evidence bundle, not a WinCE GNEX runtime or game release.
No CAB or ARM.EXE was recovered, and no actual shipped Windows CE,
Pocket PC or Palm handset model with GNEX/GVM was proved in this branch.
Do not register the named candidate phones as confirmed GNEX devices.

## Exact original bytes

`samsung-fx-primary.html` is the untouched HTTP200 response from Samsung
Newsroom. It is137832 bytes, MIME `text/html; charset=UTF-8`, SHA256
`c4859577674e03324af02df8136a94048b6997e1e8b54e34e15a9218e7424db3`.
Its exact source URL and response details are in `primary-raw-receipts.json`.
It names SPH-M4500 and a planned SCH-M450 variant, but gives no GNEX/GVM
runtime download or support proof. This live source has no CDX digest.

The literal displayed date `2001/01/29` and meta timestamp
`2001-01-29T09:22:46+09:00` are an unresolved source anomaly. They have
not been silently corrected and are not treated as a verified release date.

## Derived research records and scope

`result.json` and `result.md` summarize the finite branch, the exact queries,
the inspected Samsung manual text and false catalog matches. They are new
research notes, not original vendor documents or binary-compatibility proof.

`primary-raw-receipts.json` is the exact local request log. It also records
a Manualzilla HTTP403 response and a TTA TLS timeout. Those unsuccessful
response bodies/files are not included here and are not recovered manuals.
The already recovered KOCCA PDF and its page raster are also not duplicated;
the report records its exact original hash and the separately reviewed page.
The primary Samsung HTML is the sole newly received source payload here.

No vendor binary, installer, macro, firmware or historical network service
was executed. No credentials, private gate or TLS verification bypass used.
The HTML may contain original site scripts; it was inspected as data, not run.
Historical third-party material retains its original notices and status.

`manifest.json` covers every other member by path, byte length and SHA256.
The archive was CRC checked and extracted into a new directory, where all
five manifest file hashes were reread and matched the packaged source bytes.
