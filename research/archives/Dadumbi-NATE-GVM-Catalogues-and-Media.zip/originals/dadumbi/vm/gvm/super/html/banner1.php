<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>* ���ۺ��� ü������ ����� ��������!!~ ^^</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<style type="text/css">
<!--
td {
	font-family: "����";
	font-size: 12px;
	color: #000000;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="450" border="0" cellspacing="0" cellpadding="0" align=center>
  <form action="banner2.php" method=get>
  <tr> 
    <td colspan="3"><img src="images/title_l.gif" width="218" height="240"><img src="images/title_r.gif" width="232" height="240"></td>
  </tr>
  <tr> 
    <td colspan="3"><img src="images/step1.gif" width="354" height="40"> </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="252">������ �ڵ��� ��ȣ�� �־��ּ���.<br> <br>
      �ڵ��� ��ȣ : 
      <select name="phone_sp" size="1" id="phone_sp">
        <option value="011" selected>011</option>
        <option value="017">017</option>
      </select> - <input name="phone_num" type="text" id="mobile2" maxlength="11" size=11> <br> <br> 
      <input name="submit" type="submit" id="submit" value="Ȯ��">
      <br>
    </td>
    <td width="10">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3"><img src="images/bottom.gif" width="450" height="27"></td>
  </tr>
  </form>
</table>
</body>
</html>

