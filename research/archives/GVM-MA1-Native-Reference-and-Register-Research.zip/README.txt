Raw GVM MA1: native SDK reference and register/score inspection.
2026-11-07. Research package, not a new recovered SDK or playable FM backend.

The PE and Yamaha PDF reuse exact bytes already preserved in previous Reunion
archives. Existing-inputs provenance identifies the original archive, member and
SHA256. The historical GVM2X executable is modified; it is not attributed as an
untouched official Sinjisoft release. The PDF mirror is B2 2000.4,43 vendor pages
plus one distributor appendix. Original download receipts are included.

inspect-gvm-ma1.py executes only selected original x86 SDK instructions inside
Unicorn. It traps MIDI, WinMM timers and allocation; no Windows loader, driver,
thread, device or actual sound runs. Five original WI-TOP resources and three
synthetic fixtures yield820 native-decoded score words,1015 MIDI commands and
1278 timer requests. Synthetic reserved pitches characterize the SDK only.
The generated traces are not evidence of exact Yamaha FM sound or phone timing.

ma1.js statically reads the unchanged raw payload, voices, register block and
score. Its SDK fields match all820 words; Yamaha register ordering and nominal
tempo formula remain separate from the Windows approximation. The manual's
rest interval0/B table conflicts with its own note table; no silent correction
or unverified hardware timeline is introduced. RawMA1 synthesis is still absent.

Reproduce with Python3.11+,unicorn==2.1.4:
python tools/inspect-gvm-ma1.py originals/2x_Cr256_Magic.exe fixtures/ma1-original-resources.json --output reference-local.json
Compare the resulting JSON to derived/gvm-ma1-native-reference.json.
For the inspection CLI, use a full repository checkout (it imports its SGS reader):
node tools/ma1-info.mjs web/data/games/hellfire-witop-v1.sgs 45

Review PNGs and parsed JSON are derivatives. No SGS,PDF or executable bytes were
patched. Third-party rights remain; MIT applies to new Reunion code only.
manifest.json covers every other member, excluding itself.
