import fs from 'node:fs';
import { createHash } from 'node:crypto';
const fetchedSourceHashes = {}; const assetReads=[]; const assetReadErrors=[];
import assert from 'node:assert/strict';
const { chromium } = await import(process.env.REUNION_PLAYWRIGHT || 'playwright');
const url = process.argv[2];
if (!url || !/^https?:/.test(url))
  throw Error('Usage: node tools/browser-gameplay-check.mjs URL NEW_OUTPUT_PREFIX');
const output = process.argv[3];
if (!output || fs.existsSync(output + '.json')) throw Error('New output prefix required');
const browser = await chromium.launch({
  headless: true,
  ...(process.env.REUNION_CHROME ? { executablePath: process.env.REUNION_CHROME } : {}),
});
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }),
    errors = [];
  page.context().on('response', response => {
    const name = ['engine/cpu.js','engine/rom-accelerators.js','engine/gnex.js','engine/rgb565.js','engine/buzzer.js','engine/ma1.js','engine/ma1-render.js','smaf-worker.js','smaf-decoder.js','app.js','engine/legacy.js','input-bindings.js','data/games/hellfire-witop-v1.sgs','data/games/hellfire.sgs','data/firmware/Kingston-2.12.rom','worker.js'].find(name => new URL(response.url()).pathname.endsWith('/'+name));
    if (name) assetReads.push(response.body().then(body => { fetchedSourceHashes[name]=createHash('sha256').update(body).digest('hex'); }).catch(error=>assetReadErrors.push({name,error:String(error)})));
  });
  page.on('pageerror', (e) => errors.push(e.message));
  await page.addInitScript(() => {
    window.reunionCheck = { frames: 0, status: [], keys: [], audioRequests: [] };
    const OriginalAudioContext = window.AudioContext;
    const gain = OriginalAudioContext.prototype.createGain;
    const decode = OriginalAudioContext.prototype.decodeAudioData;
    window.audioProof = { decodes: [], starts: 0, peak: 0, samplers: [] };
    OriginalAudioContext.prototype.createGain = function(...args) {
      const node = gain.apply(this,args), tap=this.createAnalyser(), mute=gain.call(this);
      tap.fftSize=2048;mute.gain.value=0;node.connect(tap);tap.connect(mute);mute.connect(this.destination);
      audioProof.samplers.push({tap,node,buffer:new Float32Array(2048)});
      return node;
    };
    const source = OriginalAudioContext.prototype.createBufferSource;
    OriginalAudioContext.prototype.createBufferSource = function(...args) {
      const node=source.apply(this,args), start=node.start;
      node.start=function(...params){ audioProof.starts++;return start.apply(this,params);};return node;
    };
    OriginalAudioContext.prototype.decodeAudioData = async function(...args) {
      const b=await decode.apply(this,args);let peak=0;for(let c=0;c<b.numberOfChannels;c++)for(const v of b.getChannelData(c))peak=Math.max(peak,Math.abs(v));
      audioProof.decodes.push({frames:b.length,rate:b.sampleRate,channels:b.numberOfChannels,duration:b.duration,peak});return b;
    };
    setInterval(()=>{let maxRms=0;for(const s of audioProof.samplers){s.tap.getFloatTimeDomainData(s.buffer);let sum=0;for(const v of s.buffer){audioProof.peak=Math.max(audioProof.peak,Math.abs(v));sum+=v*v;}maxRms=Math.max(maxRms,Math.sqrt(sum/s.buffer.length));}audioProof.currentRms=maxRms;},25);
    const Original = Worker;
    window.Worker = class extends Original {
      constructor(...args) {
        super(...args);
        this.addEventListener('message', ({ data: m }) => {
          if (m.type === 'frame') reunionCheck.frames++;
          if (m.type === 'error') reunionCheck.status.push({ error: m.message || m.error });
          if (m.type === 'status')
            reunionCheck.status.push({
              at: performance.now(),
              events: m.events,
              status: m.status,
              error: m.diagnostics?.error,
              timers: m.diagnostics?.timers,
            });
        });
      }
      postMessage(m, ...args) {
        if (m.format) reunionCheck.audioRequests.push({id:m.id,format:m.format});
        if (m.type === 'key') reunionCheck.keys.push({ key: m.key, pressed: m.pressed });
        super.postMessage(m, ...args);
      }
    };
  });
  await page.goto(url, { timeout: 45000 });
  await page.waitForFunction(() => document.querySelectorAll('.library-item').length > 20);
  const lcd = await page.locator('#lcdWindow').boundingBox();
  await page.locator('#openLibrary').click();
  const kpex=process.env.REUNION_GAME==='kpex';
  await page.locator('#librarySearch').fill(kpex?'Hell Fire':'Hellfire (WI-TOP');
  await page
    .locator('.library-item')
    .filter({ has: page.getByText(kpex?'Hell Fire':'Hellfire (WI-TOP, GVM v1)', { exact: true }) })
    .click();
  await page.waitForFunction(
    () => document.querySelector('#playPause span').textContent === 'Пауза',
    null,
    { timeout: 45000 },
  );
  await page.waitForFunction(() => document.querySelector('#screenEmpty').hidden);
  assert.deepEqual(await page.locator('#lcdWindow').boundingBox(), lcd);
  await page.locator('#volume').fill('40');
  await page.locator('#sound').click();
  await page.locator('#sound').click();
  assert.equal(await page.locator('#volume').inputValue(), '40');
  await page.waitForFunction(()=>audioProof.starts>0&&audioProof.currentRms>0.01);
  const levels=[];
  for(const value of ['100','50','0','40']){
    await page.locator('#volume').fill(value);await page.waitForTimeout(110);
    levels.push({value:Number(value),rms:await page.evaluate(()=>audioProof.currentRms),gain:await page.evaluate(()=>audioProof.samplers.at(-1).node.gain.value)});
  }
  assert.ok(levels[0].gain>0);assert.ok(Math.abs(levels[1].gain/levels[0].gain-0.5)<0.001);
  assert.equal(levels[2].gain,0);assert.ok(Math.abs(levels[3].gain/levels[0].gain-0.4)<0.001);
  console.log(JSON.stringify(await page.evaluate(()=>({decodes:audioProof.decodes,requests:reunionCheck.audioRequests}))));
  await page.waitForFunction(()=>audioProof.decodes.some(b=>b.duration>4&&b.duration<10&&b.peak>0.01),null,{timeout:30000});
  await page.locator('#screen').focus();
  const start = Date.now();
  let count = 0;
  while (Date.now() - start < 25000) {
    const key =
      count < 5 ? (kpex?'Enter':'z') : ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', kpex?'Enter':'z'][count % 5];
    await page.keyboard.down(key);
    await page.waitForTimeout(count % 3 === 0 ? 450 : 120);
    await page.keyboard.up(key);
    await page.waitForTimeout(400);
    count++;
    assert.equal(await page.locator('#errorBanner').isVisible(), false);
  }
  await page.screenshot({ path: output + '.png' });
  const audioProof = await page.evaluate(() => ({decodes:window.audioProof.decodes,starts:window.audioProof.starts,peak:window.audioProof.peak}));
  assert.ok(audioProof.decodes.some(b=>b.peak>0.1&&b.channels===1));assert.ok(audioProof.starts>0);assert.ok(audioProof.peak>0.01);
  const report = await page.evaluate(() => reunionCheck);
  assert.ok(report.audioRequests.length>0&&report.audioRequests.every(r=>r.format==='audio/x-gvm-ma1'));

  assert.ok(report.frames > 10);
  assert.ok(report.keys.length > 30);
  for(const key of (kpex?['up','down','left','right','start']:['digit1','digit7','digit4','digit5','digit3'])) assert.ok(report.keys.some(k=>k.key===key&&k.pressed), 'native logical input '+key);
  assert.ok(report.status.at(-1).events > 20);
  assert.equal(
    report.status.some((s) => s.error || s.status === 'error'),
    false,
  );
  assert.deepEqual(errors, []);
  assert.deepEqual(await page.locator('#lcdWindow').boundingBox(), lcd);
  await Promise.all(assetReads);
  const result = {
    fetchedSourceHashes, assetReadErrors, audioProof, levels,
    utc: new Date().toISOString(),
    url: page.url(),
    scope:
      'Original browser Worker, ROM and SGS, actual host timers and UI keyboard input. RawMA1 synthesis in the separate audio worker, actual nonzero WebAudio and gain levels. Scripted smoke, not a physical controller, handset recording or full mission/freeze reproduction.',
    wallMs: Date.now() - start,
    lcd,
    errors,
    ...report,
    ok: true,
  };
  fs.writeFileSync(output + '.json', JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  console.log(
    JSON.stringify({
      ok: true,
      frames: result.frames,
      keys: result.keys.length,
      events: result.status.at(-1).events,
      wallMs: result.wallMs,
    }),
  );
} finally {
  await browser.close();
}
