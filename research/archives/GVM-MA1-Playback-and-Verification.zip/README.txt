GVM MA1 playback and verification. 2026-11-07.

The standalone SGS path now renders raw subtype1 MA1 with four mono FM parts
and each original resource's two-operator patches. The renderer is separate
from the VM and UI, with180second cap, cancellation and format-separated cache.
Pitch,multiples,TL,EGT,SUS and nominal envelope times follow the preserved
Yamaha B2 register document. Internal arithmetic,phase/retrigger behavior,
modulation index and speaker filtering remain approximate. This is not a
bit-exact physical-phone recording. Rest interval0/B follows the established
SDK zero-interval convention; the manual's contradictory table remains noted.

Kingston Hell Fire and WI-TOP Hellfire have identical five MA1 payloads.
Both catalogue launch profiles select nativeSoundType1, filtering paired
buzzer alternatives. That internal sound option does not follow appearance
shell changes. Unknown imports retain their default program-order routing.
The configured mode does not change bytecode, framebuffer or LCD parameters.
This restores standalone-game audio, not full-firmware codec emulation.

Five original payload extracts are unchanged. Five WAVs are NEW DERIVATIVES,
not recovered original audio files. Both local Chrome25second game sessions
used the actual CPU Worker,ROM,SGS and separate audio Worker, measured nonzero
WebAudio and gain100/50/0/40, and recorded78key transitions each. Ten replay
PNGs match the previous checkout byte-for-byte for215scheduled events.
These are smoke checks, not full missions or all random-freeze proof.

Tests cover measured pitch/multiples/TL,envelope times,score clock,rests,
ties,voicechanges,output bounds,cancellation,cache ownership,routing and CLI
refusal to overwrite an existing output. Browser/raw-source hashes accompany
the captured proof. Reproduction tools require a complete repository checkout.
node tools/render-ma1.mjs web/data/games/hellfire-witop-v1.sgs 45 new-theme.wav
node --test tests/unit/ma1-render.test.mjs tests/gvm-ma1.test.mjs

No historical document,SGS or firmware was patched. Original rights remain;
MIT applies to new Reunion code. manifest.json covers other members only.
