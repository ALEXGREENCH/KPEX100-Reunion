aram.start()
aram.step(180)
aram.screenshot("net-alkkagi-first.png")
