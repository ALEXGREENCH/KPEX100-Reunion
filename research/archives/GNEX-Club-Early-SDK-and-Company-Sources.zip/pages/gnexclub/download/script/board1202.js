<!--
function listArticles( aform, brid, searchType, searchKey, pageNo ) {
        aform.userAction.value 	= "list";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = brid;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.submit();
}

function searchlistArticles( aform, brid, searchType, searchKey, pageNo ) {
        aform.userAction.value 	= "search";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = brid;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.submit();
}

function listArticlesbykind( aform, brid, searchType, searchKey, pageNo, articlekind ) {
        aform.userAction.value 	= "list";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = brid;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.elements[5].name  = "articlekind";
        aform.elements[5].value = articlekind;
        aform.submit();
}

function searchlistArticlesbykind( aform, brid, searchType, searchKey, pageNo, articlekind ) {
        aform.userAction.value 	= "search";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = brid;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.elements[5].name  = "articlekind";
        aform.elements[5].value = articlekind;
        aform.submit();
}

function listArticlesbymobile( aform, brid, searchType, searchKey, pageNo, questionfield1 ) {
        aform.userAction.value 	= "list";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = brid;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.elements[5].name  = "questionfield1";
        aform.elements[5].value = questionfield1;
        aform.submit();
}

function searchlistArticlesbymobile( aform, brid, searchType, searchKey, pageNo, questionfield1 ) {
        aform.userAction.value 	= "search";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = brid;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.elements[5].name  = "questionfield1";
        aform.elements[5].value = questionfield1;
        aform.submit();
}

function readArticlebykind( aform, arid, brid, searchType, searchKey, pageNo, bno, articlekind ) {
        aform.userAction.value 	= "read";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.elements[8].name  = "articlekind";
        aform.elements[8].value = articlekind;
        aform.submit();
}

function searchreadArticlebykind( aform, arid, brid, searchType, searchKey, pageNo, bno, articlekind ) {
        aform.userAction.value 	= "sread";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.elements[8].name  = "articlekind";
        aform.elements[8].value = articlekind;
        aform.submit();
}

function readArticlebyPS( aform, arid, brid, searchType, searchKey, pageNo, bno, personcompany ) {
        aform.userAction.value 	= "read";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.elements[8].name  = "personcompany";
        aform.elements[8].value = personcompany;
        aform.submit();
}

function searchreadArticlebyPS( aform, arid, brid, searchType, searchKey, pageNo, bno, personcompany ) {
        aform.userAction.value 	= "sread";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.elements[8].name  = "personcompany";
        aform.elements[8].value = personcompany;
        aform.submit();
}

function readArticle( aform, arid, brid, searchType, searchKey, pageNo, bno ) {
        aform.userAction.value 	= "read";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.submit();
}

function readArticleMobile( aform, arid, brid, searchType, searchKey, pageNo, bno, questionfield1 ) {
        aform.userAction.value 	= "read";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.elements[8].name  = "questionfield1";
        aform.elements[8].value = questionfield1;
        aform.submit();
}

function searchreadArticleMobile( aform, arid, brid, searchType, searchKey, pageNo, bno, questionfield1 ) {
        aform.userAction.value 	= "sread";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.elements[8].name  = "questionfield1";
        aform.elements[8].value = questionfield1;
        aform.submit();
}

function readArticleExt( aform, arid, brid, searchType, searchKey, pageNo, bno ) {
        aform.userAction.value 	= "sread";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = bno;
        aform.submit();
}

function readArticle1( aform, arid, brid, searchType, searchKey, pageNo) {
        aform.userAction.value  = "read";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = arid;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = brid;
        aform.elements[4].name  = "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name  = "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "hArticleVNo";
        aform.elements[7].value = 0;
        aform.submit();
}

function readHomeArticle( aform, action, pno, searchType, searchKey, bno ) {
	aform.action = action; 
        aform.userAction.value 	= "read";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.submit();
} 

function writeArticle( aform, bno, pageNo ) {
        aform.userAction.value = "write";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = bno;
        aform.elements[2].name  = "pageNo";
        aform.elements[2].value = pageNo;
        aform.submit();
}

function writeArticlebykind( aform, bno, pageNo, articlekind ) {
        aform.userAction.value = "write";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = bno;
        aform.elements[2].name  = "pageNo";
        aform.elements[2].value = pageNo;
        aform.elements[3].name  = "articlekind";
        aform.elements[3].value = articlekind;
        aform.submit();
}

function writeArticlebyrecruit( aform, bno, pageNo, personcompany ) {
        aform.userAction.value = "write";
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = bno;
        aform.elements[2].name  = "pageNo";
        aform.elements[2].value = pageNo;
        aform.elements[3].name  = "personcompany";
        aform.elements[3].value = personcompany;
        aform.submit();
}

function replyArticle( aform, pno, bno, pageNo ) {
        aform.userAction.value 	= "reply";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.submit();
}

function replyArticlewithemail(aform, pno, bno, pageNo, hemailyn, fromemail) {
        aform.userAction.value 	= "reply";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name  = "hemailyn";
        aform.elements[4].value = hemailyn;
        aform.elements[5].name  = "fromemail";
        aform.elements[5].value = fromemail;
        aform.submit();
}

function replyArticlebykind( aform, pno, bno, pageNo, articlekind, hemailyn, fromemail ) {
        aform.userAction.value 	= "reply";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name  = "articlekind";
        aform.elements[4].value = articlekind;
        aform.elements[5].name  = "hemailyn";
        aform.elements[5].value = hemailyn;
        aform.elements[6].name  = "fromemail";
        aform.elements[6].value = fromemail;
        aform.submit();
}

function replyArticlebymobile(aform,pno,bno,pageNo,questionfield1) {
        aform.userAction.value 	= "reply";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name  = "questionfield1";
        aform.elements[4].value = questionfield1;
        aform.submit();
}

function updateArticle( aform, pno, bno, pageNo ) {
        aform.userAction.value 	= "update";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.submit();
}

function updateArticlebykind( aform, pno, bno, pageNo, articlekind ) {
        aform.userAction.value 	= "update";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name  = "articlekind";
        aform.elements[4].value = articlekind;
        aform.submit();
}

function updateArticlebymobile( aform, pno, bno, pageNo, questionfield1 ) {
        aform.userAction.value 	= "update";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name  = "questionfield1";
        aform.elements[4].value = questionfield1;
        aform.submit();
}

function updateArticleWithPasswd( aform, pno, bno, pageNo ) {
		var passwd = prompt( "��й�ȣ�� �Է��Ͻʽÿ�", "BBS" );
		if ( trim( passwd ) == "" ) {
			alert( "��й�ȣ�� �Է��Ͻʽÿ�" );
			return;
		}

        aform.userAction.value 	= "update";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "passwd";
        aform.elements[3].value = passwd;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.submit();
}

function deleteMemo( aform, pno, searchType, searchKey, bno, id, pageNo ) {
		if ( !confirm( "�޸𳻿��� �����Ͻðڽ��ϱ�?" ))
			return;
        aform.userAction.value 	= "deletememo";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.elements[5].name  = "hMemoRID";
        aform.elements[5].value = id;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.submit();
}

function deleteMemokind( aform, pno, searchType, searchKey, bno, id, pageNo, articlekind ) {
		if ( !confirm( "�޸𳻿��� �����Ͻðڽ��ϱ�?" ))
			return;

        aform.userAction.value 	= "deletememo";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.elements[5].name  = "hMemoRID";
        aform.elements[5].value = id;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "articlekind";
        aform.elements[7].value = articlekind;
        aform.submit();
}

function deleteMemomobile( aform, pno, searchType, searchKey, bno, id, pageNo, questionfield1) {
		if ( !confirm( "�޸𳻿��� �����Ͻðڽ��ϱ�?" ))
			return;
        aform.userAction.value 	= "deletememo";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.elements[5].name  = "hMemoRID";
        aform.elements[5].value = id;
        aform.elements[6].name  = "pageNo";
        aform.elements[6].value = pageNo;
        aform.elements[7].name  = "questionfield1";
        aform.elements[7].value = questionfield1;
        aform.submit();
}

function insertMemo( mform, pno, searchType, searchKey, bno, aform, pageNo ) {
		if (mform.txtMemo.value == "" || trim(mform.txtMemo.value)== "" ) {
			alert("�޸� ������ �Է��Ͻ� �� �����Ͻʽÿ�");
			mform.txtMemo.focus();
                        return;
		}
        aform.userAction.value 	= "insertmemo";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.elements[5].name  = "pageNo";
        aform.elements[5].value = pageNo;
        aform.elements[6].name  = "txtMemo";
        aform.elements[6].value = mform.txtMemo.value;
        aform.submit();
}

function insertMemokind( mform, pno, searchType, searchKey, bno, aform, pageNo, kind ) {
		if (mform.txtMemo.value == "" || trim(mform.txtMemo.value)== "" ) {
			alert("�޸� ������ �Է��Ͻ� �� �����Ͻʽÿ�");
			mform.txtMemo.focus();
                        return;
		}
        aform.userAction.value 	= "insertmemo";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.elements[5].name  = "pageNo";
        aform.elements[5].value = pageNo;
        aform.elements[6].name  = "txtMemo";
        aform.elements[6].value = mform.txtMemo.value;
        aform.elements[7].name  = "articlekind";
        aform.elements[7].value = kind;
        aform.submit();
}

function insertMemomobile( mform, pno, searchType, searchKey, bno, aform, pageNo, questionfield1 ) {
		if (mform.txtMemo.value == "" || trim(mform.txtMemo.value)== "" ) {
			alert("�޸� ������ �Է��Ͻ� �� �����Ͻʽÿ�");
			mform.txtMemo.focus();
                        return;
		}
        aform.userAction.value 	= "insertmemo";
        aform.elements[1].name  = "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name  = "searchType";
        aform.elements[2].value = searchType;
        aform.elements[3].name  = "searchKey";
        aform.elements[3].value = searchKey;
        aform.elements[4].name  = "hBoardRID";
        aform.elements[4].value = bno;
        aform.elements[5].name  = "pageNo";
        aform.elements[5].value = pageNo;
        aform.elements[6].name  = "txtMemo";
        aform.elements[6].value = mform.txtMemo.value;
        aform.elements[7].name  = "questionfield1";
        aform.elements[7].value = questionfield1;
        aform.submit();
}


function saveArticle( aform, bform ){
		aform.action = bform.action;
        if ( w_form_chk( aform ))
                aform.submit();
}

function uploadArticle( aform, bno ) {
        aform.elements[1].name  = "hBoardRID";
        aform.elements[1].value = bno;
        if ( upload_w_form_chk( aform ))
                aform.submit();
}

function deleteArticle( aform, pno, bno, pageNo ) {
        aform.userAction.value 	= "delete";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name 	= "pageNo";
        aform.elements[3].value = pageNo;
        aform.submit();
}

function deleteArticlebyqna( aform, pno, bno, pageNo, articlekind ) {
        aform.userAction.value 	= "delete";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name 	= "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name 	= "articlekind";
        aform.elements[4].value = articlekind;
        aform.submit();
}

function searchdeleteArticlebyqna( aform, pno, bno, pageNo, searchType, searchKey, articlekind ) {
        aform.userAction.value 	= "delete";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name 	= "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name 	= "searchType";
        aform.elements[4].value = searchType;
        aform.elements[5].name 	= "searchKey";
        aform.elements[5].value = searchKey;
        aform.elements[6].name 	= "articlekind";
        aform.elements[6].value = articlekind;
        aform.submit();
}

function deleteArticlebymobile(aform,pno,bno,pageNo,questionfield1) {
        aform.userAction.value 	= "delete";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name 	= "pageNo";
        aform.elements[3].value = pageNo;
        aform.elements[4].name  = "questionfield1";
        aform.elements[4].value = questionfield1;
        aform.submit();
}

function deleteArticleWithPasswd( aform, pno, bno, pageNo ) {
        var passwd = prompt( "��й�ȣ�� �Է��Ͻʽÿ�", "BBS" );
		if ( trim( passwd ) == "" ) {
			alert( "��й�ȣ�� �Է��Ͻʽÿ�" );
			return;
		}

        aform.userAction.value 	= "delete";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name  = "passwd";
        aform.elements[3].value = passwd;
        aform.elements[4].name  = "pageNo";
        aform.elements[4].value = pageNo;
        aform.submit();
}

function searchArticles( aform, baction ) {
        if ( aform.searchType.value != "Title" && aform.searchType.value != "All" && 
             aform.searchType.value != "Content" && aform.searchType.value != "File" &&
             aform.searchType.value != "User" ) 
        {        
            alert("�˻�Ÿ���� ���õ��� �ʾҽ��ϴ�");
            return;
	}
        if ( aform.searchKey.value == "" || aform.searchKey.value.length == 0 )  
        {  
            alert("�˻�� �Է��Ͻʽÿ�");
            return;
        }

	aform.action = baction;
        aform.submit();
}

function recommandArticle( aform, pno, bno, pageNo ) {
        aform.userAction.value 	= "recommand";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name 	= "pageNo";
        aform.elements[3].value = pageNo;
        aform.submit();
}

function prohibitArticle( aform, pno, bno, pageNo ) {
        aform.userAction.value 	= "prohibit";
        aform.elements[1].name 	= "hArticleRID";
        aform.elements[1].value = pno;
        aform.elements[2].name 	= "hBoardRID";
        aform.elements[2].value = bno;
        aform.elements[3].name 	= "pageNo";
        aform.elements[3].value = pageNo;
        aform.submit();
}

//download�� �ʿ��� �κ� - n���� down ��ų �� �־�� �Ѵ�.
function downArticles( aform ) {
        var filename = new Array();
		var pno      = new Array();
        var j        = 0;
        var noChkBox = aform.elements[ 'filename' ].length;

		if ( noChkBox == null ) {
			if ( aform.filename.checked == true ) {
				noChkBox = 1;
				filename[0] = aform.filename.value;
				pno[0] = aform.pno.value;
			}
		}
		else {
			for( var i=0; i<noChkBox; i++ ) {
				if ( aform.filename[i].checked == true ) {
					filename[j] = aform.filename[i].value;
					pno[j] = aform.pno[i].value;
					j = j+1;
				}
			} 
		}
                
        if ( filename.length == 0 ) {
			alert ("Down ���� ���Ϲ�ȣ�� �����Ͻʽÿ�.");
			return;
        }
	
		if ( filename.length >= 2 ) {
	    	alert("Down ���� ���Ϲ�ȣ�� �ϳ��� �����Ͻʽÿ�.");
	    	return;
		}
	
		aform.action = aform.action;
		aform.elements[1].name = "filename"; 
		aform.elements[1].value = filename[0];
		aform.elements[2].name = "ArticleRID";
		aform.elements[2].value = pno[0];
		aform.submit();
}

function downArticle( aform, bno ) {
		var filename = aform.filename.value;
		var pno = aform.pno.value;

		aform.action = aform.action;	
		aform.elements[1].name = "filename";
		aform.elements[1].value = filename;
		aform.elements[2].name = "hArticleRID";
		aform.elements[2].value = pno;
		aform.elements[3].name = "hBoardRID";
		aform.elements[3].value = bno;
		aform.submit();
}

function cancelArticle( aform, bno ) {
		history.go(-1);
}

function allSelected( aform ) {
		var noChkBox = aform.elements[ 'chkDown' ].length;

		for ( var i=0; i<noChkBox; i++ )
			aform.chkDown[i].checked = true;
}

function allDeleted( aform ) {
        var noChkBox = aform.elements[ 'chkDown' ].length;

		for ( var i=0; i<noChkBox; i++ )
			aform.chkDown[i].checked = false;
}

function resetWForm( aform ) {
        aform.title.value = "";
        aform.content.value = "";
}

function title_focus() {
        document.forms[0].title.focus();
}

function ltrim(parm_str) {
		str_temp = parm_str;

		while ( str_temp.length != 0 ) {
			if ( str_temp.substring(0, 1) == ' ') {
				str_temp = str_temp.substring( 1, str_temp.length );
			}
			else return str_temp ;
		}

		return str_temp ;
}

function rtrim( parm_str ) {
		str_temp = parm_str ;

		while ( str_temp.length != 0 ) {
			int_last_blnk_pos = str_temp.lastIndexOf(" ");
			if ((str_temp.length - 1) == int_last_blnk_pos) {
				str_temp = str_temp.substring( 0, str_temp.length - 1);
			}
			else  return str_temp;
		}

		return str_temp;
}

function trim( parm_str ) {
		return rtrim( ltrim( parm_str ));
}

function w_form_chk( aform ) {
       	title1 = aform.title.value;
       	title1 = trim( title1 );
       	if ( aform.title.value == "" || title1.length == 0 ) {
	     	alert( "������ �Է��� �ֽʽÿ�.");
	     	aform.title.focus();
	     	return false;
		}

		if ((( i=title1.indexOf('<sc')) >= 0 ) || (( i=title1.indexOf('<Sc')) >= 0 )
		 || (( i=title1.indexOf('<SC')) >= 0 ) || (( i=title1.indexOf('<sC')) >= 0 )) {
				alert( "��ũ��Ʈ�� ����� �� �����ϴ�" );
				aform.title.focus();
				return false;
		}

		cont = aform.content.value;
		cont = trim( cont );
		if ( aform.content.value == "" || cont.length == 0 ) {
				alert( "���� �ۼ��� �ֽʽÿ�.");
				aform.content.focus();
				return false;
		}

		if ((( i=cont.indexOf('<sc')) >= 0 ) || (( i=cont.indexOf('<Sc')) >= 0 )
		 || (( i=cont.indexOf('<SC')) >= 0 ) || (( i=cont.indexOf('<sC')) >= 0 )) {
				alert( "��ũ��Ʈ�� ����� �� �����ϴ�" );
				return false;
		}
	   
		return true;
}

function upload_w_form_chk( aform ) {
		alias1 = aform.alias.value;
		alias1 = trim( alias1 );
		if ( aform.alias.value == "" || alias1.length == 0 ) {
				alert( "�α� �� ����� �ּ���." );
				return false;
		}

		title1 = aform.title.value;
		title1 = trim( title1 );
		if ( aform.title.value == "" || title1.length == 0 ) {
				alert( "������ �Է��� �ֽʽÿ�." );
				aform.title.focus();
				return false;
		}

		cont = aform.content.value;
		cont = trim( cont );
		if ( aform.content.value == "" || cont.length == 0 ) {
				alert( "���� �ۼ��� �ֽʽÿ�." );
				aform.content.focus();
				return false;
		}

		if ((( i=cont.indexOf('<sc')) >= 0 ) || (( i=cont.indexOf('<Sc')) >= 0 )
		 || (( i=cont.indexOf('<SC')) >= 0 ) || (( i=cont.indexOf('<sC')) >= 0 )) {
				alert( "��ũ��Ʈ�� ����� �� �����ϴ�" );
				return false;
		}
   
		file = aform.file.value;
		if ( aform.file.value == "" || file.length == 0 ) {
				alert( "������ �Է��� �ֽʽÿ�." );
				aform.file.focus();
				return false;
		}

		return true;
}

//-->
