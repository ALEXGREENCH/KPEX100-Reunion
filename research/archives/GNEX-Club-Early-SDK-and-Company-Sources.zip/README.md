# GNEX Club: early SDK and company sources / Ранние источники GNEX Club

This preservation bundle contains exact anonymous public archived source bytes:
10 GNEX Club HTML pages, one original navigation JavaScript, the original
Sinji_Company_Intro_E.zip and its exact extracted PDF. The JavaScript was read
as data and not executed. Pages, not a working SDK distribution, are preserved.

The February 2004 page lists GNEX SDK 1.20 and GVM SDK 1.52. The December 2004
announcement describes unified SDK 1.40. Neither installer/archive named on
those pages has been recovered in this pass. No SDK executable, SGS, firmware
or newly verified handset runtime is included. Model-list titles alone are not
VM profile evidence.

В комплекте исходные страницы, навигационный JS, оригинальный ZIP Sinjisoft
и точный PDF из него. Сам SDK 1.20/1.40 не получен. Дата на обложке PDF —
июнь 2003 года; дата архивного снимка ZIP — декабрь 2005 года. Это разные даты.
Логотипы партнёров не доказывают поддержку определённой модели телефона.

manifest.json records source URLs, archive timestamps, CDX SHA-1 digests,
SHA-256 and byte sizes. All 12 original network payloads match known CDX
digests. For the navigation JS, the downloaded raw capture and matching
known CDX record have different timestamps for the same original URL.

Original Sinjisoft pages, script and PDF retain their original notices and
rights. Reunion's MIT licence does not relicense these historical materials.
The included historical licence page is documentation, not an approval or a
claim that the SDK was acquired under a new licence. Download forms were not
submitted, accounts were not used and no access restriction was bypassed.
