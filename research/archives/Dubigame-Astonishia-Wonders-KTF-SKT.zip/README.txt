Six original game ZIPs from Dubigame's mirror on Internet Archive.

The original names and SHA-256/CRC32 values are under sources/ and validation/.
No game ZIP was repacked. See aram/README.txt for the replay instructions.
The packages here use KTF/WIPI and SKT Java formats.

Report:
https://github.com/ALEXGREENCH/KPEX100-Reunion/blob/main/doc/dubigame-mirror-ktf-skt.md
