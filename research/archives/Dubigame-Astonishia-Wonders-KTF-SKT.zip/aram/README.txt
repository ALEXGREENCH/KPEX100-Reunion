ARAM core https://github.com/mirusu400/aram-core at fea299cba15696ed1460f965b76626d6edab5e03

Build: go build -o aram-debug ./cmd/aram-debug
Run from a clean directory:
aram-debug lua --timeout 55s --run-budget 200000 ORIGINAL_ZIP SCENARIO_LUA

Use validation/replays.json to select the matching case and scenario.
Opening scenes only. Audio, complete playthroughs and online modes were not tested.
