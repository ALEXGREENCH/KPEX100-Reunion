"""Verify the preserved game-portal responses and extract literal search leads."""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import struct
from urllib.parse import parse_qs, urljoin, urlsplit
import zipfile

import xlrd


def sha(data):
    return hashlib.sha256(data).hexdigest()


def cdx_sha(data):
    return base64.b32encode(hashlib.sha1(data).digest()).decode("ascii")


def load(path):
    return json.loads(path.read_text("utf8"))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", "utf8")


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("href"):
            self.current = [attrs["href"], []]
            self.links.append(self.current)

    def handle_data(self, data):
        if self.current:
            self.current[1].append(data)

    def handle_endtag(self, tag):
        if tag == "a":
            self.current = None


def select_cdx(raw):
    rows = json.loads(raw)
    return [dict(zip(rows[0], row, strict=True)) for row in rows[1:]] if rows else []


def download_ids(source, raw):
    original = source["original"]
    text = raw.decode("cp949", errors="replace")
    id_matches = re.findall(r"sendGame\('([A-Z0-9]+)'\)", text)
    if len(id_matches) != 1 or "send.jsp?ctsid=" not in text:
        return None
    purchase_id = id_matches[0]
    header = text.split("개발업체", 1)[0].rsplit("<!-- 게임소개 박스 시작 -->", 1)[-1]
    title = re.search(r'(?is)<font size="2" color="#000000"><b>([^<]+)</b>', header)
    developer = re.search(r"개발업체\s*:\s*([^<]+)", text)
    recorded_date = re.search(r"등록일자\s*:\s*(\d{4}-\d{2}-\d{2})", header)
    size = re.search(r"용량\s*:\s*([^<]+)", header)
    return {
        "viewId": source["contentId"],
        "purchaseId": purchase_id,
        "title": unescape(title[1].strip()) if title else None,
        "developer": unescape(developer[1].strip()) if developer else None,
        "catalogDate": recorded_date[1] if recorded_date else None,
        "printedSize": size[1].strip() if size else None,
        "purchaseRoute": urljoin(original, "send.jsp?ctsid=" + purchase_id),
        "capture": source["receipt"]["finalUrl"],
        "sha256": sha(raw),
    }


def swf_button_link(raw):
    assert raw[:4] == b"FWS\x05"
    assert struct.unpack_from("<I", raw, 4)[0] == len(raw)
    start = 8 + (5 + (raw[8] >> 3) * 4 + 7) // 8 + 4
    pos = start
    links = []
    counts = Counter()
    while pos + 2 <= len(raw):
        tag_header = pos
        header = struct.unpack_from("<H", raw, pos)[0]
        pos += 2
        code, size = header >> 6, header & 63
        if size == 63:
            size = struct.unpack_from("<I", raw, pos)[0]
            pos += 4
        end = pos + size
        assert end <= len(raw)
        counts[code] += 1
        if code == 34 and size >= 5:
            offset = struct.unpack_from("<H", raw, pos + 3)[0]
            action = pos + 3 + offset
            if offset and action + 4 <= end and raw[action : action + 2] == b"\0\0":
                condition = struct.unpack_from("<H", raw, action + 2)[0]
                i = action + 4
                while i < end:
                    opcode, i = raw[i], i + 1
                    if opcode == 0:
                        break
                    if opcode >= 0x80:
                        assert i + 2 <= end
                        size = struct.unpack_from("<H", raw, i)[0]
                        i += 2
                        assert i + size <= end
                        if opcode == 0x83:
                            url, target, tail = raw[i : i + size].split(b"\0")
                            assert not tail
                            links.append(
                                {
                                    "tagHeaderOffset": tag_header,
                                    "actionOpcodeOffset": i - 3,
                                    "condition": condition,
                                    "url": url.decode("ascii"),
                                    "target": target.decode("ascii"),
                                }
                            )
                        i += size
        pos = end
        if code == 0:
            break
    assert pos == len(raw) and counts[0] == 1
    assert len(links) == 1 and links[0]["url"] == "index1.html"
    return {"format": "FWS 5", "tagCounts": dict(counts), "getUrlActions": links}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("repo", type=Path)
    parser.add_argument("output", type=Path)
    options = parser.parse_args()
    root, repo = options.root, options.repo
    spec = importlib.util.spec_from_file_location(
        "scanner", repo / "tools/scan-firmware-games.py"
    )
    scanner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scanner)
    library = load(repo / "web/data/catalog.json")
    controls = scanner.check_controls(library)
    known_sgs = {r["decoded_body_sha256"]: r["id"] for r in controls["records"]}
    inventory = load(repo / "validation/preservation-inventory.json")
    prior = {}
    for archive in inventory["archives"]:
        if archive["id"] == "korean-game-portals-pass20":
            continue
        for member in archive["members"]:
            prior.setdefault(
                member["sha256"], (archive["repositoryPath"], member["path"])
            )

    objects, scans, reports, detail, beta, indexes = {}, {}, [], [], [], []
    budgets = Counter()

    def inspect(raw, name, depth=0):
        digest = sha(raw)
        if digest in scans:
            return scans[digest]
        if depth > 3 or len(raw) > 16 * 1024 * 1024:
            raise ValueError("File or nesting bound exceeded")
        budgets["scannedBytes"] += len(raw)
        if budgets["scannedBytes"] > 100 * 1024 * 1024:
            raise ValueError("Total byte bound exceeded")
        scan = scanner.scan_bytes(raw)
        for hit in scan["containers"]:
            hit["existingGameId"] = known_sgs.get(hit["decoded_body_sha256"])
        info = {"name": name, "signatureHex": raw[:12].hex(), **scan}
        if zipfile.is_zipfile(io.BytesIO(raw)):
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                members = archive.infolist()
                if (
                    len(members) > 1000
                    or sum(m.file_size for m in members) > 32 * 1024 * 1024
                ):
                    raise ValueError("ZIP member bounds exceeded")
                info["zipMembers"] = [
                    {
                        "path": member.filename,
                        "crc32": f"{member.CRC:08x}",
                        "sha256": inspect(
                            archive.read(member), member.filename, depth + 1
                        )["sha256"],
                    }
                    for member in members
                ]
        scans[digest] = info
        return info

    for folder in sorted(root.glob("*-network")):
        sources = load(folder / "sources.json")
        receipts = [
            json.loads(line)
            for line in (folder / "receipts.jsonl").read_text("utf8").split("\n")
            if line
        ]
        assert receipts == [s["receipt"] for s in sources]
        for source in sources:
            receipt = source["receipt"]
            row = {k: v for k, v in source.items() if k != "receipt"}
            allowed = {
                "content-type",
                "content-length",
                "content-disposition",
                "location",
                "memento-datetime",
                "last-modified",
                "etag",
                "x-archive-orig-content-type",
                "x-archive-orig-content-length",
                "x-archive-orig-content-disposition",
            }
            row["receipt"] = {
                **{k: v for k, v in receipt.items() if k != "headers"},
                "headers": [
                    (k, v)
                    for k, v in receipt.get("headers", [])
                    if k.lower() in allowed
                ],
            }
            row["group"] = folder.name
            reports.append(row)
            status = receipt["status"]
            if "path" not in receipt:
                continue
            body = (folder / receipt["path"]).read_bytes()
            digest = sha(body)
            assert (len(body), digest) == (receipt["bytes"], receipt["sha256"])
            if digest in prior:
                row["previouslyPublishedBody"] = dict(
                    zip(("archive", "member"), prior[digest])
                )
            objects.setdefault(digest, body)
            row["storedObject"] = f"objects/{digest}"
            if "cdx" in source:
                row["cdxBodyMatches"] = cdx_sha(body) == source["cdx"]["digest"]
            if status != 200 or not receipt["complete"]:
                continue
            inspect(body, receipt["finalUrl"])
            if "cdx/search" in source["url"]:
                indexed = select_cdx(body)
                row["indexRecords"] = len(indexed)
                indexes.append((source, indexed))
            if source.get("contentId") and row.get("cdxBodyMatches"):
                ids = download_ids(source, body)
                if ids:
                    detail.append(ids)
            final = receipt["finalUrl"]
            if any(
                path in final
                for path in (
                    "Sub_main_betagame.html",
                    "Mobilebeta_list.html",
                    "h_list.html",
                )
            ):
                page = Links()
                page.feed(body.decode("cp949", errors="replace"))
                original = final.split("id_/", 1)[1]
                for link, pieces in page.links:
                    url = urljoin(original, link)
                    path = urlsplit(url).path
                    fields = parse_qs(urlsplit(url).query)
                    title = " ".join("".join(pieces).split())
                    if (
                        title
                        and path in ("/Mobilebeta_view.html", "/ver2/h_view.html")
                        and fields.get("Bid", [""])[0] == "betanotice"
                    ):
                        beta.append(
                            {
                                "title": title,
                                "url": url,
                                "capture": final,
                                "sha256": digest,
                            }
                        )

    details = next(
        rows
        for source, rows in indexes
        if source.get("original") == "http://mgame.daum.net/view.jsp"
    )
    ids = sorted(
        {
            value
            for row in details
            if urlsplit(row["original"]).hostname == "mgame.daum.net"
            and urlsplit(row["original"]).path == "/view.jsp"
            and row["statuscode"] == "200"
            and re.fullmatch(r"[A-Z2-7]{32}", row["digest"])
            for value in parse_qs(urlsplit(row["original"]).query).get("ctsid", [])
        }
    )
    swf_row = next(
        row for row in reports if row["kind"] == "Literal developer home SWF link"
    )
    swf = objects[swf_row["receipt"]["sha256"]]
    swf_cdx = [
        r
        for source, rows in indexes
        if source.get("original", "").endswith("/Movie1.swf")
        for r in rows
    ]
    swf_evidence = {
        "bytes": len(swf),
        "sha256": sha(swf),
        "sha1Base32": cdx_sha(swf),
        "actualCapture": swf_row["receipt"]["finalUrl"],
        "matchingCdxRows": list(
            {
                r["timestamp"] + r["original"]: r
                for r in swf_cdx
                if r["digest"] == cdx_sha(swf)
            }.values()
        ),
        **swf_button_link(swf),
    }
    assert swf_evidence["matchingCdxRows"]
    xls_row = next(
        row
        for row in reports
        if row.get("cdxBodyMatches") and row["receipt"].get("bytes") == 28160
    )
    xls = objects[xls_row["receipt"]["sha256"]]
    book = xlrd.open_workbook(file_contents=xls)
    sheet = book.sheet_by_name("Sheet3")
    raw_rows = [sheet.row_values(i) for i in range(sheet.nrows)]
    models = [r for r in raw_rows[3:] if r[2] and r[3]]
    xls_evidence = {
        "filename": "GVM_phone.xls",
        "capture": xls_row["receipt"]["finalUrl"],
        "sha256": sha(xls),
        "sha1Base32": cdx_sha(xls),
        "bytes": len(xls),
        "dateCell": raw_rows[1][9],
        "sheet": sheet.name,
        "columns": sheet.ncols,
        "totalRows": sheet.nrows,
        "modelRows": len(models),
        "versionLabels": dict(Counter(r[7] for r in models)),
        "rows": raw_rows,
    }
    hits = [
        {"scannedSha256": scan["sha256"], **hit}
        for scan in scans.values()
        for hit in scan["containers"]
    ]
    output = {
        "schema": 1,
        "checkedUtc": datetime.now(timezone.utc).isoformat(),
        "requestCounts": dict(Counter(row["group"] for row in reports)),
        "httpStatusCounts": dict(Counter(row["receipt"]["status"] for row in reports)),
        "storedBodies": len(objects),
        "bodyBytes": sum(len(body) for body in objects.values()),
        "exactCdxReplayCounts": dict(
            Counter(
                str(row.get("cdxBodyMatches", "no body"))
                for row in reports
                if "cdx" in row
            )
        ),
        "daum": {
            "viewCdxRows": len(details),
            "viewCdxLimit": 1000,
            "viewIds": ids,
            "cardMetadata": detail,
            "emptyExactPurchaseIndexes": sum(
                r.get("indexRecords") == 0
                and "send.jsp?ctsid=" in r.get("original", "")
                for r in reports
            ),
        },
        "handygame": {"betaLinkRows": beta},
        "ddanguriFlash": swf_evidence,
        "earlyHandsetTable": xls_evidence,
        "scan": {
            "positiveControlsPassed": controls["passed"],
            "uniqueScannedBodies": len(scans),
            "scannedBytes": budgets["scannedBytes"],
            "candidateOffsetsTested": sum(
                scan["candidate_offsets_tested"] for scan in scans.values()
            ),
            "zipContainers": sum("zipMembers" in scan for scan in scans.values()),
            "hits": hits,
            "newSgs": sum(hit["existingGameId"] is None for hit in hits),
        },
        "responses": reports,
    }
    assert (
        output["scan"]["newSgs"] == 0
    ), "Review the new candidate before making the archive"
    options.output.mkdir(exist_ok=False)
    write(options.output / "evidence.json", output)
    write(options.output / "scan-details.json", list(scans.values()))
    (options.output / "objects").mkdir()
    for digest, body in objects.items():
        (options.output / "objects" / digest).write_bytes(body)
    print(
        json.dumps(
            {
                k: output[k]
                for k in (
                    "requestCounts",
                    "httpStatusCounts",
                    "storedBodies",
                    "exactCdxReplayCounts",
                    "scan",
                )
            },
            ensure_ascii=False,
        )
    )
    print(
        "View IDs",
        len(ids),
        "verified title rows",
        len(detail),
        "beta link rows",
        len(beta),
        "early handset rows",
        len(models),
    )


if __name__ == "__main__":
    main()
