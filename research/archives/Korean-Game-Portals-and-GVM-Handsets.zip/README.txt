Daum, HandyGame, Ddangguri and GVM Club. Acquisition pass 20.
evidence.json gives original/final URLs, retrieved UTC, sizes, HTTP status,
recorded CDX identity and original object path. HTTP errors and transport
failures are retained as observations. The response headers in this
package are limited to provenance and content metadata.

Objects are unchanged and named by SHA-256. See earlyHandsetTable and
ddanguriFlash in evidence.json for the original GVM_phone.xls and Movie1.swf
digests. Neither file was executed. The XLS is the 2002-01-03 edition.
The SWF contains a button link to index1.html, not a playable SGS.

scan-details.json records a bounded static scan of complete successful
responses and members of identified ZIP containers. One previously
preserved Hellfire SGS was present. No new SGS was recovered here.
The catalogue and forum indexes are partial. Rights in third-party
originals remain with their respective owners.
