    %{
    // Header Section
    #DEFINE SCRIPTVER         1                         // GVM version
    #DEFINE LCDCLASS          255                      // LCD Class 
    #DEFINE IMAGETYPE        2                         // image type ( BW : 1, 4GRAY : 2 )
    #DEFINE AUDIOTYPE         255                      // buzzer:1
    #DEFINE VOCTYPE            255                      // Vocoder type
    #DEFINE SCRIPTTYPE       1                         // script type ( StandAlone )
    #DEFINE SCRIPTCPID        19000                   // script cp id
    #DEFINE SCRIPTID            99                       // script id
    #define SCRIPTNAME        "HelloWorld"         // script name
    %}

    #include ".\../sscript.h"    
    void main()
    {
                 hello();
    }    
    void hello()
    {
                 ClearWhite(); //���۸� ������� ä���.
                 DrawStr(30 , 35 , "Hello World"); //���ڸ� ���ۿ� �׸���
                 Flush();
    }
