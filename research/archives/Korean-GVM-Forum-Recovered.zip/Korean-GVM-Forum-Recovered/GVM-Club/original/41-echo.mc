
%{
// Header Section
#DEFINE SCRIPTVER       1               // script version (1=GVM1X, 2=GVM2X)
#DEFINE LCDCLASS        255
#DEFINE IMAGETYPE       255             // image type ( BW : 1, 4GRAY : 2 )
#DEFINE AUDIOTYPE       255             // buzzer:1
#DEFINE VOCTYPE         255
#DEFINE SCRIPTTYPE      3               // script type ( Network )
#DEFINE SCRIPTCPID      1	            // script cp id
#DEFINE SCRIPTID        1               // script id
#DEFINE SCRIPTNAME      "ECHO TEST"		// script name
%}

#include "SScript.h"

#define SENDBUF	 				64
#define TRUE					1
#define FALSE					0


#define	REQUEST_TITLE			'T'


//////// TIME macro constant  ////////////////////
#define INIT_FRESH				2500
#define BG_REFRESH				250
#define ROLLING_TIME			300
#define PING_TIME				30000

//////// LCD Size macro constant /////////////////////
#define CONTENT_AREA_BOTTOM		(LCD_HEIGHT - 19)
#define LCD_HEIGHT				144
#define LCD_WIDTH				120


//////// STATES macro constant /////////////////////
#define MAIN_PAGE				100
#define CONTENT_PAGE			101
#define DEFAULT					200
#define LIST_PAGE				201
#define URL_PAGE				301

/////// COLOR///////////////////////////////////////
#define TEMPER_BOX_COLOR		3
#define CONTENT_BOX_COLOR		38
#define MANU_BG_COLOR			3
#define BG_COLOR				3
#define SCROLL_BG_COLOR			20


int     i;
int 	swSndBuf[SENDBUF];
int 	PAGE_STATE;




int STATE;
int nTimeCount;
//==================================================
// MAIN_PAGE global variable 
//==================================================
int initRedraw;
int CONTENTS_STATE;
const string menu[4] = {"�̺�Ʈ","����", "��ȭ","����"};



//====================================================
// Share global variable
//====================================================
string subStr;


//====================================================
// ParsingData
//====================================================


string  parseData;
string	receiveData; 
string 	proto;
string 	link;
string 	link_text[35];
string 	url[35];

int readlength;
const int start = 6;
int length;

int STAG = 0;	// 0:FALSE, 1:TRUE
int ETAG = 0;	// 0:FALSE, 1:TRUE
	
int STAG_LEN = 0;
int ETAG_LEN = 0;
int dataLen = 0;
	
int SPOS = 0;
int EPOS = 0;

int	   indexTitle = 0;
int	   indexUrl = 0;
//const string s_tag = "<A HREF ="; 
//string text;

string e_tag;

string realData;






void main()
{

	WaitPage();
	SetTimer(INIT_FRESH, S_TM_REPEAT);
	Init();
	CONTENTS_STATE = MAIN_PAGE;
	
}


void Init()
{ 
	initRedraw = TRUE;
}



void DrawMainPage()
{

	ClearBlack();
	SetStrColor( S_WHITE, S_WHITE );
	DrawText( swWidth / 2, (CONTENT_AREA_BOTTOM - 100), "Client Start..." );
	DrawText( swWidth / 2, swHeight-20, "[1]������ [2]�����" );
	Flush();
}



void WaitPage()
{
	ClearBlack();			

	SetStrType(S_FONT_MEDIUM, S_WHITE, S_GR_TRANSPARENT, S_ALIGN_CENTER);
	DrawText(swWidth / 2, 15, "Loading...");
		
	if(CONTENTS_STATE == MAIN_PAGE)
	MakeStrStr(subStr, "%s ����� ", menu[4]);
	MakeStrStr(subStr, "%s ����� ", "����Ÿ");
	DrawText((swWidth / 2), 30, subStr);
	DrawText(swWidth / 2, 45, "�ް� �ֽ��ϴ�.");	
	
	SetStrType(S_FONT_MEDIUM, S_WHITE, S_GR_TRANSPARENT, S_ALIGN_CENTER);
	DrawText(swWidth / 2, (CONTENT_AREA_BOTTOM - 2), "Please Wait..");
	Flush();
}



void TEST_STR1()
{


//	PutByte(swSndBuf, 0, REQUEST_TITLE);
//	NetSend(swSndBuf, 1);
	string str = "http:\/\/211.171.246.27\/yj\/in.html";
	int len;
	int a[1];
	len = StrLen(str);
	PutBytes(a, 0, str, len);
	NetSend (a, len);

	SetTimer2(PING_TIME, S_TM_REPEAT);
	nTimeCount = 0;
}



void DrawNewsPage()
{
	RestoreLCD();
	if(PAGE_STATE == LIST_PAGE)
	{
		Search_HREF();
	}
	Flush();
}



void SaveNewsBG()
{
	int i;
	ClearWhite();
	
	SetColor(BG_COLOR);
	FillRect(0, swHeight - 18, swWidth, swHeight);
	
	SetColor(S_BLACK);
	DrawHLine(0, swWidth, swHeight - 18);
	
	SetColor(CONTENT_BOX_COLOR);
	DrawHLine(1, swWidth -2, swHeight - 20);
	DrawVLine(1, 17, swHeight - 20);
	DrawHLine(1, swWidth - 2, swHeight - 20);
	DrawVLine(swWidth - 2, 17, swHeight - 20);
	
	SetColor(SCROLL_BG_COLOR);
	DrawVLine(2, 18, swHeight - 20);
	DrawHLine(2, swWidth - 3, 18);
	
	SaveLCD();
}


void InitNewsPage()
{
	CONTENTS_STATE = CONTENT_PAGE;
	STATE = URL_PAGE;
	PAGE_STATE = LIST_PAGE;
	SaveNewsBG();
}


void EVENT_KEYPRESS()
{
	switch(CONTENTS_STATE)
	{
		case MAIN_PAGE:
	
		if(swData == SWAP_KEY_1)
		{
			InitNewsPage();
			TEST_STR1();
		}
		
		break;
	}
}


void EVENT_TIMEOUT()
{
	switch(CONTENTS_STATE)
	{
		case MAIN_PAGE:
		
			if(initRedraw)
			{
				DrawMainPage();
				SetTimer(BG_REFRESH, S_TM_REPEAT);
			}
		break;
		
		case CONTENT_PAGE:
			if(initRedraw)
			{				
				DrawNewsPage();
				initRedraw = FALSE;	
			}
		break;
		
	}
}	




void EVENT_RECEIVE()
{

  
//   	int nSize;
  	receiveData = NULL; 
 	proto = NULL;
	parseData = NULL;
	
//	nSize = GetByte(swRcvBuf, 9);
	
// 	StrInit(proto, 6);
// 	GetBytes(swRcvBuf, 3 , proto, 5);
// 	readlength = AsciiToInt(proto);
 
 	StrInit(parseData, 128);
	GetBytes(swRcvBuf, start , parseData, 128);
//	StrInit(parseData,readlength);
//	StrCpy(parseData, receiveData);
//	StrCat(parseData,receiveData);
//	Trace3("runGame================%d %d %s",start,start,parseData);

//  for (i=0; i<2; i++)
//  {
//    	DrawText(0, (i+1)*15, StrSub(str, parseData, i*128, 128));
//	 }

//	DrawText(-readlength, 40, parseData);
//Flush();	

	
	/*for(i = start;  i<readlength; i+=128)
	{	
	
		StrInit(receiveData,128);
		GetBytes(swRcvBuf, i , receiveData, 128);
		StrCat(parseData, receiveData);
		Trace3("runGame================%d %d %s",start,start,parseData);	
	}*/

}


void Search_HREF()
{

	//string parseData = "<TITLE>YAHOO �����ҽ�<\/TITLE><a href=http:\/\/et\/ke\/mv\/0703ae0.html>GVM�����!~</a><a href=http:\/\/et\/ke\/mv\/070.html>GVM����Ѵ�!~</a>";
	string temp;
    string s_tag;
	string text;
	int	parseDataSize = 0;
	string e_tag;
	string last_tag;
	link  = NULL;
	realData = NULL;
	
	SetStrType(S_FONT_MEDIUM, S_BLACK, S_GR_TRANSPARENT, S_ALIGN_LEFT);
	STAG_LEN = StrLen(s_tag);
	
	StrCpy(s_tag, "<A HREF =");
	StrCpy(e_tag, ">");
	StrCpy(last_tag,"</A>");
	

while(1)
{
	DrawText(-400,40,parseData);
	parseDataSize = StrLen(parseData);										//ã�� �±׸� �ʱ�ȭ ���� �ش� 
	STAG_LEN = StrLen(s_tag);												//ã�� �±��� ���� ���̸� ���Ѵ�.
//	StrSub(text,s_tag,1, STAG_LEN);
//	DrawText(0,0,s_tag);
//	Trace3("runGame================%d %d %d",text,parseData,parseData);
	for(i = 0; i < parseDataSize; i++)        								//������ ���� ���� HTML�±� ������ ��ŭ �ݺ� �ؼ� ���� 
    {
    	StrSub(text,parseData,i, STAG_LEN);
	 	//DrawText(0, (i+1)*15, text);
		
		if((StrCmp(text, s_tag)) == 0)							//<a href= ã������ 
    	{
    //		DrawText(0, 20,text);
	   	    STAG = TRUE;
    //	   	SPOS = i+StrLen(s_tag);								//���� ���  ã�� �±� �������� ��ġ ��Ų��
       	    break;
    	}
    	
    	else {
       		STAG = FALSE;
      	//	DrawText(0, 20,"1111111111111111");
    	}
    }
	
	
	DrawText(0,0,realData);
	if (STAG == TRUE)                              	
	{
	
//		DrawText(0,0,parseData);
		//e_tag = ">";											//<a href= ..........>������ �±� ������ url �ּ� 	
		ETAG_LEN = StrLen(e_tag);
				
	    for(i = SPOS; i< parseDataSize; i++)  					//���� �±� ���� >�±� ã�� ������ �ݺ��� ���� 
    	{	
	 	  	StrSub(text, parseData, i, ETAG_LEN);
	// 	  	DrawText(0, (i+1)*15, parseData);					//ã�� >�±� ���� 
    	
    		if((StrCmp(text, e_tag)) == 0) 						// >�±� ã������        
    		{	
    			//DrawText(0, 20, text);															
    			ETAG = TRUE;						
    		    EPOS = i + 1;									//���� �±׸� �ٲ��ش� 
    		    break;
	    	}
    	    else {
    			ETAG = FALSE;
    	   }
    	}
    }
    else
    {
	    break;
    }
    
    
    if (STAG == TRUE && ETAG == TRUE)								//<a href= ..........>ã���� �±׵��� ��� ����
    {
		
		StrSub(link, parseData, SPOS, (EPOS-SPOS-1));   			//http://url �ּ� �κ��� ������ ���´�. 
		StrCpy(url[indexUrl], link);
//		DrawText(0, (indexUrl+1)*15, url[indexUrl]);
		indexUrl++;
		
		//e_tag = "</A>";												//</a>���� ã�´� ~~~~~~~									
		ETAG_LEN = StrLen(last_tag);		
		SPOS = EPOS;
		for(i = SPOS; i< StrLen(parseData); i++)
    	{	
	 	  	StrSub(text, parseData, i, ETAG_LEN);				//</a>�±׸� ���� �س��´� 
//	 	  	DrawText(0,40, text); 
    	
    		if((StrCmp(text, last_tag)) == 0)        
    		{
	 		//	DrawText(0, 0, text);
    			ETAG = TRUE;
    		    EPOS = i;
    		    break;
	    	}
	    	else {
	    		ETAG = FALSE;
	    	}
	    	
    	}
    	
    	StrSub(link_text[indexTitle], parseData, SPOS, (EPOS-SPOS));
    	//DrawText(0, (indexTitle+3)*15, link_text[indexTitle]);
    	indexTitle++;
    	StrSub(parseData, parseData, EPOS+ETAG_LEN, StrLen(parseData));
  	 //	Trace3("runGame================%d %d %s",SPOS,EPOS,parseData);

	  }

   }//while(���̻��� ã�� �±װ� ���ٸ�~~~~~~~~while �� ����)
 	
    Flush();   
}
	
	


