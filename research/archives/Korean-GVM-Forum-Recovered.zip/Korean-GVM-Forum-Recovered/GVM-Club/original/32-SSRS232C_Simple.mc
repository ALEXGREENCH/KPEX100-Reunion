//serial communication test pgm//
%{
//header section
#DEFINE SCRIPTVER 1 //Script version 1:GVM1X, 2:GVM2X //1
#DEFINE LCDCLASS 255 //LCD size //255
#DEFINE IMAGETYPE 255 //LCD color type //255
#DEFINE AUDIOTYPE 255 //Audio type //255
#DEFINE VOCTYPE 255 //Carrier type //255
#DEFINE SCRIPTTYPE 1 //Script ���� type 1:Stand-alon, 3:Network...)
#DEFINE SCRIPTCPID 7230 //Contents provider ID //
#DEFINE SCRIPTID 150 //Script ID 1~5999 �Ϲݼ���
#DEFINE SCRIPTNAME "SERIAL TEST"
//#DEFINE SCRIPTDIR "NETWORK" //Script Category //GVM 2X ����
//#DEFINE VALIDCOUNT 255 //Unlimited //GVM 2X ����
//#DEFINE VALIDTERM 255 //Unlimited //GVM 2X ����
%}

#include "SScript.h"

string str[10];
int outBuf[2] = {0,0};
int buf[250];
int i,a,y;
int cnt=0;

void main()
{
	ClearWhite(); //���۸� ������� ä��.
	SetStrType(S_FONT_LARGE, S_BLACK, S_WHITE, S_ALIGN_LEFT);
	DrawStr(0,0,"Serial Test"); //���ڸ� ���ۿ� �׸�.
	DrawStr(0,12,"Press key 0-9 or OK");
	Flush();
}

void EVENT_KEYPRESS()
{
	PutByte(outBuf,0,cnt++);

	switch(swData){

		case SWAP_KEY_1:
			RsCom(1,outBuf,1);
			break;

		case SWAP_KEY_2:
			RsCom(2,outBuf,1);
			break;

		case SWAP_KEY_3:
			RsCom(3,outBuf,1);
			break;

		case SWAP_KEY_4:
			RsCom(4,outBuf,1);
			break;

		case SWAP_KEY_5:
			RsCom(5,outBuf,1);
			break;

		case SWAP_KEY_6:
			RsCom(6,outBuf,1);
			break;

		case SWAP_KEY_7:
			RsCom(7,outBuf,1);
			break;

		case SWAP_KEY_8:
			RsCom(8,outBuf,1);
			break;

		case SWAP_KEY_9:
			RsCom(9,outBuf,1);
			break;

		case SWAP_KEY_0:
			RsCom(0,outBuf,1);
			break;

		case SWAP_KEY_OK:
			for (i=0;i<50;i++) buf[i]=i;
			RsSend(buf,100);
			break;

	} 
}

void EVENT_RSRECEIVE()
{
	for (i=12;i>0;i--) StrCpy(str[i],str[i-1]);

	StrInit(str[0],swData*2 + 1);

	for (i=0;i<swData;i++){
		a=GetByte(swRsRcvBuf,i);
		PutChar(str[0],i*2,'0'+(a>>4));
		PutChar(str[0],i*2+1,'0'+(a & 0x0F));
	}

	ClearWhite();
	SetStrType(S_FONT_LARGE,S_BLACK,S_WHITE,S_ALIGN_LEFT);

	y=swHeight-13;
	for (i=0;i<13;i++){
		DrawStr(0,y,str[i]);
		y-=14;
	}

	Flush();
}
