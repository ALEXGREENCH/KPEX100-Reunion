import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const base = path.dirname(fileURLToPath(import.meta.url));
const explicitRepository = process.argv[2] && !['0', '1'].includes(process.argv[2]);
const repository = explicitRepository ? path.resolve(process.argv[2]) : path.resolve(base, '../../outputs/KPEX100-Reunion');
const { LegacyRuntime, parseLegacy } = await import(pathToFileURL(path.join(repository, 'web/engine/legacy.js')));
const { TimerScheduler } = await import(pathToFileURL(path.join(repository, 'web/engine/timers.js')));
const original = path.join(base, 'derived/37-느시-member-1-0000102FFFFFFFF.sgs');
const raw = fs.readFileSync(original);
const parsed = parseLegacy(raw);
const startData = Number(process.argv[explicitRepository ? 3 : 2] ?? 1);
const mode = process.argv[explicitRepository ? 4 : 3] ?? 'input';
if (![0, 1].includes(startData) || !['input', 'idle', 'ready'].includes(mode)) throw Error('Bad research replay mode');
const output = path.join(base, `zola-start${startData}-${mode}`);
fs.mkdirSync(output, { recursive: true });
let now = 0;
const game = await LegacyRuntime.create(
  fs.readFileSync(path.join(repository, 'web/data/firmware/Kingston-2.12.rom')),
  raw,
  { profile: 'phone', width: 128, height: 128, nowMs: () => now, clock: () => new Date(2026, 0, 1, 12) },
);
const timers = new TimerScheduler();
const frames = [];
const actions = [['tick', 2], ['key', 20], ['tick', 2], ['key', 6], ['tick', 2],
  ['key', 7], ['tick', 3], ['key', 8], ['tick', 3], ['key', 9], ['tick', 3]];
function capture(label) {
  const rgba = Buffer.from(game.framebufferRGBA);
  const filename = label + '.rgba';
  fs.writeFileSync(path.join(output, filename), rgba);
  frames.push({ label, file: filename, timeMs: now, events: game.eventCount,
    status: game.status, error: game.error, rgbaSha256: createHash('sha256').update(rgba).digest('hex') });
}
try {
  game.event('START', startData);
  timers.sync(game.timerStates, now);
  capture('start');
  for (let step = 0; step < actions.length && game.status === 'idle'; step++) {
    const [kind, value] = actions[step];
    if (kind === 'key') {
      if (mode === 'input' || (mode === 'ready' && value === 20)) { game.setKey(value, true); game.setKey(value, false); }
      timers.sync(game.timerStates, now);
    } else {
      for (let i = 0; i < value && game.status === 'idle'; i++) {
        const timer = timers.next();
        if (!timer) break;
        now = timer.at;
        game.event('TIMEOUT', timer.channel);
        timers.sync(game.timerStates, now, timer.channel);
      }
    }
    capture(`${step}-${kind}${value}`);
  }
  const report = {
    source: { filename: '0000102FFFFFFFF.sgs', bytes: raw.length, sha256: createHash('sha256').update(raw).digest('hex'),
      version: parsed.version, title: parsed.title, variables: parsed.variables.length, resources: parsed.resources.length,
      entries: parsed.entries, sections: [parsed.a, parsed.b, parsed.c, parsed.d] },
    runtime: { profile: 'phone', width: 128, height: 128, startData, mode },
    note: 'START data 1 is S_GTYPE_ALONE in original SDK SScript.h; original SGS unchanged; no network connection.',
    actions, frames, diagnostics: game.diagnostics,
  };
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ startData, mode, status: game.status, error: game.error, events: game.eventCount, timeMs: now }));
} finally { game.close(); }
