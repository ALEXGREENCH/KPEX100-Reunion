//=======================================================
//
//	Hello GVM Program
//
//=======================================================

%{
// Header Section
#DEFINE SCRIPTVER		1	
#DEFINE LCDCLASS		255	
#DEFINE IMAGETYPE		255	
#DEFINE AUDIOTYPE		255	
#DEFINE VOCTYPE			255	
#DEFINE SCRIPTTYPE		1	
#DEFINE SCRIPTCPID  		100   	
#DEFINE SCRIPTID		35    	
#DEFINE SCRIPTNAME		"Hello"
%}

#include "..\SScript.h"
#include "Sound.ssd"
#include "Smile.sbm"

int x = 30;
int y = 55;

void main()
{
	Show();
}

void Show()
{
	ClearWhite();
	CopyImage(swWidth/3, swHeight/10, Smile);
	PlaySound(Sound);
	Flush();
}

void EVENT_KEYPRESS()
{
	DrawStr(x, y, "Hello GVM");
	Flush();
}