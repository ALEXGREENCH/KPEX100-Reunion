//==================================================================
//
//		
//
//==================================================================

%{
// Header Section
#DEFINE SCRIPTVER	2			// GVM 2X
#DEFINE LCDCLASS	255			// LCD Class : Any class
#DEFINE IMAGETYPE	255			// Image Type : Any type
#DEFINE AUDIOTYPE	255			// Audio Type : Any Type
#DEFINE VOCTYPE		255			// Carrier Type : SKT
#DEFINE SCRIPTTYPE		5			// Application Type : PTP
#DEFINE SCRIPTCPID	11960			// Script CPID
#DEFINE SCRIPTID	1			// Script ID
#DEFINE SCRIPTNAME	""		// Script Name
%}

#include "SScript.h"
#include "caracter.sbm"

#define TRUE 1
#define FALSE 0

#define G_INIT 1
#define G_GAME 2
#define G_OVER 3

#define KEYMAX 100
#define TIME_OUT 100
#define MAX_SND_BUFF 16

#define READY 0
#define BUSY 1
#define GAMEEND 2

int Key_Value1[KEYMAX];
int Key_Value2[KEYMAX];
int NetID;
int GameState;
string StrUID;
int Winner;
int P1_Is_Receive;
int P2_Is_Receive;
int SndBuff[MAX_SND_BUFF];

int P1_X;
int P1_Y;
int P1_State;
int P1_Delay;
int P1_Image;
int P1_Energe;
int P1_hkick;
int P1_JumpTime;
int P1_Shoot_X;
int P1_Shoot_Y;
int P1_IsShoot;
int P1_IsBlock;

int P2_X;
int P2_Y;
int P2_State;
int P2_Delay;
int P2_Image;
int P2_Energe;
int P2_hkick;
int P2_JumpTime;
int P2_Shoot_X;
int P2_Shoot_Y;
int P2_IsShoot;
int P2_IsBlock;

int GameType;

void main()
{
	GameType=swData;
	NetID=GetSysUserID(StrUID);
	GameState=G_INIT;
	P1_State=GAMEEND;
	P2_State=GAMEEND;
	SetTimer(TIME_OUT,S_TM_REPEAT);


}

void EVENT_TIMEOUT()
{
	Game_State();
}

void Game_State()
{
	switch(GameState)
	{
		case G_INIT:
			Title();
			if(GameType==S_GTYPE_ALONE&&P1_State==READY)
			{
				InitGame();
				
				
				GameState=G_GAME;
				
			}
			
			if(GameType==S_GTYPE_PTP&&P1_State==READY&&P2_State==READY)
			{
				InitGame();
				
				GameState=G_GAME;
			}
			break;
		case G_GAME:
			FightGame();
			if(GameType==S_GTYPE_ALONE)P2_Auto();
			break;
		case G_OVER:
			GameOver();
			break;
	}
}

void P2_Auto()
{

	int a;
	if(Contact(2))
	{
		a=RandRatio(50)+7;
		Key_Value2[a]=TRUE;
	}
	else 
	Key_Value2[1]=TRUE;


}

void Title()
{
	ClearWhite();
	DrawStr(40,60,"Are You Ready?");
	Flush();
}

	
void InitGame()
{
	int i;
	ClearWhite();
	P1_X=25;
	P1_Y=100;
	P1_Delay=0;
	P1_Image=0;
	P1_Energe=100;
	P1_hkick=FALSE;
	P1_JumpTime=0;
	P1_IsBlock=FALSE;
	P1_Shoot_X=0;
	P1_Shoot_Y=0;
	P1_IsShoot=FALSE;
	Draw(P1_X,P1_Y,P1_Image,1);
	
	P2_X=100;
	P2_Y=100;
	P2_Delay=0;
	P2_Image=0;
	P2_Energe=100;
	P2_hkick=FALSE;
	P2_JumpTime=0;
	P2_IsBlock=FALSE;
	P2_Shoot_X=0;
	P2_Shoot_Y=0;
	P2_IsShoot=FALSE;
	Draw(P2_X,P2_Y,P2_Image,2);
	
	P1_Is_Receive=FALSE;
	P2_Is_Receive=FALSE;
	for(i=0;i<KEYMAX;i++)
	{
		Key_Value1[i]=FALSE;
		Key_Value2[i]=FALSE;
	}
	EnergeCarculate(0,0);
			
	
}

	
	

void EnergeCarculate(int i,int j)
{


	if(GameState!=G_OVER){
    	if(j==1&&P2_IsBlock)
    		P2_Energe-=5;
    	else if(j==2&&P1_IsBlock)
    		P1_Energe-=5;
    	else 
    	{
    		switch(i)
    		{
    			case 7:
    				if(j==1)P2_Energe-=10;
    				if(j==2)P1_Energe-=10;
    				break;
    			case 8:
    				if(j==1)P2_Energe-=15;
    				if(j==2)P1_Energe-=15;
    				break;
    			case 9:
    				if(j==1)P2_Energe-=20;
    				if(j==2)P1_Energe-=20;
    				break;
    		}
    	}
    }
    if(P1_Energe<=0&&P2_Energe<=0){Winner=3;GameState=G_OVER;P1_State=GAMEEND;
	P2_State=GAMEEND;}
	
    else if(P2_Energe<=0){Winner=1;GameState=G_OVER;P1_State=GAMEEND;
	P2_State=GAMEEND;}
	
    else if(P1_Energe<=0){Winner=2;GameState=G_OVER;P1_State=GAMEEND;
	P2_State=GAMEEND;}
	
    			
    else
    {
  	 	SetColor(S_WHITE);
		FillRect(5,10,55,20);
	
		FillRect(70,10,125,20);
		Flush();
		SetColor(S_DGRAY);
		FillRect(5,10,5+P1_Energe/2,20);
	
		FillRect(70+(50-P2_Energe/2),10,120,20);
		Flush();
	}

}

void Blocking(int i)
{

    if(i==1)
    {
        P1_IsBlock=TRUE;
        Draw(P1_X,P1_Y,6,1);
        Key_Value1[SWAP_KEY_4]=FALSE;
    }

    if(i==2)
    {
        P2_IsBlock=TRUE;
        Draw(P2_X,P2_Y,6,2);
        Key_Value1[SWAP_KEY_8]=FALSE;
    }
}

void Shooting(int i)
{
	if(i==1)
	{
		P1_IsShoot=TRUE;
		P1_Shoot_X=P1_X+10;
		P1_Shoot_Y=P1_Y-20;	
		Draw(P1_Shoot_X,P1_Shoot_Y,7,1);
		Delay(1,8);
	}
	if(i==2)
	{
		P2_IsShoot=TRUE;
		P2_Shoot_X=P2_X-10;
		P2_Shoot_Y=P2_Y-20;
		Draw(P2_Shoot_X,P2_Shoot_Y,7,2);
		Delay(2,8);
	}
}

void FightGame()
{

	
	
	if((Contact(1)&&(Key_Value2[7]||Key_Value2[8])&&Key_Value1[SWAP_KEY_4])||(P2_IsShoot==TRUE&&ShootContact(1)&&Key_Value1[SWAP_KEY_4]))
	{
		Blocking(1);
	}
	
	if((Contact(2)&&(Key_Value1[7]||Key_Value1[8])&&Key_Value1[SWAP_KEY_6])||(P1_IsShoot==TRUE&&ShootContact(2)&&Key_Value1[SWAP_KEY_6]))
	{
		Blocking(2);
	}
	
		
	if(P1_IsShoot==TRUE)
	{
		
		if(ShootContact(2))
		{
			EnergeCarculate(8,1);
			P1_IsShoot=FALSE;
			
			SetColor(S_WHITE);
			FillRect(P1_Shoot_X-8,P1_Shoot_Y-4,P1_Shoot_X+7,P1_Shoot_Y+4);
			Flush();
			P1_Shoot_X=0;
			P1_Shoot_Y=0;
			
		}
		else
		{
			P1_Shoot_X+=3;
			Draw(P1_Shoot_X,P1_Shoot_Y,7,1);
		}
	}
	
	if(P2_IsShoot==TRUE)
	{
		if(ShootContact(1))
		{
			EnergeCarculate(8,2);
		
			P2_IsShoot=FALSE;
			
			SetColor(S_WHITE);
			FillRect(P2_Shoot_X-8,P2_Shoot_Y-4,P2_Shoot_X+7,P2_Shoot_Y+4);
			Flush();
			P2_Shoot_X=0;
			P2_Shoot_Y=0;
			
		}
		else
		{
			P2_Shoot_X-=3;
			Draw(P2_Shoot_X,P2_Shoot_Y,7,2);
		}
	}

	if(P1_Delay>0)
	{
		Delay(1,--P1_Delay);
		
	}
	
	else if(P1_IsBlock==TRUE);
	else
	{
	
		if(Key_Value1[SWAP_KEY_5])
		{
		    Blocking(1);
		    Key_Value1[SWAP_KEY_5]=FALSE;
		}
	
		if(Key_Value1[SWAP_KEY_9])	
		{
		
			 Shooting(1);
			 Key_Value1[SWAP_KEY_9]=FALSE;
		
		}
	
		if(Key_Value1[SWAP_KEY_4])	
		{
		
			 Backward(1);
		
		}
		if(Key_Value1[SWAP_KEY_3])
		{
	
			ForwardJump(1);
		
		}
	
		if(Key_Value1[SWAP_KEY_1])
		{
	
			BackwardJump(1);
		
		}
	
		if(Key_Value1[SWAP_KEY_2])
		{

			jump(1);
		
 
		}
	
	
		if(Key_Value1[SWAP_KEY_6])
		{
			 Forward(1);
		 
		}
	
		if(Key_Value1[SWAP_KEY_7])		
		{
			Punch(1);
			Key_Value1[SWAP_KEY_7]=FALSE;
		
		}
		if(Key_Value1[SWAP_KEY_1]==FALSE&&Key_Value1[SWAP_KEY_2]==FALSE&&Key_Value1[SWAP_KEY_3]==FALSE&&Key_Value1[SWAP_KEY_8])
		{
			Kick(1);
			Key_Value1[SWAP_KEY_8]=FALSE;
		
		}
	}
	if(P2_Delay>0)
	{
		Delay(2,--P2_Delay);
	}
	else if(P2_IsBlock==TRUE);
	else
	{
		if(Key_Value2[SWAP_KEY_5])
		{
	    	Blocking(2);
	   		 Key_Value2[SWAP_KEY_5]=FALSE;
		}
		if(Key_Value2[SWAP_KEY_9])	
		{
		
			 Shooting(2);
			 Key_Value2[SWAP_KEY_9]=FALSE;
		
		}
	
		if(Key_Value2[SWAP_KEY_6])
		{
		
			 Forward(2);
		 
		}
		if(Key_Value2[SWAP_KEY_4])	
		{
			Backward(2);
		
		}
		if(Key_Value2[SWAP_KEY_7])		
		{
			Punch(2);
			Key_Value2[SWAP_KEY_7]=FALSE;
		
		}
		if(Key_Value2[SWAP_KEY_1]==FALSE&&Key_Value2[SWAP_KEY_2]==FALSE&&Key_Value2[SWAP_KEY_3]==FALSE&&Key_Value2[SWAP_KEY_8])
		{
			Kick(2);
			Key_Value2[SWAP_KEY_8]=FALSE;
		
		}
	
		if(Key_Value2[SWAP_KEY_3])
		{
		
			ForwardJump(2);
		
		}
		if(Key_Value2[SWAP_KEY_2])
		{
			jump(2);
		
		}
		if(Key_Value2[SWAP_KEY_1])
		{
	
			BackwardJump(2);
		
		}
	}
	
}

void SendData(int key)
{
	if(NetID==0)
	{
		SndBuff[0]=1;
		SndBuff[1]=key;
		NetSend(SndBuff,sizeof(SndBuff));
	}
	if(NetID==1)
	{
		SndBuff[0]=2;
		SndBuff[1]=key;
		NetSend(SndBuff,sizeof(SndBuff));
	}
}

void EVENT_RECEIVE()
{
	
	if(swRcvBuf[0]==1&&swRcvBuf[1]==2){Key_Value1[2]=TRUE;}
	if(swRcvBuf[0]==1&&swRcvBuf[1]==1){Key_Value1[1]=TRUE;}
	if(swRcvBuf[0]==1&&swRcvBuf[1]==3){Key_Value1[3]=TRUE;}
	if(swRcvBuf[0]==1&&swRcvBuf[1]==6){Key_Value1[6]=TRUE;}
	if(swRcvBuf[0]==1&&swRcvBuf[1]==4){Key_Value1[4]=TRUE;}
	if(swRcvBuf[0]==1&&swRcvBuf[1]==7){Key_Value1[7]=TRUE;}
    if(swRcvBuf[0]==1&&swRcvBuf[1]==8){Key_Value1[8]=TRUE;}
	if(swRcvBuf[0]==1&&swRcvBuf[1]==SWAP_KEY_OK&&GameState==G_OVER&&P1_State==GAMEEND){P1_State=READY;}
    if(swRcvBuf[0]==1&&swRcvBuf[1]==SWAP_KEY_OK&&GameState==G_INIT&&P1_State==GAMEEND){P1_State=READY;}
    
    if(swRcvBuf[0]==2&&swRcvBuf[1]==2){Key_Value2[2]=TRUE;}
    if(swRcvBuf[0]==2&&swRcvBuf[1]==3){Key_Value2[3]=TRUE;}
    if(swRcvBuf[0]==2&&swRcvBuf[1]==1){Key_Value2[1]=TRUE;}
    if(swRcvBuf[0]==2&&swRcvBuf[1]==8){Key_Value2[8]=TRUE;}
    if(swRcvBuf[0]==2&&swRcvBuf[1]==7){Key_Value2[7]=TRUE;}
    if(swRcvBuf[0]==2&&swRcvBuf[1]==6){Key_Value2[6]=TRUE;}
	if(swRcvBuf[0]==2&&swRcvBuf[1]==4){Key_Value2[4]=TRUE;}
	if(swRcvBuf[0]==2&&swRcvBuf[1]==SWAP_KEY_OK&&GameState==G_OVER&&P2_State==GAMEEND){P2_State=READY;}
	if(swRcvBuf[0]==2&&swRcvBuf[1]==SWAP_KEY_OK&&GameState==G_INIT&&P2_State==GAMEEND){P2_State=READY;}
}


	
void Kick(int i)
{
	if(i==1)
	{
		
		Draw(P1_X,P1_Y,5,1);
		
		Delay(1,8);
		if(Contact(i))
		{
			EnergeCarculate(8,1);
		}
		
		P1_Image=0;
		
		
	}
	if(i==2)
	{
		Draw(P2_X,P2_Y,5,2);
		
		Delay(2,8);
		if(Contact(i))
		{
			
			EnergeCarculate(8,2);
		}
		
		P2_Image=0;
	}
}

void Punch(int i)
{
	if(i==1)
	{
		
		Draw(P1_X,P1_Y,2,1);
		Delay(1,4);
		if(Contact(i))
		{
			
			EnergeCarculate(7,1);
		}
		
		P1_Image=0;
	}
	if(i==2)
	{
		
		Draw(P2_X,P2_Y,2,2);
		Delay(2,4);
		if(Contact(i))
		{
			
			EnergeCarculate(7,2);
			
		}
		
		P2_Image=0;
		
	}
}

void ForwardJump(int i)
{
	if(i==1)
	{

		if(P1_JumpTime>=16)
		{
			Key_Value1[SWAP_KEY_3]=FALSE;
			Key_Value1[SWAP_KEY_8]=FALSE;
			P1_JumpTime=0;
			P1_hkick=FALSE;
			P1_State=READY;
			Draw(P1_X,P1_Y,0,1);

		}
		else
		{
			if(P1_JumpTime>=8)
			{
				P1_Y+=2;
			}
			else P1_Y-=2;
			
			if(!Contact(i))P1_X++;
			else if(P1_hkick==FALSE&&Contact(i)&&Key_Value1[SWAP_KEY_8])
			{
			
				
				EnergeCarculate(9,1);
				P1_hkick=TRUE;
				P1_State=BUSY;
			}
				
			P1_JumpTime++;
			
			if(Key_Value1[SWAP_KEY_8])
				Draw(P1_X,P1_Y,4,1);
			else Draw(P1_X,P1_Y,3,1);
			
		}
		
	}
	if(i==2)
	{

		if(P2_JumpTime>=16)
		{
			Key_Value2[SWAP_KEY_3]=FALSE;
			Key_Value2[SWAP_KEY_8]=FALSE;
			P2_JumpTime=0;
			P2_hkick=FALSE;
			P2_State=READY;
			Draw(P2_X,P2_Y,0,2);

		}
		else
		{
			if(P2_JumpTime>=8)
			{
				P2_Y+=2;
			}
			else P2_Y-=2;
			
			
			P2_X++;
			if(P2_hkick==FALSE&&Contact(i)&&Key_Value2[SWAP_KEY_8])
			{
			
				EnergeCarculate(9,2);
				P2_hkick=TRUE;
				P2_State=BUSY;
			}
				
			P2_JumpTime++;
			
			if(Key_Value2[SWAP_KEY_8])
				Draw(P2_X,P2_Y,4,2);
			else Draw(P2_X,P2_Y,3,2);
			
		}
		
	}
}

void BackwardJump(int i)
{
	
	
	if(i==1)
	{

		if(P1_JumpTime>=16)
		{
			Key_Value1[SWAP_KEY_1]=FALSE;
			Key_Value1[SWAP_KEY_8]=FALSE;
			P1_JumpTime=0;
			P1_hkick=FALSE;
			P1_State=READY;
			Draw(P1_X,P1_Y,0,1);

		}
		else
		{
			if(P1_JumpTime>=8)
			{
				P1_Y+=2;
			}
			else P1_Y-=2;
			
			P1_X--;
			if(P1_hkick==FALSE&&Contact(i)&&Key_Value1[SWAP_KEY_8])
			{
			
				
				EnergeCarculate(9,1);
				P1_hkick=TRUE;
				P1_State=BUSY;
			}
				
			P1_JumpTime++;
			
			if(Key_Value1[SWAP_KEY_8])
				Draw(P1_X,P1_Y,4,1);
			else Draw(P1_X,P1_Y,3,1);
			
		}
		
	}
	if(i==2)
	{

		if(P2_JumpTime>=16)
		{
			Key_Value2[SWAP_KEY_1]=FALSE;
			Key_Value2[SWAP_KEY_8]=FALSE;
			P2_JumpTime=0;
			P2_hkick=FALSE;
			P2_State=READY;
			Draw(P2_X,P2_Y,0,2);

		}
		else
		{
			if(P2_JumpTime>=8)
			{
				P2_Y+=2;
			}
			else P2_Y-=2;
			if(!Contact(2))P2_X--;
			else if(P2_hkick==FALSE&&Contact(i)&&Key_Value2[SWAP_KEY_8])
			{
			
				
				EnergeCarculate(9,2);
				P2_hkick=TRUE;
				P2_State=BUSY;
			}
				
			P2_JumpTime++;
			
			if(Key_Value2[SWAP_KEY_8])
				Draw(P2_X,P2_Y,4,2);
			else Draw(P2_X,P2_Y,3,2);
			
		}
		
	}
}
	
void jump(int i)
{


    if(i==1)
	{

		if(P1_JumpTime>=16)
		{
			Key_Value1[SWAP_KEY_2]=FALSE;
			Key_Value1[SWAP_KEY_8]=FALSE;
			P1_JumpTime=0;
			P1_hkick=FALSE;
			P1_State=READY;
			Draw(P1_X,P1_Y,0,1);

		}
		else
		{
			if(P1_JumpTime>=8)
			{
				P1_Y+=2;
			}
			else P1_Y-=2;
			
			
	
			if(P1_hkick==FALSE&&Contact(i)&&Key_Value1[SWAP_KEY_8])
			{
			
				
				EnergeCarculate(9,1);
				P1_hkick=TRUE;
				P1_State=BUSY;
			}
				
			P1_JumpTime++;
			
			if(Key_Value1[SWAP_KEY_8])
				Draw(P1_X,P1_Y,4,1);
			else Draw(P1_X,P1_Y,3,1);
			
		}
		
	}
	if(i==2)
	{

		if(P2_JumpTime>=16)
		{
			Key_Value2[SWAP_KEY_2]=FALSE;
			Key_Value2[SWAP_KEY_8]=FALSE;
			P2_JumpTime=0;
			P2_hkick=FALSE;
			P2_State=READY;
			Draw(P2_X,P2_Y,0,2);

		}
		else
		{
			if(P2_JumpTime>=8)
			{
				P2_Y+=2;
			}
			else P2_Y-=2;
			
			
	
			if(P2_hkick==FALSE&&Contact(i)&&Key_Value2[SWAP_KEY_8])
			{
			
				
				EnergeCarculate(9,2);
				P2_hkick=TRUE;
				P2_State=BUSY;
			}
				
			P2_JumpTime++;
			
			if(Key_Value2[SWAP_KEY_8])
				Draw(P2_X,P2_Y,4,2);
			else Draw(P2_X,P2_Y,3,2);
			
		}
		
	}
}

void Forward(int i)
{
	if(i==1)
	{
		Draw(P1_X,P1_Y,1,1);
		Delay(1,2);

		Key_Value1[SWAP_KEY_6]=FALSE;
		
		if(!Contact(1))
		{
			P1_X+=2;
			
		}
		P1_Image=0;
	}
	if(i==2)
	{
	
		if(Contact(1)&&(Key_Value2[7]||Key_Value2[8]))
		{
		
		}
		Draw(P2_X,P2_Y,1,2);
		Delay(2,2);

		Key_Value2[SWAP_KEY_6]=FALSE;
		P2_X+=2;
			
		
		P2_Image=0;
	}
}

void Backward(int i)
{
	if(i==1)
	{
		
		Draw(P1_X,P1_Y,1,1);
		Delay(1,2);

		Key_Value1[SWAP_KEY_4]=FALSE;
		
		
		
		P1_X-=2;
		
		P1_Image=0;
	}
	if(i==2)
	{
		Draw(P2_X,P2_Y,1,2);
		Delay(2,2);

		Key_Value2[SWAP_KEY_4]=FALSE;
				
		if(!Contact(2))
		{
			P2_X-=2;
		
		}
		P2_Image=0;
	}
}

int Contact(int i)
{
	if(i==1)P1_X+=1;
	if(i==2)P2_X-=1;
	
	if(P1_X+8>=P2_X-8&&P1_X-8<=P2_X+8)
	{
		if(P1_Y-35<=P2_Y&&P1_Y>=P2_Y-35)
		{
			if(i==1)P1_X-=1;
			if(i==2)P2_X+=1;
			return TRUE;
		}
	}
	if(i==1)P1_X-=1;
	if(i==2)P2_X+=1;
			
	return FALSE;
}

int ShootContact(int i)
{
	if(i==1)
	{
		P1_X+=1;
	
	
		if(P1_X+8>=P2_Shoot_X-5&&P1_X-8<=P2_Shoot_X+5)
		{
			if(P1_Y-35<=P2_Shoot_Y+5&&P1_Y>=P2_Shoot_Y-5)
			{
				if(i==1)P1_X-=1;
				return TRUE;
			}
		}
		P1_X-=1;
	}
	
	if(i==2)
	{
		P2_X-=1;
	
	
		if(P2_X+8>=P1_Shoot_X-5&&P2_X-8<=P1_Shoot_X+5)
		{
			if(P2_Y-35<=P1_Shoot_Y+5&&P2_Y>=P1_Shoot_Y-5)
			{
				if(i==2)P2_X+=1;
				return TRUE;
			}
		}
		P2_X+=1;
	}	
	return FALSE;
}

void GameOver()
{
	string ResultName;
	
	
	ClearWhite();
	SetStrType(S_FONT_SMALL,S_BLACK,S_WHITE,S_ALIGN_CENTER);
	MakeStr1(ResultName,"%dP Win",Winner);
	DrawStr(40,40,ResultName);
	DrawStr(40,60,"OK is Restart!");
	Flush();
}

void EVENT_KEYPRESS()
{

	if((NetID==0&&P1_State==READY&&P1_JumpTime==0)&&!(P1_IsShoot==TRUE&&swData==9))
	{
		if(P1_IsBlock==TRUE)P1_IsBlock=FALSE;
			Key_Value1[swData]=TRUE;
		if(GameType==2)SendData(swData);
	}
	else if((NetID==1&&P2_State==READY&&P2_JumpTime==0)&&!(P2_IsShoot==TRUE&&swData==9))
	{
		if(P2_IsBlock==TRUE)P2_IsBlock=FALSE;
			Key_Value2[swData]=TRUE;
		if(GameType==2)SendData(swData);
	}
	else if(P1_JumpTime>0&&NetID==0&&swData==SWAP_KEY_8&&P1_State==READY)
	{
		Key_Value1[swData]=TRUE;
		if(GameType==2)SendData(swData);
	}
	else if(P2_JumpTime>0&&NetID==1&&swData==SWAP_KEY_8&&P2_State==READY)
	{
		Key_Value2[swData]=TRUE;
		if(GameType==2)SendData(swData);
	}
	else if(NetID==0&&GameState==G_INIT&&swData==SWAP_KEY_OK&&P1_State==GAMEEND)
	{
		P1_State=READY;
		if(GameType==2)SendData(swData);
	}
	else if(NetID==1&&GameState==G_INIT&&swData==SWAP_KEY_OK&&P2_State==GAMEEND)
	{
		P2_State=READY;
		if(GameType==2)SendData(swData);
	}
	else if(NetID==0&&GameState==G_OVER&&swData==SWAP_KEY_OK&&P1_State==GAMEEND)
	{
		GameState=G_INIT;
		P1_State=READY;
		if(GameType==2)SendData(swData);
	}
	else if(NetID==1&&GameState==G_OVER&&swData==SWAP_KEY_OK&&P2_State==GAMEEND)
	{
		GameState=G_INIT;
		P2_State=READY;
		if(GameType==2)SendData(swData);
	}


}

void Draw(int x,int y,int n,int p)
{
	
	
		if(p==1)
		{
			SetColor(S_WHITE);
			if(n!=7){
			switch(P1_Image)
			{
			case 0:
				FillRect(P1_X-11,P1_Y-40,P1_X+9,P1_Y+1);
				Flush();
				break;
			case 1:
				FillRect(P1_X-8,P1_Y-40,P1_X+9,P1_Y);
				Flush();
				break;
			case 2:
				FillRect(P1_X-11,P1_Y-36,P1_X+9,P1_Y);
				Flush();
				break;
			case 3:
				FillRect(P1_X-10,P1_Y-42,P1_X+9,P1_Y);
				Flush();
				break;
			case 4:
				FillRect(P1_X-29,P1_Y-14,P1_X+29,P1_Y);
				Flush();
				break;
			case 5:
				FillRect(P1_X-10,P1_Y-40,P1_X+10,P1_Y);
				Flush();
				break;
			case 6:
				FillRect(P1_X-10,P1_Y-40,P1_X+10,P1_Y);
				Flush();
				break;
			}
			P1_Image=n;
			}
		
			else
			{
				FillRect(P1_Shoot_X-8,P1_Shoot_Y-4,P1_Shoot_X+7,P1_Shoot_Y+4);
				Flush();
			}
			
			CopyImage(x,y,caracter[n]);
			Flush();
		}
		if(p==2)
		{
			SetColor(S_WHITE);
			if(n!=7)
			{
			switch(P2_Image)
			{
			case 0:
				FillRect(P2_X-7,P2_Y-40,P2_X+7,P2_Y+1);
				Flush();
				break;
			case 1:
				FillRect(P2_X-8,P2_Y-40,P2_X+8,P2_Y);
				Flush();
				break;
			case 2:
				FillRect(P2_X-11,P2_Y-36,P2_X+11,P2_Y);
				Flush();
				break;
			case 3:
				FillRect(P2_X-10,P2_Y-42,P2_X+9,P2_Y);
				Flush();
				break;
			case 4:
				FillRect(P2_X-29,P2_Y-14,P2_X+29,P2_Y);
				Flush();
				break;
			case 5:
				FillRect(P2_X-10,P2_Y-40,P2_X+10,P2_Y);
				Flush();
				break;
			case 6:
				FillRect(P2_X-10,P1_Y-40,P2_X+10,P1_Y);
				Flush();
				break;
			}
			P2_Image=n;
			}
			else
			{
				FillRect(P2_Shoot_X-5,P2_Shoot_Y-4,P2_Shoot_X+5,P2_Shoot_Y+4);
				Flush();
			}
			 
			CopyImageDir(x,y,caracter[n],S_DIR_MIRROR);
			Flush();
		}
}

void Delay(int p,int t)
{
	if(p==1)
	{
		if(t==0)
		{
			P1_State=READY;
			Draw(P1_X,P1_Y,P1_Image,1);
		}
		else
		{
			P1_Delay=t;
			P1_State=BUSY;
			
		}
	}
	if(p==2)
	{
		if(t==0)
		{
			P2_State=READY;
			Draw(P2_X,P2_Y,P2_Image,2);
		}
		else
		{
			P2_Delay=t;
			P2_State=BUSY;
			
		}
	}
}
		
		
	