const SWAP_NOTEType Sound[] = {
	SWAP_NOTE_C4,    42,
	SWAP_NOTE_D4,    42,
	SWAP_NOTE_E4,    42,
	SWAP_NOTE_F4,    42,
	SWAP_NOTE_G4,    42,
	SWAP_NOTE_A4,    42,
	SWAP_NOTE_B4,    42,
	SWAP_NOTE_C5,    42,
	SWAP_NOTE_END,    0
};
