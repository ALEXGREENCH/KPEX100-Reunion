# Korean GVM forum recovery

Recovered on 2026-11-05. Original third-party files are preserved as data;
Reunion's source licence does not relicense them. Retain their original notices.

- GVM-Club/original: 13 exact captures, all CDX SHA-1 matches (451009 bytes).
  Three ALZ archives yield 12 CRC-verified members, including the original
  9354-byte SGS2 zola fighting game and its original Mobile C source.
- Naver/original: seven public GVM/developer archives. BomberMan is source,
  resources, Linux server and design documents, without a compiled SGS.
  NMTool1.1 contains MFC C++ sources. Three SGS demos are preserved; Hello
  and Image render in Reunion, Line is rejected by the current strict parser.
- Public-pages: source receipts, ten developer-page responses, bounded forum
  catalogues and YM-PD1 photographs. No new YM-PD1 executable was recovered.
- repo-update: documentation/evidence updates for the current Reunion source
  tree. Merge these into a complete checkout, preserving their relative paths.
  The ordinary catalogue stays at55 apps; no runtime/SGS was patched.

## Reproduce the zola offline replay

Use a complete, configured KPEX100-Reunion source tree with its original
Kingston2.12 ROM and Node dependencies (follow that repository's README).
To retain the bundled reference frames/reports, copy GVM-Club to a scratch
folder before replaying. From that copy, run:

    node replay-zola-start.mjs C:/path/to/KPEX100-Reunion 1 input
    node replay-zola-start.mjs C:/path/to/KPEX100-Reunion 1 ready

The explicit START data1 is S_GTYPE_ALONE in original SDK SScript.h.
The original source consumes swData as GameType. START0 remains at
Are You Ready?. 'ready' presses OK only; 'input' adds movement/attacks.
The128x128 research viewport is chosen from source coordinates, not a proven
phone model. Reports and raw RGBA frames are included alongside PNG previews.
No multiplayer, historical server, save, sound or full-game completion claim.
The source includes caracter.sbm, absent from the original four-file archive;
the original SGS already contains graphics. Recompilation was not attempted.

All outer originals and members retain exact bytes. SHA256SUMS covers every
included item except the sums file itself. The ZIP was checked after creation.
