# Bounded independent forum-pass review

All **188 checks pass**; no unresolved blocker remains. This review used
local saved sources only and did not change repository files. The previous
large firmware/device audits were not rerun.

## GVM Club captures and zola — 55 checks

All13 original attachments total451,009 bytes; their SHA-256, SHA-1 and
cached CDX digests agree. An independent ALZ parser verified all12 members
in three archives, including original framing, member lengths, complete raw
DEFLATE streams, CRC32, SHA-256 and the final archive markers.

The two PPT streams independently reproduce951/395 records and74/17 text
atoms; audio-mask/LCD exceptions and compression-spelling anchors agree.
Both original XLS matrices and selected model rows match:75 and108 rows,
including the literal2002.12.18 date. These are not unique new-phone counts.

The original zolaSGS independently parses as v2 with74 variables and13
resources, a blank title, and the declared9354-byte hash/section layout.
The source's GameType=swData and original SDK S_GTYPE_ALONE=1 corroborate
START data1. A copied portable harness was run in an independent directory
with an explicit repository path, for both input and ready-only control.
All original source/harness bytes remain identical. Both runs reproduce all
recorded frames, idle/no-error outcomes and12 equal-time comparisons,
including99/152/113 differing pixels. Original fight/control PNGs were viewed.
This does not establish multiplayer, sound, save or full gameplay completion.

## Live public Korean source archives — 31 checks

Seven GVM-relevant ZIPs and all160 member identities/CRCs agree. Cached
source articles explicitly allow logged-out public reading and attachment
downloads. BomberMan's57-entry source/resource archive has no named SGS.
NMTool contains source and an EXE; the EXE was not run and no open licence
is inferred from source availability. Three other WIPI packages remain
excluded from the GVM bundle.

Hello and Image originals match their archive members, parse correctly and
have clean recorded START renders; four PNGs were inspected for shape/data
and the text/cartoon images were viewed. Line's original section fields
70/134/70/70 trigger the current strict parser rejection. No guessed repair
or assertion of file corruption is justified.

## Public metadata, player photos and developer pages — 102 checks

The delegated independent review checked player source artifact/page hashes,
526 unique sanitized metadata entries and two actual player photos, plus
10 developer-page responses and the book/PCLancer leads. These sources do
not supply a new game or SDK installer binary. The player is YM-PD1; the
photos do not establish GNEX/XOV payloads.

One concrete bibliography error was found and resolved: actual YES24 HTML
gives ISBN13 **9788970504445**, ISBN10 **8970504443**. Root corrected the
final document/evidence and the derived findings; the raw HTML is unchanged.

`evidence.json` records final current byte/semantic hashes for all four source
JSONs and the main document. Full group reports retain the meaningful limits.
Office service-launch/icon documents are integrity-checked attachments,
not an exhaustively interpreted SDK. Ordinary catalogue count remains55.
