%{
// Header Section
#DEFINE SCRIPTVER		1				// script version
#DEFINE LCDCLASS		255
#DEFINE IMAGETYPE		255				// image type	( BW : 1, 4GRAY : 2 )
#DEFINE AUDIOTYPE		255				// buzzer:1
#DEFINE VOCTYPE			255
#DEFINE SCRIPTTYPE		1				// script type	( StandAlone )
#DEFINE SCRIPTCPID		100				// script cp id
#DEFINE SCRIPTID		75				// script id
#DEFINE SCRIPTNAME	    "Line"		// script name
%}

#include "sscript.h"
void main ()
{
	ClearWhite();

	SetColor(150);

	DrawLine(0,0, 100, 150);

	Flush();
}