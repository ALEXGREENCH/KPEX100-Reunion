# Live Korean forum recovery

Date: 2026-11-05. All work remains in this scratch folder. No Wayback requests, logged-in access, contact with owners, firmware repeats, or vendor executable execution.

## New original Sinjisoft network sample

Following the actual technical-download menu of [Jinimobile](https://cafe.naver.com/jinimobile) found [post22](https://cafe.naver.com/jinimobile/22), dated2004-07-16. It describes an upgraded GVM BomberMan network sample and credits GVM Club. The logged-out public response explicitly allows reading and attachment download.

- Exact file: `https://download.blog.naver.com/22b73e8d9bcfc61a37d9b288ba5a2550f8aa54b66d/data4/2004/7/16/104/2004_BomberMan3.zip`
- Local `attachments/jinimobile-22.zip`, **1,619,722B**, SHA256 **da6d2012d95d7abe38e1a097fd22989e8b260dfc9ad1b8decdb539ed30539346**. All57member ZIP CRCs pass.
- Two source branches, Flow Control and No Flow Control: original `BomberMan.mc`41484/40373bytes, headers, bitmap/IDF/SBM graphics, MA1 SSD audio, Linux C game/channel server, makefiles, database SQL sample, PPT/DOC/Visio design documentation.
- Client source explicitly names **SINJISOFT**, copyright2003, `SCRIPTVER1`, `SCRIPTTYPE3` (server), CP9670/script1035 and titleBomberMan. `NetReconnect` and other networking code are present. **No compiled SGS occurs in the archive.** It is a valuable original developer sample, not a newly playable standalone game. Source licence notices remain authoritative; no MIT/relicensing claim.

## GVM graphics demos, with original source and bytecode

The real GVM menu18 of [Mobileprograming](https://cafe.naver.com/mobileprograming) lists three additional public examples, all dated2004-09-13. Post33 was previously preserved and was not downloaded again.

| Post | Original attachment | SHA256 | Embedded SGS |
|---|---|---|---|
| [34](https://cafe.naver.com/mobileprograming/34) | Hello.zip4529B | 5154b779bda7b75394eb202de99b681d3c45a41914424ed069a1f2d65706a5f4 | Hello.sgs140B, SGS1 |
| [35](https://cafe.naver.com/mobileprograming/35) | Line.zip4486B | 3f2e3ae589b1d5b6e5a13b1480ff5f5d403501162cdb714c0b61325e24baf65b | line.sgs134B, SGS1 header |
| [36](https://cafe.naver.com/mobileprograming/36) | Image.zip20422B | 55e1cbfd46bd6b8f983251f75cdad1ddc9b45827cfff87143762ec12da5867f5 | Image.sgs5902B, SGS1 |

All ZIP CRCs pass, original C sources and SScript.h included. Byte-exact SGS hashes/headers are in `demo-sgs-bytes.json` and `evidence.json`. The unchanged CLI ran Hello and Image with an explicit128×160 test profile: both idle/error-null and visually confirmed text/bitmap. Screens and JSON in `demo-replays/`. The source does not bind these examples to a particular phone.

**Line is not declared runnable:** the original header has section offsets70,134,70,70. Current strict parser rejects it with `Invalid legacy SGS section layout`. It has no obvious resource strings, so a zero-resource compiler convention is a hypothesis only. Nothing was padded or patched.

## Original map editor source and release documents

- [Jinimobile18](https://cafe.naver.com/jinimobile/18),2004-07-16: **Neo Mobile Map Tool1.1**, original `NMTool.zip`1,960,991B, SHA256 **a2baf3b688c2c0c0ad587255c7f2bbccbb9c9b3d2473fe1840beb595540588c3**. Public post describes full source, sample village.nrj, tile attributes/events/mirroring and GVM C-source export. ZIP really contains MFC C++ project sources and samples, not just an executable. No build or execution attempted. Original source-available post is not an inferred permissive licence.
- [Jinimobile9](https://cafe.naver.com/jinimobile/9):2004-07-01 SKVM/GVM icon-production instructions, ZIP621745B SHA **cf7e42454f7bc3fb48feb99bc8f281304f8119c919a3f7013a75e7e5cd706ff0**, DOC2144768B.
- [Jinimobile8](https://cafe.naver.com/jinimobile/8):2004-07-01 SKT service-launch procedure, ZIP600511B SHA **905eecfdc646f2299f73c75aeb49b3709dcfbc23d474cf82fd5c43bba970e123**, original DOC2034176B and PPT46080B.

Exact attachment endpoints, ZIP member sizes/CRCs/SHA and CP949-decoded names are retained in `evidence.json`. These two office-document bodies were not fully interpreted in this bounded pass.

## Other genuine games, different executable format

EV-K100 board menu3 yielded three newly checked public game archives: [Magic School2](https://cafe.naver.com/evk100/2), [Hellsing](https://cafe.naver.com/evk100/3), [Com2uS Soccer2006](https://cafe.naver.com/evk100/6). They are **WIPI native/Clet packages**, not SGS, despite `.jar` container extensions and a copied Soccer review describing a different GNEX549KB version on CYON SV360.

All three contain native `client.bin*` with common Thumb loader bytes `04e0c046240204200100020001b51549`, original resource files and ADF descriptors. Hellsing adds two Java bridge classes referencing `org/kwis/msp/lcdui`. No `.sgs` member occurs. No game was run. Software-only metadata and hashes are in `other-game-formats.json` / `nested-native-members.json`; original archives remain scratch and are excluded from the proposed GVM bundle. Personal ADF transfer fields are not copied into the report.

## Actual traversal and bounded negatives

Four live cafe roots; actual menus and all relevant pagination: Mobileprograming18/33 (onepage each); Jinimobile5/8/10/12/13 (onepage each); Webmas92 (bothpages); EV-K1003 (onepage). Thus10list pages, not ten keyword-result snippets. Restricted/closed list entries were not read. Existing Jinimobile21 ImagePlus and Mobileprograming33 template were not redundantly downloaded. No new retail SGS was recovered in this pass.

`roots-receipts.json`, `lists-receipts.json`, `last-list-receipt.json`, `threads-receipts.json`, `attachment-receipts.json` preserve discovery/HTTP/body hashes. Public flags were `isReadable=true`, `isOpen=true`, `isEnableAttachFileDownload=true`, `isLogin=false` for every downloaded attachment. HTML source encoding is CP949; article/list API responses are UTF8.

## Newly recovered roster comparison

`roster-findings.md` and `new-rosters-raw.json` compare root's two newly recovered GVM Club XLS files against the existing November2002 PDF and October2003 operator XLS. Main findings: dated December2002 roster108model rows; planned **SV-120(SHX2F)/LG3511** maps to a later **SV9120** label, while later SV120 has another code; explicit GVM128×112 for SD100 alongside the earlier128×128 conflict; variant spellings X127SS/X137SS; several contradictory VM/geometry fields. Existing Cyber1000/D510, CyberVX1/D610V and i1000A/D400 aliases are not new discoveries. No manufactured firmware or new shipped-device count.
