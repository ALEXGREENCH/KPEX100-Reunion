# Two recovered GVM Club spreadsheets: comparison

The original bytes and archive source URLs are in parent `work/gvm-forum-attachments-newpass/receipts.json`; this pass performs a local read-only comparison. `new-rosters-raw.json` retains exact cell values and row numbers, without silently normalizing aliases or filling blank cells.

- `34-GVM_phone.xls`: Sheet3, 113×10, title GVM 탑재 단말기 현황, explicit date **2002.12.18** (J2); 108 model rows, 4–111. This is a stronger dated snapshot, not 108 new devices. Planned-release rows remain planned.
- `14-lead-14.bin`: BIFF XLS despite the downloaded extension, 80×10, title 단말기 사양별 가입자 및 이용자 현황; 75 model rows, 4–78. A80 explicitly attributes the data to a **2002 CP meeting**. The workbook does not itself prove March 2002. It includes subscriber/usage aggregate ratios and some unreleased rows, not a list of recovered firmware.

## New or useful distinctions

1. **LG SV-120(SHX2F)** in December C73 is explicitly **planned**, GVM2X, LCD120×160, GVM120×146, code LG3511. The previously recovered October2003 operator XLS maps **LG35** to **LG-SV9120(SHX2F)** (SKT row180). Its separately listed **LG-SV120(SHX2V)** uses **LG43** (row189). This is important historical naming divergence: do not merge the December planned label into the later SV120 hardware or count it as another confirmed shipped phone.
2. **LG SD-100(S415)** December E37/F37 explicitly gives physical128×128 / **GVM128×112**. November2002 PDF p58 says GVM128×128, while October2003 operator XLS row166 general-application area128×112. Preserve the conflict; this new source independently labels112 specifically as GVM, but does not prove all firmware revisions used it.
3. Stats sheet provides explicit variant spellings **SCH-X127SS** (E35), **SCH-X137SS** (E69), both D=1x/C=128×112. These spellings were not in the previous normalized model roster. The old operator table has neighboring base/operator variants; no byte dump or manufacturer alias proof was obtained for these suffixes. Count them as newly attested labels, not new hardware families.
4. **CYBER-VX2** stats C47/D47=128×128/**1x**, December **Cyber VX-2(D410V)** F15/H15=128×128/**2X**. Stats **CYBER-6000** D44=2x versus December cyber-6000 H19=1X. Stats **SCH-X150** D70=2x versus December X-150 H34=1X. These source disagreements must be retained; do not infer an actual upgrade chronology from an undated aggregate sheet.
5. Geometry inconsistencies: stats IM-2100 C51=120×80 versus December F5=128×80 (December physical120×96); stats IM-2400 C60=128×80 versus December F22=120×80 (December physical128×96). These look transposed, but no correction to source cells is justified. Stats MOTO226 C64=128×114 versus December Prime800(TP226) F29=120×144, another unresolved conflict.
6. December LG aliases **Cyber1000(D510)** row10, **Cyber VX-1(D610V)** row13, **i1000A(D400)** row16 are **already explicit in the November2002 PDF pp67,62,60** respectively. They add dates/codes, not newly discovered hardware. The Upgrade rows55–58 (LG25–LG28), TWC1030 and Motorola Race Track are also in earlier material.
7. December A113 explicitly says multiple EE codes distinguish carrier distribution/supply forms and A… EE codes designate017 models. Preserve the explanation instead of expanding each code into a guessed extra device.

No new firmware was downloaded; no new retail-device count is warranted from this comparison alone. Exact comparison baselines: `work/device-platform-next-pass/20021130-model-development-guide.pdf`, `gvm-2002-handset-profiles.json`, and `20031014-SKT-STI-handsets-raw.json`.
