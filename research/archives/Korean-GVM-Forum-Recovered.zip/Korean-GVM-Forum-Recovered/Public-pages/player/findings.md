# Live player-forum follow-up, 2026-11-05

No new SGS/XOV/game executable or firmware payload was recovered. Repository files were not changed. No Wayback/CDX requests, vendor-program execution, authentication, owner contacts, or private-gate bypass were used.

## Actual Korean board navigation

New live public roots identify two old Samsung discussion boards:

- https://cafe.naver.com/pmpnara — cafe10639115, menu51, 삼성; all four advertised list pages,181 article metadata rows.
- https://cafe.naver.com/gpsf — cafe10677925, menu379, 삼성; all seven advertised list pages,345 article metadata rows.

The two categories total526 unique rows within their respective cafes.61 are marked open; four have file attachments, but all four file-bearing articles are marked closed. None of the closed article bodies or attachments was requested. Public metadata is saved without writer identifiers in `sanitized-public-catalog.json`; raw public responses and SHA-256 receipts are also retained. This is a bounded category walk, not a claim to have searched every menu, private area, or Naver as a whole.

The only model-specific open question in these categories, https://cafe.naver.com/pmpnara/21695 (`YM-PD1 모델 질문 입니다.`), was read after checking its open flag. The article is publicly readable and has three comments about electronic-dictionary/AC3/other features; it has no game archive or download link. Related YM-PD1 topics on gpsf are closed and were left unread.

The previous147-topic Polish MPIO category pass was inspected locally and not repeated. New Naver searches for exact Korean model/game phrases mostly produced sales posts, unrelated material and the already-preserved YP-T8 review.

## New original-screen photographs: YM-PD1

Saved and visually inspected:

- Review: https://dpg.danawa.com/news/view?boardSeq=62&listSeq=1396809&past=Y
- Game photograph: https://img.danawa.com/cms/img/2007/03/23/pd40.jpg —530×148,146445B,SHA256 `a89b47516b55873147140a785ab7b947a81d92f510f47322958e2c6f3de82c9e`.
- File-browser photograph: https://img.danawa.com/cms/img/2007/03/23/pd42.jpg —300×169,91847B,SHA256 `558a37f3ab5d6f805c346af0612d57a54186a5ad71d4911127f83f28b081cae2`.

The left game title visibly reads **HEX TRIS2**. The right title reads **PIPE DREAM plus**, with **Enfun Entertainment** branding. The logo is specifically visible in the right-hand photograph; this alone does not attribute the left-hand game. The second photograph shows `YM-PD1 HDD` and `Game`, without filenames/extensions.

The reviewer also describes Windows CE5.0 and a promised public SDK; an independent PMPInside review preserved on https://www.enuri.com/knowcom/detail.jsp?kbno=103556 specifies test firmware `1.03 KR F8`. These are claims from contemporaneous first-hand product reviews, not a recovered firmware header or verified SDK release. Neither image nor matching game title proves GNEX/XEOVIA, SGS/XOV compatibility or binary identity with the T8 ports.

## Other routes and limits

- Actual current PMPInside root closed the connection without content. The original review's image routes remain useful archived-source leads but were not fetched through Wayback in this pass.
- An old linked Minivian BBS route returned404.
- DriverGrabber YM-PD1L HTML is a gated catalog: its sole download href is `/login/`, with a suspicious44B label. No login/download was attempted, and it is not counted as a recovered mirror.
- Web text access to ManyManuals revealed116- and131-page versions of the Samsung manual, but direct requests returned403 and stopped. No PDF bytes were recovered and no PDF rendering claims are made. Do not infer a new platform from this mirror.
- TellementNomade old Samsung history topic returned403 through the web tool and was not pursued.

`evidence.json` contains precise URLs, body lengths, hashes, observed flags and negative scope. `artifact-manifest.json` hashes all local files in this pass. New originals in this pass are HTML/JSON and two photographs; no new binary scanner was run.
