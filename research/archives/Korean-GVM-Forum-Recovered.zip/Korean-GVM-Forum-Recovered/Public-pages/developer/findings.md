# Live Korean community / publisher pass

Scope: public current Korean developer pages, category/tag navigation, preserved link indexes and publisher download lead. No Wayback, CDX, login, membership, contact or old executable execution. Repository unchanged. Previous GVM Club receipts, Korean community pass2, GNEX/Sinjisoft docs and SDK evidence were checked first; previously known emulator mirror, Daum GVM membership gate, Cenix Wayback topics and SDK installers were not downloaded again.

## New pages actually retrieved

Each raw response is saved as `<name>.bin`, a searchable text rendering as `<name>.txt`. The complete manifest records the exact source URL, final URL, HTTP status, byte count, SHA-256 and all public links. HTTP 200 by itself is not treated as valid content: the publisher response below is only a JavaScript front page.

| Source | Evidence | Payload status |
| --- | --- | --- |
| https://chamcham.tistory.com/9 | First-person portfolio: `[ 2004년 11월 ] GNEX를 사용한 핸드폰 용 알카노이드 게임`; posted 2007-12-04, describing the author's GNEX Arkanoid assignment and tools. | Page/image reference only. No `.sgs`, `.mc`, source archive or downloadable game linked in the article. This is not a recovered game. |
| https://chamcham.tistory.com/tag/GNEX | Followed the public GNEX tag from the portfolio; same project entry, no additional GNEX attachment. | Checked tag scope only; no whole-site exhaustiveness claim. |
| https://jichun.tistory.com/category/IT | Public IT list exposes two relevant 2006 GNEX entries; both opened below. | Category navigation, no source archive link found. |
| https://jichun.tistory.com/2 | First-person `GNEX프로그래밍....`, 2006-12-04, author studying Mobile C / Sinjisoft GNEX in an industry-linked school-company role. | Brief study note; no source or SDK attachment. |
| https://jichun.tistory.com/3 | `슈퍼지넥스~ 어디로갔나..??`, 2006-12-05. Author asks why an announced Super GNEX release had no corresponding GNEX Club discussion; reproduces a KMobile 2006-02-23 report. Original report URL: `http://www.kmobile.co.kr/k_mnews/news/news_view.asp?tableid=newtech&idx=65129`. | Contemporary announcement/reception evidence; no proof that the promised tool shipped. No installer or source attachment. |
| https://wanggi.tistory.com/3 | First-person `SKY U130 게임넣기`, 2007-12-30, reached via its public category. Shows WMRMake/BitPim workflow and `/wipi/sys/registry.dat`, `/wipi/sys/shared/wam/menu1.dat`, `/wipi/ctn` paths. | No game/tool attachment in this post. Its first SGS/SKVM sentence contradicts a later correction to choose GNEX for SGS; do not use the mistaken sentence as format evidence. Eternal Saga 2 is an example title, not a recovered payload or proof of SGS format. |

Main page receipts:

- `chamcham-arkanoid.bin`: 39,427 bytes, SHA-256 `635dcc47c8362d65f34b8cd652dec0f177dcd6aef62faf86a560d3b77d16ae72`.
- `jichun-study.bin`: 32,647 bytes, SHA-256 `77e92885f2b9322e9d12240a110cde6b6c6876ef330b65798a4a3984ef9caf66`.
- `jichun-supergnex.bin`: 38,370 bytes, SHA-256 `67a6f28516d0018b89607b5ed34cadd92d8c46cc4e8ddb41b9865b0d377e464f`.
- `wanggi-u130.bin`: 63,907 bytes, SHA-256 `de76f2d761bb3dcfce832f8d2d7c6bebe54a886fe36d70a1066ac49072d24a6c`.

## Publisher / book lead

The live catalogue at https://www.yes24.com/product/goods/1950963 describes **WIPI GNEX를 이용한 모바일 프로그래밍**, authors 강진영 and 정찬성, publisher 생능출판사, ISBN 9788970504445 / 8970504443. Its book description explicitly points to GNEX Club's 자료 다운로드 menu for source and executable examples. Chapter 15 is a Star Wars game example, chapter 16 Aiolos. This is a **catalogue lead**, not bytes of those examples and not evidence of identity with the already recovered SDK AioloS.

The YES24 record says 2006-01-05; one library catalogue shows 2005, so the exact edition/date should be checked against the book itself before using it as a provenance date.

`yes24-mobile-programming.bin`: 320,937 bytes, SHA-256 `c0a77b06a049c492f8e7da907ae52b433c2a3b1399ed748f7530b5b4bde9d03d`.

Publisher URL https://www.booksr.co.kr/ was established from public publisher listings and current book colophons. One direct request returned HTTP200 **764 bytes of JavaScript cookie setup, not the publisher catalogue**; saved `booksr-home.bin`, SHA-256 `22d82b5f6fc4c7333713cdef79a01bbc56314067d1c5e96b5173ab7d2b6d3d41`. Web reader likewise returned no readable content. Browser fallback was attempted through the computer-use API: Chrome and IAB both reported `Browser is not available`. No cookie was forged, no gate solved, and no publisher search/download page was reached. This remains an unresolved bounded lead.

## Old link-index lead, not followed

https://qhrb42.tistory.com/13686133 is a 2008 repost of a large public computer-tip link index. It preserves two separate GVM links:

- `http://www.pclancer.net/blog/pctip/pctip_1201604927337.asp` — GVM이란~!?
- `http://www.pclancer.net/blog/pctip/pctip_1201728384126.asp` — GVM의 특징 및 장점

The source index is 562,646 bytes, SHA-256 `1fcb4e2592029f033dd0db83b09ddaca690cf23d74f2136b9138e1c294123f2a`. These target URLs were not fetched during this bounded pass; they are likely explanatory articles by their titles, not established downloadable software. No exact attachment URI recovered here.

## Outcome

- 10 raw live HTTP responses preserved: 9 readable pages/category indexes and 1 publisher JavaScript stub.
- New standalone `.sgs`/`.mc`/`.h`/`.alz`/SDK attachments: **0**.
- Useful new preservation leads: named GNEX Arkanoid author project; book example distribution with Star Wars/Aiolos chapter identities; two exact old PCLancer article URLs.
- No assertion that a whole Korean forum, private cafe, archive domain or book publisher has been exhaustively searched.
