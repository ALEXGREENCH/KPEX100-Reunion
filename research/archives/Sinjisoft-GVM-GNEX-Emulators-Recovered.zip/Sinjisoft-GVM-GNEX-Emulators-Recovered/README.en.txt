Sinjisoft GVM / GNEX: recovered emulators and tools
=================================================

This preserves already recovered files. No Sinjisoft program was executed.
Current Windows, Wine, and real-phone usability have not been tested.

Contents
--------
original-installers/ contains unchanged GNEX SDK 2.10 and 2.12 installers.
They preserve the full distributions and all original companions, including
their embedded SDK examples. No additional retail SGS collection or phone
memory dumps are included in this package.

SDK-2.10/ and SDK-2.12/ contain a curated extraction: Emulator.exe,
EmulController.exe, GNEXIDE.exe, Mobile C / MASM tools, DLLs, INIs, all
device skins and four manuals. Names and relative paths follow the MSI tables,
including restored names such as cygintl-2.dll instead of the CAB file ID.
The original vsflex8l.ocx is under SDK-*/system-companions; it was not installed
or registered as a system component.

SDK-*/source-fragments/ preserves 43 extensionless text fragments by their
original CAB File IDs. SScript.h and interface headers are also in SDK Include.
These are not represented as a complete buildable emulator source release.
Files or sources named M16VM or M32VM were not found in the inspected SDKs.
MASM.exe is an assembler and mcc.exe is a compiler, not separate emulators.

GVM2X-2.0.6.40328-modified/ contains the separately recovered Windows x86
GVM2X Emulator mirror. Its original attachment name,
2x_Cr256_Magic_expired_remove.exe, indicates modification. It is not labelled
an untouched official release. The version comes from its PE resources;
the stable source is the public Tistory article recorded in provenance.json.

Both GNEX Emulator.exe files report PE FileVersion 3.7.0.7122 but have
different SHA-256 values. SDK version and PE file version are distinct.
These programs host the Mobile C/GVM/GNEX virtual machine with device profiles.
A profile or skin does not establish full phone CPU, modem, or firmware emulation.
Original distribution INIs, including demonstration identity values, are
unchanged. No new personal profiles, saves, credentials or forum raw responses
are included. Windows system DLLs are not supplied; import inventory alone
does not guarantee complete dynamic dependencies or portable execution.

Verification and static reproduction
-----------------------------------
Use Python 3.11+ to verify every file except manifest.json itself:

  python tools/verify-bundle.py .

Use Python 3.11+ and installed 7-Zip to reproduce the curated extraction from
the bundled original installers. The EXE overlay, MSI and CAB are read as data;
the vendor installer and MSI CustomActions are never executed:

  python tools/restore-sdk.py 2.12 restored-2.12 --seven-zip "C:/Program Files/7-Zip/7z.exe"
  python tools/restore-sdk.py 2.10 restored-2.10 --seven-zip "C:/Program Files/7-Zip/7z.exe"

Output directories must be new or empty. sdk-member-map.json specifies
selection, paths, sizes and SHA-256 values. Restored files must match their
SDK subtree and source/system companions as recorded in that map.

manifest.json records file hashes. provenance.json records stable source URLs,
PE versions, imports and evidence limits. Expiring signed download links and
mirror authors' personal details are not retained.

Rights
------
Original programs, skins, headers and manuals retain their owners' rights;
they are not relicensed under Reunion MIT. New preservation scripts are
covered by LICENSE-Reunion-MIT.txt. sdk-static.py independently implements
the container layout documented by the ISx project.
