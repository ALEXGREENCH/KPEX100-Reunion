/*======================================================================

	System Library Functions

======================================================================*/

void GetHwConfig(int hwconfig[]);
void GetSysMin(string * pStr);
void GetSysMdn(string * pStr);

int GetSysUserID(string str);


void GetLocInfo(int info[]);

void GetDate(int a[]);

void GetTime(int a[]);


int SendSMS(int TI, string dial, string text);


void BackToBrowser(string url);


int RegMusicBell(string name, sound m);


int RegScreen(string name);


void VoiceCall(string dial, int ret);


void Exit();


int GetVMInfo(void);


void GetLcdInfo(int info[]);


int GetSysInfo(string keyword, string info);

void SetSoMo(int so, int mo);


void LockChatMode(int sw);

void SetChatMode(int sw);


void SetSystemOperation(int nCommand, int nOption, int *pData);


int GetKeyState();


/*======================================================================

	Graphic Library Functions

======================================================================*/

void GetClip(int pos[]);
int GetGamma(void);
int GetActiveBuffer(void);
int GetColor(void);
int GetPixel(int x, int y);
void GetDDB(image buf, int x, int y, int w, int h, int trFlag, int trColor);
int GetPaletteColor(image m, int ind);
int GetPaletteColorRGB(image m, int ind, int rgb[]);
int GetImageAlpha(void);
int GetImageZoom(void);
int GetImageMirror(void);
int GetImageRotate(void);
void GetFontColor(int color[]);
int GetFont(void);
int GetFontAlign(void);
int GetFontStyle(void);
int GetFontWidth(void);
int GetFontHeight(void);
int GetStrWidth(string str);
void SetClip(int x1, int y1, int x2, int y2);
void ResetClip(void);
void SetActiveBuffer(int num);
void SetGamma(int gamma);
void SetColor(int c);
void SetColorRGB(int r, int g, int b);
void SetFontType(int fsize, int c1, int c2, int align);
void SetFont(int fsize);
void SetFontColor(int c1, int c2);
void SetFontAlign(int align);
void SetFontStyle(int sty);
void SetPalette(int pal[], int pallist[]);
int SetPaletteColor(image img, int ind, int mpi);
int SetPaletteColorRGB (image img, int ind, int r, int g, int b);
void SetImageAlpha (int alpha);
void SetImageZoom(int zoom);
void SetImageMirror(int mir);
void SetImageRotate(int rot);
void SetShadeColor(int c1, int c2);
void SetShadeColorRGB (int r1, int g1, int b1, int r2, int g2, int b2);
void Clear(int c);
void ClearPartial(int sx, int sy, int ex, int ey, int mpi);
void ClearRGB(int r , int g , int b);
void ClearPartialRGB (int sx, int sy, int ex, int ey, int r, int g, int b);
void ClearWhite(void);
void ClearBlack(void);
void PutPixel(int x, int y, int c);
void PutPixelDev(int x, int y, int c);
void PutPixelRGB(int x, int y, int r, int g, int b);
int RGBToIndex(int r, int g, int b);
int RGBToDev(int r, int g, int b);
void PutDDB(int x, int y, image buf);
void DrawLine(int x1, int y1, int x2, int y2);
void DrawHLine(int x1, int x2, int y);
void DrawVLine(int x, int y1, int y2);
void DrawRect(int x1, int y1, int x2, int y2);
void FillRect(int x1, int y1, int x2, int y2);
void FillRectEx(int x1, int y1, int x2, int y2, int alpha);
void ShadeRect(int x1, int y1, int x2, int y2, int dir, int wave);
void DrawRectRound(int x1, int y1, int x2, int y2, int r);
void FillRectRound(int x1, int y1, int x2, int y2, int r);
void InvertRect(int x1, int y1, int x2, int y2);
void DrawEllipse(int x, int y, int rx, int ry);
void FillEllipse(int cx, int cy, int rx, int ry);
void ShadeEllipse(int x1, int y1, int x2, int y2, int dir, int wave);
void DrawPoly(int x[], int y[], int edge_count);
void FillPoly(int x[], int y[], int edge_count);
void SaveLCD(void);
void RestoreLCD(void);
void CopyLCD(int copyDir);
void ScrollLCD(int lcd , int dx, int dy, int wrap);
void DrawStr(int x, int y, string str);
void DrawStrSolid(int x, int y, string str);
void DrawText(int x, int y, string str);
void DrawTextSolid(int x, int y, string str);
void DrawStr2(int x, int y, string str, int mode);
void DrawStrSolid2(int x, int y, string str, int mode);
void DrawStrEx(int x, int y, string str, int s, int f, int fc, int bc, int a, int style);
int InitSIS(media sis, media sis_buf, int info[]);
int GetSISFrame(media sis, media image, int n_frame);
void CopyImage(int x, int y, image img);
void CopyImageDir(int x, int y, image img, int dir);
void CopyImagePal(int x, int y, image img, int pal[]);
void CopyImageDirPal(int x, int y, image img, int dir, int pal[]);
void CopyImageEx(int x, int y, image img, int alpha, int zoom, int mir, int rot);
void CopyImagePalEx(int x, int y, image img, int pal[], int alpha, int zoom, int mir, int rot);
void CopyImageTile(image img, int x1, int y1, int x2, int y2, int alpha, int zoom, int mir, int rot);
void StretchCopyImage(int sx, int sy, int ex, int ey , image img);
void StretchCopyImagePal(int sx, int sy, int ex, int ey, image img, int p[]);
void StretchCopyImageDir(int sx, int sy, int ex, int ey, image img,int dir);
void StretchCopyImageDirPal(int sx, int sy, int ex, int ey, image img, int dir, int p[]);
void StretchCopyImageEx(int sx, int sy, int ex, int ey, image img, int alpha, int mir, int rot);
void StretchCopyImagePalEx(int sx, int sy, int ex, int ey, image img, int alpha, int mir, int rot, int p[]);
void StretchCopyImageHS(int x, int y, int w, int h, image img);
void StretchCopyImageHSPal(int x, int y, int w, int h, image img, int p[]);
void StretchCopyImageHSDir(int x, int y, int w, int h, image img, int dir);
void StretchCopyImageHSDirPal(int x, int y, int w, int h, image img, int dir, int p[]);
void StretchCopyImageHSEx(int x, int y, int w, int h, image img, int alpha, int mir, int rot);
void StretchCopyImageHSPalEx(int x, int y, int w, int h, image img, int alpha, int mir, int rot, int p[]);
int GetImage(int nType, media SrcImage, media DstImage, int pInfo[]);
int GetNextImage(int imgHandle, media DstImage);
int ReleaseImage(int imgHandle);
int GNEX_LoadImage(media DstImage, media SrcImage);
int GNEX_ReleaseImage(media img);
void GNEX_CopyImage2(int x, int y, image img);
void GetPartialImage(image src, image dst, int xStart, int yStart, int xEnd, int yEnd);
void FreePartialImage(image dst);
int DecodeImage(image dst_VDI, image src_nonVDI);
void Flush(void);
void FlushPartial(int sx, int sy, int ex, int ey);

/*======================================================================

	File System Library Functions

======================================================================*/

extern	char *am_MkRelativeToAbsolutePath(char *RelPath);
extern	void am_GetUserNV(int index, BYTE *buf, int size);
extern	void am_PutUserNV(int index, BYTE *buf, int size);


int FileGetFreeSpace(void);
int FileGetInfo(string name, int fi[]);
int FileOpen(string name, int mode);
int FileClose(int hdl);
int FileDel(string name);
int FileSeek(int hdl, int offset, int org);
int FileWriteInt(int hdl, int *p, int intSize);
int FileWriteMedia(int hdl, media m, int pos, int byteSize);
int FileReadInt(int hdl, int *p, int intSize);
int FileReadMedia(int hdl, media m, int pos, int byteSize);
int FileTest(string name);
int DirTest(string name);
int FileMakeDir (string name);
int FileRemoveDir (string name);


/*======================================================================

	Network Library Functions

======================================================================*/
int SockOpen(int t);
int SockClose(int h);
int SockConnect(int h, string ip, int port);
int SockSendInt(int h, int *p, int intSize);
int SockSendMedia(int h, media m, int pos, int byteSize);
int SockSendToInt(int h, int *p, int intSize, string ip, int port);
int SockSendToMedia(int h, media m, int pos, int byteSize, string ip, int port);
int SockRecvInt(int h, int *p, int intSize);
int SockRecvMedia(int h, media m, int pos, int byteSize);
int SockRecvFromInt (int h, int *p, int intSize, string ip, int port);
int SockRecvFromMedia (int h, media m, int pos, int byteSize, string ip, int port);


// GNEX_HTTP

int GNEX_HttpOpen(void);
void GNEX_HttpClose(int h);
int GNEX_HttpConnect(int h, string url); // h_sock HttpConnect(char *url)
int GNEX_HttpDisconnect(int h); // h_sock HttpDisconnect(h_sock id)
int GNEX_HttpGetBodyDataLen(int h);
int GNEX_HttpGetReadBodyData(int h, int bufIndex, int size);


/*======================================================================

	Handset Control Library Functions

======================================================================*/

void PlaySound(sound m);
void StopSound(void);
void PauseSound(void);
void ResumeSound(void);
void PlaySoundEx(int channel, sound m);
void StopSoundEx(int channel);
void PauseSoundEx(int channel);
void ResumeSoundEx(int channel);
int GetVolume(void);
void SetVolume(int level);
void SetVolumeEx(int channel, int level);
int GetVolumeEx(int channel);
void PlayVocoder(voc m);
void StopVocoder(void);
void PlayAdvAudio(sound m);
void RegAdvAudio(string nm, sound m);
void ManAdvAudio(int cmd);
void StartVib(int t);
void StopVib(void);
int GNEX_Vibrator(int level, int timeout);
void SetKeyTone(int sw);
void SetBackLight(int sw);
void SetBackLightEx(int id, int flag, int color);
void GetUserNV(int buf[], int intSize);
void PutUserNV(int buf[], int intSize);
void SetTimer0(int t, int flag);
void SetTimer1(int t, int flag);
void SetTimer2(int t, int flag);
void ResetTimer0();
void ResetTimer1();
void ResetTimer2();
int GetTick (int id);
void ResetTick (int id);
int GetVirtualKeyCode(int nKeyCode);
int GetKeyCode(int nVirtualKeyCode);

/*======================================================================

	String Library Functions

======================================================================*/


int GetMediaSize (int index);
int SetMediaSize(string *s, int size);
void StrInit(string * s, int len);
int StrLen(string s);
void StrCpy(string *s1, string s2);


void StrSub(string *s1, string s2, int start, int len);
void StrCat(string *s1, string s2);
int StrCmp(string s1, string s2);
int GetChar(string s, int ind);
void PutChar(string s, int ind, int ch);
int	 AsciiToInt(string s);
void IntToAscii(string *s, int a);
void PutByte(int a[], int ind, int ch);
int GetByte(int a[], int ind);
void PutBytes(int a[], int ind, string str, int size);	// media -> int
void GetBytes(int a[], int ind, string *str, int size);	// int -> media
void MakeStrStr(string *s, string format, string src);
void MakeStr1(string *s, string format, int a);
void MakeStr2(string *s, string format, int a, int b);
void MakeStr3(string *s, string format, int a, int b, int c);
void MakeStr4(string *s, string format, int a, int b, int c, int d);
void MakeStr5(string *s, string format, int a, int b, int c, int d, int e);
// edited by sonbug, 2008.10.09
int ShowStrEdit2(string title, string *str, int type, int x, int y, int maxlen, int option);
void StrInput(string title, string *str);
// edited by sonbug, 2008.10.09
void StrInput2(string title, string *str, int maxlen, int type);
int ShowStrEdit(string *str, int type, int x, int y, int maxlen, int option);
int ShowStrEdit2(string title, string *str, int type, int x, int y, int maxlen, int option);
void SetStrEditStyle(int frame, int fcr, int bcr, int width, int height, int multiline, int helpline);
int SetStrEdit(string str, int curPos);
int GetStrEdit(string* pStr, int* curPos);
void EndStrEdit();

/*======================================================================

	Memory Library Functions

======================================================================*/

int GetFreeMemory ();
void PutWord(int *ptr, int ind, int value);
int GetWord(int *ptr, int ind);
void PutWordMedia(media m, int ind, int value);
int GetWordMedia(media m, int ind);
void PutWords(int *ptr, int ind, media m, int wordSize);
void GetWords(int *ptr, int ind, media m, int wordSize);
void MemCpyInt(int *dst, int *src, int intSize);
void MemCpyMedia(media dst, int i1, media src, int i2, int byteSize);
void MemCpyIntToMedia(media m, int ind, int *ptr, int intSize);
void MemCpyMediaToInt(int *ptr, media m, int ind, int byteSize);
void CopyWordMediaToMedia(media dst, int di, media src, int si, int wordSize);
void CopyWordIntToMedia(media dst, int di, int *src, int si, int wordSize);
void CopyWordMediaToInt(int *dst, int di, media src, int si, int wordSize);
void MemSetInt(int *ptr, int c, int len);
void MemSetMedia(media m, int pos, int c, int byteSize);
int *MallocInt(int size);
int FreeInt(int* address);
void PutIntToLcd(int lcdOffset, int *ptr, int wordIndex);

/*======================================================================

	Mathematics Library Functions

======================================================================*/

void RandSeed(int seed);
int  Rand(int min, int max);
int  RandRatio(int a);
int  Abs(int a);
int  Sgn(int a);
int  Sin100(int angle);
int  Cos100(int angle);
int  Tan100(int angle);
int  ArcSin100(int arc);
int  ArcCos100(int arc);
int  ArcTan100(int arc);
unsigned int  Sqrt(unsigned int n);
int  Avr(int a, int b);
int  Avr3(int a, int b, int c);
int  Max(int v1, int v2);
int  Max3(int v1, int v2, int v3);
int  Min(int v1, int v2);
int  Min3(int v1, int v2, int v3);
int  FindMax(int a[], int size);
int  FindMin(int a[], int size);
int  FindNear(int a[], int size, int key);
/*
static void s_A2VSet(int *a, int v, int size);
static void s_A2VAdd(int *a, int v, int size);
static void s_A2VSub(int *a, int v, int size);
static void s_A2VMult(int *a, int v, int size);
static void s_A2VDiv(int *a, int v, int size);
static void s_A2VMod(int *a, int v, int size);
static void s_A2VAnd(int *a, int v, int size);
static void s_A2VOr(int *a, int v, int size);
static void s_A2VNot(int *a, int v, int size);
static void s_A2VXor(int *a, int v, int size);
static void s_A2VRShift(int *a, int v, int size);
static void s_A2VLShift(int *a, int v, int size);
static void (*s_A2VOp[])(int *a, int v, int size) =
{
	s_A2VSet,
	s_A2VAdd,
	s_A2VSub,
	s_A2VMult,
	s_A2VDiv,
	s_A2VMod,
	s_A2VAnd,
	s_A2VOr,
	s_A2VNot,
	s_A2VXor,
	s_A2VRShift,
	s_A2VLShift
};
*/
void ArrayToVar(int a[], int v, int size, int op);

/*
static void s_A2ASet(int *a, int *b, int size);
static void s_A2AAdd(int *a, int *b, int size);
static void s_A2ASub(int *a, int *b, int size);
static void s_A2AMult(int *a, int *b, int size);
static void s_A2ADiv(int *a, int *b, int size);
static void s_A2AMod(int *a, int *b, int size);
static void s_A2AAnd(int *a, int *b, int size);
static void s_A2AOr(int *a, int *b, int size);
static void s_A2ANot(int *a, int *b, int size);
static void s_A2AXor(int *a, int *b, int size);
static void s_A2ARShift(int *a, int *b, int size);
static void s_A2ALShift(int *a, int *b, int size);
static void (*s_A2AOp[])(int *a, int *b, int size) =
{
	s_A2ASet,
	s_A2AAdd,
	s_A2ASub,
	s_A2AMult,
	s_A2ADiv,
	s_A2AMod,
	s_A2AAnd,
	s_A2AOr,
	s_A2ANot,
	s_A2AXor,
	s_A2ARShift,
	s_A2ALShift
};
*/
void ArrayToArray(int a[], int b[], int size, int op);

/*
static void s_A2A2Set(int *a, int *b, int *c, int size);
static void s_A2A2Add(int *a, int *b, int *c, int size);
static void s_A2A2Sub(int *a, int *b, int *c, int size);
static void s_A2A2Mult(int *a, int *b, int *c, int size);
static void s_A2A2Div(int *a, int *b, int *c, int size);
static void s_A2A2Mod(int *a, int *b, int *c, int size);
static void s_A2A2And(int *a, int *b, int *c, int size);
static void s_A2A2Or(int *a, int *b, int *c, int size);
static void s_A2A2Not(int *a, int *b, int *c, int size);
static void s_A2A2Xor(int *a, int *b, int *c, int size);
static void s_A2A2RShift(int *a, int *b, int *c, int size);
static void s_A2A2LShift(int *a, int *b, int *c, int size);
static void (*s_A2A2Op[])(int *a, int *b, int *c, int size) = 
{
	s_A2A2Set,
	s_A2A2Add,
	s_A2A2Sub,
	s_A2A2Mult,
	s_A2A2Div,
	s_A2A2Mod,
	s_A2A2And,
	s_A2A2Or,
	s_A2A2Not,
	s_A2A2Xor,
	s_A2A2RShift,
	s_A2A2LShift
};
*/

void ArrayToArray2(int a[], int b[], int c[], int size, int op);

int  HitCheck(int v1, int v2, int d);

/*======================================================================

	2X Compatibility Library Functions

======================================================================*/

void NetReconnect(string ip, int port);
void NetSend(int buf[], int size);
int  LoadMedia(media m, int key);
int  LoadMediaResult(media m);
void RsCom(int com, int buf[], int size);
void RsSend(int buf[], int size);
void Download(int cpid, int gid, string dlsip, int dlsport, string svrip, int svrport);
void Download2(int cpid, int gid, string dlsip, int dlsport, string svrip, int svrport);
int  NetState();
void NetConnect(string IP, int Port);
void NetDisconnect();
void PtpCall(string dial);
void PtpCallMmi();
void PtpWait();
void PtpRelease();
void OemApi(int carrier, int code, int param1, int param2, int param3, int param4);
int ExtQueryFeature(int svcCode);
int ExtApiType7(int svcCode, int methodCode, media media_or_URL, int pos[ ], int size[ ], int clear, int reserved);


