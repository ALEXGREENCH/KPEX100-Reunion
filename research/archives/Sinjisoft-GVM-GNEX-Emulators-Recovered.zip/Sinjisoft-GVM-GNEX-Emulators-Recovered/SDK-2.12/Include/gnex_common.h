/*======================================================================

	WIPIGNEX.h

======================================================================*/

#define	MAX_STRING			256

//typedef char *media;
//typedef char *image;
//typedef char *sound;
//typedef char *voc;
typedef int media;
typedef int image;
typedef int sound;
typedef int voc;
//typedef char string[MAX_STRING];
typedef int string;

/*
#define	SWAP_KEY_NONE		0x00
#define	SWAP_KEY_1			0x01
#define	SWAP_KEY_2			0x02
#define	SWAP_KEY_3			0x03
#define	SWAP_KEY_4			0x04
#define	SWAP_KEY_5			0x05
#define	SWAP_KEY_6			0x06
#define	SWAP_KEY_7			0x07
#define	SWAP_KEY_8			0x08
#define	SWAP_KEY_9			0x09
#define	SWAP_KEY_0			0x0A
#define	SWAP_KEY_STAR		0x0B
#define	SWAP_KEY_SHARP		0x0C
#define	SWAP_KEY_CLR		0x0D
#define	SWAP_KEY_SND		0x0E
//#define SWAP_KEY_END		0X0F
#define	SWAP_KEY_LEFT		0x10
#define	SWAP_KEY_RIGHT		0x11
#define	SWAP_KEY_UP			0x12
#define	SWAP_KEY_DOWN		0x13
#define	SWAP_KEY_OK			0x14

#define	SWAP_KEY_1_L		0x81
#define	SWAP_KEY_2_L		0x82
#define	SWAP_KEY_3_L		0x83
#define	SWAP_KEY_4_L		0x84
#define	SWAP_KEY_5_L		0x85
#define	SWAP_KEY_6_L		0x86
#define	SWAP_KEY_7_L		0x87
#define	SWAP_KEY_8_L		0x88
#define	SWAP_KEY_9_L		0x89
#define	SWAP_KEY_0_L		0x8A
*/

#define S_WHITE				0x00
#define	S_LGRAY				0x01
#define	S_DGRAY				0x02
#define S_BLACK				0x03
#define S_TRANSPARENT		0x04

#define	S_FONT_SMALL		0	
#define	S_FONT_MEDIUM		1	
#define	S_FONT_LARGE		2	
#define	S_FONT_DOUBLE		3	

#define	S_ALIGN_LEFT		0	
#define	S_ALIGN_CENTER		1	
#define	S_ALIGN_RIGHT		2	

#define	SWAP_ECPT_STOP_OP				0
#define	SWAP_ECPT_DIV_ZERO				1
#define	SWAP_ECPT_MOD_ZERO				2
#define	SWAP_ECPT_SYM_OVER				3
#define	SWAP_ECPT_MDA_OVER				4
#define	SWAP_ECPT_STACK_OVER			5
#define	SWAP_ECPT_PCSTACK_OVER			6
#define	SWAP_ECPT_INVALID_OP			7
#define	SWAP_ECPT_INVALID_SYM_INDEX		8
#define	SWAP_ECPT_INVALID_MDA_INDEX		9
#define	SWAP_ECPT_INVALID_SYM_ADDR		10
#define	SWAP_ECPT_INVALID_MDA_ADDR		11
#define	SWAP_ECPT_OUT_OF_DIM			12

// Mobile C global variable

extern	int	swData;
extern	int	swData2;
extern	int	swData3;
extern	int	swData4;
extern	int	swVersion;

extern	int	swWidth;
extern	int	swHeight;

extern	int	swFrame;
extern	int	swFrame2;
extern	int	swFrame3;
extern	int	swFrame6;

extern	int swVMver[3];
//extern	char swModel[32];
extern	int swSmsRcvBuf[80];
extern	int swRsRcvBuf[1200];
extern	int swRcvBuf[1200];

extern	int swReserved1;
extern	int swReserved2;
extern	int swReserved3;
extern	int swReserved4;

#define	SetStrType(fsize, c1, c2, align)	SetFontType(fsize, c1, c2, align)
#define	SetStrFont(font)					SetFont(font)
#define	SetStrAlign(align)					SetFontAlign(align)
#define	SetStrColor(color1, color2)					SetFontColor(color1, color2)

// Mobile C functions: Event

void EVENT_START();
void EVENT_END();
void EVENT_TIMEOUT();
void EVENT_KEYPRESS();
void EVENT_RECEIVE();
void EVENT_RESULT();
void EVENT_RSEVENT();
void EVENT_RSRECEIVE();
void EVENT_GENERAL(); 

/*======================================================================

	mmi.h

======================================================================*/
#ifndef _MMI_H_
#define _MMI_H_

/*---------------------------------------------------------------------------

  GNEX build target platform setting

---------------------------------------------------------------------------*/
#define TEST_MODE

#define	GNEX_TARGET_EMULATOR		0x01
#define	GNEX_TARGET_STB				0x02

//#define	GNEX_TARGET			GNEX_TARGET_EMULATOR

/*---------------------------------------------------------------------------

  GNEX target carrier setting

---------------------------------------------------------------------------*/
#define GNEX_CARRIER_SKT			0x0001		// �ѱ� SK Telecom
#define GNEX_CARRIER			GNEX_CARRIER_SKT


/*---------------------------------------------------------------------------

  GNEX target language setting

---------------------------------------------------------------------------*/
#define	GNEX_LANG_ASCII				0x0001
#define	GNEX_LANG_KSC5601			0x0002	// Korean
#define	GNEX_LANG_SHIFTJIS			0x0004	// Japanese
#define	GNEX_LANG_HEBREW			0x0008
#define GNEX_LANG_BIG5				0x0010	// Traditional Chinese
#define GNEX_LANG_GB2312			0x0020	// Simplified Chinses

#define GNEX_LANG			GNEX_LANG_ASCII | GNEX_LANG_KSC5601

/*---------------------------------------------------------------------------

  GNEX carrier type�� ���� feature����

---------------------------------------------------------------------------*/
#if (GNEX_CARRIER == GNEX_CARRIER_SKT)

	#define GNEX_FEATURE_NETWORK
//	#define GNEX_FEATURE_DOWNLOAD
	#define	GNEX_FEATURE_OGL

	#define GNEX_FEATURE_EMBEDDED_OGL
	#define GNEX_FEATURE_S3D

#endif

/*---------------------------------------------------------------------------

  GNEX Information setting

---------------------------------------------------------------------------*/
#define GNEX_CARRIER_TYPE		GNEX_CARRIER
#define	GNEX_HANDSET_NAME		"GNEX EMUL"

// BUILD NUMBER		:	YYMMDDBB	(YY : Year, MM : Month, DD : Day, BB : Build Count)
#define GNEX_BUILDNUMBER		0x04032801

#define GNEX_LCD_WIDTH			320
#define GNEX_LCD_HEIGHT			240

//==============================================================
//	Number of SSB
//  Number of Embedded Contents
#define	GNEX_SSB_SIZE					4      

/*---------------------------------------------------------------------------

  GNEX LCD driver�� ���� ������

---------------------------------------------------------------------------*/
#define	GNEX_LCD_BW_HORIZ_MF				0x01
#define	GNEX_LCD_BW_HORIZ_LF				0x02
#define	GNEX_LCD_BW_VERT_MF					0x03
#define	GNEX_LCD_BW_VERT_LF					0x04
#define	GNEX_LCD_BW_VERT_VERT_LF			0x05  //12.19
#define GNEX_LCD_BW_END						0x0F

#define	GNEX_LCD_GRAY_VERT_MF				0x11
#define	GNEX_LCD_GRAY_VERT_LF				0x12 //12.19

#define	GNEX_LCD_GRAY_HORIZ_MF				0x13
#define	GNEX_LCD_GRAY_HORIZ_LF				0x14
#define	GNEX_LCD_GRAY_MP_HORIZ_MF			0x15
#define	GNEX_LCD_GRAY_MP_HORIZ_LF			0x16
#define	GNEX_LCD_GRAY_MP_VERT_MF			0x17
#define	GNEX_LCD_GRAY_MP_VERT_LF			0x18
#define	GNEX_LCD_GRAY_VM_HORIZ_MF			0x19
#define	GNEX_LCD_GRAY_VM_HORIZ_LF			0x1A
#define	GNEX_LCD_GRAY_HW_HORIZ_LF			0x1B
#define	GNEX_LCD_GRAY_VERT_LF2				0x1C //MPEON 11_29
#define	GNEX_LCD_GRAY_VERT_LF3				0x1D //MPEON 11_29
#define GNEX_LCD_GRAY_END					0x1F

#define GNEX_LCD_COLOR16_HORIZ_MF			0x21
#define GNEX_LCD_COLOR16_HORIZ_LF			0x22
#define GNEX_LCD_COLOR256_HORIZ				0x23
#define GNEX_LCD_COLOR_END					0x2F

#define GNEX_LCD_COLOR4K_HORIZ				0x30
#define GNEX_LCD_WORDCOLOR_START			0x31
#define GNEX_LCD_COLOR4K_HORIZ_WORD			0x32
#define	GNEX_LCD_COLOR4K_HORIZ_WORD_LEFT	0x33
#define GNEX_LCD_COLOR64K_HORIZ_MF			0x34
#define GNEX_LCD_COLOR64K_HORIZ_LF			0x35

#define GNEX_LCD_3BYTECOLOR_START			0x36
#define GNEX_LCD_COLOR256K_HORIZ_MF			0x37
#define GNEX_LCD_TCCOLOR_END				0x3F

#define	GNEX_LCD_TYPE		GNEX_LCD_COLOR64K_HORIZ_MF

/*---------------------------------------------------------------------------

  GNEX LCD type�� ���� ������

---------------------------------------------------------------------------*/
#if	(GNEX_LCD_TYPE < GNEX_LCD_BW_END)
 #define	GNEX_COLOR_TYPE				0x01
#elif (GNEX_LCD_TYPE < GNEX_LCD_GRAY_END)
 #define	GNEX_COLOR_TYPE				0x02
#elif (GNEX_LCD_TYPE < GNEX_LCD_COLOR_END)
 #define	GNEX_COLOR_TYPE				0x04
#elif (GNEX_LCD_TYPE < GNEX_LCD_TCCOLOR_END)
 #define	GNEX_COLOR_TYPE				0x08
#endif

/*---------------------------------------------------------------------------

  GNEX audio device setting

---------------------------------------------------------------------------*/
#define	GNEX_AUDIO_NONE					0x00
#define	GNEX_AUDIO_BUZZER				0x01
#define	GNEX_AUDIO_MA1					0x02
#define	GNEX_AUDIO_MA2					0x04
#define	GNEX_AUDIO_CMX					0x08
#define	GNEX_AUDIO_MIDI					0x10
#define GNEX_AUDIO_MA3					0x20
#define GNEX_AUDIO_MA5					0x40
#define GNEX_AUDIO_WAV					0x80
#define GNEX_AUDIO_MP3					0x100

#define	GNEX_AUDIO_TYPE		GNEX_AUDIO_WAV

#endif	//	_MMI_H_

/*======================================================================

	GNEXCOMDEF.h

======================================================================*/
#ifndef _GNEXCOMDEF_H_
#define _GNEXCOMDEF_H_

//#include "../Output/ContentInfo.h"
#include "cogp_common.h"
#include "cogp_api.h"


#define GK_FONT

/*---------------------------------------------------------------------------

	type definition

---------------------------------------------------------------------------*/
typedef unsigned char		BYTE;			// Unsigned  8 bit value type
typedef unsigned short		WORD;			// Unsigned 16 bit value type
typedef unsigned long		DWORD;			// Unsigned 32 bit value type

typedef unsigned char		UINT1;			// Unsigned  8 bit value type
typedef unsigned short		UINT2;			// Unsigned 16 bit value type
typedef unsigned long		UINT4;			// Unsigned 32 bit value type

typedef signed char		INT1;				// Signed  8 bit value type
typedef signed short	INT2;				// Signed 16 bit value type
typedef signed long		INT4;				// Signed 32 bit value type

typedef signed char		SINT1;				// Signed  8 bit value type
typedef signed short	SINT2;				// Signed 16 bit value type
typedef signed long		SINT4;				// Signed 32 bit value type

#define	byte		BYTE
#define	word		WORD

#ifndef NULL
 #define	NULL		0
#endif

#ifndef TRUE
 #define	TRUE		(1)
 #define	FALSE		(!TRUE)
#endif

#define	PACKED


typedef signed long SINT64;

/*---------------------------------------------------------------------------

  GNEX VM Feature setting

---------------------------------------------------------------------------*/

#define	GNEX_VM_FEATURE_QUICK_OPCODE
#define	GNEX_VM_FEATURE_QUICK_OPCODE_CHECK_ONLY_POP

// PLLAB - HTTP support - 081022 shko
//#define GNEX_FEATURE_HTTP
#define GNEX_FEATURE_CALLBACK

#define GNEX_FEATURE_TOUCHPAD

/*---------------------------------------------------------------------------

  GNEX target version setting

---------------------------------------------------------------------------*/
#define	GNEX_VERSION_10				0x01
#define	GNEX_VERSION_15				0x02
#define	GNEX_VERSION_30				0x03
#define	GNEX_VERSION_40				0x04
#define	GNEX_VERSION_50				0x24

#ifdef GNEX_FEATURE_GIGA
	#define	GNEX_VERSION				GNEX_VERSION_50
#else
	#define	GNEX_VERSION				GNEX_VERSION_40
#endif

/*---------------------------------------------------------------------------

  GNEX target minor version setting

---------------------------------------------------------------------------*/
// System Variable swVMver = 1.00.00
// GNEX system minor version (fixed constant)
#define	GNEX_VER_1						1
#define	GNEX_VER_2						0
#define	GNEX_VER_3						0

/*---------------------------------------------------------------------------

  GNEX LCD CLASS definition

---------------------------------------------------------------------------*/
#define	GNEX_LCD_CLASS_0				0x01	//	 96x 64 ~ 120x 80 �̸�
#define	GNEX_LCD_CLASS_1				0x02	//	120x 80 ~ 128x128 �̸�
#define	GNEX_LCD_CLASS_2				0x04	//	128x128 ~ 176x176 �̸�
#define	GNEX_LCD_CLASS_3				0x08	//	176x176 ~ 176x210 �̸�
#define	GNEX_LCD_CLASS_4				0x10	//	176x210 ~ 256x256 �̸�
#define	GNEX_LCD_CLASS_5				0x20	//	256x256 ~ 320x320 �̸�
#define	GNEX_LCD_CLASS_6				0x40	//	320x320 ~ 640x640 �̸�
#define	GNEX_LCD_CLASS_7				0x80	//	640x640 ~

/*---------------------------------------------------------------------------
  GNEX LCD Bit Size per Pixel definition (--32Bit color)  
  Added by Kwak J. H. 04.06.9
---------------------------------------------------------------------------*/
#define	GNEX_LCD_16BIT				0x01
#define	GNEX_LCD_24BIT				0x02
#define	GNEX_LCD_32BIT				0x03

#define	GNEX_LCD_SIZE					GNEX_LCD_16BIT

/*---------------------------------------------------------------------------
  GNEX LCD Format definition (--32Bit color)  
  Added by Kwak J. H. 04.05.28
---------------------------------------------------------------------------*/
#if(GNEX_LCD_SIZE == GNEX_LCD_16BIT)
	#define	GNEX_LCD_RGB565				0x01
	#define	GNEX_LCD_RGB444				0x02
#elif(GNEX_LCD_SIZE == GNEX_LCD_24BIT)
	#define	GNEX_LCD_RGB666				0x03
	#define	GNEX_LCD_RGB888				0x04
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
	#define	GNEX_LCD_ARGB8888			0x05
	#define	GNEX_LCD_BGRA8888			0x06
#endif		//GNEX_LCD_SIZE

#define	GNEX_LCD_FORMAT				GNEX_LCD_RGB565

/*--------------------------------------------------------------------------------
	D E B U G  M E S S A G E  S E T T I N G
--------------------------------------------------------------------------------*/
//#define GNEX_DEBUG
/*
#ifdef _DEBUG
 #define GNEX_DEBUG
#endif
*/

#define	GNEX_EXCEPTION_TIMEOUT			5000			// Exception timeout

/*---------------------------------------------------------------------------

  GNEX system file and directory�� ���� ����

  Network Feature �߰� by capscrom 04.04.23
---------------------------------------------------------------------------*/
#define	GNEX_MAX_SOCKET				3

//#define	GNEX_SHANDLE_TYPE			unsigned int
#define	GNEX_SHANDLE_TYPE			KDSocket*

#define	GNEX_SOCKET_R_SUCCESS		1
#define	GNEX_SOCKET_R_FAIL			-1
#define GNEX_SOCKET_R_EMPTY			0
#define	GNEX_SOCKET_R_WOULDBLOCK	65535
#define	GNEX_SOCKET_R_CLOSEPEER		-2

#define	GNEX_SOCK_TCP				1
#define	GNEX_SOCK_UDP				2

#define	GNEX_MAX_RCVBUF				1009

// PLLAB - HTTP support - 081022 shko
#ifdef GNEX_FEATURE_HTTP
#define GNEX_HTTP_R_SUCCESS			1
#define GNEX_HTTP_R_FAIL			-1
#endif // GNEX_FEATURE_HTTP

// added by sonbug: 2008.11.03
/*
	THE TOUCH EVENT
*/
typedef enum tag_TOUCH_EVENT_E
{
	GNEX_POINTER_PRESS,	
	GNEX_POINTER_DBCLICK,
	GNEX_POINTER_MOVE,	
	GNEX_POINTER_RELEASE,
	GNEX_POINTER_TIMEOUT,
	GNEX_POINTER_TIMERMAX = 50 // �̺�Ʈ �ƴ�, TIMER üũ ���� ����� 
} TOUCH_EVENT_E;


// -------------------------------------------------------------------------------------------
// 05.05.24 SJKim 
// -------------------------------------------------------------------------------------------
#define	NET_R_SUCCESS				0
#define	NET_R_FAIL					0xFFFF
// -------------------------------------------------------------------------------------------

/*---------------------------------------------------------------------------

	String length definition

---------------------------------------------------------------------------*/
#define	GNEX_LEN_GNAME				32				// sGameName length
#define	GNEX_LEN_IP					32				// IP string length
#define	GNEX_LEN_URL				256				// URL string length


// ---------------------------------------------------------------------------------------------------------
// SJKim 050519
#define	GNEX_LEN_TEXT					32				// Input chat text len
//#define	GNEX_LEN_USERID				8				// sUserID length
// ---------------------------------------------------------------------------------------------------------

/*---------------------------------------------------------------------------

  Application information structure

---------------------------------------------------------------------------*/
typedef struct _APPInfo 
{
	WORD	AppPlayerVer;						// 1x, 2x, 3x application version
	WORD	AppVer;								// application version
	char	AppName[GNEX_LEN_GNAME + 1];		// application name
	WORD	AppCPID;							// application cp id
	WORD	AppID;								// application id
	DWORD	AppSize;							// application size
	BYTE	AgentType;							// normal, agent
	BYTE	AppCompType;						// compressed, not compressed
	BYTE	AppSaveType;						// normal, compressed
	BYTE	AppImageType;
	BYTE	AppType;							// application type
	WORD	AppDynLib;
	BYTE	*AppAddr;							// Application Address

// ---------------------------------------------------------------------------------------------------------
// SJKim 050519
//	char	AppUserID[GNEX_LEN_USERID + 1];	// user id	//add for GNEXDM.
//	char	AppSvrIp[GNEX_LEN_IP+1];			// server ip
//	word	AppSvrPort;							// server port
// ---------------------------------------------------------------------------------------------------------

	BYTE	AppValid;
	BYTE	AppValidCnt;						// valid count
	BYTE	AppValidTerm[3];					// valid date

// PLLAB - Stretch LCD - 081014 shko
	int		lcdClass;
	int		carrierType;
} APPInfo;


#define GNEX_USERNV_FILE				"UserNV.sys"
#define GNEX_APPINFO_FILE				"AppInfo.sys"
#define GNEX_APP_EXT					".sgs"

// file control mode constants
#define	GNEX_FILE_OPEN_MODE_READWRITE	1
#define	GNEX_FILE_OPEN_MODE_CREATE		2
#define	GNEX_FILE_OPEN_MODE_READ		3
#define	GNEX_FILE_OPEN_MODE_APPEND		4

// file seek constants
#define	GNEX_FILE_SEEK_SET				1
#define GNEX_FILE_SEEK_CUR				2
#define GNEX_FILE_SEEK_END				3
// EFS ���� GNEX Result�� ���� �������� ���޵��� �ʴ´�.
#define GNEX_FILE_R_NOEFS				-2		// EFS�� ������ ����. �Ϲ� ���Ϸ� �Ѿ�� operation
#define GNEX_FILE_R_FAIL				-1
#define GNEX_FILE_R_SUCCESS				1
#define GNEX_LEN_PATH					128

#define GNEX_FILE_R_FAIL				-1
#define GNEX_FILE_R_SUCCESS				1
//#define GNEX_FHANDLE_TYPE				M_Uint32 
#define GNEX_FHANDLE_TYPE				KDFile*	//ksmoon

// file seek constants
#define	GNEX_FILE_SEEK_SET				1
#define GNEX_FILE_SEEK_CUR				2
#define GNEX_FILE_SEEK_END				3

//#define GNEX_FILE_R_OPENERROR			NULL
#define GNEX_FILE_R_OPENERROR			-1
#define GNEX_PACKED

/*--------------------------------------------------------------------------------

  GNEX key code

--------------------------------------------------------------------------------*/

#define GNEX_KEY_1						0x01
#define	GNEX_KEY_2						0x02
#define	GNEX_KEY_3						0x03
#define	GNEX_KEY_4						0x04
#define	GNEX_KEY_5						0x05
#define	GNEX_KEY_6						0x06
#define	GNEX_KEY_7						0x07
#define	GNEX_KEY_8						0x08
#define	GNEX_KEY_9						0x09
#define	GNEX_KEY_0						0x0A
#define	GNEX_KEY_STAR					0x0B
#define	GNEX_KEY_SHARP					0x0C

#define	GNEX_KEY_CLR					0x0D
#define	GNEX_KEY_SND					0x0E
#define	GNEX_KEY_END					0x0F

#define	GNEX_KEY_LEFT					0x10
#define	GNEX_KEY_RIGHT					0x11
#define	GNEX_KEY_UP						0x12
#define	GNEX_KEY_DOWN					0x13
#define	GNEX_KEY_OK						0x14

#define GNEX_KEY_F1						0x15
#define GNEX_KEY_F2						0x16
#define GNEX_KEY_ENTER					0x17

/* KSMOON */
// Qwerty Key �߰�
#define GNEX_KEY_A			0x18
#define GNEX_KEY_B			0x19
#define GNEX_KEY_C			0x1A
#define GNEX_KEY_D			0x1B
#define GNEX_KEY_E			0x1C
#define GNEX_KEY_F			0x1D
#define GNEX_KEY_G			0x1E
#define GNEX_KEY_H			0x1F
#define GNEX_KEY_I			0x20
#define GNEX_KEY_J			0x21
#define GNEX_KEY_K			0x22
#define GNEX_KEY_L			0x23
#define GNEX_KEY_M			0x24
#define GNEX_KEY_N			0x25
#define GNEX_KEY_O			0x26
#define GNEX_KEY_P			0x27
#define GNEX_KEY_Q			0x28
#define GNEX_KEY_R			0x29
#define GNEX_KEY_S			0x2A
#define GNEX_KEY_T			0x2B
#define GNEX_KEY_U			0x2C
#define GNEX_KEY_V			0x2D
#define GNEX_KEY_W			0x2F
#define GNEX_KEY_X			0x30
#define GNEX_KEY_Y			0x31
#define GNEX_KEY_Z			0x32

// Function Key �߰�
#define GNEX_KEY_AT				0x33
#define GNEX_KEY_BACK			0x34
#define GNEX_KEY_SHIFT			0x35
#define GNEX_KEY_COMMA			0x36
#define GNEX_KEY_RETURN			0x37
#define GNEX_KEY_ALT			0x38
#define GNEX_KEY_SPACE			0x39
#define GNEX_KEY_PERIOD			0x3A

#define	GNEX_KEY_1_L					0x81
#define	GNEX_KEY_2_L					0x82
#define	GNEX_KEY_3_L					0x83
#define	GNEX_KEY_4_L					0x84
#define	GNEX_KEY_5_L					0x85
#define	GNEX_KEY_6_L					0x86
#define	GNEX_KEY_7_L					0x87
#define	GNEX_KEY_8_L					0x88
#define	GNEX_KEY_9_L					0x89
#define	GNEX_KEY_0_L					0x8A
#define	GNEX_KEY_STAR_L					0x8B
#define	GNEX_KEY_SHARP_L				0x8C

#define	GNEX_KEY_CLR_L					0x8D
#define	GNEX_KEY_SND_L					0x8E
#define	GNEX_KEY_END_L					0x8F

#define	GNEX_KEY_LEFT_L					0x90
#define	GNEX_KEY_RIGHT_L				0x91
#define	GNEX_KEY_UP_L					0x92
#define	GNEX_KEY_DOWN_L					0x93
#define	GNEX_KEY_OK_L					0x94

#define GNEX_KEY_F1_L					0x95
#define GNEX_KEY_F2_L					0x96
#define GNEX_KEY_ENTER_L				0x97

// Qwerty Long Key �߰�
#define GNEX_KEY_A_L			0x98
#define GNEX_KEY_B_L			0x99
#define GNEX_KEY_C_L			0x9A
#define GNEX_KEY_D_L			0x9B
#define GNEX_KEY_E_L			0x9C
#define GNEX_KEY_F_L			0x9D
#define GNEX_KEY_G_L			0x9E
#define GNEX_KEY_H_L			0x9F
#define GNEX_KEY_I_L			0xA0
#define GNEX_KEY_J_L			0xA1
#define GNEX_KEY_K_L			0xA2
#define GNEX_KEY_L_L			0xA3
#define GNEX_KEY_M_L			0xA4
#define GNEX_KEY_N_L			0xA5
#define GNEX_KEY_O_L			0xA6
#define GNEX_KEY_P_L			0xA7
#define GNEX_KEY_Q_L			0xA8
#define GNEX_KEY_R_L			0xA9
#define GNEX_KEY_S_L			0xAA
#define GNEX_KEY_T_L			0xAB
#define GNEX_KEY_U_L			0xAC
#define GNEX_KEY_V_L			0xAD
#define GNEX_KEY_W_L			0xAF
#define GNEX_KEY_X_L			0xB0
#define GNEX_KEY_Y_L			0xB1
#define GNEX_KEY_Z_L			0xB2

// Function Long Key �߰�
#define GNEX_KEY_AT_L			0xB3
#define GNEX_KEY_BACK_L			0xB4
#define GNEX_KEY_SHIFT_L		0xB5
#define GNEX_KEY_COMMA_L		0xB6
#define GNEX_KEY_RETURN_L		0xB7
#define GNEX_KEY_ALT_L			0xB8
#define GNEX_KEY_SPACE_L		0xB9
#define GNEX_KEY_PERIOD_L		0xBA

#define GNEX_KEY_RELEASE				0xFF

#ifdef GNEX_FEATURE_TOUCHPAD
#define	TOUCHPAD_DBCLIK_AREA			5
#define GNEX_POINTER_PRESS				0x00
#define GNEX_POINTER_DBCLICK			0x01
#define GNEX_POINTER_MOVE				0x02
#define GNEX_POINTER_RELEASE			0x03
#endif // GNEX_FEATURE_TOUCHPAD

/*--------------------------------------------------------------------------------

  Buzzer note

--------------------------------------------------------------------------------*/
typedef	enum 
{
	GNEX_NOTE_G3,	// 0
	GNEX_NOTE_G3P, 
	GNEX_NOTE_A3,  
	GNEX_NOTE_A3P, 
	GNEX_NOTE_B3,  
	GNEX_NOTE_C4,  
	GNEX_NOTE_C4P, 
	GNEX_NOTE_D4,  
	GNEX_NOTE_D4P, 
	GNEX_NOTE_E4,  
	GNEX_NOTE_F4,	// 10
	GNEX_NOTE_F4P, 
	GNEX_NOTE_G4,  
	GNEX_NOTE_G4P, 
	GNEX_NOTE_A4,  
	GNEX_NOTE_A4P, 
	GNEX_NOTE_B4,  
	GNEX_NOTE_C5,  
	GNEX_NOTE_C5P, 
	GNEX_NOTE_D5,  
	GNEX_NOTE_D5P,	// 20
	GNEX_NOTE_E5,  
	GNEX_NOTE_F5,  
	GNEX_NOTE_F5P, 
	GNEX_NOTE_G5,  
	GNEX_NOTE_G5P, 
	GNEX_NOTE_A5,  
	GNEX_NOTE_A5P, 
	GNEX_NOTE_B5,  
	GNEX_NOTE_C6,  
	GNEX_NOTE_C6P,	// 30
	GNEX_NOTE_D6,  
	GNEX_NOTE_D6P, 
	GNEX_NOTE_E6,  
	GNEX_NOTE_F6,  
	GNEX_NOTE_F6P, 
	GNEX_NOTE_G6,
	GNEX_NOTE_R,
	GNEX_NOTE_END	// 38: End of tone table
} S_NoteDef;

// buzzer data type structure
typedef	PACKED struct _S_NoteType
{
	BYTE	Note;						// Tone height, GNEX_NOTEDef type
	BYTE	Milisec;					// Tone duration, 3 milisecond unit
} S_NoteType;

/*---------------------------------------------------------------------------

  2x event code definition

---------------------------------------------------------------------------*/
#define	GNEX_EVENT_MENU					0
#define	GNEX_EVENT_DOWNLOAD_START		1
#define	GNEX_EVENT_SVM_START			2
#define	GNEX_EVENT_SVM_PTP_START		3
#define	GNEX_EVENT_TEXTEDIT				4
#define	GNEX_EVENT_CHATEDIT				5
#define	GNEX_EVENT_CONTINUE				6
#define	GNEX_EVENT_SMS_RESULT			7
#define	GNEX_EVENT_CONNECT_RESULT		8
#define	GNEX_EVENT_DISCON_OK			9
#define	GNEX_EVENT_PTPDIAL				10
#define	GNEX_EVENT_PTPWAIT				11
#define	GNEX_EVENT_PTP_RESULT			12
#define	GNEX_EVENT_PTPDISCON_OK			13


/*---------------------------------------------------------------------------

  3x added event code

---------------------------------------------------------------------------*/
#define	GNEX_EVENT_START				14
#define	GNEX_EVENT_APP_START			15
#define	GNEX_EVENT_NETWORK				16
#define	GNEX_EVENT_TIMER				17
#define	GNEX_EVENT_KEY					18
#define	GNEX_EVENT_HOLD					19
#define	GNEX_EVENT_SMS_RECV				20
#define	GNEX_EVENT_SOUND_PLAYEND		21
#ifdef GNEX_FEATURE_TOUCHPAD
#define	GNEX_EVENT_TOUCHPAD				22
#endif
#ifdef	GNEX_FEATURE_VODCTL						
#define	GNEX_EVENT_VOD					23
#endif
#define	GNEX_EVENT_COM					24		
#define GNEX_EVENT_STREDIT				25		
#define GNEX_EVENT_EXIT					26

#ifdef GNEX_FEATURE_CALLBACK
#	define GNEX_EVENT_FUNCTION_CALL		28
#endif

// PLLAB - HTTP support - 081022 shko
#ifdef GNEX_FEATURE_HTTP
#	define GNEX_EVENT_HTTP						29
#endif


//==============================================================
//	GNEX tedit state
//
#define GNEX_TEDIT_DONE					1
#define GNEX_TEDIT_CANCEL				2
#define GNEX_TEDIT_CALL					3
#define GNEX_TEDIT_CALLDROP				4
#define GNEX_TEDIT_EXIT					5


//==============================================================
//	GNEX Network state
// Network Feature �߰� ���� ���� by capscrom 04.04.26
#define	GNEX_NETWORK_CONNECT			1
#define	GNEX_NETWORK_DISCONNECT			2
#define	GNEX_NETWORK_SEND_ENABLE		3
#define	GNEX_NETWORK_RECV_ENABLE		4
#define	GNEX_NETWORK_PPP_CLOSED			5

// PLLAB - HTTP support - 081022 shko
//==============================================================
//	GNEX Http state
//
#ifdef GNEX_FEATURE_HTTP
#	define GNEX_NETWORK_HTTP_CONNECT		6
#	define GNEX_NETWORK_HTTP_DATA_RECV	7
#endif // GNEX_FEATURE_HTTP

/*---------------------------------------------------------------------------

  result code

---------------------------------------------------------------------------*/
#define	GNEX_RC_NONE					1
#define	GNEX_RC_EXIT					2
#define	GNEX_RC_EXEC_EXIT				3
#define	GNEX_RC_TEXTEDIT				4
#define	GNEX_RC_CHATEDIT				5			// obsolete
#define	GNEX_RC_OUT_OF_MEM				6
#define	GNEX_RC_CONNECT					7
#define	GNEX_RC_CONNECT_FAIL			8
#define	GNEX_RC_DISCONNECT				9
#define	GNEX_RC_DISCONNECT_FAIL			10
#define	GNEX_RC_INCOMINGCALL			11
#define	GNEX_RC_VOICECALL				12
#define	GNEX_RC_VOICECALL_FAIL			13
#define	GNEX_RC_PTPCALL					14			// obsolete
#define	GNEX_RC_PTPCALLMMI				15			// obsolete
#define	GNEX_RC_PTPWAIT					16			// obsolete
#define	GNEX_RC_PTPCALL_FAIL			17			// obsolete
#define	GNEX_RC_PTPRELEASE				18			// obsolete
#define	GNEX_RC_PTPRELEASE_FAIL			19			// obsolete
#define	GNEX_RC_DOWNLOAD				20
#define	GNEX_RC_BROWSER_DISCONNECT		21
#define	GNEX_RC_BROWSER					22
#define	GNEX_RC_BACK_TO_BROWSER			23
#define	GNEX_RC_EXCEPTION				24
#ifdef GNEX_FEATURE_VODPLAY
#define	GNEX_RC_VODPLAY					25
#endif
#define GNEX_RC_STREDIT					26		//Added by Kjaehwa for StrEdit 2005.06.01
#define	GNEX_RC_ERROR					27
#define GNEX_RC_DLCOMP					28


/*---------------------------------------------------------------------------

  GNEX result reason

---------------------------------------------------------------------------*/
#define	GNEX_RR_DISCONNECT				1
#define	GNEX_RR_DISCONNECT_DLSSBERR		2
#define	GNEX_RR_DISCONNECT_DLMEMERR		3
#define	GNEX_RR_DISCONNECT_DLSCRERR		4
#define	GNEX_RR_DISCONNECT_DLSIZEERR	5
#define	GNEX_RR_DISCONNECT_DLSUMERR		6
#define	GNEX_RR_DISCONNECT_DLAUTHERR	7
#define	GNEX_RR_DISCONNECT_DLPKTERR		8
#define	GNEX_RR_DISCONNECT_DLCOMP		9
#define	GNEX_RR_DISCONNECT_DLRETRYFAIL	10
#define	GNEX_RR_DISCONNECT_DLCALLDROP	11
#define	GNEX_RR_DISCONNECT_DLEXIT		12
#define	GNEX_RR_DISCONNECT_BROWSER		13
#define	GNEX_RR_DISCONNECT_CALLDROP		14
#define	GNEX_RR_DISCONNECT_SVREXIT		15
#define	GNEX_RR_DISCONNECT_EXIT			16
#ifdef GNEX_DOWNLOAD_RCVERR
#define GNEX_RR_DISCONNECT_RCVERR		17
#endif

/*---------------------------------------------------------------------------

  GNEX error code

---------------------------------------------------------------------------*/
#define	GNEX_ERR_DECOMPFAIL				0
#define	GNEX_ERR_LOADFAIL				1
#define	GNEX_ERR_DOWNFAIL				2
#define	GNEX_ERR_DOWNFAILSIZE			3
#define	GNEX_ERR_DOWNFAILSUM			4
#define	GNEX_ERR_AUTHFAIL				5
#define	GNEX_ERR_NETSTARTFAIL			6
#define	GNEX_ERR_EMPTY					7
#define	GNEX_ERR_GETAPPINFO_FAIL		8
#define	GNEX_ERR_MEMINIT_FAIL			9
#define	GNEX_ERR_LOADING				10
#define	GNEX_ERR_UNKNOWN				11

// Validation Check�� ���� �߰�. moonchild 2003/09/21
#define	GNEX_ERR_INVALID_SCRIPT			12
#define	GNEX_ERR_CONTENT_EXIST			13

/*--------------------------------------------------------------------------------

  GNEX result

--------------------------------------------------------------------------------*/
typedef struct 
{
	char	*ip;
	WORD	port;
	BYTE	reasons;
} S_SvrParam;

typedef struct 
{
	DWORD	size;
	DWORD	lack;
	int		index;
} S_SsbParam;

typedef struct 
{
	char		*dial;
	BYTE	ret;
} S_CallParam;

typedef	struct 
{
	int		ecode;
	DWORD	addr;
	DWORD	pc;
} S_Exception;


// added by son, 2008.10.09
typedef struct {
	char	*title;
	char	*input;
	BYTE	maxlen;
	BYTE	strtype;
} S_EditParam;

// added by son, 2008.10.09
typedef struct {
	char	*title; 
	char	*input;
	int		maxlen;
	WORD	xpos;
	WORD	ypos;
	BYTE	strtype;
	BYTE	option;	
} S_StrEditParam;

typedef struct 
{
	int		code;
	int		type;
	union 
	{
		int		data;
		char	*str;
		S_SsbParam		ssb;
		S_SvrParam		svr;
		S_CallParam		call;
		S_Exception		exception;
		
		// added by son, 2008.10.09
		S_EditParam		edit;
		S_StrEditParam	stredit;
		
	} param;
} S_Result;

/*--------------------------------------------------------------------------------

  GNEX event

--------------------------------------------------------------------------------*/
typedef struct 
{
	int		index;
	int		mode;
	int		type;
	int		width;
	int		height;
} S_AppParam;

#ifdef GNEX_FEATURE_TOUCHPAD
typedef struct {
	int		type;
	int		x;
	int		y;
} S_TouchPadParam;
#endif

typedef struct {		//added by Kjaehwa 2005.06.14 For StrEdit
	BYTE	event;
	BYTE    reserve[3];
	char	*str;
	int		option;
} S_SEditParam;	


// Network Feature �߰�  by capscrom 04.04.26
typedef struct 
{
	int		type;
	int		data;
	GNEX_SHANDLE_TYPE	sockid;
} S_NetParam;

#ifdef GNEX_FEATURE_CALLBACK
typedef struct {
	int  cdi; // callback data
} S_CBParam;
#endif	// GNEX_FEATURE_CALLBACK


typedef struct 
{
	int		code;
	int		type;
	union 
	{
		int		data;
		char		*str;
		S_AppParam		app;
#ifdef GNEX_FEATURE_TOUCHPAD
		S_TouchPadParam	tpad;
#endif
		S_SEditParam	stredit;	//added by Kjaehwa 2005.06.14 For StrEdit
		S_NetParam		net;	// Network Feature �߰� by capscrom 04.04.26
#ifdef GNEX_FEATURE_CALLBACK
		S_CBParam			callback;
#endif // GNEX_FEATURE_CALLBACK
	} param;
} S_Event;

// --------------------------------------------------------------------------------------------
// SJKim 050524
// --------------------------------------------------------------------------------------------
typedef struct _sGNXTimer
{
	int timerid;
	int timeout;
	int repeat;
	int buse;
	int timeintv;
}sGNEXTimer;

typedef struct _SOCKETHandle {
	GNEX_SHANDLE_TYPE	Handle;
	int			SetFlag;
} SOCKETHandle;

typedef enum {
	GNEX_SOCK_CLOSE,			// ���� ����
		GNEX_SOCK_OPEN_TEMP,	// �ӽ÷� Open�� ����
		GNEX_SOCK_OPEN			// Open �� ���� Socket Handle�� ���� ����
} SOCKET_OPEN_STATE;

typedef enum {
	GNEX_SOCK_CON_NONE,
		GNEX_SOCK_CON_WAIT,
		GNEX_SOCK_CON_OK
} SOCKET_CON_STATE;

typedef struct _SOCKET_ID_TAG
{
	GNEX_SHANDLE_TYPE	ph_sock;
	int					type;
	SOCKET_OPEN_STATE	state;
	SOCKET_CON_STATE	connect_state;
	signed long			ip;
	signed short		port;
	char				url[GNEX_LEN_TEXT];
} GNEX_HANDLE_SOCKETID;


#ifdef GNEX_FEATURE_CALLBACK
/*
 ****************************************************************************
 * Enumeration used for callback
 ****************************************************************************
 */
// �񵿱� ȣ��� �Լ� ID
enum asCallData_keys {
	asCallData_keys_FIRST = 0,
	asc_immediate_call,

// ---- �� �Ʒ����� �񵿱� �Լ� ȣ��� ID ����
// -------------------------------------------------------------------------
// Http Download
	asc_if_HttpConnectHandler,
	asc_if_HttpDownloadHandler,

// -------------------------------------------------------------------------
	asCallData_keys_LAST
};
#endif

// PLLAB - HTTP support - 081022 shko
#ifdef GNEX_FEATURE_HTTP
#	ifndef HTTP_T_DEFINED
#		define HTTP_T_DEFINED
#		define HTTP_T(x)	(httpConTextData_t + x)
#		define HTTP_CHECK_HANDLE(x) ((((x)>=0) && ((x)<GNEX_MAX_HTTP))?TRUE:FALSE) 
 
/*
 ****************************************************************************
 * Structure used for HTTP
 ****************************************************************************
 */

typedef GNEX_PACKED struct _HTTPContextData {

	// progress state
	int nState;

	//icalldata_t nOpenCB;
	int nOpenCB;

	// connect, read retry
	int nRetry;
	
	// Network ID (wipi)
	int nNetID;

	int nIsComplete;

//////////////////////////////////////////////
// HTTP GNEX Handle structure
//////////////////////////////////////////////

	// gnex http handle .. max:3 (gnex)
	GNEX_SHANDLE_TYPE	nHandle;	
	
	// whether using http handle
	int			nSetFlag;

	// http descriptor (wipi)
	int			nFd;						

	// wipi socket descriptor (wipi)
	int			nSd;		

//////////////////////////////////////////////
// HTTP Request 
//////////////////////////////////////////////
	BYTE *pUrl;					

	// request url length
	int  nUrlLen;				
	
	// need to .... proxy, request method & property, 

//////////////////////////////////////////////
// HTTP Response 
//////////////////////////////////////////////

	// http response code : 200, 400 ... etc
	int		nResCode;		

	// http response body length
	int		nBodyLen;	
	
	// http response body data
	BYTE	*pBuf;		// buffer for socket read 
	int   nBufLen;	// length for socket read
	int   nReadPos;	// socket data read offset
	// need to .... header field, get type, encoding ...
} HTTPContextData;

// PLLAB - HTTP support - 081022 shko
#ifdef GNEX_FEATURE_HTTP
#define GNEX_MAX_HTTP					3
#endif

extern HTTPContextData httpConTextData_t[GNEX_MAX_HTTP];

/*
 ****************************************************************************
 * Enumeration used when http connecting state
 ****************************************************************************
 */
typedef enum {

	// HTTP Connect State
	HTTP_S_NETCON_INIT = 10,
	HTTP_S_NETCON_PROGRESS,				// NetConnectEx progress
	HTTP_S_NETCON_SUCCESS,				// NetConnectEx success
	HTTP_S_NETCON_ERROR,					// NetConnectEx error
	HTTP_S_CON_PROGRESS,								
	HTTP_S_CON_SUCCESS,
	HTTP_S_CON_ERROR,

	// HTTP Data Read State
	HTTP_S_DATA_READ_INIT,
	HTTP_S_DATA_READ_PROGRESS,
	HTTP_S_DATA_READ_SUCCESS,
	HTTP_S_DATA_READ_ERROR
	
} HTTP_CON_STATE;
#endif // HTTP_T_DEFINED
				
extern void midd_HttpNetOpen(HTTPContextData* pHttpCD);
extern void midd_HttpResultProc(int nEvent, int nState, HTTPContextData* pHttpCD);
extern void midd_HttpNetConnect(HTTPContextData* pHttpCD);
extern int	midd_NetDisConnect(HTTPContextData* pHttpCD);
extern int midd_HttpNetDisconnect(HTTPContextData* pHttpCD);
extern void midd_HttpNetReadData(HTTPContextData* pHttpCD);
#endif // GNEX_FEATURE_HTTP

// -------------------------------------------------------------------------------------------

/*---------------------------------------------------------------------------

	Download request information structure		// Download feature �߰� 2004.9.14 by kwak.j.h

---------------------------------------------------------------------------*/

// ---------------------------------------------------------------------------------------------------------
// SJKim 050519
/*
typedef struct _APPReqInfo 
{
	char	AppUserID[GNEX_LEN_USERID + 1];
	WORD	AppCPID;
	WORD	AppID;
	char	AppDlSvrIp[GNEX_LEN_IP + 1];
	WORD	AppDlPort;
	char	AppSvrIp[GNEX_LEN_IP+1];
	WORD	AppSvrPort;
	char	AppRetURL[GNEX_LEN_URL+1];
	WORD	AppVer;
	DWORD  AppSize;
} APPReqInfo;
*/
// ---------------------------------------------------------------------------------------------------------

/*---------------------------------------------------------------------------

  GNEX CORE global system variable

---------------------------------------------------------------------------*/
//#if(GNEX_LCD_SIZE == GNEX_LCD_16BIT)

//extern	WORD	*sLcdBuf;
//extern	WORD	*sBackLcdBuf;	
/*
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
extern	DWORD	*sLcdBuf;			//--32bit color buffer
extern	DWORD	*sBackLcdBuf;		//--32bit color buffer
#endif		//GNEX_LCD_SIZE
*/
// --------------------------------------------------
extern	int		sLcdBufID;
extern	int		sBackLcdBufID;
// ----------------------------------------
extern	BYTE	*sSysMem;
extern	int		sSysMemID;
extern	SINT4	sSysMemSize;
extern	int		knlGammaSave;

extern		KDColor* grp;
extern		KDColor* back_grp;

extern	sGNEXTimer s_timer[3];

// PLLAB - Stretch LCD - 081014 shko
extern KDColor* grpStretch;
	
extern	int		mmiAnnunHeight;

/*--------------------------------------------------------------------------------
	M I D D  F U N C T I O N  P R O T O T Y P E S
--------------------------------------------------------------------------------*/
// memory control
extern	int			midd_InitMemory(int size);
extern	void		midd_CloseMemory(int);

// lcd device
extern	void		midd_UpdateScreen(int bufID);
extern	void		midd_UpdatePartialScreen(int bufID, int sx, int sy, int ex, int ey);

// PLLAB - Stretch LCD - 081014 shko
// Added by KHJ 2004.08.19 : Stretch Lcd ���� midd �Լ�
extern void (*midd_StretchLcd)(KDColor* dst, KDColor* src);
extern void midd_StretchLcdMemOriginal(KDColor* dst, KDColor* src);
extern void midd_StretchLcdMem2to3(KDColor* dst, KDColor* src);
extern void midd_StretchLcdMem1to2(KDColor* dst, KDColor* src);
extern void midd_StretchLcdMem3to4(KDColor* dst, KDColor* src);

// sound device
extern   void		midd_SetSoundVol(int channel, int level);
extern	void		midd_PlaySound(int channel, BYTE *data, DWORD len);
extern	void		midd_StopSound(int channel);
extern	void		midd_PauseSound(int channel);
extern	void		midd_ResumeSound(int channel);

// s/w time & timer
extern	void		midd_StartTimer(int id, int t, int flag);
extern	void		midd_StopTimer(int id);
extern	void		midd_GetTimeTick(DWORD *htick, DWORD *ltick);
extern	int			midd_GetDate(UINT2 *year, UINT2 *month, UINT2 *day, UINT2 *wday);
extern	int			midd_GetTime(UINT2 *hour, UINT2 *min, UINT2 *sec, UINT2 *msec);

// Network Feature �߰� by capscrom 04.04.23
// socket midd
extern	int 		midd_SocketOpen(int type, int index);
extern	int			midd_SocketClose(GNEX_SHANDLE_TYPE h_sock);
extern	int			midd_SocketConnect(int index, char *ip, UINT2 port);
extern	int			midd_SocketSend(int index, BYTE *buf, UINT2 len);
extern	int			midd_SocketSendTo(int index, BYTE *buf, UINT2 len, char *ip, UINT2 port);
extern	int			midd_SocketRecv(int index, BYTE *buf, UINT2 len);
extern	int			midd_SocketRecvFrom(int index, BYTE *buf, UINT2 len, char *ip, UINT2 port);
extern	void		midd_SetSoMo(int so, int mo);
//extern	void		midd_SocketClosePPP(void);

// file midd
extern	int		midd_FileMkDir(char *dirname);
extern	int		midd_FileRmDir(char *dirname);
extern	int		midd_FileTest(char *filename);
extern	int		midd_DirTest(char *dirname);
extern	GNEX_FHANDLE_TYPE	midd_FileOpen(char *filename, int mode);
extern	int		midd_FileClose(GNEX_FHANDLE_TYPE h_file);
extern	int		midd_FileRead(GNEX_FHANDLE_TYPE h_file, BYTE *data, int size);
extern	int		midd_FileWrite(GNEX_FHANDLE_TYPE h_file, BYTE *data, int size);
extern	int		midd_FileSeek(GNEX_FHANDLE_TYPE h_file, int offset, int origin);
extern	int		midd_FileTell( GNEX_FHANDLE_TYPE h_file );
extern	int		midd_FileDel(char *filename);
extern	int		midd_FileInfo(char *filename, int *size, int *year, int *month, int *day);
extern	int		midd_FileGetFreeSpace(void);

//system midd
extern void midd_GetLocInfo(UINT2 *locinfo);





// -------------------------------------------------------------------------------------
// 05.05.17. graphicace
extern int midd_GetLcdInfo(int*width,int* height);
extern void InitGNEXSocket();
// -------------------------------------------------------------------------------------
/*--------------------------------------------------------------------------------
	A M  F U N C T I O N  P R O T O T Y P E S
--------------------------------------------------------------------------------*/
extern	int			knl_StartGNEX(int width, int height, int memSize);
extern	void		knl_EndGNEX(void);
extern	S_Result	*knl_EventAppStart(int data);
extern	S_Result	*knl_EventDownloadStart(int data);
extern	S_Result	*knl_EventKeypress(int data);
extern	S_Result	*knl_EventTimeout(int data);
extern	S_Result	*knl_EventNetwork(int etype, int result, int sid );
extern	S_Result	*knl_EventSound(int data);
extern	S_Result    *knl_EventTouchPad(int data, int x, int y);
extern	S_Result	*knl_EventAppExit(int data);
extern	void		knl_NetworkClean(void);
extern	void		(*knl_CurrentProc)(S_Event *);

#define	GNEX_CR_MARGIN					3			// black
#define	GNEX_CR_MAIN					0			// white

#define	GNEX_TEXT_DL_READY				"Connecting..."
#define GNEX_TEXT_DL_NONAME			""
#define GNEX_TEXT_DL_READY				"Connecting..."
#define GNEX_TEXT_DL_TITLE				"Downloading..."

#define GNEX_TEXT_DL_CANCEL			"Download Cancel!"
#define GNEX_TEXT_DL_FAIL				"Download Fail!"
#define GNEX_TEXT_DL_TIMEOUT			"Download Timeout!"

#define GNEX_TEXT_DL_OUTOFSSB			"Out of Script Slot!"
#define GNEX_TEXT_DL_OUTOFMEM			"Out of Memory!"
#define GNEX_TEXT_DL_GUIDE1			"To Ensure Download,"
#define GNEX_TEXT_DL_GUIDE2			"Remove Stored Script"

#define MAX_SOUND_CHANNEL		5
#define	GNEX_MAX_FILE					15

//File APIs DEF
//#define GNEX_FHANDLE_TYPE				M_Uint32
//#define GNEX_FILE_R_OPENERROR			NULL
#define GNEX_FILE_R_OPENERROR			-1
#define GNEX_DIR_CHARACTER				'/'
#define GNEX_DIR_CHARSTR				"/"





// added by sonbug: 2008.10.13 / for StrEdit

// for heap allocation
extern  int MAX_DYNAMIC_POOL;
//MAX_DYNAMIC__POOL is defined on _ConstantPool.h

extern int _DynamicPool[];
extern unsigned short _DynamicPoolDataSize[];
extern int _DynamicPoolCount;
extern const unsigned char * _ConstantPool[];
extern unsigned int  _ConstantPoolDataSize[];
extern const int _ConstantPoolCount;
extern int _ConstantPoolMap[];

extern int mm_MallocString(int * pIdx, int size);
extern char * mm_GetAddr(int idx);
extern char * mm_FindOrSetMemory(int * pStr, int size);
extern int mm_GetSize(int index);



// added by sonbug: 2008.11.1 / for StrInput, StrInput2
extern int isStrInput;
extern int swData;

#endif	//  _GNEXCOMDEF_H_

/*======================================================================

	mil.h

======================================================================*/
//==============================================================================
//
//	SINJISOFT SWAP MODULE LIBRARY HEADER
//
//	FILE NAME
//		MGL.h
//
//	DESCRIPTION
//		Mobile Interface Library Graphic Part
//
//	REFERENCES
//		SINJISOFT SWAP Porting Guide
//
//	Copyright (C) 2000, 2001 by SINJISOFT. All Rights Reserved.
//
//	HISTORY
//		2000. 5.20  Alpha Release
//		2000. 6.10  Beta Release
//		2000. 7. 3  Beta2 Release
//		2000. 7.24  Beta3 Release
//		2000. 8. 7  Version 1.0 Release
//		2000. 8.28  Version 1.01 Release
//		2000. 9.26  Version 1.02 Release
//		2000.10.27  Version 1.10 Release
//		2000.12.19	Version 1.5 Beta Start
//		2001. 1. 1	Version 1.5 Release
//		2001.10.12 	Version 1.55.01 Beta Release (True Color)
//		2001.10.17	Version 1.55.01 Release
//		2002.11.18	Version 2.0 Beta start
//		2002.12. 4	Version 2.0 Beta2 (GVM3X Merge)
//
//==============================================================================

#ifndef	_MGL_H_
#define	_MGL_H_

//==============================================================================
//
//	Definitions
//
//==============================================================================

//==============================================================
//	Maximum resolution
//

#define	MGL_MAX_WIDTH				GNEX_LCD_WIDTH
#define	MGL_MAX_HEIGHT				GNEX_LCD_HEIGHT

//==============================================================
//	LCD Type Definition
//

#define	MGL_LCD_1BIT_BW				0
#define	MGL_LCD_2BIT_GRAY			1	// 4 Gray
#define	MGL_LCD_4BIT_GRAY			2	// 16 Gray
#define	MGL_LCD_4BIT_COLOR			3	// 16 Color
#define	MGL_LCD_8BIT_COLOR			4	// 256 Color
#define	MGL_LCD_12BIT_COLOR			5	// 4K Color
#define	MGL_LCD_16BIT_COLOR			6	// 64K Color
#define	MGL_LCD_18BIT_COLOR			7
#define	MGL_LCD_24BIT_COLOR			8
#define	MGL_LCD_32BIT_COLOR			9		//--32bit color buffer by Kwak J.H.

#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
#define	MGL_LCD_MAJOR				MGL_LCD_16BIT_COLOR
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
#define	MGL_LCD_MAJOR				MGL_LCD_32BIT_COLOR		//--32bit color buffer
#endif		//GNEX_LCD_SIZE

//==============================================================
//	Color Definitions
//

#define MGL_GRAY0					0x00		// White
#define MGL_GRAY1					0x01		// Light Gray
#define MGL_GRAY2					0x02		// Dark Gray
#define MGL_GRAY3					0x03		// Black
#define MGL_TRANSPARENT				0x04		// Transparent color

#define MGL_WHITE					MGL_GRAY0
#define MGL_BLACK					MGL_GRAY3

#define	MGL_MASTER_PAL_MAX			182			// 0-3/16-139=Pure color, 4=Tansparent color, 5-15/140-181=Blink color

#define	MGL_GAMMA_MAX				7

//==============================================================
//	mgl_ShadeRect Effect Definition
//

#define	MGL_SHADE_L2R				0		// left -> right
#define	MGL_SHADE_T2B				1		// top -> bottom
#define	MGL_SHADE_LT2RB				2		// left-top -> right-bottom
#define	MGL_SHADE_RT2LB				3		// right-top -> left-bottom
#define	MGL_SHADE_IN2OUT_ROUND		4		// in -> out round
#define	MGL_SHADE_IN2OUT_RECT		5		// in -> out rect
#define	MGL_SHADE_IN2OUT_DIA		6		// in -> out dia
#define	MGL_SHADE_IN2OUT_CROSS		7		// in -> out cross

//==============================================================
//	Image Type Info Definitions
//

/*

	typedef	__packed struct _VDI_Header1 {
		BYTE	type;				// 1bit, 2bit, 4bit, 8bit
		BYTE	w, h;				// Width, height
		INT1	cx, cy;				// Hot spot
		BYTE	palette[n];			// Palette data
		BYTE	*bitmap;			// Bitmap data
	} VDI_Header;

*/

#define VDI_TYPE_GRAY1				2		// VDI image type
#define VDI_TYPE_GRAY2				3
#define VDI_TYPE_GRAY4				4

#define VDI_TYPE_COLOR1				5
#define VDI_TYPE_COLOR2				6
#define VDI_TYPE_COLOR4				7
#define VDI_TYPE_COLOR8				8

// Added by melooks - 07.06.20
#define VDI_TYPE_TC1				9
#define VDI_TYPE_TC2				10
#define VDI_TYPE_TC4				11
#define VDI_TYPE_TC8				12
#define VDI_TYPE_MAX				13
#define VDI_TYPE_EX					0x80 

#define VDI_4GRAY_HEADER			5 // type(1byte),Width(1byte), Height(1byte), xCoord(1byte), yCoord(1byte) 
#define VDI_4GRAYEX_HEADER			9 // type(1byte),Width(2byte), Height(2byte), xCoord(2byte), yCoord(2byte) 
#define VDI_TCOLOR_HEADER			7 // type(1byte),Width(1byte), Height(1byte), xCoord(1byte), yCoord(1byte), User Pal(1byte)
#define VDI_TCOLOREX_HEADER			11 // type(1byte),Width(2byte), Height(2byte), xCoord(2byte), yCoord(2byte), Transparent color(1byte) User Pal(1byte)

/*

	typedef	__packed struct _VDI_Header2 {
		BYTE	type;				// 1bit, 2bit, 4bit, 8bit
		BYTE	w, h;				// Width, height
		INT1	cx, cy;				// Hot spot
		BYTE	transparent_flag;	// 0=no transparent
		BYTE	pal_size;			// 2~256
		BYTE	palette[n][3];		// RGB Palette data
		BYTE	*bitmap;			// Bitmap data
	} VDI_Header;

*/


// Modified by melooks - 07.06.20
/*
#define VDI_TYPE_TC1				9
#define VDI_TYPE_TC2				10
#define VDI_TYPE_TC4				11
#define VDI_TYPE_TC8				12

// VDI image field access function

#define	VDI_TYPE(img)				(*((img)) & 0x7F)			// Get image type
//#define	VDI_TYPE(img)				(*((img) + 0))			// Get image type
#define	VDI_WIDTH(img)				(*((img) + 1))			// Get image width
#define	VDI_HEIGHT(img)				(*((img) + 2))			// Get image height
#define	VDI_CX(img)					((INT1)*((img) + 3))	// Get image hot-spot x
#define	VDI_CY(img)					((INT1)*((img) + 4))	// Get image hot-spot y

#define	VDI_PAL_PTR(img)			((img) + 5)				// Gray/256 image palette address
#define	VDI_TRFLAG(img)				(*((img) + 5))			// Truecolor image transparent flag
#define	VDI_PALSIZE(img)			(*((img) + 6))			// Truecolor image palette size
#define	VDI_TCPAL_PTR(img)			((img) + 7)				// Truecolor image palette address

#define	VDI_BITMAP_GRAY1(img)		((img) + 6)				// Bitmap address of VDI_TYPE_GRAY1
#define	VDI_BITMAP_GRAY2(img)		((img) + 7)				// Bitmap address of VDI_TYPE_GRAY2
#define	VDI_BITMAP_GRAY4(img)		((img) + 5)				// Bitmap address of VDI_TYPE_GRAY4

#define	VDI_BITMAP_COLOR1(img)		((img) + 7)				// Bitmap address of VDI_TYPE_COLOR1
#define	VDI_BITMAP_COLOR2(img)		((img) + 9)				// Bitmap address of VDI_TYPE_COLOR2
#define	VDI_BITMAP_COLOR4(img)		((img) + 21)			// Bitmap address of VDI_TYPE_COLOR4
#define	VDI_BITMAP_COLOR8(img)		((img) + 5)				// Bitmap address of VDI_TYPE_COLOR8

#define	VDI_BITMAP_TC1(img)			((img) + 11)			// Bitmap address of VDI_TYPE_TC1
#define	VDI_BITMAP_TC2(img)			((img) + 15)			// Bitmap address of VDI_TYPE_TC2
*/

#define	VDI_TYPE(img)				( *((img) + 0) & 0x7F )			// Get image type
#define VDI_ISEX(img)				( (*(img) & VDI_TYPE_EX) == 0 ) 

#define	VDI_WIDTH(img)				( VDI_ISEX(img) ? (*((img) + 1)) : EXVDI_WIDTH(img))		// Get image width		-modify 2byte
#define	VDI_HEIGHT(img)				( VDI_ISEX(img) ? (*((img) + 2)) : EXVDI_HEIGHT(img))		// Get image height		-modify 2byte
#define	VDI_CX(img)					( VDI_ISEX(img) ? ((INT1)*((img) + 3)) : EXVDI_CX(img))	// Get image hot-spot x	-modify 2byte
#define	VDI_CY(img)					( VDI_ISEX(img) ? ((INT1)*((img) + 4)) : EXVDI_CY(img))	// Get image hot-spot y	-modify 2byte

#define	VDI_PAL_PTR(img)			( VDI_ISEX(img) ? ((img) + 5) : ((img) + 9)	)			// Gray/256 image palette address		//+4byte
#define	VDI_TRFLAG(img)				( VDI_ISEX(img) ? (*((img) + 5)) : (*((img) + 9)))			// Truecolor image transparent flag
#define	VDI_PALSIZE(img)			( VDI_ISEX(img) ? (*((img) + 6)) : (*((img) + 10)))			// Truecolor image palette size
#define	VDI_TCPAL_PTR(img)			( VDI_ISEX(img) ? ((img) + 7) : ((img) + 11))				// Truecolor image palette address

#define	VDI_BITMAP_GRAY1(img)		( VDI_ISEX(img) ? ((img) + 6) : ((img) + 10))				// Bitmap address of VDI_TYPE_GRAY1
#define	VDI_BITMAP_GRAY2(img)		( VDI_ISEX(img) ? ((img) + 7) : ((img) + 11))				// Bitmap address of VDI_TYPE_GRAY2
#define	VDI_BITMAP_GRAY4(img)		( VDI_ISEX(img) ? ((img) + 5) : ((img) + 9)	)			// Bitmap address of VDI_TYPE_GRAY4

#define	VDI_BITMAP_COLOR1(img)		( VDI_ISEX(img) ? ((img) + 7) : ((img) + 11))				// Bitmap address of VDI_TYPE_COLOR1
#define	VDI_BITMAP_COLOR2(img)		( VDI_ISEX(img) ? ((img) + 9) : ((img) + 13))				// Bitmap address of VDI_TYPE_COLOR2
#define	VDI_BITMAP_COLOR4(img)		( VDI_ISEX(img) ? ((img) + 21) : ((img) + 25))			// Bitmap address of VDI_TYPE_COLOR4
#define	VDI_BITMAP_COLOR8(img)		( VDI_ISEX(img) ? ((img) + 5) : ((img) + 9)	)			// Bitmap address of VDI_TYPE_COLOR8

#define	VDI_BITMAP_TC1(img)			( VDI_ISEX(img) ? ((img) + 11) : ((img) + 15))			// Bitmap address of VDI_TYPE_TC1
#define	VDI_BITMAP_TC2(img)			( VDI_ISEX(img) ? ((img) + 15) : ((img) + 19))			// Bitmap address of VDI_TYPE_TC2

#define	EXVDI_WIDTH(img)				(((INT2)(*((img) + 2)) << 8) | ((INT2)(*((img) + 1))))		// Get image width		-modify 2byte
#define	EXVDI_HEIGHT(img)				(((INT2)(*((img) + 4)) << 8) | ((INT2)(*((img) + 3))))			// Get image height		-modify 2byte
#define	EXVDI_CX(img)					(((INT2)(*((img) + 6)) << 8) | ((INT2)(*((img) + 5))))	// Get image hot-spot x	-modify 2byte
#define	EXVDI_CY(img)					(((INT2)(*((img) + 8)) << 8) | ((INT2)(*((img) + 7))))	// Get image hot-spot y	-modify 2byte

//#define VDI_HEADER_SIZE(img)		( VDI_ISEX(img) ? 7 : 11)		
#define VDI_HEADER_SIZE			7
#define VDI_EXHEADER_SIZE		11	

// end

//==============================================================
//	Pixel Operation & Alpha-Blending Definitions
//

#define VDI_OP_OPAQUE				0		// Image operation & alpha-blending
#define VDI_OP_ALPHA_75PCT			1
#define VDI_OP_ALPHA_50PCT			2
#define VDI_OP_ALPHA_25PCT			3
#define VDI_OP_INVERT				4
#define VDI_OP_XOR					5
#define VDI_OP_MAX					6

//==============================================================
//	Geometry Definitions
//

#define	VDI_ROTATE_0				0		// Image rotation
#define	VDI_ROTATE_90				1
#define	VDI_ROTATE_180				2
#define	VDI_ROTATE_270				3
#define	VDI_ROTATE_MAX				4
#define VDI_ROTATE_MIN				-4

//#define	VDI_ROTATE_MIN				-360
//#define	VDI_ROTATE_MAX				360


#define VDI_SCROLL_BUFSIZE			512		// Max LCD width, for scroll buffer


//==============================================================
//	rotate minimum angle Definitions
//

#define MGL_ANGLE_MIN				5
//==============================================================
//	Font Definition
//

#define	MGL_FONT_SMALL				0		// Font size
#define	MGL_FONT_MEDIUM				1
#define	MGL_FONT_LARGE				2
#define	MGL_FONT_DOUBLE				3
// -----------------------------------------------------------------------------------------------------------
// SJKim   05.06.01
// -----------------------------------------------------------------------------------------------------------
#define	MGL_FONT_MAX				4
/*
#define	MGL_FONT_HUGE				4
#define	MGL_FONT_HUGE_DOUBLE		5
#define	MGL_FONT_MAX				6
*/
// -----------------------------------------------------------------------------------------------------------

#define	MGL_ALIGN_LEFT				0		// Font alignment
#define	MGL_ALIGN_CENTER			1
#define	MGL_ALIGN_RIGHT				2
#define	MGL_ALIGN_MAX				3

#define	MGL_STYLE_NORMAL			0		// Font style
#define MGL_STYLE_BOLD				1
#define MGL_STYLE_ITALIC			2
#define MGL_STYLE_UNDERLINE			4
#define	MGL_STYLE_MAX				8

//==============================================================================
//
//	DDB(Device Dependent Bitmap) Functions
//
//==============================================================================

/*

	typedef	__packed struct _DDB_Header {
		BYTE	devType;
		BYTE	trFlag;
		BYTE	width;
		BYTE	height;
		BYTE	left_margin;
		BYTE	top_margin;
		DWORD	trColor;				//--32bit color buffer
		DWORD	bitmap[width*height];	//--32bit color buffer
	};

*/

#define	DDB_HEADER_SIZE				8

#define	DDB_DEVTYPE(buf)			(*((BYTE*)(buf) + 0))		// Get device type
#define	DDB_TRFLAG(buf)				(*((BYTE*)(buf) + 1))		// Get transparent flag
#define	DDB_WIDTH(buf)				(*((BYTE*)(buf) + 2))		// Get block width
#define	DDB_HEIGHT(buf)				(*((BYTE*)(buf) + 3))		// Get block height
#define	DDB_LEFT_SPC(buf)			(*((BYTE*)(buf) + 4))		// Get block left margin
#define	DDB_TOP_SPC(buf)			(*((BYTE*)(buf) + 5))		// Get block top margin
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
#define	DDB_TRCOLOR(buf)			(*((WORD*)(buf) + 3))		// Get transparent color	
#define	DDB_BITMAP(buf)				((WORD*)(buf) + 4)			// Get bitmap pointer		
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
#define	DDB_TRCOLOR(buf)			(*((DWORD*)(buf) + 3))		// Get transparent color	//--32bit color buffer
#define	DDB_BITMAP(buf)				((DWORD*)(buf) + 4)			// Get bitmap pointer		//--32bit color buffer
#endif		//GNEX_LCD_SIZE


/*---------------------------------------------------------------------------

  	LCD Stretch �ó����� ���� : Added by KHJ 2004.09.14

---------------------------------------------------------------------------*/
#define CARRIER_STERTCH_APPLY_MASK	0x80	// Stretch ���� ���� Masking
#define CARRIER_STERTCH_APPLY_YES	0x80	// Stretch ���� ��
#define CARRIER_STERTCH_APPLY_NO	0x00	// Stretch ���� ����

#define CARRIER_STRETCH_MASK		0xF0	// Stretch �Ǵܿ� ���Ǵ� ���� 4bit Masking
#define CARRIER_STRETCH_AUTO		0x80	// �ڵ� Stretch : �������� �ʴ� ���. ����ڰ� ������ �������� �ʾ�����
#define CARRIER_STRETCH_3TO4		0x90	// 1.3�� Ȯ��
#define CARRIER_STRETCH_2TO3		0xA0	// 1.5�� Ȯ��
#define CARRIER_STRETCH_1TO2		0xB0	// 2.0�� Ȯ��

#define STRETCH_POWER_ORIGINAL		0
#define STRETCH_POWER_3TO4			1
#define STRETCH_POWER_2TO3			2
#define STRETCH_POWER_1TO2			3


//==============================================================================
//
//	Data Structures
//
//==============================================================================

//==============================================================
//	Image parsing parameters
//

typedef struct _ImgProcInfo {

	BYTE	palSize;			//  0 Palette size
	BYTE	bmpOffset;			//  2 Bitmap offset

	BYTE	imgShift1;			//  4 Shift parameter 1
	BYTE	imgShift2;			//  6 Shift parameter 2

	BYTE	imgShift3;			//  8 Shift parameter 3
	BYTE	imgShift4;			// 10 Shift parameter 4

	BYTE	imgMask5;			// 12 Mask parameter 1
	BYTE	imgMask6;			// 14 Mask parameter 2

} ImgProcInfo;

//==============================================================
//	Image transformation parameters
//

typedef struct _TransformInfo {

	INT2	pixMov;				//  0 Pixel move step
	INT2	scanMov;			//  2 Scan move step

	INT2	xmovx;				//  4 Transformation matrix
	INT2	xmovy;				//  6 Transformation matrix

	INT2	ymovx;				//  8 Transformation matrix
	INT2	ymovy;				// 10 Transformation matrix

} TransformInfo;

//==============================================================
//	Alpha-blending parameters
//
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
typedef	struct	_AlphaInfo {
	WORD	dstMask1;	
	WORD	dstMask2;	
	WORD	srcMask1;	
	WORD	srcMask2;	
} AlphaInfo;
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
typedef	struct	_AlphaInfo {
	DWORD	dstMask1;	//--32bit color buffer
	DWORD	dstMask2;	//--32bit color buffer
	DWORD	srcMask1;	//--32bit color buffer
	DWORD	srcMask2;	//--32bit color buffer
} AlphaInfo;
#endif		//GNEX_LCD_SIZE


//==============================================================
//	Font information
//

typedef struct _FontControl {

	BYTE	*m_pAsciiFont;		// 0-3  Ascii font buffer
	BYTE	*m_pKoreanFont;		// 4-7  Korean font buffer
	BYTE	*m_pSymbolFont;		// 8-11 Korean symbol font buffer

	BYTE	m_bAsciiByteLen;	// 12 Ascii char buffer length
	BYTE	m_bKoreanByteLen;	// 13 Korean char buffer length
	BYTE	m_bDispWidth;		// 14 Drawable pixel width
	BYTE	m_bDispHeight;		// 15 Drawable pixel height

	BYTE	m_bIsDouble;		// 16 Is 2x2 drawing
	BYTE	m_bItalicMargin;	// 17 Italic margin
	BYTE	m_bStartSlope;		// 18 Italic slope step
	BYTE	m_bMoveSlope;		// 19 Italic slope slice
	
} FontControl;

//==============================================================
//	Global graphic parameter data structure
//

typedef struct _GraphInfo {

	//========================
	// Global graphic control
	//========================

	INT2	m_nViewportLeft;
	INT2	m_nViewportTop;
	INT2	m_nViewportRight;
	INT2	m_nViewportBtm;


//	BYTE	*m_pbLcdBuf;					//  0 Foreground LCD buffer
//	BYTE	*m_pbBackBuf;					//  4 Background LCD buffer
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
//	WORD	*m_pwLcdBufWord;				//  8 Foreground LCD buffer(WORD ptr)
//	WORD	*m_pwBackBufWord;				// 12 Background LCD buffer(WORD ptr)
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
//	DWORD	*m_pwLcdBufWord;				//  8 Foreground LCD buffer(WORD ptr)	--32bit color buffer
//	DWORD	*m_pwBackBufWord;				// 12 Background LCD buffer(WORD ptr)	--32bit color buffer
#endif		//GNEX_LCD_SIZE
	
	INT2	m_nLcdWidth, m_nLcdHeight;		// 16 LCD Width
	WORD	m_wLcdRowFeed, m_wLcdColFeed;	// 20 Column enhancement
//	INT2	m_nCenterX, m_nCenterY;			// 24 Coordinate center

	INT2	m_nClipLeft, m_nClipRight;		// 28 Clipping area
	INT2	m_nClipTop, m_nClipBtm;			// 32 Clipping area
	
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
	WORD	*m_pwMasPal;					// 36 Current master palette
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
	DWORD	*m_pwMasPal;					// 36 Current master palette	--32bit color buffer
#endif		//GNEX_LCD_SIZE
	
	BYTE	m_bMasColorIdx;					// 40 Pixel color index
	BYTE	m_bGamma;						// 41 Gamma correction
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
	WORD	m_wDevColor;					// 42 Device pixel color
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
	DWORD	m_wDevColor;					// 42 Device pixel color		--32bit color buffer
#endif		//GNEX_LCD_SIZE

	DWORD	m_dwLcdByteLen;					// 44 Total LCD buffer byte size
	WORD	m_wFrame6;						// 48 Blink counter

	BYTE	m_bAlphaDefault;				// 50 Alpha-blending
	BYTE	m_bZoomDefault;					// 51 Zooming
	BYTE	m_bMirrorDefault;				// 52 Mirroring
	BYTE	m_bRotateDefault;				// 53 Rotate image

	BYTE	m_bFontDefault;					// 54 Font type
	BYTE	m_bForeColorDefault;			// 55 Default String color
	BYTE	m_bBackColorDefault;			// 56 String back color
	BYTE	m_bAlignDefault;				// 57 String alignment
	BYTE	m_bStyleDefault;				// 58 String drawing mode

	BYTE	m_bActBuf;						// 59 Activate frame buffer

	//========================
	// Image control
	//========================

	BYTE	m_bAlpha;						// 60 Alpha-blending
	BYTE	m_bZoom;						// 61 Zooming
	BYTE	m_bMirror;						// 62 Mirroring
	BYTE	m_bRotate;						// 63 Rotate image

	BYTE	m_bType;						// 64 Image type
	BYTE	padding[3];						// 65-67

	BYTE	*m_pbImgAddr;					// 68 Image block
	BYTE	*m_pbBitmap;					// 72 Bitmap data or Font data

	INT2	m_nX, m_nY;						// 76 Drawing position
	INT2	m_nSx, m_nSy;					// 80 Skip margin
	INT2	m_nWidth, m_nHeight;			// 84 Width, height

	INT2	m_nWidth0;						// 88 Original width
	WORD	m_wTrIndex;						// 90 Transparent index

#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
	WORD	m_wDevPal[256];					// 92 HW palette
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
	DWORD	m_wDevPal[256];					// 92 HW palette	--32bit color buffer
#endif		//GNEX_LCD_SIZE


	ImgProcInfo		m_ImgProc;				// Image bit depth information

		//	BYTE	palSize;				// 604 Palette size
		//	BYTE	bmpOffset;				// 605 Bitmap offset
		//	BYTE	imgShift1;				// 606 Shift parameter 1
		//	BYTE	imgShift2;				// 607 Shift parameter 2
		//	BYTE	imgShift3;				// 608 Shift parameter 3
		//	BYTE	imgShift4;				// 609 Shift parameter 4
		//	BYTE	imgMask5;				// 610 Mask parameter 1
		//	BYTE	imgMask6;				// 611 Mask parameter 2

	TransformInfo	m_Trans;				// Image transformation information

		//	INT2	pixMov;					// 612 Pixel move step
		//	INT2	scanMov;				// 614 Scan move step
		//	INT2	xmovx;					// 616 Transformation matrix
		//	INT2	xmovy;					// 618 Transformation matrix
		//	INT2	ymovx;					// 620 Transformation matrix
		//	INT2	ymovy;					// 622 Transformation matrix
	
	AlphaInfo		m_Alpha;				// Alpha-blending information

		//	WORD	dstMask1;				// 624
		//	WORD	dstMask2;				// 626
		//	WORD	srcMask1;				// 628
		//	WORD	srcMask2;				// 630

} GraphInfo;								// Total size 632 bytes (if JA108, 636 bytes)


typedef struct _StretchInfo {
		// ���� LCD Stretch ����� Ȯ���ų GNEX ����
		int		LcdWidth;
		int		LcdHeight;

		// ���� ������� ��Ȯ��� ������ ���� Pixel ��
		int		nLeftGap;
		int		nRightGap;
		int		nUpGap;
		int		nDownGap;
} StretchInfo;

//==============================================================================
//
//	MGL System Variables
//
//==============================================================================

extern	const	ImgProcInfo	s_ImgProcDB[];
extern  TransformInfo		s_TransformDB[4][2];
extern  const	AlphaInfo	s_AlphaDB[];
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
extern  const	WORD		s_MasterPalCr64k[7][6][MGL_MASTER_PAL_MAX];
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
extern  const	DWORD		s_MasterPalCr64k[7][6][MGL_MASTER_PAL_MAX];		//--32bit color buffer
#endif		//GNEX_LCD_SIZE
extern  FontControl			s_FontDB[6];
extern	GraphInfo			s_Grp;
extern	StretchInfo			s_Stretch;
extern	int sBigLcdStretchMode;
//==============================================================================
//
//	External MGL Functions
//
//==============================================================================

// Math library
// capsbada : int -> unsigned
extern	unsigned int	mgl_Sqrt(unsigned int n);
extern	void 	mgl_RandSeed(int randSeed);
extern	int 	mgl_Rand(int min, int max);
extern	int		mgl_RandRatio(int ratio);
extern	int 	mgl_Abs(int value);
extern	int	 	mgl_Sgn(int value);
extern	int	 	mgl_Sin100(register int angle);
extern	int	 	mgl_Cos100(register int angle);
extern	int	 	mgl_Tan100(register int angle);
extern	int 	mgl_ASin100(register int arc);
extern	int 	mgl_ACos100(register int arc);
extern	int 	mgl_ATan100(register int arc);
extern	int 	mgl_Avr(int a, int b);
extern	int 	mgl_Avr3(int a, int b, int c);
extern	int 	mgl_Max(int a, int b);
extern	int 	mgl_Max3(int a, int b, int c);
extern	int 	mgl_Min(int a, int b);
extern	int 	mgl_Min3(int a, int b, int c);
extern	int 	mgl_FindMax(SINT4 *ptr, int size);
extern	int 	mgl_FindMin(SINT4 *ptr, int size);
extern	int 	mgl_FindNear(SINT4 *ptr, int size, int key);
extern	void	mgl_SetA2VOp(void);
extern	int 	mgl_ArrayToVar(SINT4 *addr, int value, int size, int op);
extern	void	mgl_SetA2AOp(void);
extern	int 	mgl_ArrayToArray(SINT4 *addr1, SINT4 *addr2, int size, int op);
extern	void	mgl_SetA2A2Op(void);
extern	int 	mgl_ArrayToArray2(SINT4 *addr1, SINT4 *addr2, SINT4 *addr3, int size, int op);
extern	int 	mgl_HitCheck(int v1, int v2, int d);

// System setup function

extern	void	mgl_Initialize(int width, int height, BYTE *foreBuf, BYTE *backBuf);
extern	void	mgl_SetBlinkFrame(int frame6);
extern	void	mgl_GetLcdInfo(int *size, int *width, int *height, int *colormodel);

extern	void	mgl_SetCenterPoint(int x, int y);						// JA108 Microcode 1
extern	void	mgl_SetClip(int x1, int y1, int x2, int y2);			// JA108 Microcode 2
extern	void	mgl_ResetClip(void);									// JA108 Microcode 3
extern	void	mgl_SetActiveBuffer(int lcd);							// JA108 Microcode 4
extern	void	mgl_SetGamma(int gamma);								// JA108 Microcode 5
extern	void	mgl_SetColor(int mpi);									// JA108 Microcode 6
extern	void	mgl_SetColorRGB(int r, int g, int b);					// JA108 Microcode 7

extern	void	mgl_SetShadeColor(int c1, int c2);
extern	void	mgl_SetShadeColorRGB(int r1, int g1, int b1, int r2, int g2, int b2);

extern	void	mgl_GetCenterPoint(int *x, int *y);
extern	void	mgl_GetClip(int *x1, int *y1, int *x2, int *y2);
extern	int		mgl_GetActiveBuffer(void);
extern	int		mgl_GetGamma(void);
extern	int		mgl_GetColor(void);

// Color conversion

extern	int		mgl_RGBToIndex(int r, int g, int b);
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
extern	WORD	mgl_RGBToDEV(int r, int g, int b);
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
extern	DWORD	mgl_RGBToDEV(int r, int g, int b);		//--32bit color buffer
#endif		//GNEX_LCD_SIZE

// Put pixel

extern	void	mgl_PutPixel(int x, int y, int mpi);
extern	void	mgl_PutPixelRGB(int x, int y, int r, int g, int b);
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
extern	void	mgl_PutPixelDEV(int x, int y, WORD dev);
extern	WORD	mgl_GetPixel(int x, int y);				
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
extern	void	mgl_PutPixelDEV(int x, int y, DWORD dev);		//--32bit color buffer
extern	DWORD	mgl_GetPixel(int x, int y);				//--32bit color buffer
#endif		//GNEX_LCD_SIZE

// LCD operations

extern	void	mgl_Clear(int mpi);										// JA108 Microcode 8
extern	void	mgl_ClearPartial(int sx, int sy, int ex, int ey, int mpi);
extern	void	mgl_ClearRGB(int r, int g, int b);						// JA108 Microcode 9
extern	void	mgl_ClearPartialRGB(int sx, int sy, int ex, int ey, int r, int g, int b);

extern	void	mgl_CopyLCD(int dir);									// JA108 Microcode 10

extern	void	mgl_ScrollLCD(int lcd, int dx, int dy, int wrap);

// 2D primitive functions

extern	void	mgl_DrawLine(int x1, int y1, int x2, int y2);

extern	void	mgl_DrawPoly(int x[], int y[], int size);
extern	void	mgl_FillPoly(int x[], int y[], int size);

extern	void	mgl_DrawRect(int x1, int y1, int x2, int y2);
extern	void	mgl_FillRectEx(int x1, int y1, int x2, int y2, int alpha);
extern	void	mgl_FillRect(int x1, int y1, int x2, int y2);
extern	void	mgl_ShadeRect(int x1, int y1, int x2, int y2, int dir, int wave);

extern	void	mgl_DrawRectRound(int x1, int y1, int x2, int y2, int r);
extern	void	mgl_FillRectRound(int x1, int y1, int x2, int y2, int r);

extern	void	mgl_DrawEllipse(int cx, int cy, int rx, int ry);
extern	void	mgl_FillEllipse(int cx, int cy, int rx, int ry);
extern	void	mgl_ShadeEllipse(int cx, int cy, int rx, int ry, int dir, int wave);


// DDB(Device Dependent Bitmap) functions

extern	int		mgl_GetDDBSize(int width, int height);
#if (GNEX_LCD_SIZE == GNEX_LCD_16BIT)
extern	void	mgl_GetDDB(WORD *buf, int x, int y, int width, int height, int trFlag, WORD trColor);	
extern	void	mgl_PutDDB(WORD *buf, int x, int y);
#elif(GNEX_LCD_SIZE == GNEX_LCD_32BIT)
extern	void	mgl_GetDDB(DWORD *buf, int x, int y, int width, int height, int trFlag, DWORD trColor);	//--32bit color buffer
extern	void	mgl_PutDDB(DWORD *buf, int x, int y);			//--32bit color buffer
#endif		//GNEX_LCD_SIZE


// SIS image handling

extern	int		mgl_BuildSisHeader(BYTE *buf, int type, int width, int height, BYTE *palette, int palinfo);

// VDI(Variable Depth Image) functions

extern	int		mgl_GetPaletteColor(BYTE *block, int index);
extern	int		mgl_GetPaletteColorRGB(BYTE *block, int index, int *r, int *g, int *b);
extern	int		mgl_SetPaletteColor(BYTE *block, int index, int mpi);
extern	int		mgl_SetPaletteColorRGB(BYTE *block, int index, int r, int g, int b);

extern	void	mgl_SetImageAlpha(int alpha);							// JA108 Microcode 11
extern	void	mgl_SetImageZoom(int zoom);								// JA108 Microcode using acc_SetByteParam 12
extern	void	mgl_SetImageMirror(int mirror);							// JA108 Microcode using acc_SetByteParam
extern	void	mgl_SetImageRotate(int rotate);							// JA108 Microcode using acc_SetByteParam

extern	int		mgl_GetImageAlpha(void);
extern	int		mgl_GetImageZoom(void);
extern	int		mgl_GetImageMirror(void);
extern	int		mgl_GetImageRotate(void);

extern	void	mgl_CopyImagePalEx(BYTE *block, int x, int y, BYTE *palette, int alpha,
								   int zoom, int mirror, int rotate);	// JA108 Microcode 13 (heavy)
extern	void	mgl_CopyImageEx(BYTE *block, int x, int y, int alpha,
								int zoom, int mirror, int rotate);		// JA108 Microcode using mgl_CopyImagePalEx
extern	void	mgl_CopyImagePal(BYTE *block, int x, int y,
								 BYTE *palette);						// JA108 Microcode using mgl_CopyImagePalEx
extern	void	mgl_CopyImage(BYTE *block, int x, int y);				// JA108 Microcode using mgl_CopyImagePalEx

extern	void	mgl_CopyImageTile(BYTE *block, int x1, int y1, int x2, int y2,
								  int alpha, int zoom, int mirror, int rotate);

// Text display functions

extern	void	mgl_SetFontColor(int fcr, int bcr);						// JA108 Microcode 14
extern	void	mgl_SetFont(int font);									// JA108 Microcode using acc_SetByteParam
extern	void	mgl_SetFontAlign(int align);							// JA108 Microcode using acc_SetByteParam
extern	void	mgl_SetFontStyle(int style);							// JA108 Microcode using acc_SetByteParam

extern	void	mgl_GetFontColor(int *fcr, int *bcr);
extern	int		mgl_GetFont(void);
extern	int		mgl_GetFontAlign(void);
extern	int		mgl_GetFontStyle(void);
extern	int		mgl_GetFontWidth(void);
extern	int		mgl_GetFontHeight(void);
extern	int		mgl_GetStringWidth(char *str);

extern	void	mgl_DrawStringEx(int x, int y, char *str, int solid, int font, int fcr, int bcr, int align, int style);
extern	void	mgl_DrawString(int x, int y, char *str, int solid);
extern  void	mgl_StretchCopyImagePalEx(BYTE* block, int x, int y, BYTE *palette, int alpha, int zoom, int mirror, int rotate,int ex,int ey);
extern  void	mgl_StretchCopyImageHSPalEx(BYTE* block, int x, int y, BYTE *palette, int alpha, int zoom, int mirror, int rotate,int ex,int ey);

// For prevoius version

#define	mil_DrawLineV(x, y1, y2)						mgl_DrawLine(x, y1, x, y2)
#define	mil_DrawLineH(x1, x2, y)						mgl_DrawLine(x1, y, x2, y)
#define	mil_CopyImage(block, x, y)						mgl_CopyImagePalEx(block, x, y, NULL, 0, 0, 0, 0)
#define	mil_DrawString(x, y, str, f, fcr, a)			mgl_DrawStringEx(x, y, str, 0, f, fcr,   0, a, 0)
#define	mil_DrawStringSolid(x, y, str, f, fcr, bcr, a)	mgl_DrawStringEx(x, y, str, 1, f, fcr, bcr, a, 0)

#endif // _MGL_H_

/*======================================================================

	gnexcore.h

======================================================================*/

#ifndef	_GNEXCORE_H_
#define	_GNEXCORE_H_

//#include "GNEXCOMDEF.h"
//#include "mil.h"

//	constants
#define	GNEX_STACK_SIZE				512
#define	GNEX_PC_STACK_SIZE			128

#define	GNEX_MEDIA_ACCEPT_DIFF		16

#define	GNEX_ELEM_CONST				0			// Constant flag
#define	GNEX_ELEM_VAR				1			// Variable flag

#define	GNEX_NUMBER_OF_TIMER		3
#define	GNEX_NUMBER_OF_TICK			10

#define	GNEX_TIMER_TICK				50
#define	GNEX_NET_TIMER_TICK			50

#define	GNEX_2X_SSB_SIZE			0x40000		// 256K
#define	GNEX_2X_WRK_SIZE			0x10000		// 64K
#define	GNEX_MIN_MEMORY				0x80000		// 512K
#define	GNEX_MIN_HEAP				0x10000		// 64K

#define	GNEX_MAX_SYSTEM_VAR			16

#define	PF_ALT						0x08		/* alternate form */
#define	PF_LADJUST					0x10		/* left adjustment */
#define	PF_ZEROPAD					0x20		/* zero (as opposed to blank) pad */
#define	PF_HEXPREFIX				0x40		/* add 0x or 0X prefix */

#define	PF_MAXCHAR					255


/*---------------------------------------------------------------------------

	GNEX memory manager constant

---------------------------------------------------------------------------*/
#define	MM_N_FREE					1024
#define	MM_N_ALLOC					1024

/*---------------------------------------------------------------------------

	GNEX static library constant

---------------------------------------------------------------------------*/
//#define SL_N_LIB					392
#define SL_N_LIB					393		// getSysMdn



/*---------------------------------------------------------------------------

  GNEX script type

---------------------------------------------------------------------------*/
#define GNEX_STYPE_ALONE			1
#define GNEX_STYPE_SERVER			3
#define GNEX_STYPE_FREE				4

//�ٿ�ε� ��� ������ 2X ������ �� Ÿ�� ��ȯ�� ���� �߰� by ldj 20040816 
//#define	GNEX_STYPE_ALONE_PTP		4		// Stand-alone + Phone-to-phone
//#define	GNEX_STYPE_ALONE_SERVER		5		// Stand-alone + TCP/IP
#define	GNEX_STYPE_PTP_SERVER		6		// Phone-to-phone + TCP/IP
#define	GNEX_STYPE_ALL				7		// Stand-alone + Phone-to-phone + TCP/IP

/*---------------------------------------------------------------------------

  GNEX result code

---------------------------------------------------------------------------*/
#define GNEX_RST_RECON_FAIL				0
#define	GNEX_RST_RECON_OK				1
#define	GNEX_RST_TEDIT_DONE				2
#define	GNEX_RST_MDOWN_OK				3
#define	GNEX_RST_MDOWN_FAIL				4
#define	GNEX_RST_INVALID_LCD			5
#define	GNEX_RST_RCV_CHAT				6
#define	GNEX_RST_SMS_OK					7
#define	GNEX_RST_SMS_FAIL				8
#define	GNEX_RST_DISCON_OK				9
#define	GNEX_RST_DISCON_FAIL			10
#define	GNEX_RST_TALK_FAIL				11
#define	GNEX_RST_PTPCON_OK				12
#define	GNEX_RST_PTPCON_FAIL			13
#define	GNEX_RST_PTPREL_OK				14
#define	GNEX_RST_PTPREL_FAIL			15
#define	GNEX_RST_ABN_DISCON				16
#define	GNEX_RST_ABN_PTPREL				17
#define	GNEX_RST_CONTINUE				18

#define GNEX_RST_SCREEN_OK				19		// Not used for compatiblity
#define GNEX_RST_SCREEN_FAIL			20		// Not used for compatiblity
#define GNEX_RST_MUSICBELL_OK			21		// Not used for compatiblity
#define GNEX_RST_MUSICBELL_FAIL			22		// Not used for compatiblity

#define GNEX_RST_SOUND_END				23

#define	GNEX_RST_VOD_PLAY_END			24
#define	GNEX_RST_VOD_RECORD_END			25

#define	GNEX_RST_COM_READ				26	
#define	GNEX_RST_COM_WRITE				27

#define GNEX_RST_STREDIT_DONE			29		//add for StrEdit by Kjaehwa 2005.06.14

// PLLAB - Stretch LCD - 081014 shko
/*---------------------------------------------------------------------------
  	LCD Stretch �ó����� ���� : Added by KHJ 2004.09.14
---------------------------------------------------------------------------*/
#define CARRIER_STERTCH_APPLY_MASK	0x80	// Stretch ���� ���� Masking
#define CARRIER_STERTCH_APPLY_YES	0x80	// Stretch ���� ��
#define CARRIER_STERTCH_APPLY_NO	0x00	// Stretch ���� ����

#define CARRIER_STRETCH_MASK		0xF0	// Stretch �Ǵܿ� ���Ǵ� ���� 4bit Masking
#define CARRIER_STRETCH_AUTO		0x80	// �ڵ� Stretch : �������� �ʴ� ���. ����ڰ� ������ �������� �ʾ�����
#define CARRIER_STRETCH_3TO4		0x90	// 1.3�� Ȯ��
#define CARRIER_STRETCH_2TO3		0xA0	// 1.5�� Ȯ��
#define CARRIER_STRETCH_1TO2		0xB0	// 2.0�� Ȯ��

#define STRETCH_POWER_ORIGINAL		0
#define STRETCH_POWER_3TO4			1
#define STRETCH_POWER_2TO3			2
#define STRETCH_POWER_1TO2			3


/*---------------------------------------------------------------------------

  GNEX download result reason

---------------------------------------------------------------------------*/
// ----------------------------------------------------------------------------------------------------------
// SJKim 050519
// ----------------------------------------------------------------------------------------------------------
#define	GNEX_RR_DOWNLOAD				0
#define	GNEX_RR_CONNECT_START			1
#define	GNEX_RR_CONNECT_FROM_ALONE		2
#define	GNEX_RR_CONNECT_FROM_SVR		3
// ----------------------------------------------------------------------------------------------------------
/*---------------------------------------------------------------------------

  GNEX continue result reason

---------------------------------------------------------------------------*/
// ----------------------------------------------------------------------------------------------------------
// SJKim 050519
// ----------------------------------------------------------------------------------------------------------

//#define	GNEX_RR_RUNALONE				0
//#define	GNEX_RR_SELECT					1
//#define	GNEX_RR_SVRSELECT				2
//#define	GNEX_RR_PTPSELECT				3
//#define	GNEX_RR_PTPREADY					4
//#define	GNEX_RR_PTPDIAL					5
//#define	GNEX_RR_PTPDIAL_FROM_ALONE		6
//#define	GNEX_RR_SVRDOWNLOAD_RETRY		7
//#define	GNEX_RR_DOWNLOAD_COMP				8
//#define	GNEX_RR_LOADMENU					9
//#define	GNEX_RR_DECOMPMENU				10
// ----------------------------------------------------------------------------------------------------------

/*---------------------------------------------------------------------------

  GNEX exception code

---------------------------------------------------------------------------*/
#define	GNEX_ECPT_STOP_OP				0
#define	GNEX_ECPT_DIV_ZERO				1
#define	GNEX_ECPT_MOD_ZERO				2
#define	GNEX_ECPT_SYM_OVER				3
#define	GNEX_ECPT_MDA_OVER				4
#define	GNEX_ECPT_STACK_OVER			5
#define	GNEX_ECPT_PCSTACK_OVER			6
#define	GNEX_ECPT_INVALID_OP			7
#define	GNEX_ECPT_INVALID_SYM_INDEX		8
#define	GNEX_ECPT_INVALID_MDA_INDEX		9
#define	GNEX_ECPT_INVALID_SYM_ADDR		10
#define	GNEX_ECPT_INVALID_MDA_ADDR		11
#define	GNEX_ECPT_OUT_OF_DIM			12
#define GNEX_ECPT_MEM_OVER				13
#define GNEX_ECPT_ALLOC_FAIL			14
#define GNEX_ECPT_INVALID_SLIB			15
#define GNEX_ECPT_INIT_DLL				16

/*---------------------------------------------------------------------------

  GNEX network code

---------------------------------------------------------------------------*/
// ----------------------------------------------------------------------------------------------------------
// SJKim 050519
// ----------------------------------------------------------------------------------------------------------
/*
#ifdef GNEX_FEATURE_NETWORK
 #define GNEX_RCV_NONE					1
 #define GNEX_RCV_DLCOMP				2
 #define GNEX_RCV_DLSSBERR				3
 #define GNEX_RCV_DLMEMERR				4
 #define GNEX_RCV_DLSCRERR				5
 #define GNEX_RCV_DLSIZEERR				6
 #define GNEX_RCV_DLSUMERR				7
 #define GNEX_RCV_DLAUTHERR				8
 #define GNEX_RCV_DLPKTERR				9
#endif

#ifdef GNEX_DOWNLOAD_PKTRETRY
  #define GNEX_RCV_DLPKTSKIP			10
  #define GNEX_RCV_DLPROCFAIL			11
  #define GNEX_RCV_DLRELFAIL			12
 #endif

 #ifdef GNEX_DOWNLOAD_RCVERR
  #define GNEX_RCV_DLNAKERR				13
 #endif

//==============================================================
//	Send code of s_SendNak
//
 #ifdef GNEX_DOWNLOAD_SNDERR
  #define GNEX_NAK_DLRETRY				0
  #define GNEX_NAK_DLSSBERR				1
  #define GNEX_NAK_DLMEMERR				2
  #define GNEX_NAK_DLSCRERR				3
  #define GNEX_NAK_DLSIZEERR			4
  #define GNEX_NAK_DLSUMERR				5
  #define GNEX_NAK_DLAUTHERR			6
  #define GNEX_NAK_DLPKTERR				7
  #define GNEX_NAK_DLTIMEOUTERR			8
  #define GNEX_NAK_DLUSREXIT			9
 #endif
*/
// ----------------------------------------------------------------------------------------------------------

/*---------------------------------------------------------------------------

	3x symbol and media table structure

---------------------------------------------------------------------------*/
typedef PACKED struct _SymTbl 
{
	BYTE	var;							// 0=Const, 1=Variable
	BYTE	init;							// 0=No data, 1=Init data in pool
	UINT2	dim;							// Dimension
	SINT4	*addr;
} SymTbl;

/*---------------------------------------------------------------------------

	3x symbol and media table structure

---------------------------------------------------------------------------*/
typedef PACKED struct _MdaTbl 
{
	BYTE	var;							// 0=Const, 1=Variable with init, 2=Variable without init
	BYTE	type;							// 0x00=String, 0x01=Image, 0x02=Sound, 0x03=Vocoder
	BYTE	reserved[2];					// added to make 4 multiple of media table size
	UINT4	size;							// Media size
	BYTE*	addr;
} MdaTbl;

/*---------------------------------------------------------------------------

	GNEX opcode handler

---------------------------------------------------------------------------*/
typedef struct _OpHandler 
{
	void (*_OpHandle)(void);
} OpHandler;

/*---------------------------------------------------------------------------

	GNEX static library handler

---------------------------------------------------------------------------*/
typedef struct _SlHandler 
{
	void (*_SlHandle)(void);
} SlHandler;


/*---------------------------------------------------------------------------

	3x sgs application header structure
		GNEX SGS��� ����ü

---------------------------------------------------------------------------*/
typedef PACKED struct _S_HeaderType2 
{
	////////////////////////////////
	// Script info
	////////////////////////////////
	// 0x00:
	BYTE	AppPlayerVer;
	BYTE	LcdClass;
	BYTE	ImageType;
	BYTE	AudioType;
	BYTE	CarrierType;				// 1=SKT, 2=Orange				
	BYTE	AppType;					// = ScriptType of GVM2X
	// 0x06:
	WORD	AppCPID;					// application creator ID
	WORD	AppID;						// application ID
	char	AppName[16];				// application name
	// 0x1A:
	BYTE	AppCompType;				// 0=Normal 1=Compress
	BYTE	AgentType;					// 0=Normal 1=Agent

	////////////////////////////////
	// Entry table
	////////////////////////////////
	// 0x1C:
	DWORD	StartEntry;
	DWORD	EndEntry;
	DWORD	TimerEntry;
	DWORD	KeyEntry;
	DWORD	RSEventEntry;
	DWORD	RSReceiveEntry;
	DWORD	ResultEntry;
	DWORD	ReceiveEntry;
	DWORD	NetEntry;
	DWORD	SMSRecvEntry;
	DWORD	GenericEntry;
	////////////////////////////////
	// Data table
	////////////////////////////////
	// 0x44:
	DWORD	SymTable;
	DWORD	SymPool;
	DWORD	MediaTable;
	DWORD	MediaPool;	
	DWORD	LinkFuncTable;	
	// 0x58:
	BYTE	ValidCount;
	BYTE	ValidTerm;
	BYTE	DirectRun;				// 0=Normal 1=DirectRun
	BYTE	AppSaveType;			// 0=save as Non compression 1=save as compression
	BYTE	ServiceState;			// 0=Not used(default) 1=Service
	BYTE	ComfirmType;			
	WORD	AppVer;					// application version
	// 0x60
	DWORD	AppAuth;				// Application auth code	
	DWORD	UserAuth;				// User auth code	
	// 0x5E:
	BYTE	Reserved[10];			// Not used
	// 0x76:
	WORD	AppDynLib;				// number of dll import function
	DWORD	AppSize;				// application BYTE size
	DWORD	VerifyStamp;			// Verification stamp
	// 0x80: Compress start point
} S_HeaderType2;

/*---------------------------------------------------------------------------

	GNEX memory manager data structure

---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------
	Heap�� ���� Free Block�� �����ϴ� ����ü
---------------------------------------------------------------------------*/
typedef struct _FREEBlock 
{
	SINT4	size;
	SINT4	offset;
} FREEBlock;

/*--------------------------------------------------------------------------------
	Heap�� ��� Alloc Block�� �����ϴ� ����ü
--------------------------------------------------------------------------------*/
typedef struct _ALLOCBlock 
{
	SINT4	size;
	SINT4	offset;
} ALLOCBlock;

/*---------------------------------------------------------------------------

	Dynamic library opcode enumeration

---------------------------------------------------------------------------*/
// ----------------------------------------------------------------------------------------------------------
// SJKim 050519
// ----------------------------------------------------------------------------------------------------------
/*
enum {
	dllNOP = 0x00,
	dllPUSHX,		dllPUSHI,		dllPUSHIC,		dllPUSHZ,		dllPUSHC,
	dllPUSHMI,		dllPUSHW,		dllPOPX,		dllPOPI,		dllPOPIC,
	dllPOPZ,		dllSSP,			dllRSP,			dllINC,			dllDEC,
	dllDUP,			dllNEG,			dllSWP,			dllADD,			dllSUB,
	dllMULT = 0x50,
	dllDIV,			dllMOD,			dllAND,			dllOR,			dllNOT,
	dllXOR,			dllSHIFTR,		dllSHIFTL,		dllGT,			dllLT,
	dllGE,			dllLE,			dllEQ,			dllNE,			dllSETX,
	dllSETI,		dllSETN,		dllSETZ,		dllSETC,		dllSETMI,
	dllISETX,		dllISETI,		dllISETN,		dllISETZ,		dllISETC,
	dllISETMI,		dllNSETX,		dllNSETI,		dllNSETN,		dllNSETZ,
	dllNSETC,		dllNSETMI,		dllZSETX,		dllZSETI,		dllZSETN,
	dllZSETZ,		dllZSETC,		dllZSETMI,		dllINCX,		dllINCI,
	dllINCN,		dllINCZ,		dllGTJP,		dllLTJP,		dllGEJP,
	dllLEJP,		dllEQJP,		dllNEJP,		dllUJP,			dllTJP,
	dllFJP,			dllCALL = 0x85,
	dllRET,			dllSTOP,		dllSKIP,		dllSTNX,		dllSTNI,
	dllSTNIC,		dllSTNZ,		dllLDRIC,		dllLDRZ,		dllIXA,
	dllSTA,			dllSTAN,		dllCALLS,		dllCALLD,		dllCOPYIMAGE,
	dllCOPYIMAGEDIR,	dllCOPYIMAGEPAL,	dllCOPYIMAGEDIRPAL,	dllCOPYIMAGEEX,	dllCOPYIMAGEPALEX,
	dllPUSHIXQ = 0xCA,	dllPUSHICZQ,	dllPOPIXQ,	dllPOPICZQ,		dllSETIXQ,
	dllSETNZQ,		dllSETCQ,		dllNSETIXQ,		dllNSETNZQ,		dllNSETCQ,
	dllINCIXQ,		dllINCNZQ,		dllSTNIXQ,		dllSTNICZQ,		dllLDRICZQ,
	dllPUSHIX2Q,	dllPUSHICZ2Q,	dllPOPIX2Q,		dllPOPICZ2Q,	dllSETIX2Q,
	dllSETNZ2Q,		dllSETC2Q,		dllNSETIX2Q,	dllNSETNZ2Q,	dllNSETC2Q,
	dllINCIX2Q,		dllINCNZ2Q,		dllSTNIX2Q,		dllSTNICZ2Q,	dllLDRICZ2Q,

	// Short Add opcode add by moonchild, 03/07/03
	dllADDZZC,		dllADDZZCQ,		dllADDZZC2Q,	dllADDZZ,		dllADDZZQ,
	dllADDZZ2Q,		dllADDZ,		dllADDZQ,		dllADDZ2Q,		dllADDLDRZC,
	dllADDLDRZCQ,	dllADDLDRZC2Q,
	dllEND = 0xFF
};
*/

/*---------------------------------------------------------------------------

	Dynamic library header structure

---------------------------------------------------------------------------*/
// ----------------------------------------------------------------------------------------------------------
// SJKim 050519
// ----------------------------------------------------------------------------------------------------------
/*
typedef PACKED struct _DLLHeader {
	WORD	AuthCode;
	WORD	Type;
	char	Name[32];
	DWORD	Identifier;
	WORD	MajorVersion;
	WORD	MinorVersion;
	DWORD	CodeStart;
	DWORD	CodeSize;
	DWORD	SymTableStart;
	DWORD	SymTableSize;
	DWORD	SymPoolStart;
	DWORD	SymPoolSize;
	DWORD	MediaTableStart;
	DWORD	MediaTableSize;
	DWORD	MediaPoolStart;
	DWORD	MediaPoolSize;
	DWORD	MetaInfoStart;
	DWORD	RuntimeLibraryCount;
	DWORD	SRLSize;
} DLLHeader;
*/
// ----------------------------------------------------------------------------------------------------------


/*---------------------------------------------------------------------------

	reserved symbol enumeration

---------------------------------------------------------------------------*/
enum {
	SYM_RSVD1,
	SYM_RSVD2,
	SYM_RSVD3,
	SYM_RSVD4,
	SYM_RSVD5,
	SYM_RSVD6,
	SYM_RSVD7,
	SYM_RSVD8,
	SYM_RSVD9,
	SYM_RSVD10,
	SYM_RSVD11,
	SYM_RSVD12,
	SYM_RSVD13,
	SYM_RSVD14,
	SYM_RSVD15,
	SYM_RSVD16,
	SYM_RSVD17,
	SYM_RSVD18,
	SYM_RSVD19,
	SYM_RSVD20,
	SYM_RSVD_SIZE
};

/*---------------------------------------------------------------------------

	3x stack macro

---------------------------------------------------------------------------*/
#define	STOP0()							gpStack[sTop]
#define	STOP1()							gpStack[sTop-1]
#define	STOP2()							gpStack[sTop-2]
#define	STOP3()							gpStack[sTop-3]
#define	STOP4()							gpStack[sTop-4]
#define	STOP5()							gpStack[sTop-5]
#define	STOP6()							gpStack[sTop-6]
#define	STOP7()							gpStack[sTop-7]
#define STOP8()							gpStack[sTop-8]
#define STOP9()							gpStack[sTop-9]

#define	GP_PUSH(A)						{ gpStack[++sTop] = (A); }
#define GP_POP(A)						{ (A) = gpStack[sTop--]; }


/*---------------------------------------------------------------------------

	3x check macros

---------------------------------------------------------------------------*/
#define	GP_CHECK_STACK_OVERFLOW(top)	if ((top) >= GNEX_STACK_SIZE || (top)<-1) { s_Exception(GNEX_ECPT_STACK_OVER); return; }
#define	GP_CHECK_SYMBOL_DIM(A, c)		if ((c) >= gpSymTable[A].dim) { s_Exception(GNEX_ECPT_OUT_OF_DIM); return; }
#define	GP_CHECK_SYMBOL_INDEX(i)		if ((i) >= gpSymSize) { s_Exception(GNEX_ECPT_INVALID_SYM_INDEX); return; }
#define	GP_CHECK_SYMBOL_ADDR(p)			if (!(gpSymPool <= (p) && (p) < gpSymPoolLast)) { s_Exception(GNEX_ECPT_INVALID_SYM_ADDR); return; }
#define	GP_CHECK_SYMBOL(p, A, c)		{ GP_CHECK_SYMBOL_INDEX(A); GP_CHECK_SYMBOL_DIM(A, c); (p) = gpSymTable[A].addr + (c); GP_CHECK_SYMBOL_ADDR(p); }
#define	GP_CHECK_SYMBOL0(p, A)			{ GP_CHECK_SYMBOL_INDEX(A); (p) = gpSymTable[A].addr; GP_CHECK_SYMBOL_ADDR(p); }
#define	GP_CHECK_MEDIA_INDEX(i)			if ((i) < 0 || (i) >= gpMdaSize) { s_Exception(GNEX_ECPT_INVALID_MDA_INDEX); return; }
#define	GP_CHECK_MEDIA_ADDR(p)			if (!(gpMdaPool <= (p) && (p) < gpMdaPoolLast) && !(gpHeapMdaPoolLast <= (p) && (p) < gpHeapMdaPool)) { s_Exception(GNEX_ECPT_INVALID_MDA_ADDR); return; }
// GetFrameBuffer ������ LCD Buffer Ȯ�� �ʿ� ����....modified by Moonchild. 2003.07.02
//#define GP_CHECK_MEDIA_ADDR2(p)			if (!(gpMdaPool <= (p) && (p) < gpMdaPoolLast) && !(gpHeapMdaPoolLast <= (p) && (p) < gpHeapMdaPool) && !(gpFrameBufferStart <= (p) && (p) < gpFrameBufferEnd)) { s_Exception(GNEX_ECPT_INVALID_MDA_ADDR); return; }
#define	GP_CHECK_MEDIA(p, A)			{ GP_CHECK_MEDIA_INDEX(A); (p) = gpMdaTable[A].addr; GP_CHECK_MEDIA_ADDR(p); }
//#define GP_CHECK_MEDIA2(p, A)			{ GP_CHECK_MEDIA_INDEX(A); (p) = gpMdaTable[A].addr; GP_CHECK_MEDIA_ADDR2(p); }

#define GP_CHECK_SYMBOL_ADDR2(p, A)	{														\
		if((A) & GP_HEAP_SETMASK) {															\
		if ((SINT4 *)(p) < gpHeapSymPool || gpHeapSymPoolLast <= (SINT4 *)(p)) {			\
				s_Exception(GNEX_ECPT_INVALID_SYM_ADDR);									\
				return;																		\
			}																				\
		}else {																				\
			if ((SINT4 *)(p) < gpSymPool || gpSymPoolLast <= (SINT4 *)(p)) {				\
				s_Exception(GNEX_ECPT_INVALID_SYM_ADDR);									\
				return;																		\
			}																				\
		}																					\
	}																							

// write��: System Variable���� ħ������
#define GP_CHECK_SYMBOL_ADDR3(p, A)	{														\
		if((A) & GP_HEAP_SETMASK) {															\
		if ((SINT4 *)(p) < gpHeapSymPool || gpHeapSymPoolLast <= (SINT4 *)(p)) {			\
				s_Exception(GNEX_ECPT_INVALID_SYM_ADDR);									\
				return;																		\
			}																				\
		}else {																				\
			if ((SINT4 *)(p) < gpSymPool + sizeof(SINT4) * GNEX_MAX_SYSTEM_VAR				\
				|| gpSymPoolLast <= (SINT4 *)(p)) {											\
				s_Exception(GNEX_ECPT_INVALID_SYM_ADDR);									\
				return;																		\
			}																				\
		}																					\
	}																							

#define GP_MEDIA_PTR(i)				((i < gpMdaSize) ? &gpMdaTable[i] : gp_InvalidMedia())
#define GP_MEDIA_ADDR(i)			(GP_MEDIA_PTR(i)->addr)
#define GP_MEDIA_SIZE(i)			(GP_MEDIA_PTR(i)->size)

#if defined	(GNEX_VM_FEATURE_QUICK_OPCODE)

	// GNEX�� ��ũ��. (WORD-Based Operation)	MCQ
	#define	GP_PARA_CONST_WORD(pc)		(*(SINT2*)(pc))
	#define	GP_PARA_LABEL_WORD(pc)		(*(WORD*)(pc))
	#define	GP_PARA_LABEL_DWORD_N(pc)	(*(DWORD*)(pc))
	#define GP_PARA_LABEL_DWORD(pc)		((((DWORD)(*(pc))) << 16 ) + (*(pc + 1)))
	//#define	GP_PARA_LABEL_DWORD2(pc)	(*(DWORD*)(pc+1))
	#define GP_PARA_LABEL_DWORD2(pc)	((((DWORD)(*(pc+1))) << 16 ) + (*(pc + 2)))


	#define	GP_GET_SWORD(v, a)			{ v = *(SINT2*)(a);		a ++; }
	#define	GP_GET_UWORD(v, a)			{ v = *(UINT2*)(a);		a ++; }
	//#define	GP_GET_SDWORD(v, a)			{ v = *(SINT4*)(a);		a += 2; }
	#define	GP_GET_SDWORD(v, a)			{ v = (SINT4)(((((DWORD)(*(a))) << 16 ) + (*(a + 1))));	a += 2; }
	//#define	GP_GET_UDWORD(v, a)			{ v = *(UINT4*)(a);		a += 2; }
	#define	GP_GET_UDWORD(v, a)			{ v = (UINT4)(((((DWORD)(*(a))) << 16 ) + (*(a + 1))));	a += 2; }

	// QuickCode�� ��ũ��.		MCQ
	//#define	GP_GET_POOLADDR(v, a)	{ v = (SINT4*)(sSysMem + *((DWORD*)(a)));	a += 2; }
	#define	GP_GET_POOLADDR(v, a)		{ v = (SINT4*)((BYTE*)contents + GP_PARA_LABEL_DWORD(a));	a += 2; }
	#define	GP_GET_POOLADDR2(v, a)		{ v = gpSymPool + GP_PARA_LABEL_WORD(a);	a ++; }

	#define GNEX_MAX_OPCODE				255
//-----------------------------------------------
	#define GVM_N_OPCODE				239
	#define GNEX_N_OPCODE				( 0xF5 )

//-----------------------------------------------

	typedef WORD						BASE_TYPE;
	#define	INC_COUNTER(a)				( (a)>>1 )
#else	// (GNEX_VM_FEATURE_QUICK_OPCODE)
	// GNEX�� ��ũ��. (BYTE-Based Operation)
	#define	GP_PARA_CONST_BYTE(pc)		(SINT1)(*(pc))
	#define	GP_PARA_CONST_WORD(pc)		(SINT2)(((*(pc)) << 8) + *((pc) + 1))
	#define	GP_PARA_LABEL_WORD(pc)		(WORD)(((*(pc)) << 8) + *((pc) + 1))
	#define	GP_PARA_LABEL_WORD1(pc)		(WORD)(((*((pc) + 1)) << 8) + *((pc) + 2))
	#define	GP_PARA_LABEL_DWORD(pc)		(DWORD)(((*(pc)) << 24) + ((*((pc) + 1)) << 16) + ((*((pc) + 2)) << 8) + *((pc) + 3))
	#define	GP_PARA_LABEL_DWORD1(pc)	(DWORD)(((*((pc) + 1)) << 24) + ((*((pc) + 2)) << 16) + ((*((pc) + 3)) << 8) + *((pc) + 4))
	#define	GP_PARA_LABEL_DWORD2(pc)	(DWORD)(((*((pc) + 2)) << 24) + ((*((pc) + 3)) << 16) + ((*((pc) + 4)) << 8) + *((pc) + 5))

	#define PARA_CONST(pc)				GP_PARA_CONST_BYTE(pc)
	#define PARA_LABEL(pc)				GP_PARA_LABEL_WORD(pc)
	#define PARA_LABEL1(pc)				GP_PARA_LABEL_WORD1(pc)

	#define	GP_GET_N_SBYTE(v, a, n)		{ v=(SINT1)(*((a)+(n))); ((a)+=((n)+1)); }
	#define	GP_GET_N_UBYTE(v, a, n)		{ v=(UINT1)(*((a)+(n))); ((a)+=((n)+1)); }
	#define	GP_GET_SBYTE(v, a)			GP_GET_N_SBYTE(v, a, 0)
	#define	GP_GET_UBYTE(v, a)			GP_GET_N_SBYTE(v, a, 0)
	#define	GP_GET_N_SWORD(v, a, n)		{ v=(SINT2)(((*((a)+(n)))<<8) + *((a)+(n)+1)); (a)+=((n)+2); }
	#define	GP_GET_N_UWORD(v, a, n)		{ v=(UINT2)(((*((a)+(n)))<<8) + *((a)+(n)+1)); (a)+=((n)+2); }
	#define	GP_GET_SWORD(v, a)			GP_GET_N_SWORD(v, a, 0)
	#define	GP_GET_UWORD(v, a)			GP_GET_N_UWORD(v, a, 0)
	#define	GP_GET_N_SDWORD(v, a, n)	{ v=(SINT4)(((*((a)+(n)))<<24) + ((*((a)+(n)+1))<<16) + ((*((a)+(n)+2))<<8) + *((a)+(n)+3)); (a)+=((n)+4); }
	#define	GP_GET_N_UDWORD(v, a, n)	{ v=(UINT4)(((*((a)+(n)))<<24) + ((*((a)+(n)+1))<<16) + ((*((a)+(n)+2))<<8) + *((a)+(n)+3)); (a)+=((n)+4); }
	#define	GP_GET_SDWORD(v, a)			GP_GET_N_SDWORD(v, a, 0)
	#define	GP_GET_UDWORD(v, a)			GP_GET_N_UDWORD(v, a, 0)

	#define GNEX_MAX_OPCODE				255

	#define GVM_N_OPCODE				239
	#define GNEX_N_OPCODE				154


	typedef BYTE						BASE_TYPE;
	#define	INC_COUNTER(a)				(a)
#endif // !(GNEX_VM_FEATURE_QUICK_OPCODE)

//	workspace�� rom/ram���� �ĺ� mask
//	GVM2x
#define	S_ROM_SETMASK					0x4000			// Set ROM addr index mask
#define	S_ROM_DELMASK					0xBFFF			// Reset ROM addr index mask
//	GNEX
#define GP_HEAP_SETMASK					0x40000000
#define GP_HEAP_DELMASK					0xBFFFFFFF


/*---------------------------------------------------------------------------

	GVM2X and GNEX ���� ����

---------------------------------------------------------------------------*/

extern	S_Result	sResult;
//extern	S_Event	sEvent;

extern	int		sTop;
extern	int		sPcTop;
extern	int		sSaveTop;
extern	OpHandler	sOpHandler[GNEX_MAX_OPCODE];

extern	APPInfo	sAppInfo;

//extern	int		sTextIndex;
extern	int		sRunAppVer;
extern	int		sAppType;
extern	int		sAppIndex;
extern	int		sAppVer;
extern	int		sDirectRun;
extern	int		sAgentFlag;
extern	int		sResultReason;
extern	int		sConnectingFlag;
extern	int		sRunMode;

extern	UINT4	sSaveTime[GNEX_NUMBER_OF_TIMER];
extern	BYTE	sSaveRepeat[GNEX_NUMBER_OF_TIMER];

extern	int		sAppLcdClass;
extern	int		sLcdWidth;
extern	int		sLcdHeight;

extern	BYTE	sEndCode;

/*---------------------------------------------------------------------------

	GNEX core extern variable

---------------------------------------------------------------------------*/
#if defined (GNEX_VM_FEATURE_QUICK_OPCODE)
	extern	WORD	*gpPc;								// MCQ	: GNEX�� Program Counter
	extern	WORD	*gpPcStack[GNEX_PC_STACK_SIZE];		// MCQ	: GNEX�� Program Counter Stack
#else
	#define	gpPc			sPc
	#define gpPcStack		sPcStack
#endif
// GNEX calculation stack
extern	SINT4	gpStack[GNEX_STACK_SIZE];
// symbol control variable
extern	int		gpSymSize;
extern	int		gpSymPoolSize;
extern	SymTbl	*gpSymTable;
extern	SINT4	*gpSymPool;
extern	SINT4	*gpSymPoolLast;
// media control variable
extern	int		gpMdaSize;
extern	int		gpMdaPoolSize;
extern	MdaTbl	*gpMdaTable;
extern	BYTE	*gpMdaPool;
extern	BYTE	*gpMdaPoolLast;
// heap control variable
extern	int		gpHeapSymPoolSize;
extern	SINT4	*gpHeapSymPool;
extern	SINT4	*gpHeapSymPoolLast;
extern	int		gpHeapMdaPoolSize;
extern	BYTE	*gpHeapMdaPool;
extern	BYTE	*gpHeapMdaPoolLast;

extern	SINT4	*gpData1;
extern	SINT4	*gpData2;
extern	SINT4	*gpData3;
extern	SINT4	*gpData4;

extern	SINT4	*gpVMVer;
extern	SINT4	*gpSmsRcvBuf;
extern	SINT4	*gpRcvBuf;
extern	SINT4	*gpRsRcvBuf;

extern	BYTE	*gpFrameBufferStart;
extern	BYTE	*gpFrameBufferEnd;

extern	int		gpRunFlag;


// PLLAB - Stretch LCD - 081014 shko
// Added by KHJ 2004.08.06 : ���� LCD Stretch ����� Ȯ���ų GNEX ����
extern	int		sBigLcdStretchMode;
extern	int		sStretchLcdWidth;
extern	int		sStretchLcdHeight;
// Added by KHJ 2004.08.24 : ���� ������� ��Ȯ��� ������ ���� Pixel ��
extern	int		sStretchLeftGap;
extern	int		sStretchRightGap;
extern	int		sStretchUpGap;
extern	int		sStretchDownGap;

// memory manager extern variable
extern	int		mmNFree;						// number of free block of heap
extern	int		mmNAlloc;						// number of alloc block of heap

extern	FREEBlock	mmFreeList[MM_N_FREE];			// free block list
extern	ALLOCBlock	mmAllocList[MM_N_ALLOC];		// alloc block list

//add for GNEXDM by kwak.j.h
extern	int		sSoundType;		
extern	char	sResultString[GNEX_LEN_URL + 1];

/*---------------------------------------------------------------------------

	GVM2X and GNEX ������ �Լ�

---------------------------------------------------------------------------*/
extern	void	s_ResetAllTimers(void);
extern	void	s_PauseAllTimers(void);
extern	void	s_ContinueAllTimers(void);
extern	void	s_Exception(int code);
extern	void	s_MakeStrCore( char *fstr, char *lpszFormat, int top[], int NumOfParam );


/*---------------------------------------------------------------------------

	GNEX core extern function

---------------------------------------------------------------------------*/
extern	void	gp_KeyEvent(int code);
extern	void	gp_TimerEvent(int id);
extern	void	gp_ResultEvent(int code);
extern	void	gp_NetEvent(int code, int data, int sock_id);
extern	void	gp_GenericEvent(int code, int type, int data1, int data2, BYTE *buf, int size);
extern	void	gp_StartPlayer(void);
extern	void	gp_EndPlayer(void);
extern	void	gp_PausePlayer(void);
extern	void	gp_ContinuePlayer(void);
extern	MdaTbl	*gp_InvalidMedia(void);

// GNEX memory manager extern function
extern	int		mm_AllocInt(int size);
extern	int		mm_FreeInt(SINT4 offset);
extern	int		mm_AllocMedia(int index, int size);
extern	SINT4	*mm_GetPoolAddr(SINT4 offset);
extern	SINT4	*mm_GetPoolAddrForWrite(SINT4 offset);

// GNEX static library extern function
extern	void	sl_SetHandler(void);
extern	void	sl_Call(UINT2 index);

//add for GNEXDM by kwak.j.h
extern	int		knl_GetLcdClass(int width, int height);
extern	void	gp_ReceiveEvent(int length);

#endif	// _GNEXCORE_H_

/*======================================================================

	gnexif.h

======================================================================*/

#ifndef _GNEXIF_H_
#define _GNEXIF_H_

#define IF_MAX_EVENT_Q		10
#define SEND_MAX_SIZE		1024

/*--------------------------------------------------------------------------------

	GNEX socket handle mapping structure
	
--------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------

	GNEX file handle mapping structure

--------------------------------------------------------------------------------*/
typedef struct _FILEHandle {
	GNEX_FHANDLE_TYPE	Handle;
	int		SetFlag;
} FILEHandle;

// ----------------------------------------------------------------------------------------
// 05.05.25. SJKim in GNEXCOMDEF.h
// ----------------------------------------------------------------------------------------
/*
typedef struct _SOCKETHandle 
{
	GNEX_SHANDLE_TYPE	Handle;
	int		SetFlag;
} SOCKETHandle;
*/
// ----------------------------------------------------------------------------------------
extern	SOCKETHandle	ifSHandle[GNEX_MAX_SOCKET];

extern	void		if_InitEventQ(void);
extern	S_Event	*if_FetchEventFromQueue(void);
extern	int		if_InsertEventToQueue(S_Event *event);

extern	int		if_SockOpen(int type);
extern	int		if_SockConnect(int h_sock, char *ip, UINT2 port);
extern	int		if_SockClose(int h_sock);
extern	int		if_SockSend(int h_sock, BYTE *buf, UINT2 len);
extern	int		if_SockRecv(int h_sock, BYTE *buf, UINT2 len);
extern	int		if_SockSendTo(int h_sock, BYTE *buf, UINT2 len, char *ip, UINT2 port);
extern	int		if_SockRecvFrom(int h_sock, BYTE *buf, UINT2 len, char *ip, UINT2 port);
extern	void		if_CloseAllSock(void);
extern	int		if_GetSockId(GNEX_SHANDLE_TYPE sHandle);
extern	int		if_IsEmptyOpenSock(void);

extern	int		if_CheckFileName(char *dir);
extern	int		if_FileMakeDir(char *dir);
extern	int		if_FileRemoveDir(char *dir);
extern	int		if_FileTest(char *filename);
extern	int		if_DirTest(char *dirname);
extern	int		if_FileOpen(char *filename, int openmode);
extern	int		if_FileSeek(int h_file, int offset, int origin);
extern	int		if_FileRead(int h_file, BYTE *buf, int len);
extern	int		if_FileWrite(int h_file, BYTE *buf, int len);
extern	int		if_FileDel(char *filename);
extern	int		if_FileInfo(char *filename, int *size, int *year, int *month, int *day);
extern	int		if_FileClose(int h_file);
extern	void	if_CloseAllFile(void);
extern	int		if_GetEmptyFileHandle(void);

// PLLAB - HTTP support - 081022 shko
#ifdef GNEX_FEATURE_HTTP
extern int if_HttpOpen(void);
extern int if_HttpConnect(int handle, char *url);
extern int if_HttpRequest(int handle, char *uri);
extern int if_HttpResponse(int handle, BYTE *ptr, int len);
extern int if_HttpDisconnect(int handle);
extern int if_HttpGetBodyDataLen(int handle);
extern int if_HttpGetReadBodyData(int handle, BYTE *ptr, int len);
extern void if_HttpClose(int handle);
extern void if_HttpConnectHandler(int nState, HTTPContextData* pHttpCD);
extern void if_HttpDownloadHandler(int nState, HTTPContextData* pHttpCD);
#endif

#endif

/*======================================================================

	gnexmenu.h

======================================================================*/
#ifndef _GNEXMENU_H_
#define _GNEXMENU_H_

#define	GNEX_APP_RUNMODE_NORMAL		0
#define	GNEX_APP_RUNMODE_AGENT		1

#define	GNEX_APP_RUNTYPE_NORMAL		0
#define	GNEX_APP_RUNTYPE_DIRECT		1

#define MMI_MENU_LIST			0

#define MMI_MENU_NORMAL_LIST	0
#define MMI_MENU_AGENT_LIST		1

#define MMI_MENU_NORMAL_DELETE	0
#define MMI_MENU_AGENT_DELETE	1

#define MMI_ANNUN_HEIGHT		16		//	top annunciator height
#define MMI_MENU_HEIGHT			16		//	bottom menu height
#define MMI_TEXT_LEN			32		//	mmi text length

#define MMI_MAX_EFS_SIZE		10*1024*1024
//================================
//	Timeout value
//================================
#define	MMI_LOGO_TIMEOUT			200
#define	MMI_NOAPP_TIMEOUT			3000

//================================
//	softkey feature definition
//================================
#define MMI_SOFTKEY_OK			0
#define MMI_SOFTKEY_SELECT		1
#define MMI_SOFTKEY_EXEC		2
#define MMI_SOFTKEY_CANCEL		3
#define MMI_SOFTKEY_DELETE		4
#define MMI_SOFTKEY_MENU		5
#define MMI_SOFTKEY_AGENTMENU	6
#define MMI_SOFTKEY_AGENTSET	7
#define MMI_SOFTKEY_SYS			8
#define MMI_SOFTKEY_MAX			9

#define	TEXT_MSG_DELETE_ENG		"Delete Script?"
#define	TEXT_MSG_DELETE_KOR		"�����Ͻðڽ��ϱ�?"

//================================
//	Application display data
//	structure
//================================
typedef struct _MMI_SCR_APP_LIST_T {
	int		ScrAppIndex;
	int		ScrAppRunMode;
	char	ScrAppName[GNEX_LEN_GNAME + 1];
	char	ScrAppPath[GNEX_LEN_PATH + 1];
	DWORD	ScrAppSize;
} MMI_SCR_APP_LIST_T;

//================================
//	MMI event enums
//================================
enum _mmiEvents {
	ENTER_S,
	KEYIN_S,
	TIMEOUT_S,
	NETWORK_S,		// Network Feature �߰� by capscrom 04.04.26
	SOUND_S,
	EVENT_S,
	SERIAL_S,
#ifdef GNEX_FEATURE_TOUCHPAD
	TOUCH_S,
#endif
	REPAINT_S,
	EXIT_S
};

enum _mmiErrors {
	MMI_ERROR_GET_APPINFO,
};

enum _mmiKeyCodes {
	DIGIT1_K = 1,	DIGIT2_K,		DIGIT3_K,		DIGIT4_K,		DIGIT5_K,
	DIGIT6_K,		DIGIT7_K,		DIGIT8_K,		DIGIT9_K,		DIGIT0_K,

	STAR_K,			SHARP_K,
	CLR_K,			SND_K,			END_K,
	LEFT_K,			RIGHT_K,		UP_K,			DOWN_K,			OK_K,
	F1_K,			F2_K,			ENTER_K,
	
	//ksmoon
	// Qwerty Key
	QWERTY_A_K, QWERTY_B_K, QWERTY_C_K, QWERTY_D_K, QWERTY_E_K, 
	QWERTY_F_K, QWERTY_G_K, QWERTY_H_K, QWERTY_I_K, QWERTY_J_K,
	QWERTY_K_K, QWERTY_L_K, QWERTY_M_K, QWERTY_N_K, QWERTY_O_K,
	QWERTY_P_K, QWERTY_Q_K, QWERTY_R_K, QWERTY_S_K, QWERTY_T_K,
	QWERTY_U_K, QWERTY_V_K, QWERTY_W_K, QWERTY_X_K, QWERTY_Y_K, QWERTY_Z_K,
	
	// Function key
	FUNC_AT_K,	FUNC_BACK_K, FUNC_SHIFT_K, FUNC_COMMA_K, FUNC_RETURN_K,
	FUNC_ALT_K, FUNC_SPACE_K, FUNC_PERIOD_K,
	//ksmoon

	DIGIT1_LK,		DIGIT2_LK,		DIGIT3_LK,		DIGIT4_LK,		DIGIT5_LK,
	DIGIT6_LK,		DIGIT7_LK,		DIGIT8_LK,		DIGIT9_LK,		DIGIT0_LK,

	STAR_LK,		SHARP_LK,
	CLR_LK,			SND_LK,			END_LK,
	LEFT_LK,		RIGHT_LK,		UP_LK,			DOWN_LK,		OK_LK,
	F1_LK,			F2_LK,			ENTER_LK,
	
	//ksmoon
	// Qwerty Long Key
    QWERTY_A_LK, QWERTY_B_LK, QWERTY_C_LK, QWERTY_D_LK, QWERTY_E_LK, 
	QWERTY_F_LK, QWERTY_G_LK, QWERTY_H_LK, QWERTY_I_LK, QWERTY_J_LK,
	QWERTY_K_LK, QWERTY_L_LK, QWERTY_M_LK, QWERTY_N_LK, QWERTY_O_LK,
	QWERTY_P_LK, QWERTY_Q_LK, QWERTY_R_LK, QWERTY_S_LK, QWERTY_T_LK,
	QWERTY_U_LK, QWERTY_V_LK, QWERTY_W_LK, QWERTY_X_LK, QWERTY_Y_LK, QWERTY_Z_LK,
	
	// Function Long key
	FUNC_AT_LK,	 FUNC_BACK_LK, FUNC_SHIFT_LK, FUNC_COMMA_LK, FUNC_RETURN_LK,
	FUNC_ALT_LK, FUNC_SPACE_LK,	FUNC_PERIOD_LK,

	//ksmoon

	RELEASE_K,		MMI_KEY_MAX
};

#ifdef GNEX_FEATURE_TOUCHPAD
enum _mmiTouchCodes {
	CLICK_P,
	DBCLICK_P,
	MOVE_P,
	UP_P
};
#endif

extern char uiSoftKeyText[MMI_SOFTKEY_MAX][32];

//================================
//	Event variables
//================================
extern S_Event mmiEvent;
extern S_Event mmiNextEvent;

#ifdef GNEX_FEATURE_TOUCHPAD
extern  int     tState; //Touch State
extern  int     touchTmrCheck; //Touch Timer Check
#endif // GNEX_FEATURE_TOUCHPAD

//================================
//	Application display data
//================================
extern MMI_SCR_APP_LIST_T mmiScrAppList[GNEX_SSB_SIZE];

//================================
//	Global variables
//================================
extern int mmiAgentSetFlag;		// agent application setting flag
extern int mmiAgentAppIndex;	// agent set application index

extern int mmiSelectPos;
extern int mmiLangCurrent;		// current mmi language
extern int mmiNumOfApp;			// number of application

extern int mmiUsedEfsSize;

extern int mmiLcdWidth;
extern int mmiLcdHeight;

#if (GNEX_LCD_TYPE > GNEX_LCD_WORDCOLOR_START)
 extern WORD *mmiLcdBuf;
 extern WORD *mmiBackLcdBuf;
#else
 extern BYTE *mmiLcdBuf;
 extern BYTE *mmiBackLcdBuf;
#endif

extern	char	mmiAppList[GNEX_SSB_SIZE][MMI_TEXT_LEN];
extern	char	mmiMenuTitle[MMI_TEXT_LEN];

extern	const char	*mmiGNexImgType[];
extern	const char	*mmiGNexVersion[];
extern	const char	*mmiGNexType[];

//================================
//	MMI event callbacks
//================================
extern	void	(*mmi_StatePrev)(int event, int data, int data2, int data3);
extern	void	(*mmi_StateCurrent)(int event, int data, int data2, int data3);
extern	void	(*mmi_StateNext)(int event, int data, int data2, int data3);

//Added by Kjaehwa for StrEdit 2005.06.15
extern	void	mmi_StateStrEditSymbol(int event, int data, int data2, int data3);
extern	void	mmi_StateStrEdit(int event, int data, int data2, int data3);

extern	void	mmi_InitialStrEdit( );
extern	void	mmi_SetStrEditStyle(int frame, int fcr, int bcr, int width, int height, int multiline, int helpline);
extern	void	mmi_SetStrEdit(int textindex, int cursor);
extern	int		mmi_GetStrEdit(int* textindex, int* cursor);

extern	void	mmi_StateNoApp(int event, int data);
extern	void	mmi_StateIdle(int event, int data);
extern	void	mmi_StateMenu(int event, int data);
extern	void	mmi_StateSystem(int event, int data);
extern	void	mmi_StateInitConfirm(int event, int data);
extern	void	mmi_StateFreeSpace(int event, int data);
extern	void	mmi_StateAgentMenu(int event, int data);
extern	void	mmi_StateDelMenu(int event, int data);
//extern	void	mmi_StateRun(int event, int data);
extern	void	mmi_StateAgentRun(int event, int data);
extern	void	mmi_StateDownload(int event, int data);
extern	void	mmi_StateTextEdit(int event, int data);
//extern	void	mmi_StateError(int event, int data);
extern	void	mmi_ResultHandle(S_Result *result);
extern	int		mmi_GetAppList(int type);

extern	void	mmi_StateRun(int event, int data, int data2, int data3);
extern	void	mmi_StateError(int event, int data, int data2, int data3);
extern	void	mmi_ResultHandle(S_Result *result);

extern	int		mmi_Init(int width, int height, int memSize);
extern	void	mmi_Release(void);
extern	void	mmi_InitDisplay(int lang);
extern	void	mmi_EventProc(int event, int data, int data2, int data3);
extern 	void	mmi_NetProc( int etype, int result, int State, int sid );
extern	void	wipi_TouchEventProc(int type, int x , int y);
extern	void	mm_InitRes();
				// etype: Network event type, result: True/False, sid: Sock ID
				// 2004. 4. 27�� �߰� by capscrom

extern	void	ui_DrawAnnun();

#endif	// _GNEXMENU_H_





