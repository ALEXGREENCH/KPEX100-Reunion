"""Restore the curated emulator/tool subset from a bundled original SDK installer.

Python 3.11+, standard library, and an installed 7-Zip CLI. Vendor programs
are treated as archive data and are never launched by this script.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("version", choices=("2.10", "2.12"))
    parser.add_argument("output", type=Path, help="New or empty output directory")
    parser.add_argument("--seven-zip", default="7z", help="Installed 7z executable")
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent.parent
    provenance = json.loads((bundle / "provenance.json").read_text(encoding="utf-8"))
    source = next(s for s in provenance["sdk"] if s["version"] == args.version)
    installer = bundle / source["installerPath"]
    if digest(installer) != source["sha256"] or installer.stat().st_size != source["bytes"]:
        raise ValueError("Original installer checksum mismatch")
    if args.output.is_symlink():
        raise ValueError("Output must not be a symlink")
    output = args.output.resolve()
    if output.exists() and (output.is_symlink() or not output.is_dir() or any(output.iterdir())):
        raise ValueError("Output must be a new or empty ordinary directory")
    output.mkdir(parents=True, exist_ok=True)
    members = json.loads((bundle / "sdk-member-map.json").read_text(encoding="utf-8"))
    selected = [row for row in members if row["sdkVersion"] == args.version]
    with tempfile.TemporaryDirectory(prefix="sinjisoft-static-") as scratch:
        scratch = Path(scratch)
        outer, msi, flat = [scratch / name for name in ("outer", "msi", "cab")]
        subprocess.run(
            [sys.executable, "-B", str(bundle / "tools/sdk-static.py"), str(installer), "--extract", str(outer)],
            check=True, stdout=subprocess.DEVNULL,
        )
        subprocess.run(
            [args.seven_zip, "x", str(outer / "GNEX SDK.msi"), "-o" + str(msi), "-y"],
            check=True, stdout=subprocess.DEVNULL,
        )
        subprocess.run(
            [args.seven_zip, "x", str(msi / "Data1.cab"), "-o" + str(flat), "-y"],
            check=True, stdout=subprocess.DEVNULL,
        )
        for row in selected:
            relative = PurePosixPath(row["curatedRelativePath"])
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("Unsafe curated member path")
            file_id = row["fileId"]
            if Path(file_id).name != file_id or file_id in (".", ".."):
                raise ValueError("Unsafe CAB file id")
            original = flat / file_id
            if original.is_symlink() or not original.is_file():
                raise ValueError("Missing regular CAB member: " + file_id)
            if original.stat().st_size != row["bytes"] or digest(original) != row["sha256"]:
                raise ValueError("CAB member checksum mismatch: " + file_id)
            target = output / relative
            if not target.resolve().is_relative_to(output):
                raise ValueError("Curated path escapes output")
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(original.read_bytes())
    print(f"Restored {len(selected)} unchanged files for SDK {args.version}; no vendor execution.")


if __name__ == "__main__":
    main()
