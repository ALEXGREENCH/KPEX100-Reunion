"""Verify manifest hashes without executing preserved programs."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("directory", type=Path)
args = parser.parse_args()
root = args.directory.resolve()
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
expected = {row["path"] for row in manifest["files"]} | {"manifest.json"}
actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
if actual != expected:
    raise ValueError("File set differs from manifest")
for row in manifest["files"]:
    relative = PurePosixPath(row["path"])
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("Unsafe manifest member path")
    path = root / relative
    if path.is_symlink() or not path.resolve().is_relative_to(root):
        raise ValueError("Symlink or escaping member path")
    raw = path.read_bytes()
    if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
        raise ValueError("File checksum mismatch: " + row["path"])
print(f"Verified {len(manifest['files'])} files; no preserved program execution.")
