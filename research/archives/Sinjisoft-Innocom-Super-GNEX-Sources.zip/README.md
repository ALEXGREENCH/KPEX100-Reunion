# Innocom / ICOLS / Super GNEX: preserved sources

This package preserves four unchanged HTTP HTML response bodies (312,561 bytes),
their retrieval receipts, clearly labelled derived text and scoped findings.
The two Newswire releases identify ICOLS itself as their provider. The other
originals are contemporary ETNews and Financial News reports. Dates, HTTP
failures and the distinction between announcements and shipped devices remain
explicit. Original notices are retained inside the unchanged HTML bodies.

`originals/` contains only the four successfully obtained raw HTML responses.
`derived/` contains four locally extracted text files and three Web-reader text
representations. The SEC/ADVFN representations are not original HTML and may
be partial. No exact original SEC or ADVFN HTML is claimed: direct retrieval
returned HTTP 403. No blocked-response body is presented as a source document.

The MOU (27 February 2007), later company announcements and handset customer
names provide research leads. They do not establish a new GNEX handset, shipped
Super GNEX SDK, firmware image, game binary, common ABI or WND compatibility.
No vendor software was executed. See findings.json for evidence and limits.

manifest.json records every other member's size and SHA-256. The enclosing ZIP
has its own independently recorded size/SHA-256 in the Reunion research catalog.
Source rights are separate from the Reunion MIT license.
