//==================================================================
//					����
//					
//==================================================================

%{
#DEFINE SCRIPTVER	1							//GVM 1X
#DEFINE LCDCLASS	255						//LCD ������ �׷�
#DEFINE IMAGETYPE	 12						//256COLOR
#DEFINE AUDIOTYPE 	255					//16POLY(yamaha2)
#DEFINE VOCTYPE		255
#DEFINE SCRIPTTYPE	1 						// script type - stand alone
#DEFINE SCRIPTCPID	17317				//CP ID CODE
#DEFINE SCRIPTID	30012					//APP ID CODE
#DEFINE SCRIPTNAME	"profile�׽�Ʈ"		//APP name
%}
//===============================================================================
#include "SScript.h"
//===============================================================================


void main()
{
	string buf="-_-";
	Clear(0);
	GetSysMin(buf);		//��ȭ��ȣ�� ����
	SetStrType(S_FONT_LARGE, 3, 4, S_ALIGN_LEFT);
	DrawStrSolid(10,10,buf);
	Flush();
}