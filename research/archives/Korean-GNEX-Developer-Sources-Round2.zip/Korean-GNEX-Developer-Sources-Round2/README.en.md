# Korean GVM / GNEX developer sources — round 2

Two public Naver tutorial materials were recovered on 5 November 2026.
These are **source files, with no SGS and no newly recovered runnable games**.

- `originals/3dTest-tack0829.zip` is the unchanged 31,426-byte archive from the [18 July 2006 post](https://blog.naver.com/tack0829/100026419558). It contains `3dTest.mc` and `airplane.H`; exact extracted copies are in `sources/`.
- `originals/test-1335-tack0829.mc` is the unchanged 913-byte source from the [26 June 2006 post](https://blog.naver.com/tack0829/100025603784). It calls `GetSysMin` and draws the result. This is code, not a profile or phone-data dump.

The aircraft example declares `PLAYERVER 4` and uses GNEX3D, a timer and model controls. Its author says `airplane.H` came from an SDK sample; that origin has not been independently matched by hash. The ZIP lacks `SScript.h`, `GNEX3D.h` and `GNEX3D.SSL`, which the post expects from an installed SDK. The other source declares `SCRIPTVER 1` and labels it GVM 1X in a comment. Source declarations do not validate a compiled SGS format.

No recovered program or source was executed or compiled. Buildability, current Windows usability and Reunion execution are untested. Original bytes and encoding are retained. The Reunion license does not relicense these historical third-party sources.

`manifest.json` records SHA-256, sizes, CRC32 and canonical sources. The outer ZIP and original nested ZIP passed CRC checks. Every manifested file and both extracted source copies were verified after clean extraction.

`book-leads.json` records three GNEX books. Their project discs/games were not recovered. Only the titles of 36 GBBook download-list entries were inspected. Three ZIP replay requests returned 429 and their live origins returned 404. Those archives remain content-unverified, not confirmed game-free.

Only the listed sources, original ZIP and curated descriptions are included. Temporary download URLs, blog HTML, member data and research dumps are excluded.
