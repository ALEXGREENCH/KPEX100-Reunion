aram.start()
aram.step(600)
aram.screenshot("opening.png")
aram.tap("ok", 3)
aram.step(180)
aram.screenshot("after-ok.png")
aram.tap("ok", 3)
aram.step(360)
aram.screenshot("after-second-ok.png")
aram.tap("right", 12)
aram.step(120)
aram.screenshot("after-right.png")
aram.tap("1", 3)
aram.step(180)
aram.screenshot("after-one.png")

aram.tap("ok",3)
aram.step(230)
aram.screenshot("extra-0.png")

aram.tap("ok",3)
aram.step(230)
aram.screenshot("extra-1.png")

aram.tap("ok",3)
aram.step(230)
aram.screenshot("extra-2.png")

aram.tap("ok",3)
aram.step(230)
aram.screenshot("extra-3.png")

aram.tap("ok",3)
aram.step(230)
aram.screenshot("extra-4.png")

aram.tap("ok",3)
aram.step(230)
aram.screenshot("extra-5.png")

aram.tap("down",3)
aram.step(440)
aram.screenshot("advance-0.png")

aram.tap("down",3)
aram.step(440)
aram.screenshot("advance-1.png")

aram.tap("down",3)
aram.step(440)
aram.screenshot("advance-2.png")

aram.tap("down",3)
aram.step(440)
aram.screenshot("advance-3.png")

aram.tap("down",3)
aram.step(440)
aram.screenshot("advance-4.png")

aram.tap("ok",3)
aram.step(440)
aram.screenshot("advance-5.png")

aram.tap("ok",3)
aram.step(440)
aram.screenshot("advance-6.png")

aram.tap("ok",3)
aram.step(440)
aram.screenshot("advance-7.png")

aram.tap("ok",3)
aram.step(440)
aram.screenshot("advance-8.png")

aram.screenshot("before-last-2.png")
aram.tap("ok",14)
aram.step(30)
aram.screenshot("final-2.png")
