# SPDX-License-Identifier: GPL-2.0-or-later
"""Decode observed legacy LG KDZ, MAIN and game PXO layers as data.

Requires PyCryptodome for KDZ. LZO layers require an operator-built upstream
LZO2.10 library exporting lzo1f_decompress_safe. Never supply a phone/vendor DLL.
The untouched upstream source and build command accompany this research bundle.
"""
import argparse
import ctypes
import hashlib
import importlib.util
import json
from pathlib import Path
import struct

MAX = 256 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def lzo_decoder(library):
    require(
        library is not None,
        "Supply --lzo-library built from the included upstream source",
    )
    module = ctypes.CDLL(str(library.resolve()))
    decode = module.lzo1f_decompress_safe
    decode.argtypes = [
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_size_t),
        ctypes.c_void_p,
    ]
    decode.restype = ctypes.c_int

    def unpack(slot, capacity, exact):
        require(len(slot) >= 8 and 1 <= capacity <= MAX, "Invalid LZO slot bounds")
        stream = slot[4:].rstrip(b"\xff")
        require(
            stream.endswith(b"\xe1\0\0") and len(slot) - 4 - len(stream) <= 31,
            "Unsupported LZO terminator or padding",
        )
        target = ctypes.create_string_buffer(capacity)
        used = ctypes.c_size_t(capacity)
        code = decode(stream, len(stream), target, ctypes.byref(used), None)
        require(
            code == 0
            and 0 < used.value <= capacity
            and (not exact or used.value == capacity),
            f"LZO failure/status/length: {code}, {used.value}/{capacity}",
        )
        return target.raw[: used.value]

    return unpack


def decode_pxo(raw, unpack):
    if raw.startswith(b"PXO4"):
        result = raw
    else:
        require(len(raw) >= 8, "Truncated PXO wrapper")
        total = struct.unpack_from("<I", raw)[0]
        require(48 <= total <= 64 * 1024 * 1024, "Invalid PXO total")
        result = bytearray()
        for offset in range(0, len(raw), 8192):
            slot = raw[offset : offset + 8192]
            require(len(slot) >= 8, "Truncated PXO slot")
            capacity = total if offset == 0 else struct.unpack_from("<I", slot)[0]
            require(1 <= capacity <= total, "Invalid PXO block declaration")
            result.extend(unpack(slot, capacity, offset != 0))
            require(len(result) <= total, "PXO exceeds declaration")
        require(len(result) == total, "PXO total mismatch")
    require(len(result) >= 48 and result[:4] == b"PXO4", "Missing PXO4")
    require(
        struct.unpack_from("<I", result, 8)[0] == len(result),
        "PXO internal size mismatch",
    )
    require(
        struct.unpack_from("<I", result, 12)[0] + 32 <= len(result),
        "PXO metadata outside file",
    )
    return bytes(result)


def decode_main(raw, unpack):
    start = raw.find(b"\x7fELF")
    require(start >= 512 and start + 8192 <= len(raw), "Unsupported MAIN header")
    first, second = struct.unpack_from("<2I", raw, start - 512)
    require(
        start + first + second == len(raw) and first >= 8192 and second > 0,
        "MAIN component lengths mismatch",
    )
    result = bytearray(raw[start : start + 8192])
    for offset in range(start + 8192, start + first, 0x20000):
        slot = raw[offset : min(offset + 0x20000, start + first)]
        require(len(slot) >= 8, "Truncated MAIN slot")
        count = struct.unpack_from("<I", slot)[0]
        require(
            1 <= count <= 16 * 1024 * 1024 and len(result) + count <= MAX,
            "MAIN output exceeds bound",
        )
        result.extend(unpack(slot, count, True))
    require(result[:6] == b"\x7fELF\x01\x01", "Unsupported ELF class/endian")
    fields = struct.unpack_from("<16sHHIIIIIHHHHHH", result)
    phoff, phsize, phnum = fields[5], fields[9], fields[10]
    require(
        fields[2] == 40
        and phsize == 32
        and 1 <= phnum <= 128
        and phoff + phsize * phnum <= 8192,
        "Invalid ARM ELF program header table",
    )
    ends = []
    for i in range(phnum):
        values = struct.unpack_from("<8I", result, phoff + i * phsize)
        require(
            values[1] + values[4] <= len(result),
            "ELF segment outside decoded component",
        )
        ends.append(values[1] + values[4])
    require(max(ends) == len(result), "Decoded ELF has unexpected trailing bytes")
    return bytes(result), raw[start + first :]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=["kdz", "main", "pxo"])
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path, help="New directory; never overwrite")
    parser.add_argument("--lzo-library", type=Path)
    args = parser.parse_args()
    require(0 < args.source.stat().st_size <= MAX, "Input exceeds bound")
    require(not args.output.exists(), "Output already exists")
    raw = args.source.read_bytes()
    if args.kind == "kdz":
        spec = importlib.util.spec_from_file_location(
            "legacy_kdz", Path(__file__).parent / "upstream/kdz.py"
        )
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        body = helper.find_cipher(str(len(raw))).decrypt(raw)
        require(body.startswith(b"MSCF"), "Decrypted data is not CAB")
        files = {"decoded.cab": body}
    else:
        unpack = (
            lzo_decoder(args.lzo_library)
            if args.kind == "main" or not raw.startswith(b"PXO4")
            else None
        )
        if args.kind == "pxo":
            files = {"decoded.pxo": decode_pxo(raw, unpack)}
        else:
            first, second = decode_main(raw, unpack)
            files = {"first.elf": first, "second.bin": second}
    args.output.mkdir(parents=True)
    report = {
        "kind": args.kind,
        "sourceBytes": len(raw),
        "sourceSha256": sha(raw),
        "files": [],
    }
    if args.lzo_library:
        report["operatorBuiltLzoSha256"] = sha(args.lzo_library.read_bytes())
    for name, body in files.items():
        (args.output / name).write_bytes(body)
        report["files"].append({"path": name, "bytes": len(body), "sha256": sha(body)})
    (args.output / "report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf8"
    )
    print(json.dumps(report))


if __name__ == "__main__":
    main()
