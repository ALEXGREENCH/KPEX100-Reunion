# Korean phone layers, preservation pass16

The five sibling firmware ZIPs contain all11 unchanged received7z bodies,
their network receipts, independent member CRC/hash audits and small original
game files. Each ZIP's manifest checks every other member. No phone/vendor
executable or DLL was run. These firmware images are research inputs, not
new supported Reunion boot targets or new playable SGS.

`reports/` preserves complete extraction manifests and scanner results.
`session-helpers/` contains the exact recorded helpers, including workspace
path assumptions; these are evidence, not the portable entry point below.
All source URLs, UTC, sizes and hashes are retained in receipts/reports.
The original HTML indexes and failures are under `pages/`.

## Reproduce layers

Python3.11+, PyCryptodome,7-Zip. Use a fresh directory for each output.
For LZO build your own open-source decoder; NEVER use a firmware companion DLL.
The included `fresh-lzo1f-safe.dll` is the independently built upstream Windows
decoder bound to `lzo-build-evidence.json`, not an LG library. Full upstream
LZO2.10 source and GPL are included unchanged.

Linux, from extracted lzo-2.10 source:

```sh
cc -shared -fPIC -O2 -Iinclude src/lzo1f_d2.c -o ../liblzo1f-safe.so
```

Windows, from the same source with LLVM-MinGW on PATH:

```powershell
clang -shared -O2 -Iinclude src/lzo1f_d2.c -o ../fresh-lzo1f-safe.dll
```

Extract a received7z with7-Zip. For KDZ, use the portable entry point:

```sh
python -m pip install pycryptodome
python recover-cyon.py kdz SW210721_00.kdz recovered-cab
7z x recovered-cab/decoded.cab -ocab-members
python unpack-lg-wdb.py cab-members/SW210721_00.wdb cab-members/LGSH210.dll wdb-files
```

Use the actual companion DLL/WDB names in the preserved CAB listing;
`LGSH210.dll` above is a placeholder, not a claimed original member name.
`unpack-lg-wdb.py` reads DLL size as data and never loads it.
The KDZ helper `upstream/kdz.py` is an unchanged MIT source copy from
https://github.com/michaelwright235/kdz_decrypt_encrypt . Its license is retained.

SH210/SH240 first MAIN component and original second component:

```sh
python recover-cyon.py main wdb-files/BIN/SW210721_00.bin recovered-main --lzo-library ./liblzo1f-safe.so
python recover-cyon.py pxo wdb-files/MODULE/C/Game_EyeShot.pxo recovered-pxo --lzo-library ./liblzo1f-safe.so
```

On Windows use the corresponding independently built DLL path. Flat SH100/
SH110 MAIN is a different format and intentionally rejected by this command.
Second components begin `txPI` and are retained verbatim, not claimed decoded.
Reports record source/output SHA256. Portable implementation reproduced22
recorded outputs:4CABs,4MAIN components and14PXOs, with the same LZO primitive.
It is not an independent decompression algorithm.

## Search limits

Known ordinary/XOR-A5 SGSv1/v2/v4/v36 only. Whole large images were scanned
using64MiB windows/32MiB overlap, complete bodies <=32MiB,48boundary controls,
all69 real SGS positive controls. No accepted SGS in7raw BINs,6039 LG layers,
14decodedPXOs or435nestedLKZ resources. Other packing/formats/engines are not
excluded. Firmware strings and MIME records are leads, not player binaries.

SH110 contains an identical189-byte length-prefixed registration fragment in
two images: GNEX/Sinjisoft Co.,Ltd/036.016.000/PLAYER/application/x-gnex-sgs.
The exact fragments/fields are saved; executable code extent is not recovered.
SDK1.20/1.40 and a standalone phone GNEX player remain missing.

Reunion collection/current VM code is not duplicated here. For scanning use
the repository's `tools/scan-firmware-games.py`; its64MiB input bound is explicit.
The archived window helper documents this pass's larger-file method and results.

Historical firmware and games retain original rights. MIT applies only to
the included Reunion MIT tools; recover-cyon.py and LZO have GPL-2.0-or-later.
The unchanged KDZ helper retains MIT. No original file is relicensed by Reunion.
