"""Validate contiguous length-prefixed SH110 registration fields as static data."""
from pathlib import Path
import hashlib,json,struct
base=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
out=base/'registration';out.mkdir(exist_ok=True)
rows=[]
for source in ['inspection/07-SH110/000.bin','inspection/08-SH110/wdb-files/BIN/SW110617_00.bin']:
 raw=(base/source).read_bytes();start=raw.find(b'\x07\0\0\0CONTENT\x0a\0\0\0A000200001')
 assert start>=0 and raw.find(b'\x07\0\0\0CONTENT\x0a\0\0\0A000200001',start+1)<0
 cursor=start;fields=[]
 def text(expected):
  global cursor
  at=cursor;n=struct.unpack_from('<I',raw,cursor)[0];cursor+=4
  value=raw[cursor:cursor+n];assert value==expected,(source,at,n,value)
  fields.append({'lengthOffset':at,'bytes':n,'value':value.decode('ascii')});cursor+=n
 def integer(expected):
  global cursor
  at=cursor;value=struct.unpack_from('<I',raw,cursor)[0];cursor+=4;assert value==expected
  fields.append({'offset':at,'uint32':value,'meaning':'uninterpreted scalar'})
 text(b'CONTENT');text(b'A000200001');text(b'application/x-wipi-app');integer(0);integer(1)
 for value in [b'GNEX',b'Sinjisoft Co.,Ltd',b'036.016.000']:text(value)
 integer(4)
 for value in [b'EXECUTABLE',b'PLAYER',b'MULTI-INSTANCE']:text(value)
 n=struct.unpack_from('<I',raw,cursor)[0];assert n==6
 fields.append({'lengthOffset':cursor,'bytes':n,'hex':raw[cursor+4:cursor+4+n].hex(),'meaning':'uninterpreted bytes'});cursor+=4+n
 integer(1);text(b'application/x-gnex-sgs')
 body=raw[start:cursor];path=out/(sha(body)+'.bin')
 if not path.exists():path.write_bytes(body)
 rows.append({'source':source,'sourceBytes':len(raw),'sourceSha256':sha(raw),'start':start,'endExclusive':cursor,'bytes':len(body),'sha256':sha(body),'extractedPath':path.relative_to(base).as_posix(),'fields':fields})
assert rows[0]['sha256']==rows[1]['sha256']
(base/'phone-registration.json').write_text(json.dumps({'scope':'Verified contiguous length-prefixed registration fragment in two SH110 images. Unknown integer fields and six raw bytes remain uninterpreted. This is not an extracted independently installable player or executable extent.','fragments':rows,'identicalBytes':True},indent=2)+'\n',encoding='utf8')
print(json.dumps({'fragments':len(rows),'bytesEach':rows[0]['bytes'],'sha256':rows[0]['sha256']}))
