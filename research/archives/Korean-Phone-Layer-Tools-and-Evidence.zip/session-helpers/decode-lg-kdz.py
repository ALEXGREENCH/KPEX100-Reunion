from pathlib import Path
import hashlib,importlib.util,json,subprocess

base=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('legacy_kdz',base.parent/'lg-cyon-device-research/legacy-kdz/kdz.py')
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((base/'archive-inspection.json').read_text('utf8'));reports=[]
seven='C:/Program Files/7-Zip/7z.exe'
for row in rows:
 for member in row['members']:
  if not member.get('path','').endswith('.kdz'):continue
  source=base/member['path'];target=source.with_suffix('.cab')
  assert sha(source)==member['sha256'];cipher=legacy.find_cipher(str(source.stat().st_size))
  with source.open('rb') as f:header=cipher.decrypt(f.read(4))
  r={'model':row['source']['modelDirectory'],'sourcePath':member['path'],'sourceSha256':member['sha256'],'decodedHeader':header.hex()};reports.append(r)
  if header!=b'MSCF':r['status']='unsupported-key-or-format';continue
  if not target.exists():
   cipher=legacy.find_cipher(str(source.stat().st_size))
   with source.open('rb') as f,target.open('xb') as out:
    while data:=f.read(1024*1024):out.write(cipher.decrypt(data))
  r.update(cabPath=target.relative_to(base).as_posix(),cabSha256=sha(target),cabBytes=target.stat().st_size)
  test=subprocess.run([seven,'t','-bd',str(target)],capture_output=True);(target.parent/'cab-test.txt').write_bytes(test.stdout+test.stderr);r['cabTestPassed']=test.returncode==0
  listing=subprocess.run([seven,'l','-slt','-ba',str(target)],capture_output=True);(target.parent/'cab-listing.txt').write_bytes(listing.stdout+listing.stderr)
  r['status']='cab-verified' if test.returncode==0 else 'cab-rejected'
  print(json.dumps(r),flush=True)
 (base/'lg-kdz-decoding.json').write_bytes((json.dumps(reports,ensure_ascii=False,indent=2)+'\n').encode())
