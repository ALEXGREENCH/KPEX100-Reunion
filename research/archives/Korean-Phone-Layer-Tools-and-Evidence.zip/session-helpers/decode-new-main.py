# SPDX-License-Identifier: GPL-2.0-or-later
"""Research candidate framing; reads firmware as data, never calls LG code.

Uses the previously built upstream LZO2.10 safe1F decoder.128KiB slots are
verified independently; source lengths and unchanged ELF prefix are preserved.
"""
from pathlib import Path
import ctypes,hashlib,json,struct

base=Path(__file__).resolve().parent
lib=base.parent/'lg-main-lzo-review/fresh-lzo1f-safe.dll'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(lib.read_bytes())=='46971fd48d86a48aa1fd2aeb68cc213227d58e1d296eaae4d2b586b4f48e80da'
module=ctypes.CDLL(str(lib));decode=module.lzo1f_decompress_safe
decode.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p];decode.restype=ctypes.c_int
reports=[]
for row in json.loads((base/'lg-wdb-results.json').read_text('utf8')):
 record=next(r for r in row['files'] if r['path'].startswith('BIN/'))
 source=base/row['output']/record['path'];raw=source.read_bytes();assert sha(raw)==record['sha256']
 start=raw.find(b'\x7fELF');r={'model':row['model'],'source':source.relative_to(base).as_posix(),'sourceBytes':len(raw),'sourceSha256':sha(raw),'elfOffset':start};reports.append(r)
 if start<0:
  r['status']='flat-arm-body-not-elf-slot-format';continue
 first,second=struct.unpack_from('<2I',raw,start-512)
 assert start+first+second==len(raw),(row['model'],first,second,len(raw),start)
 r.update(firstStoredBytes=first,secondStoredBytes=second)
 output=bytearray(raw[start:start+8192]);blocks=[]
 for offset in range(start+8192,start+first,0x20000):
  slot=raw[offset:min(offset+0x20000,start+first)];assert len(slot)>=8
  count=struct.unpack_from('<I',slot)[0];assert 1<=count<=16*1024*1024,(row['model'],len(blocks),hex(offset),count,slot[:20].hex(),first,second)
  stream=slot[4:].rstrip(b'\xff');assert stream.endswith(b'\xe1\0\0')
  padding=len(slot)-4-len(stream);assert padding<=31
  target=ctypes.create_string_buffer(count);used=ctypes.c_size_t(count)
  code=decode(stream,len(stream),target,ctypes.byref(used),None)
  assert code==0 and used.value==count and len(output)+count<=256*1024*1024
  data=target.raw[:count];blocks.append({'sourceOffset':offset,'storedBytes':len(slot),'declaredBytes':count,'streamBytes':len(stream),'paddingBytes':padding,'decodedOffset':len(output),'sha256':sha(data)})
  output.extend(data)
 fields=struct.unpack_from('<16sHHIIIIIHHHHHH',output);phoff,phsize,phnum=fields[5],fields[9],fields[10]
 assert fields[2]==40 and phsize==32 and phoff+phsize*phnum<=8192
 segments=[]
 for i in range(phnum):
  values=struct.unpack_from('<8I',output,phoff+i*phsize);p=dict(zip(['type','offset','vaddr','paddr','filesz','memsz','flags','align'],values))
  assert p['offset']+p['filesz']<=len(output);segments.append(p)
 r.update(status='first-elf-component-decoded',decodedBytes=len(output),decodedSha256=sha(output),blocks=blocks,programHeaders=segments,segmentsEnd=max(p['offset']+p['filesz'] for p in segments),secondHeader=raw[start+first:start+first+48].hex())
 dest=source.parent/(row['model']+'-first.elf');assert not dest.exists();dest.write_bytes(output);r['decodedPath']=dest.relative_to(base).as_posix()
 tail=source.parent/(row['model']+'-second.bin');assert not tail.exists();tail.write_bytes(raw[start+first:]);r.update(secondPath=tail.relative_to(base).as_posix(),secondSha256=sha(tail.read_bytes()))
 print(json.dumps({k:r[k] for k in ['model','status','decodedBytes','segmentsEnd','secondStoredBytes','secondHeader']}),flush=True)
 (base/'new-main-decoding.json').write_bytes((json.dumps(reports,ensure_ascii=False,indent=2)+'\n').encode())
