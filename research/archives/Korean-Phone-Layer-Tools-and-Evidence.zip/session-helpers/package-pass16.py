from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib,json,zipfile,zlib

base=Path(__file__).resolve().parent
repo=base.parent.parent/'outputs/KPEX100-Reunion'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda obj:(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
rows=read(base/'archive-inspection.json');wdb=read(base/'lg-wdb-results.json');pxo=read(base/'game-pxo-decoding.json')
archiveReports=[]

def package(name,entries):
 for name0 in entries:
  assert not PurePosixPath(name0).is_absolute() and '..' not in PurePosixPath(name0).parts and ':' not in name0 and '\\' not in name0
 manifest=[]
 for name0,value in sorted(entries.items()):
  body=value.read_bytes() if isinstance(value,Path) else value
  manifest.append({'path':name0,'bytes':len(body),'sha256':sha(body),'crc32':f'{zlib.crc32(body):08x}'})
 entries['manifest.json']=js({'schema':1,'selfExcluded':True,'files':manifest})
 target=repo/'research/archives'/name
 assert not target.exists()
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name0,value in sorted(entries.items()):
   body=value.read_bytes() if isinstance(value,Path) else value
   z.writestr(name0,body,compress_type=zipfile.ZIP_STORED if name0.endswith(('.7z','.zip','.tar.gz','.bundle')) else zipfile.ZIP_DEFLATED)
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  for r in manifest:
   body=z.read(r['path']);assert len(body)==r['bytes'] and sha(body)==r['sha256'] and f'{zlib.crc32(body):08x}'==r['crc32']
 assert target.stat().st_size<100*1024*1024
 report={'repositoryPath':target.relative_to(repo).as_posix(),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'members':len(entries),'manifestMembersVerified':len(manifest),'zipCrcPassed':True}
 archiveReports.append(report);print(json.dumps(report),flush=True)
 return report

groups=[('Samsung-Korean-Phone-Originals-Pass16.zip',lambda r:r['source']['modelDirectory'].startswith('SCH-')),
 ('LG-SH100-Original-and-Games.zip',lambda r:r['source']['modelDirectory']=='SH100'),
 ('LG-SH110-Originals-and-Games.zip',lambda r:r['source']['modelDirectory']=='SH110'),
 ('LG-SH210-Original-and-Games.zip',lambda r:r['source']['modelDirectory']=='SH210'),
 ('LG-SH240-Original-and-Games.zip',lambda r:r['source']['modelDirectory']=='SH240')]
for name,predicate in groups:
 selected=[r for r in rows if predicate(r)];entries={};sources=[]
 for row in selected:
  s=row['source'];receipt=s['receipt'];original=base/'downloads'/receipt['path'];assert sha(original.read_bytes())==receipt['sha256']
  member='originals/'+s['modelDirectory']+'/'+s['listedFilename'];entries[member]=original;sources.append({**s,'preservedPath':member})
  folder=base/row['members'][0]['path'];folder=folder.parent
  for p in folder.glob('*.txt'):entries['inspection/'+s['modelDirectory']+'/'+s['listedFilename']+'/'+p.name]=p
 entries['sources.json']=js(sources);entries['archive-inspection.json']=js(selected)
 models={r['source']['modelDirectory'] for r in selected}
 for row in wdb:
  if row['model'] not in models:continue
  for f in row['files']:
   if f['path'].startswith('MODULE/C/Game') or f['path'].startswith('MODULE/BUILTIN/GAME/'):
    p=base/row['output']/f['path'];assert sha(p.read_bytes())==f['sha256'];entries['extracted/'+row['model']+'/'+f['path']]=p
  entries['reports/'+row['model']+'-wdb-files.json']=js(row)
 for row in pxo:
  if row['model'] in models:entries['derived/'+row['decodedPath']]=base/row['decodedPath']
 entries['reports/game-pxo-decoding.json']=js([r for r in pxo if r['model'] in models])
 entries['README.txt']=('Korean phone preservation, 2026-11-07 MSK.\n\nOriginals are unchanged received7z bodies. sources.json contains original URL,\nHTTP headers, acquisition UTC, size/SHA256 and index identity. Extraction\nreports distinguish originals and derived game PXO; original games remain\nunder extracted/. All7z CRC checks and selected member independent CRC passed.\nNo firmware or vendor DLL was executed. Folder/model labels and filenames do\nnot establish complete factory state, engine support or game playability.\n\nSee sibling Korean-Phone-Layer-Tools-and-Evidence.zip for complete scans,\nall WDB file manifests, source indexes, GPL LZO sources and portable decoder.\nThe corresponding repository doc is doc/korean-phone-preservation-pass16.md.\nNo original firmware/game is relicensed under Reunion MIT.\nmanifest.json checks every other direct member by size/SHA256/CRC32.\n').encode()
 package(name,entries)

entries={'README.md':base/'toolkit-README.md','recover-cyon.py':base/'recover-cyon.py','upstream/kdz.py':base/'upstream/kdz.py','upstream/LICENSE':base/'upstream/LICENSE','lzo/lzo-2.10.tar.gz':base.parent/'lg-kdz-extractor-research/pxo-source/lzo-2.10.tar.gz','lzo/COPYING':base.parent/'lg-main-lzo-review/fresh-lzo-source/lzo-2.10/COPYING','lzo/fresh-lzo1f-safe.dll':base.parent/'lg-main-lzo-review/fresh-lzo1f-safe.dll','lzo-build-evidence.json':js(read(base.parent/'lg-main-lzo-review/evidence.json')['build'])}
for name in ['unpack-lg-wdb.py','preserve-firmware-files.py','scan-firmware-games.py']:entries[name]=repo/'tools'/name
entries['LICENSE-Reunion-MIT']=repo/'LICENSE'
for p in (base/'registration').iterdir():entries['registration/'+p.name]=p
for name in ['archive-inspection.json','firmware-seeds.json','lg-kdz-decoding.json','lg-wdb-results.json','new-main-decoding.json','game-pxo-decoding.json','game-resource-zips.json','phone-registration.json','portable-recovery-checks.json','layer-analysis.json','raw-sgs-scan.json','lg-unpacked-sgs-scan.json','decoded-pxo-sgs-scan.json','nested-resources-sgs-scan.json','window-scanner-tests.json','candidate-directories.json','known-local-archive-names.json']:
 entries['reports/'+name]=base/name
for name in ['analyze-layers.py','inspect-downloads.py','decode-lg-kdz.py','unpack-lg-cabs.py','decode-new-main.py','decode-game-pxo.py','scan-large-images.py','verify-phone-registration.py','package-pass16.py']:
 entries['session-helpers/'+name]=base/name
for folder in ['indexes','model-indexes','lg-sky-indexes']:
 for p in (base/folder).rglob('*'):
  if p.is_file():entries['pages/'+folder+'/'+p.relative_to(base/folder).as_posix()]=p
package('Korean-Phone-Layer-Tools-and-Evidence.zip',entries)

inv=read(base/'sinjisoft-source-inventory.json')
entries={'git/Sinjisoft-GLib-upstream.bundle':base/'Sinjisoft-GLib-upstream.bundle','reports/source-inventory.json':base/'sinjisoft-source-inventory.json','reports/git-acquisition-checks.json':base/'glib-acquisition-checks.json','reports/array-inventory.json':base/'glib-array-inventory.json','reports/raw-image-matches.json':base/'glib-raw-image-matches.json','reports/layer-analysis.json':base/'layer-analysis.json','session-helpers/match-glib-arrays.py':base/'match-glib-arrays.py','doc/sinjisoft-glib-source-and-namu.md':repo/'doc/sinjisoft-glib-source-and-namu.md'}
for f in inv['files']:
 p=base/'sinjisoft-raw-source'/f['path'];assert sha(p.read_bytes())==f['sha256'];entries['upstream-tree/'+f['path']]=p
for p in (base/'glib-arrays').iterdir():entries['derived/glib-arrays/'+p.name]=p
for folder in ['namu-pages','additional-pages','namu-outlinks']:
 for p in (base/folder).rglob('*'):
  if p.is_file():entries['pages/'+folder+'/'+p.relative_to(base/folder).as_posix()]=p
entries['README.txt']=('Sinjisoft GLib source preservation, 2026-11-07 MSK.\n\nSource: https://git.fifo-f.eu/raulmario28/sinjisoft\nCommit: ed4049f7189e2d9f3a7ebbc9adfc983ced04836a\nAll169 raw Git blobs /13695248bytes checked against Git SHA1 and SHA256.\nComplete received Git history:5commits, HEAD/main, independent bundle clone\nand fsck. No checkout/CRLF conversions in upstream-tree/.\nExact retrieval completion timestamp was not recorded; verification UTC and\nbundle preserved-by filesystem time are explicitly distinguished in report.\n\nNative C GLib callbacks and eight registered games, not a recovered SGS VM\nor early GNEX SDK/player. Build/playability and claimed original firmware\norigins are not established here. Literal byte arrays are derived extractions.\nNo root LICENSE is present; all existing per-file notices remain unchanged,\nincluding SINJISOFT and Sonivox. Reunion MIT does not relicense upstream.\n\nNamu primary returned403; the separate Korean namu.moe mirror returned200.\nFive outlink responses are HTML/blog shells, not acquired game packages.\nForgejo API429 responses are retained; retries were not attempted.\nOriginal HTTP bodies, derived text and receipts remain in separate folders.\nmanifest.json checks every other member by size/SHA256/CRC32.\n').encode()
package('Sinjisoft-GLib-Source-History-and-Research.zip',entries)

summary={'schema':1,'verifiedUtc':datetime.now(timezone.utc).isoformat(),'archives':archiveReports,'originalArchives':[{**{k:r['source'][k] for k in ['url','modelDirectory','listedFilename','listingUrl','listingSha256']},'receipt':r['source']['receipt'],'archiveTestPassed':r['archiveTestPassed'],'members':r['members']} for r in rows],'counts':{'received7z':len(rows),'received7zBytes':sum(r['source']['receipt']['bytes'] for r in rows),'wdbFiles':sum(len(r['files']) for r in wdb),'gamePxoFiles':len(pxo),'wrappedPxoFiles':sum(bool(r['blocks']) for r in pxo),'resourceZipMembers':435,'rawBinScans':7,'lgLayerScans':6039,'decodedPxoScans':14,'nestedResourceScans':435,'positiveControlSgs':69,'boundaryTests':48,'confirmedNewSgs':0,'newPlayableCatalogEntries':0},'portableRecovery':read(base/'portable-recovery-checks.json'),'registration':read(base/'phone-registration.json'),'mainComponents':[{k:v for k,v in r.items() if k!='blocks'} for r in read(base/'new-main-decoding.json')],'limits':'No phone code or vendor DLL executed; PXO native games are not identified as GNEX/GVM or added as supported games. SDK1.20/1.40 and standalone phone player remain missing. MIME and registration fragment do not delimit an executable player.'}
(repo/'validation/korean-phone-preservation-pass16.json').write_bytes(js(summary))
glib={'schema':1,'verifiedUtc':summary['verifiedUtc'],'archive':archiveReports[-1],'source':inv,'gitChecks':read(base/'glib-acquisition-checks.json'),'literalArrayCount':len(read(base/'glib-array-inventory.json')),'eligibleUniqueArrays':206,'anchoredComparedArrays':189,'lowDiversityArraysSkipped':17,'rawImagesCompared':7,'selectedLayersCompared':110,'exactAssetMatches':0,'registeredGameNames':['G80 Apache5','G81 Raccoon3','G82 MarsScouter3','G83 Samtris3','G84 Puzzle3','G124 Gaza2_3','G198 HamsterBox','UG01 FlyingBubble'],'namuSourceStatuses':[{k:r.get(k) for k in ['url','kind','receipt']} for r in read(base/'namu-pages/sources.json')+read(base/'additional-pages/sources.json')+read(base/'namu-outlinks/sources.json')],'limits':'Native GLib C callback library, not demonstrated SGS interpreter or SDK1.20/1.40. Historical notices preserved; original vendor authorship/firmware provenance/build/playability not independently established. Namu mirror is secondary lead index.'}
(repo/'validation/sinjisoft-glib-source-preservation.json').write_bytes(js(glib))
(base/'package-results.json').write_bytes(js(archiveReports))
