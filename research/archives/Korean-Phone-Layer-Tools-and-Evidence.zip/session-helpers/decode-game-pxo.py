# SPDX-License-Identifier: GPL-2.0-or-later
"""Decode observed8192-byte LZO1F PXO wrappers with self-built upstream decoder."""
from pathlib import Path
import ctypes
import hashlib
import json
import struct
import zipfile

base=Path(__file__).resolve().parent
lib=base.parent/'lg-main-lzo-review/fresh-lzo1f-safe.dll'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(lib.read_bytes())=='46971fd48d86a48aa1fd2aeb68cc213227d58e1d296eaae4d2b586b4f48e80da'
module=ctypes.CDLL(str(lib));decode=module.lzo1f_decompress_safe
decode.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p];decode.restype=ctypes.c_int
reports=[];zipReports=[]
for row in json.loads((base/'lg-wdb-results.json').read_text('utf8')):
 for f in row['files']:
  source=base/row['output']/f['path']
  if f['path'].endswith('data.lkz'):
   with zipfile.ZipFile(source) as z:
    assert z.testzip() is None
    zipReports.append({'source':source.relative_to(base).as_posix(),'sha256':f['sha256'],'bytes':f['bytes'],'crcPassed':True,'members':[{'path':i.filename,'bytes':i.file_size,'crc32':f'{i.CRC:08x}','sha256':sha(z.read(i))} for i in z.infolist() if not i.is_dir()]})
   continue
  if not (f['path'].startswith('MODULE/C/Game') and f['path'].endswith('.pxo')):continue
  raw=source.read_bytes();assert sha(raw)==f['sha256'];blocks=[]
  if raw.startswith(b'PXO4'):
   output=raw;kind='original-unwrapped-PXO4'
  else:
   total=struct.unpack_from('<I',raw)[0];assert 48<=total<=64*1024*1024
   output=bytearray();kind='LZO1F-8192-byte-slots'
   for offset in range(0,len(raw),8192):
    slot=raw[offset:offset+8192];assert len(slot)>=8
    declared=struct.unpack_from('<I',slot)[0];capacity=total if offset==0 else declared
    assert 1<=capacity<=total
    stream=slot[4:].rstrip(b'\xff');assert stream.endswith(b'\xe1\0\0') and len(slot)-4-len(stream)<=31
    target=ctypes.create_string_buffer(capacity);used=ctypes.c_size_t(capacity)
    status=decode(stream,len(stream),target,ctypes.byref(used),None)
    assert status==0 and (offset==0 or used.value==declared) and len(output)+used.value<=total
    body=target.raw[:used.value];blocks.append({'sourceOffset':offset,'storedBytes':len(slot),'declared':declared,'decodedBytes':len(body),'sha256':sha(body),'paddingBytes':len(slot)-4-len(stream)})
    output.extend(body)
   assert len(output)==total
  assert output[:4]==b'PXO4' and struct.unpack_from('<I',output,8)[0]==len(output)
  meta=struct.unpack_from('<I',output,12)[0];assert meta+32<=len(output)
  target=base/'game-pxo-decoded'/row['model']/source.name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(output)
  reports.append({'model':row['model'],'source':source.relative_to(base).as_posix(),'sourceBytes':len(raw),'sourceSha256':sha(raw),'kind':kind,'decodedPath':target.relative_to(base).as_posix(),'decodedBytes':len(output),'decodedSha256':sha(output),'metadataOffset':meta,'metadataWords':list(struct.unpack_from('<8I',output,meta)),'blocks':blocks})
(base/'game-pxo-decoding.json').write_text(json.dumps(reports,indent=2)+'\n',encoding='utf8')
(base/'game-resource-zips.json').write_text(json.dumps(zipReports,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(base/'decoded-pxo-scan-inputs.json').write_text(json.dumps([str((base/r['decodedPath']).resolve()) for r in reports],indent=2)+'\n',encoding='utf8')
print(json.dumps({'PXOs':len(reports),'wrapped':sum(bool(r['blocks']) for r in reports),'resourceZIPs':len(zipReports),'resourceMembers':sum(len(r['members']) for r in zipReports)}))
