"""Scan full large images with64MiB windows and32MiB overlap, not just first64MiB.

Only complete SGS bodies <=32MiB are counted. No NAND geometry/ECC is guessed.
The original64MiB parser and extraction identities are preserved unchanged.
"""
from pathlib import Path
import hashlib,importlib.util,json

base=Path(__file__).resolve().parent
repo=base.parent.parent/'outputs/KPEX100-Reunion'
spec=importlib.util.spec_from_file_location('scanner',repo/'tools/scan-firmware-games.py')
scanner=importlib.util.module_from_spec(spec);spec.loader.exec_module(scanner)

def scan(path,window=64*1024*1024,overlap=32*1024*1024):
 if not 128<=overlap<window<=scanner.MAX_INPUT_BYTES:raise ValueError('invalid windows')
 size=path.stat().st_size
 if size>512*1024*1024:raise ValueError('input exceeds512MiB')
 digest=hashlib.sha256();hits={};windows=[]
 with path.open('rb') as f:
  while block:=f.read(1024*1024):digest.update(block)
  for start in range(0,max(1,size),window-overlap):
   f.seek(start);body=f.read(window);r=scanner.scan_bytes(body)
   windows.append({'start':start,'bytes':len(body),'candidateAttempts':r['candidate_offsets_tested']})
   for h in r['containers']:
    if h['declared_body_bytes']>overlap:continue
    h={**h,'source_offset':h['source_offset']+start,'body_offset':h['body_offset']+start}
    key=(h['body_offset'],h['xor_mask'],h['decoded_body_sha256'])
    if key not in hits or h['wrapper_bytes']>hits[key]['wrapper_bytes']:hits[key]=h
   if start+window>=size:break
 assert path.stat().st_size==size
 return {'bytes':size,'sha256':digest.hexdigest(),'windows':windows,'candidate_offsets_tested':sum(w['candidateAttempts'] for w in windows),'containers':sorted(hits.values(),key=lambda h:h['body_offset']),'limit':'Complete SGS <=overlap32MiB; candidate attempt count includes overlap retests; unknown encoding/packing/native games not ruled out.'}

if __name__=='__main__':
 import sys
 output=Path(sys.argv[1]);assert not output.exists()
 paths=[Path(p) for p in (json.loads(Path(sys.argv[2][1:]).read_text('utf8')) if len(sys.argv)==3 and sys.argv[2].startswith('@') else sys.argv[2:])]
 controls=scanner.check_controls(json.loads((repo/'web/data/catalog.json').read_text('utf8')))
 result={'schema':1,'parserSourceSha256':hashlib.sha256((repo/'tools/scan-firmware-games.py').read_bytes()).hexdigest(),'positiveControls':controls,'scans':[]}
 for index,path in enumerate(paths):
  r={'path':str(path.relative_to(base)),**scan(path)};result['scans'].append(r)
  if index%100==0 or index==len(paths)-1 or r['containers']:
   output.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
  print(json.dumps({'file':r['path'],'bytes':r['bytes'],'windows':len(r['windows']),'containers':len(r['containers'])}),flush=True)
