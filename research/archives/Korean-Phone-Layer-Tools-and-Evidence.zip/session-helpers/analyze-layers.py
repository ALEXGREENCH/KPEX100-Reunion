"""Static markers, model labels and exact GLib asset comparisons; no execution."""
from pathlib import Path
import hashlib
import json
import re

base = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
markers = [b'GNEX', b'GVM', b'SINJISOFT', b'application/x-sgs', b'GameMain', b'SWAP_LCD', b'SAMSUNG', b'CYON']
arrays = json.loads((base / 'glib-array-inventory.json').read_text('utf8'))
needles = {}
for a in arrays:
    if a['bytes'] < 256 or not a['source'].startswith(('map', 'ma2', 'ma3')):
        continue
    body = (base / a['path']).read_bytes()
    off = max(range(0, min(len(body) - 31, 256), 8), key=lambda i: len(set(body[i:i+32])))
    if len(set(body[off:off+32])) >= 8:
        needles[a['sha256']] = (a, body, off)

raws = [base / m['path'] for row in json.loads((base/'archive-inspection.json').read_text('utf8')) for m in row['members'] if m.get('path','').endswith('.bin')]
wdb = json.loads((base/'lg-wdb-results.json').read_text('utf8'))
paths = raws + [base / row['output'] / f['path'] for row in wdb for f in row['files']]
for row in json.loads((base/'new-main-decoding.json').read_text('utf8')):
    paths += [base / row[k] for k in ['decodedPath','secondPath'] if k in row]
games=[]; records=[]; comparisons=[]
for path in paths:
    data = path.read_bytes(); label=path.relative_to(base).as_posix()
    record={'path':label,'bytes':len(data),'sha256':sha(data),'markers':[]}
    upper = data.upper()
    for marker in markers:
        positions=[]; start=0
        while (start:=upper.find(marker.upper(), start)) >= 0:
            if len(positions)<20:
                context=data[max(0,start-40):start+len(marker)+80]
                positions.append({'offset':start,'context':''.join(chr(c) if 32<=c<127 else '.' for c in context),'contextHex':context.hex()})
            start += len(marker)
        if positions:record['markers'].append({'marker':marker.decode(),'first20':positions})
    if path in raws or '/BIN/' in label:
        record['modelLabels'] = sorted({m.decode() for m in re.findall(rb'(?:SCH|SH|SW|M6280)[-_]?[A-Z]?[0-9]{3,6}',data)})[:100]
    records.append(record)
    game = '/MODULE/C/Game' in label or '/MODULE/BUILTIN/GAME/' in label
    if game:games.append({**{k:record[k] for k in ['path','bytes','sha256']},'header':data[:64].hex(),'kind':'native-PXO-candidate' if path.suffix.lower()=='.pxo' else 'game-directory-resource'})
    # Compare large/raw code layers and named game resources, not unrelated skins/fonts.
    if path in raws or '/BIN/' in label or game:
        matches=[]
        for a,body,off in needles.values():
            start=data.find(body[off:off+32])
            while start>=0:
                at=start-off
                if at>=0 and data[at:at+len(body)]==body:matches.append({'arraySha256':a['sha256'],'source':a['source'],'symbol':a['symbol'],'bytes':len(body),'offset':at})
                start=data.find(body[off:off+32],start+1)
        comparisons.append({'path':label,'bytes':len(data),'sha256':record['sha256'],'matches':matches})
    if len(records)%500==0:print('checked',len(records),'files',flush=True)

result={'scope':'Unmodified extracted BINs, all6089 WDB members and four derived first/second components. Markers are leads only; native PXO and GVM/GNEX are not equated. Strings alone do not establish an engine or playable game.','scannedFiles':len(records),'files':records,'gameFiles':games,'glibComparisons':comparisons,'glibTargetArrays':len(needles),'matchMethod':'Exact entire literal map/ma2/ma3 BYTE array >=256bytes after32byte anchor with at least8 distinct byte values; no code identity or playability claim.'}
(base/'layer-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'files':len(records),'gameFiles':len(games),'glibComparisons':len(comparisons),'matches':sum(len(c['matches']) for c in comparisons),'markerFiles':sum(bool(r['markers']) for r in records)}),flush=True)
