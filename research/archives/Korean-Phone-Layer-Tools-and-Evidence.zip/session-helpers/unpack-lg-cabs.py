from pathlib import Path
import hashlib,json,subprocess,sys

base=Path(__file__).resolve().parent
repo=base.parent.parent/'outputs/KPEX100-Reunion';seven='C:/Program Files/7-Zip/7z.exe'
reports=[]
for row in json.loads((base/'lg-kdz-decoding.json').read_text('utf8')):
 if not row.get('cabTestPassed'):continue
 cab=base/row['cabPath'];folder=cab.parent/'cab-files';folder.mkdir(exist_ok=True)
 text=(cab.parent/'cab-listing.txt').read_text('utf8').replace('\r\n','\n');members=[]
 for index,block in enumerate(text.split('\n\n')):
  attrs={k:v for line in block.splitlines() if ' = ' in line for k,v in [line.split(' = ',1)]}
  if 'Path' not in attrs:continue
  name=attrs['Path'];ext=Path(name).suffix.lower();assert ext in ['.dll','.wdb']
  target=folder/(str(index)+ext)
  if not target.exists():
   with target.open('xb') as stream:subprocess.run([seven,'e','-so','-bd','-spd',str(cab),'--',name],stdout=stream,stderr=subprocess.PIPE,check=True)
  assert target.stat().st_size==int(attrs['Size'])
  members.append({'name':name,'path':target.relative_to(base).as_posix(),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 output=cab.parent/'wdb-files';assert output.resolve().is_relative_to(base.resolve())
 wdb=next(base/r['path'] for r in members if r['name'].lower().endswith('.wdb'));dll=next(base/r['path'] for r in members if r['name'].lower().endswith('.dll'))
 r={'model':row['model'],'members':members,'output':output.relative_to(base).as_posix()}
 if not output.exists():
  result=subprocess.run([sys.executable,str(repo/'tools/unpack-lg-wdb.py'),str(wdb),str(dll),str(output)],capture_output=True)
  (cab.parent/'wdb-extract-log.txt').write_bytes(result.stdout+result.stderr);r['status']='unpacked' if result.returncode==0 else 'unsupported-or-error';r['log']=(result.stdout+result.stderr).decode('utf8',errors='replace')
 else:r['status']='existing-unpacked'
 if output.exists():
  r['files']=[{'path':p.relative_to(output).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in output.rglob('*') if p.is_file()]
 reports.append(r);(base/'lg-wdb-results.json').write_bytes((json.dumps(reports,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'model':r['model'],'status':r['status'],'log':r.get('log'),'files':len(r.get('files',[]))}),flush=True)
