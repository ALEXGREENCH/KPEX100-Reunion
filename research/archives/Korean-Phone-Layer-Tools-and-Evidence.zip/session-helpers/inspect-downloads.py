from pathlib import Path, PurePosixPath
import hashlib,json,subprocess,zlib

base=Path(__file__).resolve().parent
seven=Path('C:/Program Files/7-Zip/7z.exe')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((base/'downloads/sources.json').read_text('utf8'))
out=base/'inspection';out.mkdir(exist_ok=True)
results=[]
for index,row in enumerate(rows):
 receipt=row['receipt'];prefix=f'{index:02}-{row["modelDirectory"]}'
 item={'source':row,'archiveTestPassed':False,'members':[]};results.append(item)
 if receipt.get('status')!=200 or not receipt.get('complete'):
  item['status']='download-failed';continue
 archive=base/'downloads'/receipt['path'];assert sha(archive)==receipt['sha256']
 test=subprocess.run([str(seven),'t','-bd',str(archive)],capture_output=True)
 (out/(prefix+'-test.txt')).write_bytes(test.stdout+test.stderr)
 item['archiveTestPassed']=test.returncode==0
 if test.returncode: item['status']='archive-failed';continue
 listing=subprocess.run([str(seven),'l','-slt','-ba',str(archive)],capture_output=True,check=True)
 (out/(prefix+'-listing.txt')).write_bytes(listing.stdout)
 text=listing.stdout.decode('utf8',errors='strict').replace('\r\n','\n')
 folder=out/prefix;folder.mkdir(exist_ok=True)
 for memberIndex,block in enumerate(text.split('\n\n')):
  attrs={k:v for line in block.splitlines() if ' = ' in line for k,v in [line.split(' = ',1)]}
  if 'Path' not in attrs or attrs.get('Folder')=='+':continue
  member=attrs['Path'];size=int(attrs['Size'])
  record={'archivePath':member,'bytes':size,'archiveCrc32':attrs.get('CRC')};item['members'].append(record)
  suffix=PurePosixPath(member.replace('\\','/')).suffix.lower()
  if suffix not in ['.bin','.binx','.rom','.rsc','.pdl','.kdz','.wdb','.dll','.img','.mbn','.hex']:
   record['status']='manifest-only';continue
  if size>512*1024*1024:record['status']='size-bound';continue
  target=folder/(f'{memberIndex:03}'+suffix)
  if not target.exists():
   with target.open('xb') as stream:
    result=subprocess.run([str(seven),'e','-so','-bd','-y','-spd',str(archive),'--',member],stdout=stream,stderr=subprocess.PIPE)
   if result.returncode:raise ValueError(result.stderr.decode('utf8',errors='replace'))
  body=target.read_bytes();crc=f'{zlib.crc32(body):08x}'
  assert len(body)==size and (not record['archiveCrc32'] or crc==record['archiveCrc32'].lower())
  record.update(status='extracted-crc-verified',path=target.relative_to(base).as_posix(),sha256=hashlib.sha256(body).hexdigest(),crc32=crc,header=body[:48].hex())
 item['status']='archive-verified';print(json.dumps({'model':row['modelDirectory'],'bytes':receipt['bytes'],'members':[(r['archivePath'],r['bytes']) for r in item['members']]}),flush=True)
 (base/'archive-inspection.json').write_bytes((json.dumps(results,ensure_ascii=False,indent=2)+'\n').encode())
