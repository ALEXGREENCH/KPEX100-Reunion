Sinjisoft GLib source preservation, 2026-11-07 MSK.

Source: https://git.fifo-f.eu/raulmario28/sinjisoft
Commit: ed4049f7189e2d9f3a7ebbc9adfc983ced04836a
All169 raw Git blobs /13695248bytes checked against Git SHA1 and SHA256.
Complete received Git history:5commits, HEAD/main, independent bundle clone
and fsck. No checkout/CRLF conversions in upstream-tree/.
Exact retrieval completion timestamp was not recorded; verification UTC and
bundle preserved-by filesystem time are explicitly distinguished in report.

Native C GLib callbacks and eight registered games, not a recovered SGS VM
or early GNEX SDK/player. Build/playability and claimed original firmware
origins are not established here. Literal byte arrays are derived extractions.
No root LICENSE is present; all existing per-file notices remain unchanged,
including SINJISOFT and Sonivox. Reunion MIT does not relicense upstream.

Namu primary returned403; the separate Korean namu.moe mirror returned200.
Five outlink responses are HTML/blog shells, not acquired game packages.
Forgejo API429 responses are retained; retries were not attempted.
Original HTTP bodies, derived text and receipts remain in separate folders.
manifest.json checks every other member by size/SHA256/CRC32.
