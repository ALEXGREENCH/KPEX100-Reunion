from pathlib import Path
import hashlib,json,re,sys

base=Path(__file__).resolve().parent
source=base/'sinjisoft-raw-source';dest=base/'glib-arrays';dest.mkdir(exist_ok=True)
arrays=[]
for path in sorted(source.glob('*.cpp')):
 data=path.read_bytes();plain=re.sub(rb'/\*.*?\*/|//[^\r\n]*',b'',data,flags=re.S)
 for m in re.finditer(rb'(?:static\s+)?const\s+BYTE\s+(\w+)\s*\[[^\]]*\]\s*=\s*\{([^{}]*)\}',plain,re.S):
  tokens=re.findall(rb'0[xX][0-9a-fA-F]+|\b[0-9]+\b',m[2]);left=re.sub(rb'0[xX][0-9a-fA-F]+|\b[0-9]+\b|[\s,]',b'',m[2])
  if left:continue
  numbers=[int(t,16 if t.lower().startswith(b'0x') else 10) for t in tokens]
  if any(n>255 for n in numbers):continue
  body=bytes(numbers);digest=hashlib.sha256(body).hexdigest();target=dest/(digest+'.bin')
  if not target.exists():target.write_bytes(body)
  arrays.append({'source':path.name,'symbol':m[1].decode(),'bytes':len(body),'sha256':digest,'path':target.relative_to(base).as_posix(),'kind':'smaf-candidate' if body.startswith(b'MMMD') else 'literal-byte-array'})
(base/'glib-array-inventory.json').write_bytes((json.dumps(arrays,indent=2)+'\n').encode())
needles={a['sha256']:a for a in arrays if a['bytes']>=256 and a['source'].startswith(('map','ma2','ma3'))}
print('Arrays',len(arrays),'full-match targets',len(needles),flush=True)
results=[]
for path in map(Path,sys.argv[2:]):
 raw=path.read_bytes();matches=[]
 for a in needles.values():
  body=(base/a['path']).read_bytes();anchorOffset=max(range(0,min(len(body)-31,256),8),key=lambda i:len(set(body[i:i+32])))
  anchor=body[anchorOffset:anchorOffset+32]
  if len(set(anchor))<8:continue
  cursor=raw.find(anchor)
  while cursor>=0:
   start=cursor-anchorOffset
   if start>=0 and raw[start:start+len(body)]==body:matches.append({**a,'offset':start})
   cursor=raw.find(anchor,cursor+1)
 r={'image':str(path),'imageBytes':len(raw),'imageSha256':hashlib.sha256(raw).hexdigest(),'matches':matches};results.append(r)
 print(json.dumps({'image':path.name,'bytes':len(raw),'matches':len(matches)}),flush=True)
 Path(sys.argv[1]).write_bytes((json.dumps({'method':'Complete literal BYTE arrays >=256bytes, min8distinctbytes in a32byte anchor; exact full byte equality after anchor. This identifies shared assets, not whole engine/code identity or native playability.','arrayInventory':arrays,'scans':results},ensure_ascii=False,indent=2)+'\n').encode())
