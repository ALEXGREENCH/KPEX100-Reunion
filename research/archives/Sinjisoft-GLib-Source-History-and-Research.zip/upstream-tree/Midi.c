#include "Midi.h"

BOOL InitMidiPlayer(MidiPlayerContext* context);
BOOL PlayMidiFromMemory(MidiPlayerContext* context, const BYTE* buffer, int size);
void StopMidiPlayback(MidiPlayerContext* context);
void CleanupMidiPlayer(MidiPlayerContext* context);

#pragma comment(lib, "winmm.lib")

static char tempFileName[MAX_PATH];

// Callback function for waveOut
static void CALLBACK WaveOutProc(HWAVEOUT hwo, UINT uMsg, DWORD_PTR dwInstance,
    DWORD_PTR dwParam1, DWORD_PTR dwParam2) {
    MidiPlayerContext* context = (MidiPlayerContext*)dwInstance;

    if (uMsg == WOM_DONE && context->isPlaying) {
        WAVEHDR* waveHdr = (WAVEHDR*)dwParam1;

        // Render more audio data from EAS
        int tchauMamma = 0; //context->channels gets set to 0 so use this tempo value
        EAS_RESULT result = EAS_Render(context->easData, (EAS_PCM*)waveHdr->lpData,
            context->bufferSize / (context->channels * sizeof(EAS_PCM)),
            &tchauMamma);

        if (result != EAS_SUCCESS) {
            EAS_Report(_EAS_SEVERITY_ERROR, "EAS_Render returned %ld\n", result);
            return;
        }

        // Check if playback is complete
        EAS_I32 state;
        if (context->easHandle != NULL)
        {
            EAS_State(context->easData, context->easHandle, &state);
            if (state == EAS_STATE_STOPPED) {
                // Optionally restart playback for looping
                EAS_Prepare(context->easData, context->easHandle);
                EAS_CloseFile(context->easData, context->easHandle);
				DeleteFileA(tempFileName);
                context->easHandle = NULL;
            }

            // Queue the buffer back to waveOut
            waveOutWrite(context->hWaveOut, waveHdr, sizeof(WAVEHDR));
        }
    }
}

// File I/O functions
static FILE* OpenFileHandle(const char* filename, const char* mode) {
    FILE* f = fopen(filename, mode);
    return f;
}

static int ReadFile2(void* handle, void* buf, int offset, int size) {
    fseek((FILE*)handle, offset, SEEK_SET);
    return fread(buf, 1, size, (FILE*)handle);
}

static int SizeFile(void* handle) {
    fseek((FILE*)handle, 0, SEEK_END);
    return ftell((FILE*)handle);
}

static void CloseFile(void* handle) {
    fclose((FILE*)handle);
}

BOOL InitMidiPlayer(MidiPlayerContext* context) {
    EAS_RESULT result;
    const S_EAS_LIB_CONFIG* pLibConfig;

    // Initialize context
    memset(context, 0, sizeof(MidiPlayerContext));

    // Get EAS configuration
    pLibConfig = EAS_Config();
    context->bufferSize = pLibConfig->mixBufferSize * pLibConfig->numChannels * sizeof(EAS_PCM);
    context->sampleRate = pLibConfig->sampleRate;
    context->channels = pLibConfig->numChannels;

    // Initialize EAS library
    if ((result = EAS_Init(&context->easData)) != EAS_SUCCESS) {
        EAS_Report(_EAS_SEVERITY_FATAL, "EAS_Init returned %ld - aborting!\n", result);
        return FALSE;
    }

    // Set up waveOut format
    WAVEFORMATEX wfx;
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = (WORD)context->channels;
    wfx.nSamplesPerSec = context->sampleRate;
    wfx.wBitsPerSample = 16;  // EAS_PCM is 16-bit
    wfx.nBlockAlign = wfx.nChannels * (wfx.wBitsPerSample / 8);
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
    wfx.cbSize = 0;

    // Open waveOut device
    if (waveOutOpen(&context->hWaveOut, WAVE_MAPPER, &wfx, (DWORD_PTR)WaveOutProc,
        (DWORD_PTR)context, CALLBACK_FUNCTION) != MMSYSERR_NOERROR) {
        EAS_Report(_EAS_SEVERITY_ERROR, "Failed to open waveOut device\n");
        EAS_Shutdown(context->easData);
        return FALSE;
    }

    // Allocate and prepare wave headers and buffers
    for (int i = 0; i < NUM_BUFFERS; i++) {
        context->waveHeaders[i].lpData = (LPSTR)malloc(context->bufferSize);
        if (!context->waveHeaders[i].lpData) {
            EAS_Report(_EAS_SEVERITY_ERROR, "Failed to allocate buffer memory\n");
            // Clean up previously allocated buffers
            for (int j = 0; j < i; j++) {
                free(context->waveHeaders[j].lpData);
            }
            waveOutClose(context->hWaveOut);
            EAS_Shutdown(context->easData);
            return FALSE;
        }

        context->waveHeaders[i].dwBufferLength = context->bufferSize;
        context->waveHeaders[i].dwFlags = 0;

        if (waveOutPrepareHeader(context->hWaveOut, &context->waveHeaders[i],
            sizeof(WAVEHDR)) != MMSYSERR_NOERROR) {
            EAS_Report(_EAS_SEVERITY_ERROR, "Failed to prepare waveOut header\n");
            // Clean up
            for (int j = 0; j <= i; j++) {
                free(context->waveHeaders[j].lpData);
            }
            waveOutClose(context->hWaveOut);
            EAS_Shutdown(context->easData);
            return FALSE;
        }
    }

    return TRUE;
}

BOOL MIDIPlayFromMemory(MidiPlayerContext* context, const BYTE* buffer, int size) {
    EAS_RESULT result;
    EAS_FILE fLocator;
    char tempPath[MAX_PATH];

    // Set debug level
#ifndef _DEBUG
    EAS_SetDebugLevel(_EAS_SEVERITY_INFO);
#else
    EAS_SetDebugLevel(_EAS_SEVERITY_DETAIL);
#endif

    // Create temporary file
    GetTempPathA(MAX_PATH, tempPath);
    GetTempFileNameA(tempPath, "MID", 0, tempFileName);

    FILE* file = fopen(tempFileName, "wb");
    if (!file) return FALSE;

    fwrite(buffer, 1, size, file);
    fclose(file);

    // Set up file locator
    fLocator.handle = OpenFileHandle(tempFileName, "rb");
    fLocator.readAt = ReadFile2;
    fLocator.size = SizeFile;

    // Open MIDI file with EAS
    if ((result = EAS_OpenFile(context->easData, &fLocator, &context->easHandle)) != EAS_SUCCESS) {
        EAS_Report(_EAS_SEVERITY_ERROR, "EAS_OpenFile returned %ld\n", result);
        return FALSE;
    }

    // Prepare to play the file
    if ((result = EAS_Prepare(context->easData, context->easHandle)) != EAS_SUCCESS) {
        EAS_Report(_EAS_SEVERITY_ERROR, "EAS_Prepare returned %ld\n", result);
        EAS_CloseFile(context->easData, context->easHandle);
        return FALSE;
    }

    // Start playback
    context->isPlaying = TRUE;
    context->channels = 1;

    // Fill and queue all buffers
    for (int i = 0; i < NUM_BUFFERS; i++) {
        int tchauMamma = 0; //context->channels gets set to 0 so use this tempo value
        EAS_Render(context->easData, (EAS_PCM*)context->waveHeaders[i].lpData,
            context->bufferSize / (context->channels * sizeof(EAS_PCM)),
            &tchauMamma);

        waveOutWrite(context->hWaveOut, &context->waveHeaders[i], sizeof(WAVEHDR));
    }

    return TRUE;
}

void StopMidiStream(MidiPlayerContext* context) {
    if (!context->isPlaying) return;

    context->isPlaying = FALSE;

    // Stop waveOut
    waveOutReset(context->hWaveOut);

    // Close EAS file
    if (context->easHandle) {
        EAS_CloseFile(context->easData, context->easHandle);
        context->easHandle = NULL;
    }

    // Delete temp file
    DeleteFileA(tempFileName);
}

void CleanupMidiPlayer(MidiPlayerContext* context) {
    // Stop playback if still playing
    if (context->isPlaying) {
        StopMidiStream(context);
    }

    // Clean up waveOut resources
    for (int i = 0; i < NUM_BUFFERS; i++) {
        if (context->waveHeaders[i].lpData) {
            waveOutUnprepareHeader(context->hWaveOut, &context->waveHeaders[i], sizeof(WAVEHDR));
            free(context->waveHeaders[i].lpData);
        }
    }

    if (context->hWaveOut) {
        waveOutClose(context->hWaveOut);
    }

    // Shutdown EAS
    if (context->easData) {
        EAS_Shutdown(context->easData);
    }
}

