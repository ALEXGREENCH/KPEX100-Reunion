﻿#include <Windows.h>

static HANDLE hEmuDLL;
static BYTE* EmuBuf;
static BYTE* EmuP;
static BOOL EmuSMAFPlaying = FALSE;
static BOOL EmuInited = FALSE;

static int (*MaSound_EmuInitialize)(DWORD, DWORD, BYTE*);
static int (*MaSound_Initialize)(int, BYTE*, int);
static int (*MaSound_DeviceControl)(int, int, int, int);
static int (*MaSound_Terminate)();
static int (*MaSound_Create)(int);
static int (*MaSound_Load)(int, BYTE*, DWORD, int, int, int);
static int (*MaSound_Control)(int, int, int, int*, int);
static int (*MaSound_Open)(int, int, int, int);
static int (*MaSound_Standby)(int, int, int);
static int (*MaSound_Start)(int, int, int, int);
static int (*MaSound_GetEmuInfo)(int);
static int (*MaSound_Stop)(int, int, int);
static int (*MaSound_Seek)(int, int, int, int, int);
static int (*MaSound_Close)(int, int, int);
static int (*MaSound_Unload)(int, int, int);
static int (*MaSound_Delete)(int);
static int (*MaSound_Terminate)();
static int (*MaSound_EmuTerminate)();
static int (*SetMidiMsg)(BYTE*, DWORD);

static BOOL InitEmuFunctions(HANDLE hdll)
{
	// Only need functions...

	if (!((FARPROC)MaSound_EmuInitialize = GetProcAddress(hdll, "MaSound_EmuInitialize")))	return FALSE;
	if (!((FARPROC)MaSound_Initialize = GetProcAddress(hdll, "MaSound_Initialize")))		return FALSE;
	if (!((FARPROC)MaSound_DeviceControl = GetProcAddress(hdll, "MaSound_DeviceControl")))	return FALSE;
	if (!((FARPROC)MaSound_Terminate = GetProcAddress(hdll, "MaSound_Terminate")))		return FALSE;
	if (!((FARPROC)MaSound_Create = GetProcAddress(hdll, "MaSound_Create")))			return FALSE;
	if (!((FARPROC)MaSound_Load = GetProcAddress(hdll, "MaSound_Load")))			return FALSE;
	if (!((FARPROC)MaSound_Control = GetProcAddress(hdll, "MaSound_Control")))			return FALSE;
	if (!((FARPROC)MaSound_Open = GetProcAddress(hdll, "MaSound_Open")))			return FALSE;
	if (!((FARPROC)MaSound_Standby = GetProcAddress(hdll, "MaSound_Standby")))			return FALSE;
	if (!((FARPROC)MaSound_Start = GetProcAddress(hdll, "MaSound_Start")))			return FALSE;
	if (!((FARPROC)MaSound_GetEmuInfo = GetProcAddress(hdll, "MaSound_GetEmuInfo")))		return FALSE;
	if (!((FARPROC)MaSound_Stop = GetProcAddress(hdll, "MaSound_Stop")))			return FALSE;
	if (!((FARPROC)MaSound_Seek = GetProcAddress(hdll, "MaSound_Seek")))			return FALSE;
	if (!((FARPROC)MaSound_Close = GetProcAddress(hdll, "MaSound_Close")))			return FALSE;
	if (!((FARPROC)MaSound_Unload = GetProcAddress(hdll, "MaSound_Unload")))			return FALSE;
	if (!((FARPROC)MaSound_Delete = GetProcAddress(hdll, "MaSound_Delete")))			return FALSE;
	if (!((FARPROC)MaSound_Terminate = GetProcAddress(hdll, "MaSound_Terminate")))		return FALSE;
	if (!((FARPROC)MaSound_EmuTerminate = GetProcAddress(hdll, "MaSound_EmuTerminate")))	return FALSE;
	if (!((FARPROC)SetMidiMsg = GetProcAddress(hdll, "SetMidiMsg")))				return FALSE;

	return TRUE;
}

BOOL Emu526829(void)
{
	if (MaSound_DeviceControl(0x05, 2, 0, 0))
	{
		return FALSE;
	}
	if (MaSound_DeviceControl(0x06, 0, 0, 0))
	{
		return FALSE;
	}
	if (MaSound_DeviceControl(0x08, 2, 0, 0))
	{
		return FALSE;
	}
	if (MaSound_DeviceControl(0x09, 0, 0, 0))
	{
		return FALSE;
	}

	return TRUE;
}

BOOL EmuInitialize(void)
{
	if (!(hEmuDLL = LoadLibrary("M5_EmuSmw5.dll")))
	{
		return FALSE;
	}

	if (!InitEmuFunctions(hEmuDLL))
		return FALSE;

	// TODO: このバッファの意味を調べよう
	EmuBuf = malloc(1024);	// とりあえず確保
	EmuP = EmuBuf;
	while (((DWORD)EmuP & 0xFF) != 0x81)	// MaSound_EmuInitializeのParam3はアドレス下1バイトが0x81以下?てかJust0x81でなくてはならないらしい。Align?
		EmuP++;

	// Init. FLAGS
	EmuSMAFPlaying = FALSE;
	EmuInited = TRUE;
	return TRUE;
}

void EmuUninitialize(void)
{
	free(EmuBuf);

	FreeLibrary(hEmuDLL);
}


BOOL EmuSMAFInitialize(void)
{
	if (EmuInited == FALSE)
	{
		EmuInitialize();
		if (MaSound_EmuInitialize(48000, 2, EmuP))
		{
			return FALSE;
		}
	}

	if (MaSound_Initialize(0, EmuBuf/* + 0x2F*/, 0))//ok?
	{
		return FALSE;
	}
	if (MaSound_DeviceControl(0x0D, 0, 0, 0))	//pcm
	{
		return FALSE;
	}
	if (!Emu526829())
	{
		return FALSE;
	}

	EmuSMAFPlaying = FALSE;

	return TRUE;
}

void EmuSMAFUninitialize(void)
{
	MaSound_Terminate();
	MaSound_EmuTerminate();

	EmuSMAFPlaying = FALSE;
	EmuInited = FALSE;

	return;
}

static int EmuPlayTempo = 100;
static int EmuPlayKeypitch = 0;

BOOL EmuSMAFPlay(void* snd_data, int snd_size, int volume)
{
	if (!snd_data)
	{
		return FALSE;
	}
	if (!snd_size)
	{
		return FALSE;
	}

	// Init
	if (!EmuSMAFInitialize())
		return FALSE;

	// open
	if (MaSound_Create(1) != 1)
	{
		return FALSE;
	}
	if (MaSound_Load(1, snd_data, snd_size, 1, (int)NULL, 0) != 1)	// なんかATS-MA5みるとコールバックっぽいけど、ATS-MA5では一度も呼ばれてない。NULL指定してもOKだったので採用。
	{
		return FALSE;
	}
	if (MaSound_Open(1, 1, 0, 0))
	{
		return FALSE;
	}
	if (MaSound_Standby(1, 1, 0))
	{
		return FALSE;
	}

	// Play
	if (MaSound_Control(1, 1, 0, &volume, 0))	// 音量 between 0 to 127
	{
		return FALSE;
	}
	if (MaSound_Control(1, 1, 2, &EmuPlayKeypitch, 0))	// キーピッチ between -12 to 12
	{
		return FALSE;
	}
	if (MaSound_Control(1, 1, 1, &EmuPlayTempo, 0))	// テンポ(%) between 70 to 130.
	{
		return FALSE;
	}

	if (MaSound_Seek(1, 1, 0, 0, 0))
	{
		return FALSE;
	}

	if (MaSound_Start(1, 1, 1, 0))
	{
		return FALSE;
	}

	EmuSMAFPlaying = TRUE;

	return TRUE;
}
void EmuSMAFStop(void)
{
	if (!EmuSMAFPlaying)
	{
		return;
	}

	MaSound_Stop(1, 1, 0);

	MaSound_Close(1, 1, 0);
	MaSound_Unload(1, 1, 0);
	MaSound_Delete(1);

	EmuSMAFUninitialize();

	EmuSMAFPlaying = FALSE;

	return;
}