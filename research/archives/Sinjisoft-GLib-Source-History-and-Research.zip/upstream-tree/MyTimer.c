#include "MyTimer.h"
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#include <time.h>
#include <signal.h>
#endif

#define MAX_TIMERS 3


typedef struct {
    TimerCallback callback;
    void* arg;
    int active;
#ifdef _WIN32
    HANDLE timer_handle;
#else
    timer_t timer_id;
#endif
} Timer;

static Timer timers[MAX_TIMERS];
static int initialized = 0;

#ifdef _WIN32
VOID CALLBACK myTimerCallback(PVOID arg, BOOLEAN TimerOrWaitFired) {
    Timer* timer = (Timer*)arg;
    if (timer && timer->active && timer->callback) {
        timer->callback(timer->arg);
        ;
    }
}
#else
static void myTimerHandler(union sigval sv) {
    Timer* timer = (Timer*)sv.sival_ptr;
    if (timer && timer->active && timer->callback) {
        timer->callback(timer->arg);
    }
}
#endif

void Timer_Init(void) {
    if (!initialized) {
        memset(timers, 0, sizeof(timers));
        initialized = 1;
    }
}

void Timer_Cleanup(void) {
    for (int i = 0; i < MAX_TIMERS; i++) {
        if (timers[i].active) {
            Timer_Stop(timers[i].callback, timers[i].arg);
        }
    }
    initialized = 0;
}

int Timer_Start(unsigned long ms, TimerCallback callback, void* arg) {

    if (!initialized) {
        Timer_Init();
    }

    if (!callback) {
        return -1;
    }

    // Find free timer slot
    int slot = -1;
    for (int i = 0; i < MAX_TIMERS; i++) {
        if (!timers[i].active) {
            slot = i;
            break;
        }
    }

    if (slot == -1) {
        return -1;
    }

    Timer* timer = &timers[slot];
    timer->callback = callback;
    timer->arg = arg;
    timer->active = 1;

#ifdef _WIN32
    HANDLE handle;
    if (!CreateTimerQueueTimer(&handle, NULL, myTimerCallback,
        timer, ms, ms, WT_EXECUTEINTIMERTHREAD)) {
        timer->active = 0;
        return -1;
    }
    timer->timer_handle = handle;
#else
    struct sigevent sev;
    timer_t timerid;

    sev.sigev_notify = SIGEV_THREAD;
    sev.sigev_notify_function = myTimerHandler;
    sev.sigev_value.sival_ptr = timer;
    sev.sigev_notify_attributes = NULL;

    if (timer_create(CLOCK_REALTIME, &sev, &timerid) == -1) {
        timer->active = 0;
        return -1;
    }

    struct itimerspec its;
    its.it_value.tv_sec = ms / 1000;
    its.it_value.tv_nsec = (ms % 1000) * 1000000;
    its.it_interval.tv_sec = ms / 1000;
    its.it_interval.tv_nsec = (ms % 1000) * 1000000;

    if (timer_settime(timerid, 0, &its, NULL) == -1) {
        timer_delete(timerid);
        timer->active = 0;
        return -1;
    }

    timer->timer_id = timerid;
#endif

    return 0;
}

int Timer_Stop(TimerCallback callback, void* arg) {
    if (!initialized || !callback) {
        return -1;
    }

    for (int i = 0; i < MAX_TIMERS; i++) {
        if (timers[i].active && timers[i].callback == callback && timers[i].arg == arg) {
#ifdef _WIN32
            DeleteTimerQueueTimer(NULL, timers[i].timer_handle, NULL);
#else
            timer_delete(timers[i].timer_id);
#endif
            timers[i].active = 0;
            timers[i].callback = NULL;
            timers[i].arg = NULL;
            if (i == MAX_TIMERS - 1)
                return 0;
            if (!timers[i + 1].active)
                return 0;
        }
    }

    return -1;
}