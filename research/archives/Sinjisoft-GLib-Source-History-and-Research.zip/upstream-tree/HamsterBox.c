#include <stdio.h> 

#include <string.h> 

#include <stdlib.h>

#include "GLib.h"

#include "ma3HamsterBox.cpp"

#include "mapHamsterBox.cpp"

extern void gm_DrawPauseMark();
extern void gm_PlayStageChange();
extern void DrawReadyMark(int stageNum, int nX);

int i;
int j;
int k;
int q;
DWORD enemy_x[14];
DWORD enemy_y[14];
int enemy_action[14];
DWORD enemy_dir[14];
DWORD enemy_type[14];
BYTE map[42][35];
BYTE mapCopy[42][35];
WORD mapStack[1470];
int moveStack[150];
DWORD order_dir[8];
char strArray[10];
int itemTime[3];
int hamster_val1;
int hamster_val2;
int map_ratio;
int player_x;
int player_y;
int player_dir;
int player_animation;
int map_stack_index;
int move_stack_index;
int max_x;
int max_y;
int min_x;
int min_y;
int user_area;
int mode;
int stage;
int life;
int dx;
int dy;
int temp;
int flag;
int animation_index;
int player_speed;
int forward;
int backward;
int enemy_speed_up_time;
int player_action;
int sound_seq;
int score;
int Old_x;
int Old_y;
int Dist_x;
int Dist_y;
int area_obtain_flag;
int item_flag;
int Alldrawflag;

static const BYTE* playerImage[] = { playerImage00, playerImage01, playerImage02, playerImage03,
                                     playerImage04, playerImage05, playerImage06, playerImage07,
                                     playerImage08, playerImage09 };

static const BYTE* explosionImage[] = { playerImage04, explosionImage00, explosionImage01, };

static const BYTE* enemyImage[4][5] = { {enemyImage00, enemyImage01, enemyImage00, enemyImage02, enemyImage03},
                                        {enemyImage04, enemyImage05, enemyImage06, enemyImage07, enemyImage08},
                                        {enemyImage09, enemyImage10, enemyImage09, enemyImage11, enemyImage12},
                                        {enemyImage13, enemyImage14, enemyImage15, enemyImage16, enemyImage17} };

static const BYTE* backgroundImage[] = {backgroundImage01, backgroundImage02, backgroundImage19,
                                   backgroundImage18, backgroundImage17, backgroundImage03,
                                   backgroundImage05, backgroundImage08, backgroundImage14,
                                   backgroundImage00, backgroundImage15, backgroundImage16,
                                   backgroundImage04, backgroundImage10, backgroundImage12,
                                   backgroundImage11, backgroundImage07, backgroundImage06,
                                   backgroundImage13, backgroundImage09 };

static const BYTE* imgNextStage_0[] = {LandEngland_0, LandItaly_0, LandSwiss_0, LandGermany_0,
                                   LandNetherlands_0, LandFrance_0, LandGreece_0, LandChina_0,
                                   LandBrazil_0, LandAmerica_0, LandSpain_0, LandCanada_0,
                                   LandJapan_0, LandIndia_0, LandThailand_0, LandRussia_0,
                                   LandAustralia_0, LandEgypt_0, LandChile_0, LandKorea_0 };

static const BYTE* lightImage[] = { lightImage00, lightImage01, lightImage02 };

static const BYTE* endingTextImage_0[] = { endingTextImage00_0, endingTextImage01_0, endingTextImage02_0 };

static const BYTE* introTextImage_0[] = { introTextImage00_0, introTextImage01_0 };

static const BYTE* itemTextImage_0[] = { itemTextImage00_0, itemTextImage01_0, itemTextImage02_0 };

static const DWORD enemyCount[] = { 4, 5, 6, 7, 8, 8, 9, 9, 10, 10};

static const BYTE enemyType[] = { 0, 0, 0, 0, 0, 0,
                                  1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 2, 1, 0, 0, 0,
                                  0, 2, 3, 3, 2, 0, 0, 0, 1, 2, 3, 3, 2, 1, 0, 0, 0,
                                  1, 2, 3, 2, 1, 0, 0, 0, 1, 2, 2, 3, 2, 2, 1, 0, 0,
                                  0, 1, 2, 3, 3, 2, 1, 0, 0, 0, 0, 2, 3, 3, 3, 3, 2,
                                  0, 0 };

static const DWORD enemySpeed[] = { 2, 3, 4, 4 };

void InitLCD()
{
    mil_CopyImage(backgroundImage[stage], 0, 0);
    mil_CopyImage(scoreBorderImage, 0, 0);
    mil_CopyImage(scoreBorderImage0, 0, 25);
    mil_CopyImage(scoreBorderImage1, 125, 25);
    mil_CopyImage(scoreBorderImage2, 3, 125);
}

void InitRange()
{
    max_x = -1;
    max_y = -1;
    min_x = 100;
    min_y = 100;
}

void InitEnemyDirection()
{
    for (i = 0; enemyCount[stage / 2] > i; ++i)
    {
        if (enemy_type[i])
        {
            if (enemy_type[i] == 1)
            {
                enemy_dir[i] = 2 * (i % 4) + 1;
            }
            else if (enemy_type[i] == 2 || enemy_type[i] == 3)
            {
                enemy_dir[i] = i % 8;
            }
        }
        else
        {
            enemy_dir[i] = 2 * (i % 4) + 1;
        }
    }
}

void InitEnemyType()
{
    temp = 0;
    for (i = 0; stage / 2 > i; ++i)
        temp += enemyCount[i];
    for (i = 0; enemyCount[stage / 2] > i; ++i)
        enemy_type[i] = enemyType[temp + i];
}

void InitEnemyLocation()
{
    for (i = 0; i < 14; ++i)
        enemy_action[i] = 4;
    temp = 35 / (enemyCount[stage / 2] / 2 + (enemyCount[stage / 2] % 2) + 1);
    for (i = 0; enemyCount[stage / 2] / 2 > i; ++i)
    {
        enemy_x[2 * i] = 14;
        enemy_y[2 * i] = temp * (i + 1);
        enemy_action[2 * i] = i % 2;
        enemy_dir[2 * i] = 2 * i % 4;
        enemy_x[2 * i + 1] = 28;
        enemy_y[2 * i + 1] = temp * (i + 1);
        enemy_action[2 * i + 1] = (i + 1) % 2;
    }
    if ((enemyCount[stage / 2] & 1) != 0)
    {
        enemy_x[enemyCount[stage / 2] - 1] = 21;
        enemy_y[enemyCount[stage / 2] - 1] = 35 - temp;
        enemy_action[enemyCount[stage / 2] - 1] = enemyCount[stage / 2] % 2;
    }
    InitEnemyType();
    InitEnemyDirection();
}

void GameInit()
{
    Alldrawflag = 1;
    InitEnemyLocation();
    for (i = 0; i < 42; ++i)
    {
        for (j = 0; j < 35; ++j)
            map[i][j] = 0;
    }
    for (i = 1; i < 35; ++i)
    {
        map[0][i] = 1;
        map[41][i] = 1;
    }
    for (i = 0; i < 42; ++i)
    {
        map[i][0] = 1;
        map[i][34] = 1;
    }
    for (i = 0; i < 3; ++i)
        itemTime[i] = 0;
    player_action = 4;
    player_x = 0;
    player_y = 0;
    Dist_x = 21;
    Dist_y = (128 - 25)/6;
    Old_x = 0;
    Old_y = 0;
    map_stack_index = 0;
    move_stack_index = 0;
    map_ratio = 0;
    user_area = 0;
    player_dir = -1;
    InitRange();
    InitLCD();
    sound_seq = 0;
    area_obtain_flag = 0;
    item_flag = 0;
    gext_StopSound();
}

int Pow(int number, int factor)
{
    int result;

    result = 1;
    for (k = 0; k < factor; ++k)
        result *= number;
    return result;
}

void SetRange(int x, int y)
{
    if (max_x < x)
        max_x = x;
    if (max_y < y)
        max_y = y;
    if (min_x > x)
        min_x = x;
    if (min_y > y)
        min_y = y;
}

void AddLine()
{
    for (i = min_x - 1; i <= max_x + 1; ++i)
    {
        for (j = min_y - 1; j <= max_y + 1; ++j)
        {
            if (map[i][j] == 2)
            {
                map[i][j] = 1;
                ++user_area;
                ++score;
                Alldrawflag = 1;
                area_obtain_flag = 1;
            }
        }
    }
}

void PushMapStack(int x, int y)
{
    mapStack[map_stack_index++] = (x << 8) | y;
}

DWORD PopMapStack()
{
    --map_stack_index;
    return mapStack[map_stack_index];
}

void AddMap(int map_x, int map_y)
{
    int pms;
    int x;
    int y;

    PushMapStack(map_x, map_y);
    while (map_stack_index > 0)
    {
        pms = PopMapStack();
        x = pms >> 8;
        y = pms&0xff;
        if (!map[x][y])
            map[x][y] = 1;
        if (x < 42 && !map[x + 1][y])
        {
            PushMapStack(x + 1, y);
            map[x + 1][y] = 1;
            ++user_area;
            ++score;
        }
        if (x > 0 && !map[x - 1][y])
        {
            PushMapStack(x - 1, y);
            map[x - 1][y] = 1;
            ++user_area;
            ++score;
        }
        if (y < 35 && !map[x][y + 1])
        {
            PushMapStack(x, y + 1);
            map[x][y + 1] = 1;
            ++user_area;
            ++score;
        }
        if (y > 0 && !map[x - 1][y + 34])
        {
            PushMapStack(x, y - 1);
            map[x - 1][y + 34] = 1;
            ++user_area;
            ++score;
        }
    }
}

void ProcessMapCopy()
{
    for (i = 0; i < 42; ++i)
    {
        for (j = 0; j < 35; ++j)
            mapCopy[i][j] = map[i][j];
    }
}

DWORD IsMinimumMapingLoop(int map_x, int map_y)
{
    int maploop; // r6
    int pms; // r0
    int x; // r4
    int y; // r5
    DWORD result; // r0
    int minimum; // [sp+0h] [bp-20h]

    maploop = 0;
    minimum = 0;
    ProcessMapCopy();
    PushMapStack(map_x, map_y);
    while (1)
    {
        if (map_stack_index <= 0)
            return 1;
        pms = PopMapStack();
        x = pms >> 8;
        y = pms & 0xff;
        if (!mapCopy[x][y])
        {
            mapCopy[x][y] = 1;
            ++maploop;
        }
        if (x < 42 && !mapCopy[x + 1][y])
        {
            PushMapStack(x + 1, y);
            mapCopy[x + 1][y] = 1;
            ++maploop;
        }
        if (x > 0 && !mapCopy[x - 1][y])
        {
            PushMapStack(x - 1, y);
            mapCopy[x - 1][y] = 1;
            ++maploop;
        }
        if (y < 35 && !mapCopy[x][y + 1])
        {
            PushMapStack(x, y + 1);
            mapCopy[x][y + 1] = 1;
            ++maploop;
        }
        if (y > 0 && !mapCopy[x - 1][y + 34])
        {
            PushMapStack(x, y - 1);
            mapCopy[x - 1][y + 34] = 1;
            ++maploop;
        }
        if ((1470 - user_area) / 2 < maploop)
            break;
        if (map_stack_index > minimum)
            minimum = map_stack_index;
    }
    result = 0;
    map_stack_index = 0;
    return result;
}

DWORD ProcessCoordinate()
{
    int x; // r4
    int y; // r5
    int result; // r0

    x = -1;
    y = -1;
    for (i = min_x; i <= max_x; ++i)
    {
        for (j = min_y; j <= max_y; ++j)
        {
            if (map[i][j] == 2 && !map[i - 1][j + 34] && !map[i][j + 1])
            {
                x = i;
                y = j;
                break;
            }
        }
    }
    if (x == -1)
    {
        for (i = min_x; i <= max_x; ++i)
        {
            for (j = min_y; j <= max_y; ++j)
            {
                if (map[i][j] == 2 && !map[i - 1][j] && !map[i + 1][j])
                {
                    x = i;
                    y = j;
                    break;
                }
            }
        }
        if (x == -1)
        {
            result = -1;
        }
        else if (IsMinimumMapingLoop(x - 1, y))
        {
            result = ((x - 1) << 8) | y;
        }
        else
        {
            result = ((x + 1) << 8) | y;
        }
    }
    else if (IsMinimumMapingLoop(x, y - 1))
    {
        result = (x << 8) | (y - 1);
    }
    else
    {
        result = (x << 8) | (y + 1);
    }
    return result;
}

void AddArea()
{
    int pms; // r0

    while (1)
    {
        pms = ProcessCoordinate();
        if (pms == -1)
            break;
        AddMap(pms >> 8, pms&0xff);
    }
    AddLine();
    InitRange();
    map_ratio = 1470/ (40 * user_area);
    player_dir = -1;
    if (map_ratio >= 30)
    {
        for (i = 0; i < 42; ++i)
        {
            for (j = 0; j < 35; ++j)
                map[i][j] = 1;
        }
        for (i = 0; enemyCount[stage / 2] > i; ++i)
        {
            if (enemy_action[i] < 3)
                enemy_action[i] = 3;
        }
        for (i = 0; i < 3; ++i)
            itemTime[i] = 0;
    }
}

void PushMoveStack(int x, int y)
{
    moveStack[move_stack_index++] = (x << 8) | y;
}

DWORD PeekMoveStack()
{
    return moveStack[move_stack_index - 1];
}

void RelocateEnemy()
{
    temp = gext_Random(0, enemyCount[stage / 2]);
    for (k = 0; enemyCount[stage / 2] > k; ++k)
    {
        if (enemyCount[stage / 2] % (k + temp) != i)
        {
            if (enemy_action[(k + temp) % enemyCount[stage / 2]] < 3)
            {
                enemy_x[i] = enemy_x[enemyCount[stage / 2] % (k + temp)];
                enemy_y[i] = enemy_y[enemyCount[stage / 2] % (k + temp)];
                enemy_action[i] = 0;
            }
        }
    }
}

void ProcessMoveDegree(int degree)
{
    dx = 0;
    dy = 0;
    switch (degree)
    {
    case 0:
        dy = -1;
        break;
    case 1:
        dy = -1;
        dx = 1;
        break;
    case 2:
        dx = 1;
        break;
    case 3:
        dx = 1;
        dy = 1;
        break;
    case 4:
        dy = 1;
        break;
    case 5:
        dx = -1;
        dy = 1;
        break;
    case 6:
        dx = -1;
        break;
    case 7:
        dx = -1;
        dy = -1;
        break;
    default:
        return;
    }
}

void FindRandomDirection()
{
    for (k = 0; k < 8; ++k)
        order_dir[k] = k;
    for (k = 0; k < 10; ++k)
    {
        forward = gext_Random(0, 8);
        backward = gext_Random(0, 8);
        if (forward == backward)
            backward = (forward + 1) % 8;
        temp = order_dir[forward];
        order_dir[forward] = order_dir[backward];
        order_dir[backward] = temp;
    }
    for (k = 0; k < 8; ++k)
    {
        ProcessMoveDegree(order_dir[k]);
        if (map[enemy_x[i] + dx][enemy_y[i] + dy] != 1)
        {
            enemy_dir[i] = order_dir[k];
            return;
        }
    }
}

void FindFixedDirection()
{
    for (k = 1; k < 4; ++k)
    {
        switch (k)
        {
        case 1:
            temp = (enemy_dir[i] + 2) % 8;
            break;
        case 2:
            temp = (enemy_dir[i] + 6) % 8;
            break;
        case 3:
            temp = (enemy_dir[i] + 4) % 8;
            break;
        }
        ProcessMoveDegree(temp);
        if (map[enemy_x[i] + dx][enemy_y[i] + dy] != 1)
        {
            enemy_dir[i] = temp;
            return;
        }
    }
}

void EnemyMove(int enemies)
{
    int curr_x; // r0
    int curr_y; // r0

    ProcessMoveDegree(enemy_dir[i]);
    for (j = 0; j < enemies; ++j)
    {
        if (player_x - enemy_x[i] < 0)
            curr_x = enemy_x[i] - player_x;
        else
            curr_x = player_x - enemy_x[i];
		if (player_y - enemy_y[i] < 0)
			curr_y = enemy_y[i] - player_y;
		else
			curr_y = player_y - enemy_y[i];

        /* In original there's an additional case, map[player_x][player_y] == 2 && curr_x < 2 && curr_y < 2 */
        /* This condition will cause the player to die whenever trying to access the capture area, so removed */

        if (map[enemy_x[i]][enemy_y[i]] == 2)
        {
            if (life >= 0 && !player_action)
            {
                player_action = 1;
                gext_StartVib(1);
            }
        }
        if (map[enemy_x[i] + dx][enemy_y[i] + dy] == 1)
        {
            if (enemy_type[i] >= 2)
                FindRandomDirection();
            else
                FindFixedDirection();
            break;
        }
        enemy_x[i] += dx;
        enemy_y[i] += dy;
    }
    if (map[enemy_x[i] - 1][enemy_y[i]] == 1
        && map[enemy_x[i]][enemy_y[i] + 1] == 1
        && map[enemy_x[i] - 1][enemy_y[i] + 34] == 1)
    {
        enemy_action[i] = 3;
        if (map_ratio < 30)
        {
            score += 200 * enemy_type[i] + 200;
            if (!(gext_Random(0, 4 - enemy_type[i]) | item_flag))
            {
                itemTime[gext_Random(0, 3)] = 40;
                item_flag = 1;
            }
        }
    }
}

void AllEnemyMove()
{
    for (i = 0; enemyCount[stage / 2] > i; ++i)
    {
        if (enemy_action[i] < 2)
        {
            if (enemy_action[i])
            {
                if ((int)enemy_type[i] <= 0 || gext_Random(0, 20))
                    enemy_action[i] = 0;
                else
                    enemy_action[i] = 2;
            }
            else
            {
                enemy_action[i] = 1;
            }
            temp = enemySpeed[enemy_type[i]];
            if ((enemy_dir[i] & 1) != 0)
                temp = (10 * temp)/14;
            if (hamster_val1)
                temp /= 2;
            EnemyMove(temp);
            continue;
        }
        if (enemy_action[i] == 2)
        {
            switch (enemy_type[i])
            {
            case 1:
                if (enemy_speed_up_time < 20)
                {
                    ++enemy_speed_up_time;
                    temp = 2 * enemySpeed[enemy_type[i]];
                    if ((enemy_dir[i] & 1) != 0)
                        temp = (10 * temp)/14;
                    if (hamster_val1)
                        temp /= 2;
                    EnemyMove(temp);
                    continue;
                }
                enemy_speed_up_time = 0;
                enemy_action[i] = 0;
                break;
            case 2:
                enemy_dir[i] = (enemy_dir[i] + 4) % 8;
                enemy_action[i] = 0;
                break;
            case 3:
                RelocateEnemy();
                break;
            }
        }
        else
        {
            if (enemy_action[i] >= 200)
            {
                RelocateEnemy();
                continue;
            }
            ++enemy_action[i];
        }
    }
    item_flag = 0;
}

void PlayerMove()
{
    int mapi;
    int pms;

    if (player_action)
    {
        if (player_action == 7)
        {
            player_action = 0;
            player_dir = -1;
            player_x = Old_x;
            player_y = Old_y;
            move_stack_index = 0;
        }
        else if (player_action == 3)
        {
            for (j = min_x - 1; j <= max_x + 1; ++j)
            {
                for (k = min_y - 1; k <= max_y + 1; ++k)
                {
                    if (map[j][k] == 2)
                        map[j][k] = 0;
                }
            }
            --life;
            ++player_action;
            Old_x = moveStack[0]>>8;
            Old_y = moveStack[0]&0xff;
            Dist_x = (63 - 3 * Old_x)/3;
            Dist_y = (53 - 3 * Old_y)/3;
            gext_StopSound();
            gext_PlaySound(player_die, sizeof(player_die));
        }
        else
        {
            ++player_action;
        }
    }
    else
    {
        if (itemTime[0])
            player_speed = 4;
        else
            player_speed = 2;
        if (player_dir != -1)
        {
            for (q = 0; q < player_speed; ++q)
            {
                ProcessMoveDegree(player_dir);
                if ((player_x + dx) < 42 && (player_y + dy) < 35)
                {
                    mapi = map[player_x + dx][player_y + dy];
                    if (!(player_x + dx)
                        || player_x + dx == 41
                        || !(player_y + dy)
                        || player_y + dy == 34
                        || !map[player_x + dx][player_y + dy]
                        || mapi == 2
                        || map[player_x][player_y] == 2 && mapi == 1
                        || map[player_x + dy][player_y + dx] != 1
                        || map[player_x - dy][player_y - dx] != 1
                        || mapi == 1 && map[player_x + dx + dy][player_y + dy + dx] != 1
                        || mapi == 1 && map[player_x + dx - dy][player_y + dy - dx] != 1)
                    {
                        if ((map[player_x + dx][player_y + dy] || map[player_x + dx + dy][player_y + dy + dx] != 1)
                            && (map[player_x + dx][player_y + dy] || map[player_x + dx - dy][player_y + dy - dx] != 1))
                        {
                            player_x += dx;
                            player_y += dy;
							printf("player_x: %d, player_y: %d\n", player_x, player_y);
                            backward = map[player_x][player_y];
                            flag = 0;
                            if (backward)
                            {
                                if (backward == 1)
                                {
                                    if (move_stack_index > 0)
                                    {
                                        pms = PeekMoveStack();
                                        if (player_y == pms >> 8 && player_x == pms & 0xff)
                                        {
                                            map[player_x - dx][player_y - dy] = 0;
                                            --move_stack_index;
                                        }
                                        if (move_stack_index > 0)
                                        {
                                            AddArea();
                                            move_stack_index = 0;
                                        }
                                    }
                                }
                                else if (backward == 2)
                                {
                                    pms = PeekMoveStack();
                                    if (player_y == pms >> 8 && player_x == pms & 0xff)
                                    {
                                        --move_stack_index;
                                        map[player_x - dx][player_y - dy] = 0;
                                    }
                                    else
                                    {
                                        player_x -= dx;
                                        player_y -= dy;
                                        player_dir = (player_dir + 4) % 8;
                                        flag = 1;
                                    }
                                }
                            }
                            else
                            {
                                SetRange(player_x, player_y);
                                map[player_x][player_y] = 2;
                                PushMoveStack(player_x - dx, player_y - dy);
                            }
                            printf("set to %d\n", map[player_x][player_y]);
                            if (flag)
                                break;
                        }
                    }
                }
            }
        }
    }
}

void DrawScore()
{
    mil_CopyImage(lifeImage, 15, 11);
    strArray[0] = life + '0';
    strArray[1] = 0;
    mil_DrawStr(29, 8, strArray, 1, 0, 0, 0, 0);
    mil_SetColor(168);
    mil_FillRect(47, 7, map_ratio + 47, 15);
    temp = 0;
    for (i = 0; i < 4; ++i)
    {
        if (!(score/Pow(10, temp + 1)))
            break;
        ++temp;
    }
    for (i = 0; i <= temp; ++i)
    {
        strArray[i] = (score % Pow(10, temp + 1 - i))/ Pow(10, temp - i) + '0';
    }
    for (i = temp + 1; i < 6; ++i)
        strArray[i] = 0;
    mil_DrawStr(90, 8, strArray, 1, 0, 0, 0, 0);
}

void DrawItem()
{
    for (i = 40; i > 35; --i)
    {
        flag = 0;
        for (j = 0; j < 3; ++j)
        {
            if ((&itemTime)[j] == (int*)i)
            {
                mil_CopyImage(itemTextImage_0[j], 64, 14 * j + 50);
                flag = 1;
            }
        }
        if (flag)
            break;
    }
}

void DrawObject()
{
    for (i = 0; enemyCount[stage / 2] > i; ++i)
    {
        if (enemy_action[i] < 5)
            mil_CopyImage(enemyImage[enemy_type[i]][enemy_action[i]], 3 * enemy_x[i] + 3, 3 * enemy_y[i] + 24);
    }
    if (player_action)
    {
        if (player_action >= 3)
        {
            if (life >= 0)
            {
                switch (player_action)
                {
                case 4:
                    mil_CopyImage(lightImage02, 64, (128 - 25) / 2 + 25);
                    break;
                case 5:
                    mil_CopyImage(lightImage01, 3 * Old_x + 2 * Dist_x + 1, 3 * Old_y + 2 * Dist_y + 22);
                    break;
                case 6:
                    mil_CopyImage(lightImage01, 3 * Old_x + Dist_x + 1, 3 * Old_y + Dist_y + 22);
                    break;
                case 7:
                    mil_CopyImage(lightImage00, 3 * Old_x + 1, 3 * Old_y + 22);
                    break;
                }
            }
        }
        else
        {
            mil_CopyImage(explosionImage[player_action], 3 * player_x + 3, 3 * player_y + 24);
        }
    }
    else if (player_dir == -1)
    {
        mil_CopyImage(playerImage[player_animation + 4], 3 * player_x + 3, 3 * player_y + 24);
    }
    else
    {
        mil_CopyImage((&playerImage[player_dir / 2])[player_animation], 3 * player_x + 3, 3 * player_y + 24);
    }
}

void DrawMap()
{
    for (i = 0; i < 42; ++i)
    {
        for (j = 0; j < 35; ++j)
        {
            if (map[i][j])
            {
                if (i && i != 41 && j && j != 34)
                {
                    mil_SetColor(0);
                    if (!map[i - 1][j])
                        mil_DrawLineV(3 * i + 1, 3 * j + 22, 3 * j + 25);
                    if (!map[i + 1][j])
                        mil_DrawLineV(3 * i + 3, 3 * j + 22, 3 * j + 25);
                    if (!map[i - 1][j + 34])
                        mil_DrawLineH(3 * i + 1, 3 * i + 4, 3 * j + 22);
                    if (!map[i][j + 1])
                        mil_DrawLineH(3 * i + 1, 3 * i + 4, 3 * j + 24);
                }
            }
            else
            {
                mil_SetColor(3);
                mil_FillRect(3 * i + 1, 3 * j + 22, 3 * i + 4, 3 * j + 25);
            }
        }
    }
}

void DrawGame()
{
    if (Alldrawflag == 1)
    {
        InitLCD();
        if (area_obtain_flag == 1)
        {
            if (itemTime || hamster_val1 || hamster_val2)
            {
                if (itemTime)
                {
                    gext_PlaySound(speed_up, sizeof(speed_up));
                }
                else if (hamster_val1)
                {
                    gext_PlaySound(speed_down, sizeof(speed_down));
                }
                else if (hamster_val2)
                {
                    gext_PlaySound(life_up, sizeof(life_up));
                }
            }
            else
            {
                gext_PlaySound(area_obtain, sizeof(area_obtain));
            }
            area_obtain_flag = 0;
        }
        DrawMap();
        mil_SaveLCD();
        Alldrawflag = 0;
    }
    mil_RestoreLCD();
    if (!player_action || player_action == 1)
    {
        mil_SetColor(0);
        for (i = move_stack_index - 1; i > 0; --i)
        {
            mil_FillRect(3 * (moveStack[i] >> 8) + 1,
                         3 * (moveStack[i] & 0xff) + 22,
                         3 * (moveStack[i] >> 8) + 3,
                         3 * (moveStack[i] & 0xff) + 24);
        }
    }
    DrawObject();
    DrawItem();
    DrawScore();
    gext_DrawLcd(swLcdBuffer);
}

void DrawGameOver()
{
    mil_Clear(0);
    mil_CopyImage(gameOverImage_0, 64, 64);
    if (s_Frame2)
        mil_CopyImage((char*)failHamster1, 64, 64);
    else
        mil_CopyImage((char*)failHamster2, 64, 64);
    gext_DrawLcd(swLcdBuffer);
}

void DrawTitle()
{
    mil_Clear(0);
    mil_CopyImage(scoreViewImage, 0, 0);
    mil_CopyImage(titleSphinx, 3, 54);
    mil_CopyImage(titleRainbow, 3, 124);
    switch (animation_index)
    {
    case 1:
        mil_CopyImage(titleHamster1, 100, 80);
        break;
    case 2:
        mil_CopyImage(titleHamster2, 96, 78);
        break;
    case 3:
        mil_CopyImage(titleHamster1, 92, 76);
        break;
    case 4:
        mil_CopyImage(titleHamster2, 88, 75);
        break;
    case 5:
        mil_CopyImage(titleHamster1, 84, 74);
        break;
    case 6:
        mil_CopyImage(titleHamster2, 80, 74);
        break;
    case 7:
        mil_CopyImage(titleHamster1, 76, 74);
        break;
    case 8:
        mil_CopyImage(titleHamster2, 72, 74);
        break;
    case 9:
        mil_CopyImage(titleHamster1, 68, 74);
        break;
    case 10:
        mil_CopyImage(titleHamster2, 64, 74);
        break;
    case 11:
        mil_CopyImage(titleHamster1, 64, 74);
        mil_CopyImage(introTextImage00_0, 64, 30);
        break;
    case 12:
        mil_CopyImage(titleHamster2, 64, 74);
        mil_CopyImage(introTextImage01_0, 64, 30);
        mil_CopyImage(introTextImage00_0, 64, 30);
        break;
    default:
        break;
    }
    gext_DrawLcd(swLcdBuffer);
}

void DrawGameClear()
{
    mil_Clear(S_BLACK);
    mil_CopyImage(backgroundImage[stage], 0, 0);
    mil_CopyImage(gameClearImage_0, 64, 54);
    gext_DrawLcd(swLcdBuffer);
}

void DrawNextStage()
{
    mil_Clear(S_BLACK);
    mil_SaveGamma();
    mil_SetGamma(5);
    mil_CopyImage(backgroundImage[stage + 1], 0, 0);
    mil_RestoreGamma();
    mil_CopyImage(nextStageImage_0, 64, 54);
    mil_CopyImage(imgNextStage_0[stage + 1], 64, 113);
    gext_DrawLcd(swLcdBuffer);
}

void DrawGameEnd()
{
    mil_CopyImage((char*)endingBack, 0, 0);
    if ((animation_index & 1) != 0)
        mil_CopyImage(endingImage, 64, 85);
    else
        mil_CopyImageDir((unsigned __int8*)endingImage, 64, 85, 1);
    if (animation_index > 8)
    {
        mil_CopyImage(endingTextImage00_0, 39, 20);
        mil_CopyImage(endingTextImage01_0, 79, 20);
        mil_CopyImage(endingTextImage02_0, 64, 40);
    }
    gext_DrawLcd(swLcdBuffer);
}

void CheckItem()
{
    if (hamster_val2 == 40)
        ++life;
    for (i = 0; i < 3; ++i)
    {
        if (itemTime[i] > 0)
            --itemTime[i];
    }
}

void CheckEnd()
{
    if (life >= 0)
    {
        flag = 1;
        for (i = 0; enemyCount[stage / 2] > i; ++i)
        {
            if (enemy_action[i] < 5)
            {
                flag = 0;
                break;
            }
        }
        if (flag)
        {
            gext_StopSound();
            mode = 4;
            gext_PlaySound(clear_sound, sizeof(clear_sound));
        }
    }
    else
    {
        gext_StopSound();
        mode = 3;
    }
}

int HamsterBoxMain(int nReason, int nData)
{
    int result; // r0

    switch (nReason)
    {
    case 0:
        mil_Clear(S_WHITE);
        mil_CopyImage(introImage, 0, 0);
        if (s_Frame2)
            mil_CopyImage(introTextImage01_0, 64, 24);
        mil_CopyImage(introTextImage00_0, 64, 24);
        if (s_Frame2)
            mil_CopyImage(playerImage03, 20, 18 + 43);
        else
            mil_CopyImage(playerImage06, 20, 18 + 43);
        return 0;
    case 1:
        mode = 0;
        animation_index = 0;
        gext_PlaySound(gameSound, sizeof(gameSound));
        DrawTitle();
        g_StartTimer(0, 250, 1);
        player_animation = 0;
        return 0;
    case 2:
        switch (mode)
        {
        case 0:
            DrawTitle();
            break;
        case 1:
            DrawGame();
            break;
        case 2:
            DrawNextStage();
            break;
        case 3:
            DrawGameOver();
            break;
        case 4:
            DrawGameClear();
            break;
        case 5:
            DrawGameEnd();
            break;
        default:
            break;
        }
        gm_DrawPauseMark();
        gext_DrawLcd(swLcdBuffer);
        return 1;
    case 3:
        g_StartTimer(0, 250, 1);
        if (mode == 1)
            InitLCD();
        return 0;
    case 4:
        switch (mode)
        {
        case 0:
            if (animation_index >= 12)
                animation_index = 11;
            else
                ++animation_index;
            DrawTitle();
            break;
        case 1:
            if (!nData)
            {
                player_animation = (player_animation) ? 0 : 5;
                PlayerMove();
                AllEnemyMove();
                DrawGame();
                CheckItem();
                CheckEnd();
            }
            break;
        case 2:
            DrawNextStage();
            break;
        case 3:
            DrawGameOver();
            break;
        case 4:
            DrawGameClear();
            break;
        case 5:
            if (animation_index >= 12)
                animation_index = 11;
            else
                ++animation_index;
            DrawGameEnd();
            break;
        default:
            return 0;
        }
        return 0;
    case 5:
        switch (mode)
        {
        case 0:
            if (nData == 30 || nData == 5)
            {
                stage = 0;
                score = 0;
                life = 3;
                mode = 1;
                gext_StopSound();
                GameInit();
            }
            return 0;
        case 1:
            if (nData == 26)
            {
                player_dir = 6;
            }
            else if (nData > 26)
            {
                switch (nData)
                {
                case 27:
                    player_dir = 2;
                    break;
                case 28:
                    player_dir = 0;
                    break;
                case 29:
                    player_dir = 4;
                    break;
                case 30:
                    player_dir = -1;
                    break;
                }
            }
            else
            {
                switch (nData)
                {
                case 2:
                    player_dir = 0;
                    break;
                case 4:
                    player_dir = 6;
                    break;
                case 5:
                    player_dir = -1;
                    break;
                case 6:
                    player_dir = 2;
                    break;
                case 8:
                    player_dir = 4;
                    break;
                default:
                    return 0;
                }
            }
            return 0;
        case 2:
            if (nData == 30 || nData == 5)
            {
                mode = 1;
                ++stage;
                GameInit();
            }
            return 0;
        case 3:
            if (nData == 7)
            {
                life = 3;
                mode = 1;
                score = 0;
                GameInit();
                return 0;
            }
            if (nData != 9)
                return 0;
            mode = 6;
            mil_Clear(S_WHITE);
            mil_CopyImage(scoreViewImage, 0, 0);
            mil_CopyImage(scoreTitle_0, 64, 12);
        LABEL_52:
            result = g_CheckScore(score);
            break;
        case 4:
            if (nData == 30 || nData == 5)
            {
                if (stage >= 19)
                {
                    mode = 5;
                    animation_index = 0;
                    gext_PlaySound(endingSound, sizeof(endingSound));
                }
                else
                {
                    gext_StopSound();
                    gext_PlaySound(introSound, sizeof(introSound));
                    mode = 2;
                }
            }
            return 0;
        case 5:
            if (nData != 30 && nData != 5)
                return 0;
            gext_StopSound();
            mode = 6;
            mil_Clear(S_WHITE);
            mil_CopyImage(scoreViewImage, 0, 0);
            mil_CopyImage(scoreTitle_0, 64, 12);
            goto LABEL_52;
        default:
            return 0;
        }
        return result;
    case 6:
        return 1;
    case 7:
    case 8:
        mil_Clear(S_WHITE);
        mil_CopyImage(scoreViewImage, 0, 0);
        mil_CopyImage(scoreTitle_0, 64, 12);
        return 0;
    case 9:
        mil_Clear(S_BLACK);
        mil_CopyImage(helpImage_0, 64, 64);
        return 0;
    default:
        return 0;
    }
}