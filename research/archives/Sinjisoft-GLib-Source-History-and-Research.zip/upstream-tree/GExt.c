//==============================================================================
//
//	MOBILE GAME EMULATOR STANDARD HEADER
//
//	FILE NAME
//		GExt.cpp
//
//	DESCRIPTION
//		All the declarations and definitions necessary for the Mobile Game
//		Emulator to interact with the Mobile and Game Emulator
//
//	REFERENCES
//		Mobile Game Emulator Porting Guide
//
//	Copyright (C) 1999 by SINJISOFT. All Rights Reserved.
//
//		1999.11. 0	Release Version 0.9
//		1999.12.21	Release Version 1.0
//		2000. 1. 7  Release Version 1.1
//		2000. 2.22  Release Version 1.2
//		2000.10. 8  Release Version 2.0
//
//==============================================================================
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "SimulatorLibrary.h"
#include <time.h>
#include "GLib.h"
#include "MyTimer.h"
#include "Midi.h"

#define	GAME_FILE	"game_nv.dat"
#define GAME_DATA_SIZE	76
#define GAME_NUMBER	5

#if defined(WIN32)||defined(_WINDOWS)
#include <io.h>
#define F_OK 0
#define access _access
#endif

MidiPlayerContext ctxt;

BYTE midiInit = 0;

//==============================================================================
//
//	Game Definition List
//
//==============================================================================

const s_GameDefType	s_GameDef[] = {

//	"Game Title",			Game title
//	"Game Description",		Game description
//	GameMain,				Game main function
//	0,						Game mode (0=Stand-alone, 1=1:1, 2=Network)
//	120, 80,				LCD width, height
//	76,						NV-ROM size = (((11+2+2)*G_SCOREBOARD_SIZE) +1) Gext.h�� Glib.h�� ���ڿ� ��ġ�Ͽ��� �Ѵ�.

#ifdef SKTT5

	"G80 Apache5",
	"Apache5",
	Apache5Main,
	0,
	128, 160,
	76,

	"G81 Raccoon3",
	"Raccoon3",
	Raccoon3Main,
	0,
	128, 160,
	76,

	"G82 MarsScouter3",
	"MarsScouter3",
	MarsScouter3Main,
	0,
	128, 160,
	76,

	"G83 Samtris3",
	"Samtris3",
	Samtris3Main,
	0,
	128, 160,
	76,

	"G84 Puzzle3",
	"Puzzle3",
	Puzzle3Main,
	0,
	128, 160,
	76,

#endif	//#ifdef SKTT5

	"G124 Gaza2_3",
	"Gaza2_3",
	Gaza2Main,
	0,
	128, 128,
	76,

	"G198 HamsterBox",
	"HamsterBox",
	HamsterBoxMain,
	0,
	128, 128,
	76,

	"UG01 FlyingBubble",
	"FlyingBubble",
	FlyingBubbleMain,
	0,
	128, 128,
	76,

	NULL, NULL, 0, 0, 0, 0
};

//==============================================================================
//
//	Game Extension Function
//
//==============================================================================

//======================================
//	Initialize game buffer
//

BYTE *GExt_Heap;

void gext_InitMemory()
{
	GExt_Heap = (BYTE*)malloc(1024*1024);

	if (GExt_Heap == NULL)
	{
		return;
	}

	swLcdBuffer     = (BYTE*)GExt_Heap;
    swBackLcdBuffer = swLcdBuffer + (S_LCD_BUFFER);

    memset(swLcdBuffer, 0, S_LCD_BUFFER);
    memset(swBackLcdBuffer, 0, S_LCD_BUFFER);

	//good place to init here the timer...

	Timer_Init();
}

//======================================
//	Close game buffer
//
void gext_CloseMemory()
{
	if (GExt_Heap != NULL)
	{
		free(GExt_Heap);
	}
	
	Timer_Cleanup();
}

//======================================
//	LCD update function
//

void gext_DrawLcd(const char* pLcdBuf)
{
	extern void DrawLCD(void* pLcdBuffer);
	DrawLCD((void*)pLcdBuf);
}

//======================================
//	Sound play function
//
//		data : sound data
//		size : byte size
//
void gext_PlaySound(const BYTE *pData, const int nSize)
{
	extern bool EmuSMAFPlay(void* snd_data, int snd_size, int volume);
	extern BOOL MIDIPlayFromMemory(MidiPlayerContext * context, const BYTE * buffer, int size);
	if (*pData == 0x02)
		EmuSMAFPlay((BYTE*)(pData + 2), nSize - 2, 127);
	else
	{
		if (pData[0] == 'M' && pData[1] == 'M' && pData[2] == 'M' && pData[3] == 'D')
			EmuSMAFPlay(pData, nSize, 127);
		else
		{
			if (midiInit == 0)
			{
				midiInit = 1;
				InitMidiPlayer(&ctxt);
			}
			MIDIPlayFromMemory(&ctxt, pData, nSize);
		}
			
	}
		
}

//======================================
//	Sound play function
//
//		data : sound data
//		size : byte size
//
void gext_PlaySound_background(const BYTE *pData, const int nSize)
{
	extern bool EmuSMAFPlay(void* snd_data, int snd_size, int volume);
	extern int MIDIPlayFromMemory(const BYTE * buffer, int size);
	if (*pData == 0x02)
		EmuSMAFPlay((BYTE*)(pData + 2), nSize - 2, 127);
	else
	{
		if (pData[0] == 'M' && pData[1] == 'M' && pData[2] == 'M' && pData[3] == 'D')
			EmuSMAFPlay(pData, nSize, 127);
		else
			MIDIPlayFromMemory(pData, nSize);
	}
}

//======================================
//	Stop playing sound background
//
void gext_StopSound()
{
	extern void EmuSMAFStop(void);
	extern void StopMidiStream(MidiPlayerContext * context);
	EmuSMAFStop();
	if (midiInit == 1)
	{
		StopMidiStream(&ctxt);
	}
}

//======================================
//	Start vibrator
//
void gext_StartVib(const int nSec)
{
}

//======================================
//	Stop vibrator
//
void gext_StopVib()
{
}

//For timer where it is controlled from functions...

void HandleTimer1(void* pUser)
{
	glib_GameEvent(GLIB_TIMEOUT_EVENT, 0);
}

void HandleTimer2(void* pUser)
{
	glib_GameEvent(GLIB_TIMEOUT_EVENT, 1);
}

void HandleTimer3(void* pUser)
{
	glib_GameEvent(GLIB_TIMEOUT_EVENT, 2);
}

//======================================
//	Start timer
//
//		nTid    : timer ID, 0, 1, 2
//		nMse    : timeout duration
//		nRepeat : timer repeat switch
//
void gext_StartTimer(const int nTid, int nMse, const int nRepeat)
{
	switch(nTid) {
	case 0:
		Timer_Start(nMse, HandleTimer1, NULL);
		break;
	case 1:
		Timer_Start(nMse, HandleTimer2, NULL);
		break;
	case 2:
		Timer_Start(nMse, HandleTimer3, NULL);
		break;
	default:
		break;
	}
}

//======================================
//	Stop timer
//
//		nTid : timer ID, 0, 1, 2
//
void gext_StopTimer(const int nTid)
{
    switch(nTid) {
	case 0:
		Timer_Stop(HandleTimer1, NULL);
		break;
	case 1:
		Timer_Stop(HandleTimer2, NULL);
		break;
	case 2:
		Timer_Stop(HandleTimer3, NULL);
		break;
	default:
		break;
	}
}

//======================================
//	Get game NV
//
//		nGid  : Game ID
//		pData : NV data pointer
//
void gext_GetNV(const int nGid, BYTE* const pData)
{
    FILE*	hFile;

    if(access(GAME_FILE, F_OK))
	{
		memset(pData, 0x00, GAME_DATA_SIZE);
		return;
	}

	hFile = fopen(GAME_FILE, "rb");

    fseek(hFile, GAME_DATA_SIZE * nGid, SEEK_SET);

	fread(pData, GAME_DATA_SIZE, 1, hFile);

    fclose(hFile);
}

//======================================
//	Put game NV-ROM data
//
//		nGid  : Game ID
//		pData : NV data pointer
//
void gext_PutNV(const int nGid, const BYTE* pData)
{
	FILE*	hFile;
	BYTE	szTmp[GAME_DATA_SIZE];
	BYTE	i;

    if(access(GAME_FILE, F_OK))
	{
		hFile = fopen(GAME_FILE, "wb");
		memset(szTmp, 0x00, GAME_DATA_SIZE);

		for(i = 0; i < GAME_NUMBER; i++)
			fwrite(szTmp, GAME_DATA_SIZE, 1, hFile);

		fseek(hFile, 0, SEEK_SET);
	}
	else
		hFile = fopen(GAME_FILE, "wb");

	fseek(hFile, GAME_DATA_SIZE * nGid, SEEK_SET);

	fwrite(pData, GAME_DATA_SIZE, 1, hFile);

	fclose(hFile);
}

//======================================
//	Get current time
//
void gext_GetDate(int* year, int* month, int* day, int* hour, int* min, int* sec)
{
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	*year = tm.tm_year+1900;
	*month = tm.tm_mon;
	*day = tm.tm_mday;
	*hour = tm.tm_hour;
	*min = tm.tm_min;
	*sec = tm.tm_sec;
}

//======================================
//	Set pseudo random seed
//
//		nSeed : pseudo random seed
//
void gext_RandomSeed(const int nSeed)
{
    srand(nSeed);
}

//======================================
//	Get pseudo random value
//
//		nBegin : random min boundary
//		nEnd   : random max boundary
//
int	gext_Random(const int nBegin, const int nEnd)
{
    return nBegin + (rand()%(nEnd - nBegin));
}

//jimylee 2001.04.27
//======================================
//
//	Turn On Key Tone Sound
//
//
void gext_OnKeyTone()
{
}
//jimylee 2001.04.27
//======================================
//
//	Turn Off Key Tone Sound
//
//
void gext_OffKeyTone()
{   
}

