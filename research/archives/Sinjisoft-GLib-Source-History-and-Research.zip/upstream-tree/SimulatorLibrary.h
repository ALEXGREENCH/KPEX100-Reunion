#include <stdbool.h>
#ifndef SIMULATORLIBRARY_H
#define SIMULATORLIBRARY_H
void MyGLibSimulator_SetKeyTone(bool bOn);
#endif