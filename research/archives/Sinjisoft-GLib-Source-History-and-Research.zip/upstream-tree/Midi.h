#ifndef MIDI_H
#define MIDI_H
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <mmsystem.h>
#include "sonivox_eas/Host/Inc/eas.h"
#include "sonivox_eas/Host/Inc/eas_report.h"

#define NUM_BUFFERS 8

typedef struct {
    HWAVEOUT hWaveOut;
    WAVEHDR waveHeaders[NUM_BUFFERS];
    EAS_DATA_HANDLE easData;
    EAS_HANDLE easHandle;
    BOOL isPlaying;
    EAS_I32 bufferSize;
    EAS_I32 sampleRate;
    EAS_I32 channels;
} MidiPlayerContext;
#endif