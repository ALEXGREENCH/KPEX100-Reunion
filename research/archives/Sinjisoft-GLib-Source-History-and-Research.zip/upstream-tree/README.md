# Sinjisoft GLib game simulator and games

# Purpose

Project purpose is to demonstrate running some SinjiSoft GLib games under PC, controlled
from a phone simulator window. User can select game to play on start.

# Games

## Current:

- Mars Scouter (ENG)

- Baby Raccoon Adventure (KOR)

- Samtris (KOR)

- Apache Fighter (KOR)

- Puzzle (ENG)

- Hamster Box (ENG, Decompile from SGH-C100)

## Upcoming games:

- Flying Bubble (ENG)

- Gaza 2 (ENG, Decompile from Giga Gxx-430)