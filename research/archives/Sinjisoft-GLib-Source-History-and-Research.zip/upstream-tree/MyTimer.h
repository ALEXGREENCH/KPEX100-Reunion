#ifndef TIMER_H
#define TIMER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

typedef void(*TimerCallback)(void* user);


// Start a timer with specified milliseconds delay, callback function and argument
int Timer_Start(unsigned long ms, TimerCallback callback, void* arg);

// Stop a timer based on its callback function and argument
int Timer_Stop(TimerCallback callback, void* arg);

// Initialize timer system
void Timer_Init(void);

// Cleanup timer system
void Timer_Cleanup(void);

#ifdef __cplusplus
}
#endif

#endif // TIMER_H