#include <stdio.h> 

#include <string.h> 

#include <stdlib.h>

#include "GLib.h"

#include "ma2Gaza2.cpp"

#include "mapGaza2.cpp"


typedef __packed struct t_opponentMap
{
    BYTE type;
    DWORD dx;
    DWORD dy;
    WORD frame;
    BYTE x;
    BYTE y;
} opponentMap;


char gameState;
unsigned __int16 score;
int gameScore;
char timedigit1; // weak
char timedigit2; // weak
char lives; // weak
char keys; // weak
int introFrame;
BYTE playerIsMoving;
int timeinMs; // idb
int level;
BYTE horizWallMap[10][8];
char vertWallMap[9][9];
BYTE horizWallMapback[10][8];
BYTE vertWallMapback[9][9];
BYTE playerOrientation; // weak
int playerAllX;
int playerAllY;
BYTE playerState;
DWORD playerX; // weak
DWORD playerY; // weak
opponentMap enemyAndKeyPlacement[8];
int spaceshipIntroX; // weak
int spaceshipIntroY; // weak
char strBuffer[12];
int GameLanguage; // weak
int dword_109074C; // weak
int playerFrame; // weak
int dword_1090754; // weak

#define getInteger(a) a
#define setInteger(a, b) { printf("set %s to %d\n", #b, a); b = (a); }

BYTE* paddleArray[8] = { paddleImage_0, paddleImage_1, paddleImage_2, paddleImage_3,
                          paddleImage_4, paddleImage_5, paddleImage_6, paddleImage_7};
BYTE* playerAnimation[10] = { playerImage_0, playerImage_1, playerImage_2, playerImage_3, playerImage_4,
                               playerImage_5, playerImage_6, playerImage_7, playerImage_8, playerImage_9};
BYTE* enemyImageArray[3][10] =
{
  {
    enemyImage_0, enemyImage_1, enemyImage_2, enemyImage_3, enemyImage_4,
    enemyImage_5, enemyImage_6, enemyImage_7, enemyImage_8, enemyImage_9
  },
  {
	enemyImage_10,enemyImage_11, enemyImage_12, enemyImage_13, enemyImage_14,
	enemyImage_15, enemyImage_16, enemyImage_17, enemyImage_18, enemyImage_19
  },
  {
	enemyImage_20, enemyImage_21, enemyImage_22, enemyImage_23, enemyImage_24,
	enemyImage_25, enemyImage_26, enemyImage_27, enemyImage_28, enemyImage_29
  }
};
BYTE* playerGameOverAnimation[2] = { playerLoseImage_0, playerLoseImage_1 };

void gameDrawLogo()
{
    mil_CopyImage(gameLogoMenu, SWAP_LCD_WIDTH / 2, 10);
}

void gameDrawStatus()
{
    int v0; // r1
    int v1; // r0
    unsigned int v2; // r0
    int v3; // r1
    int v4; // r1

    sprintf(strBuffer, "%d", timedigit1);
    mil_DrawString(SWAP_LCD_WIDTH - 14, 15, strBuffer, 1, 3, 0);
    sprintf(strBuffer, "%d", timedigit2);
    mil_DrawString(SWAP_LCD_WIDTH - 8, 15, strBuffer, 1, 3, 0);
    sprintf(strBuffer, "%d", lives);
    mil_DrawString(SWAP_LCD_WIDTH - 10, 38, strBuffer, 1, 3, 0);
    if (score + 1 >= 10)
    {
        sprintf(strBuffer, "%d", (score + 1)/10);
        mil_DrawString(SWAP_LCD_WIDTH - 14, 70, strBuffer, 1, 3, 0);
        sprintf(strBuffer, "%d", (score + 1)&10);
        mil_DrawString(SWAP_LCD_WIDTH - 8, 70, strBuffer, 1, 3, 0);
    }
    else
    {
        sprintf(strBuffer, "%d", score + 1);
        mil_DrawString(SWAP_LCD_WIDTH - 10, 70, strBuffer, 1, 3, 0);
    }
    sprintf(strBuffer, "%d", 5 - keys);
    mil_DrawString(SWAP_LCD_WIDTH - 10, 98, strBuffer, 1, 3, 0);
    if (timedigit1 == 1 && !timedigit2 || !timedigit1 && timedigit2 == 5)
    {
        gext_PlaySound(hurrySound, 209);
        gext_StartVib(2);
    }
}

void gameDrawElement()
{
    int i;
    int j;
    int k;
    int l;

    mil_RestoreLCD();
    for (i = 0; i < 10; ++i)
    {
        for (j = 0; j<8; j++)
        {
            if (horizWallMap[i][j] > 1u)
                mil_CopyImage(paddleArray[horizWallMap[i][j] - 2], 14 * j + 1, 14 * i + 1);
        }
    }
    for (i = 0; i < 9; ++i)
    {
        for (j = 0; j < 9; j++)
        {
            if (vertWallMap[i][j] > 1u)
                mil_CopyImage(paddleArray[vertWallMap[i][j] - 2], 14 * j + 1, 14 * i + 1);
        }
    }
    gameDrawStatus();
    for (k = 0; k < 5; ++k)
    {
        if (enemyAndKeyPlacement[k+3].type == 1)
            mil_CopyImage(keyImageS, getInteger(enemyAndKeyPlacement[k + 3].dx), getInteger(enemyAndKeyPlacement[k + 3].dy) + 1);
    }
    switch (playerOrientation)
    {
    case 0:
        mil_CopyImage(playerAnimation[playerFrame], getInteger(playerAllX), getInteger(playerAllY) + 1);
        break;
    case 1:
        setInteger(getInteger(playerAllX) - 7, playerAllX);
        --playerState;
        mil_CopyImage(playerAnimation[playerState + 4], getInteger(playerAllX), getInteger(playerAllY) + 1);
        if (!playerState)
            playerOrientation = 0;
        break;
    case 2:
        setInteger(getInteger(playerAllX) + 7, playerAllX);
        --playerState;
        mil_CopyImage(playerAnimation[playerState + 2], getInteger(playerAllX), getInteger(playerAllY) + 1);
        if (!playerState)
            playerOrientation = 0;
        break;
    case 3:
        setInteger(getInteger(playerAllY) + 7, playerAllY);
        --playerState;
        mil_CopyImage(playerAnimation[playerState + 8], getInteger(playerAllX), getInteger(playerAllY) + 1);
        if (!playerState)
            playerOrientation = 0;
        break;
    case 4:

        setInteger(getInteger(playerAllY) - 7, playerAllY);
        --playerState;
        mil_CopyImage(playerAnimation[playerState + 6], getInteger(playerAllX), getInteger(playerAllY) + 1);
        if (!playerState)
            playerOrientation = 0;
        break;
    default:
        break;
    }
    for (l = 0; l < 3; ++l)
    {
        switch (enemyAndKeyPlacement[l].type)
        {
        case 0:
            mil_CopyImage(enemyImageArray[l][playerFrame], getInteger(enemyAndKeyPlacement[l].dx), getInteger(enemyAndKeyPlacement[l].dy) + 1);
            break;
        case 1:
            setInteger(getInteger(enemyAndKeyPlacement[l].dx) - 7, enemyAndKeyPlacement[l].dx);
            --enemyAndKeyPlacement[l].frame;
            mil_CopyImage(enemyImageArray[l][enemyAndKeyPlacement[l].frame + 4], getInteger(enemyAndKeyPlacement[l].dx), getInteger(enemyAndKeyPlacement[l].dy) + 1);
            if (!enemyAndKeyPlacement[l].frame)
                enemyAndKeyPlacement[l].type = 0;
            break;
        case 2:
            setInteger(getInteger(enemyAndKeyPlacement[l].dx), enemyAndKeyPlacement[l].dx);
            --enemyAndKeyPlacement[l].frame;
            mil_CopyImage(enemyImageArray[l][enemyAndKeyPlacement[l].frame + 2], getInteger(enemyAndKeyPlacement[l].dx), getInteger(enemyAndKeyPlacement[l].dy) + 1);
            if (!enemyAndKeyPlacement[l].frame)
                enemyAndKeyPlacement[l].type = 0;
            break;
        case 3:
            setInteger(getInteger(enemyAndKeyPlacement[l].dy) + 7, enemyAndKeyPlacement[l].dy);
            --enemyAndKeyPlacement[l].frame;
            mil_CopyImage(enemyImageArray[l][enemyAndKeyPlacement[l].frame + 8], getInteger(enemyAndKeyPlacement[l].dx), getInteger(enemyAndKeyPlacement[l].dy) + 1);
            if (!enemyAndKeyPlacement[l].frame)
                enemyAndKeyPlacement[l].type = 0;
            break;
        case 4:
            setInteger(getInteger(enemyAndKeyPlacement[l].dy) - 7, enemyAndKeyPlacement[l].dy);
            --enemyAndKeyPlacement[l].frame;
            mil_CopyImage(enemyImageArray[l][enemyAndKeyPlacement[l].frame + 6], getInteger(enemyAndKeyPlacement[l].dx), getInteger(enemyAndKeyPlacement[l].dy) + 1);
            if (!enemyAndKeyPlacement[l].frame)
                enemyAndKeyPlacement[l].type = 0;
            break;
        default:
            continue;
        }
    }
    playerIsMoving = 0;
}
// 8: using guessed type int dword_8;
// 1090750: using guessed type int playerFrame;

//----- (0007D31C) --------------------------------------------------------
int gameDrawBackground()
{
    int i; // r4
    int j; // r7
    int k; // r4
    int l; // r7

    mil_CopyImage(backgroundImage, 0, 0);
    mil_CopyImage(doorImage, SWAP_LCD_WIDTH - 15, 110);
    mil_CopyImage(timeImage, SWAP_LCD_WIDTH - 12, 3);
    mil_CopyImage(lifeImage, SWAP_LCD_WIDTH - 12, 28);
    mil_CopyImage(scoreImage, SWAP_LCD_WIDTH - 12, 55);
    mil_CopyImage(keyImage, SWAP_LCD_WIDTH - 12, 85);
    for (i = 0; i < 10; ++i)
    {
        for (j = 0; j < 8; ++j)
        {
            if (horizWallMap[i][j] == 1)
                mil_CopyImage(wallHImage, 14 * j + 1, 14 * i + 1);
        }
    }
    for (k = 0; k < 9; ++k)
    {
        for (l = 0; l < 9; ++l)
        {
            if (vertWallMap[k][l] == 1)
                mil_CopyImage(wallVImage, 14 * l + 1, 14 * k + 1);
        }
    }
    mil_SaveLCD();
}
// 1090824: using guessed type int SWAP_LCD_WIDTH;

//----- (0007D400) --------------------------------------------------------
void gameDrawIntroBackground()
{
    mil_CopyImage(introBackgroundImage, 0, 0);
    mil_CopyImage(gameLogoImage, 0, 10);
    mil_SaveLCD();
}

//----- (0007D428) --------------------------------------------------------
void gameInitKeys()
{
    int i; // r4

    for (i = 0; i < 5; ++i)
    {
        do
        {
            enemyAndKeyPlacement[i+3].x = gext_Random(0, 7);
            enemyAndKeyPlacement[i+3].y = gext_Random(0, 8);
            setInteger(14 * enemyAndKeyPlacement[i+3].x + 2, enemyAndKeyPlacement[i+3].dx);
            setInteger(14 * enemyAndKeyPlacement[i+3].y + 3, enemyAndKeyPlacement[i+3].dy);
        } while (!enemyAndKeyPlacement[i+3].x && !enemyAndKeyPlacement[i+3].y);
    }
}

//----- (0007D488) --------------------------------------------------------
void gameInitEnemies()
{
    int i; // r4

    for (i = 0; i < 3; ++i)
    {
        do
        {
            enemyAndKeyPlacement[i].type = 0;
            enemyAndKeyPlacement[i].x = gext_Random(0, 7);
            enemyAndKeyPlacement[i].y = gext_Random(0, 8);
            setInteger(14 * enemyAndKeyPlacement[i].x + 2, enemyAndKeyPlacement[i].dx);
            setInteger(14 * enemyAndKeyPlacement[i].y + 1, enemyAndKeyPlacement[i].dy);
            enemyAndKeyPlacement[i].frame = 2;
        } while (enemyAndKeyPlacement[i].x < 3 && enemyAndKeyPlacement[i].y < 3);
    }
}

//----- (0007D4F4) --------------------------------------------------------

void gameSetMap(void)

{
    BYTE bVar1;
    BYTE bVar2;
    INT4 uVar3;
    int iVar4;
    int x;
    int y;
    DWORD uVar5;
    int rg2;
    DWORD rg;
    DWORD local_28;
    DWORD local_24;
    DWORD local_20;
    DWORD local_1c;
    DWORD local_18;

    rg2 = 0;
    y = 0;
    do {
        x = 0;
        do {
            horizWallMap[y][x] = 0;
            x = x + 1;
        } while (x < 8);
        y = y + 1;
    } while (y < 10);
    y = 0;
    do {
        x = 0;
        do {
            vertWallMap[y][x] = 0;
            x = x + 1;
        } while (x < 9);
        y = y + 1;
    } while (y < 9);
    rg = 0;
    for (y = 0; y < 10; ++y)
    {
        for (x = 0; x < 8; ++x)
        {
            if (playerFrame == 1 && (y - 1) <= 1)
                break;
            if (!horizWallMap[y][x])
            {
                switch (gext_Random(horizWallMap[y][x], 5))
                {
                case 0:
                case 4:
                    rg = 0;
                    break;
                case 1:
                    if (++rg < 3)
                        horizWallMap[y][x] = 1;
                    else
                        rg = 0;
                    break;
                case 2:
                    if (x == 7 || (y - 1) >= 8)
                    {
                        if (++rg >= 3)
                            rg = 0;
                    }
                    else
                    {
                        if (horizWallMap[y][x] != 2 && horizWallMap[y - 1][x] != 6)
                        {
                            horizWallMap[y][x] = 2;
                            horizWallMap[y][x + 1] = 4;
                        }
                        if (++rg >= 3)
                            rg = 0;
                    }
                    horizWallMap[y][x] = 1;
                    break;
                case 3:
                    if (x == 7 || (y - 1) >= 8)
                    {
                        if (++rg < 3)
                        {
                            horizWallMap[y][x] = 1;
                            break;
                        }
                    }
                    else
                    {
                        if (horizWallMap[y][x] == 2 || horizWallMap[y][x] == 6)
                        {
                            if (++rg < 3)
                                horizWallMap[y][x] = 1;
                        }
                        else
                        {
                            horizWallMap[y][x] = 6;
                            horizWallMap[y][x + 1] = 8;
                        }
                    }
                    if (rg >= 3)
                        rg = 0;
                    break;
                default:
                    break;
                }
            }
        }
    }
    y = 0;
    rg2 = 0;
    do {
        x = 0;
        do {
            if ((playerFrame == 0) && (rg2 - 1U < 2)) break;
            if (vertWallMap[x][rg2] != 0) goto LAB_0007d7b4;
            iVar4 = gext_Random(1, 4);
            if (iVar4 == 1) {
                if ((x == 8) && (6 < rg2)) goto LAB_0007d76a;
                if ((((x != 0) || ((horizWallMap[0][rg2 + 7] != 1 || (horizWallMap[9][rg2 + 7] != 1)))) &&
                    ((x != 9 || ((horizWallMap[8][rg2 + 7] != 1 || (vertWallMap[8][rg2 + 8] != 1)))))) &&
                    (x + 1 < 9)) {
                    bVar2 = horizWallMap[x + -1][rg2 + 7];
                    if ((((bVar2 != 2) && (bVar2 != 6)) && (bVar1 = horizWallMap[x][rg2 + 7], bVar1 != 2)) &&
                        (bVar1 != 6)) {
                        if ((((bVar2 != 1) || (bVar1 != 1)) || (vertWallMap[x + -1][rg2 + 8] != 1)) &&
                            (((rg2 != 7 || (horizWallMap[x][7] != 1)) || (horizWallMap[x + 1][7] != 1))))
                            goto joined_r0x0007d66e;
                        goto LAB_0007d76a;
                    }
                }
            }
            else {
                if (iVar4 == 2) {
                    if ((x != 8) || (rg2 != 7)) {
                        if ((rg2 == 0) || (rg2 == 8)) {
                        joined_r0x0007d66e:
                            if (y + 1 < 3) {
                                y = y + 1;
                                vertWallMap[x][rg2] = 1;
                                goto LAB_0007d7b4;
                            }
                        }
                        else if (x != 8) {
                            if ((((horizWallMap[x][rg2 + 7] != 0) || (horizWallMap[x + 1][rg2] != 0)) ||
                                (bVar2 = vertWallMap[x + -1][rg2 + 8], bVar2 == 3)) ||
                                (((bVar2 == 7 || (bVar2 = horizWallMap[x + -1][rg2 + 7], bVar2 == 2)) ||
                                    (bVar2 == 6)))) goto LAB_0007d7b4;
                            vertWallMap[x][rg2] = 3;
                            bVar2 = 5;
                        LAB_0007d7a6:
                            vertWallMap[x + 1][rg2] = bVar2;
                        }
                    }
                }
                else {
                    if (iVar4 != 3) goto LAB_0007d7b4;
                    if ((x != 8) || (rg2 != 7)) {
                        if ((rg2 == 0) || (rg2 == 8)) goto joined_r0x0007d66e;
                        if (x != 8) {
                            if ((((horizWallMap[x][rg2 + 7] == 0) && (horizWallMap[x + 1][rg2] == 0)) &&
                                (bVar2 = vertWallMap[x + -1][rg2 + 8], bVar2 != 3)) &&
                                (((bVar2 != 7 && (bVar2 = horizWallMap[x + -1][rg2 + 7], bVar2 != 2)) &&
                                    (bVar2 != 6)))) {
                                vertWallMap[x][rg2] = 7;
                                bVar2 = 9;
                                goto LAB_0007d7a6;
                            }
                            goto LAB_0007d7b4;
                        }
                    }
                }
            LAB_0007d76a:
                y = 0;
            }
        LAB_0007d7b4:
            x = x + 1;
        } while (x < 9);
        rg2 = rg2 + 1;
        if (8 < rg2) {
            y = 0;
            do {
                horizWallMap[0][y] = 1;
                rg2 = y + 1;
                horizWallMap[9][y] = 1;
                y = rg2;
            } while (rg2 < 8);
            y = 0;
            do {
                vertWallMap[y][0] = 1;
                if (y == 8) {
                    vertWallMap[8][8] = 0;
                }
                else {
                    vertWallMap[y][8] = 1;
                }
                y = y + 1;
            } while (y < 9);
            y = 0;
            do {
                rg2 = 0;
                do {
                    horizWallMapback[y][rg2] = horizWallMap[y][rg2];
                    rg2 = rg2 + 1;
                } while (rg2 < 8);
                y = y + 1;
            } while (y < 10);
            y = 0;
            do {
                rg2 = 0;
                do {
                    vertWallMapback[y][rg2] = vertWallMap[y][rg2];
                    rg2 = rg2 + 1;
                } while (rg2 < 9);
                y = y + 1;
            } while (y < 9);
            return;
        }
    } while (1);
}


// 7D69A: conditional instruction was optimized away because of 'r5.4<9'
// 1090750: using guessed type int playerFrame;

//----- (0007D84C) --------------------------------------------------------
void gameBackupMap()
{
    int i; // r1
    int j; // r0

    for (i = 0; i < 10; ++i)
    {
        for (j = 0; j < 8; ++j)
            horizWallMap[i][j] = horizWallMapback[i][j];
    }
    for (i = 0; i < 9; ++i)
    {
        for (j = 0; j < 9; ++j)
            vertWallMap[i][j] = vertWallMapback[i][j];
    }
}

//----- (0007D89C) --------------------------------------------------------
void gameCollectKeyHandle()
{
    int i;
    for (i = 0; i < 5; ++i)
    {
        if (enemyAndKeyPlacement[i+3].type == 1 && playerX == enemyAndKeyPlacement[i + 3].x && playerY == enemyAndKeyPlacement[i+3].y)
        {
            enemyAndKeyPlacement[i+3].type = 0;
            gameScore += 10;
            ++keys;
            gext_PlaySound(endSound, 1026);
            break;
        }
    }
}
// 8: using guessed type int dword_8;
// C: using guessed type int dword_C;
// 109056B: using guessed type char keys;

//----- (0007D8FC) --------------------------------------------------------
void playerMoveLeft()
{
    if (playerX > 0)
    {
        if (vertWallMap[playerY][playerX])
        {
            if (vertWallMap[playerY][playerX] != 5 || horizWallMap[playerY][playerX - 1] || horizWallMap[playerY][playerX])
            {
                if (vertWallMap[playerY][playerX] != 7 || horizWallMap[playerY + 1][playerX - 1] || horizWallMap[playerY + 1][playerX])
                {
                    playerOrientation = 0;
                }
                else
                {
                    vertWallMap[playerY][playerX] = 0;
                    vertWallMap[playerY + 1][playerX] = 0;
                    horizWallMap[playerY + 1][playerX - 1] = 6;
                    horizWallMap[playerY + 1][playerX] = 8;
                    playerX--;
                    playerState = 2;
                    playerOrientation = 1;
                }
            }
            else
            {
                vertWallMap[playerY][playerX] = 0;
                vertWallMap[playerY - 1][playerX] = 0;
                horizWallMap[playerY][playerX - 1] = 2;
                horizWallMap[playerY][playerX] = 4;
                playerX--;
                playerOrientation = 1;
                playerState = 2;
            }
        }
        else
        {
            playerOrientation = 1;
            playerState = 2;
            playerX--;
        }
        gameCollectKeyHandle();
    }
}
// 8: using guessed type int dword_8;

//----- (0007D9AC) --------------------------------------------------------
void playerMoveRight()
{
    if (playerX + 1 < 8)
    {
        if (vertWallMap[playerY][playerX + 1])
        {
            if (vertWallMap[playerY][playerX + 1] != 3 || horizWallMap[playerY + 1][playerX] || horizWallMap[playerY + 1][playerX + 1])
            {
                if (vertWallMap[playerY][playerX + 1] != 9 || horizWallMap[playerY][playerX] || horizWallMap[playerY][playerX + 1])
                {
                    playerOrientation = 0;
                }
                else
                {
                    vertWallMap[playerY][playerX + 1] = 0;
                    vertWallMap[playerY - 1][playerX + 1] = 0;
                    horizWallMap[playerY][playerX] = 6;
                    horizWallMap[playerY][playerX + 1] = 8;
                    playerX++;
                    playerOrientation = 2;
                    playerState = 2;
                }
            }
            else
            {
                vertWallMap[playerY][playerX + 1] = 0;
                vertWallMap[playerY + 1][playerX + 1] = 0;
                horizWallMap[playerY + 1][playerX] = 2;
                horizWallMap[playerY + 1][playerX + 1] = 4;
                playerX++;
                playerOrientation = 2;
                playerState = 2;
            }
        }
        else
        {
            playerOrientation = 2;
            playerState = 2;
            playerX++;
        }
        gameCollectKeyHandle();
    }
    if (!vertWallMap[playerY][playerX + 1] && playerX == 7 && playerY == 8 && keys == 5)
    {
        gameScore += 10 * timedigit1 + timedigit2;
        level = 0;
        gameState = 2;
        gext_PlaySound(winSound, 593);
        introFrame = 0;
        setInteger(50, playerAllX);
        setInteger(70, playerAllY);
        spaceshipIntroY = 20;
        spaceshipIntroX = 0;
        if (score != 255)
            score++;
    }
}
// 0: using guessed type int dword_0;
// 8: using guessed type int dword_8;
// 1090568: using guessed type char timedigit1;
// 1090569: using guessed type char timedigit2;
// 109056B: using guessed type char keys;
// 1090734: using guessed type int spaceshipIntroX;
// 1090738: using guessed type int spaceshipIntroY;

//----- (0007DAC8) --------------------------------------------------------
void playerMoveUp()
{
    if (playerY > 0)
    {
        if (horizWallMap[playerY][playerX])
        {
            if (horizWallMap[playerY][playerX] != 2 || vertWallMap[playerY - 1][playerX - 1] || vertWallMap[playerY][playerX + 1])
            {
                if (horizWallMap[playerY][playerX] != 8 || vertWallMap[playerY - 1][playerX] || vertWallMap[playerY][playerX])
                {
                    playerOrientation = 0;
                }
                else
                {
                    horizWallMap[playerY][playerX] = 0;
                    horizWallMap[playerY][playerX - 1] = 0;
                    vertWallMap[playerY - 1][playerX] = 7;
                    vertWallMap[playerY][playerX] = 9;
                    playerY--;
                    playerOrientation = 4;
                    playerState = 2;
                }
            }
            else
            {
                horizWallMap[playerY][playerX] = 0;
                horizWallMap[playerY][playerX + 1] = 0;
                vertWallMap[playerY - 1][playerX - 1] = 3;
                vertWallMap[playerY][playerX + 1] = 5;
                playerY--;
                playerOrientation = 4;
                playerState = 2;
            }
        }
        else
        {
            playerOrientation = 4;
            playerState = 2;
            playerY--;
        }
        gameCollectKeyHandle();
    }
}
// 8: using guessed type int dword_8;

//----- (0007DB7C) --------------------------------------------------------
void playerMoveDown()
{
    if (playerY + 2 < 10)
    {
        if (horizWallMap[playerY][playerX])
        {
            if (horizWallMap[playerY + 1][playerX] != 4 || vertWallMap[playerY][playerX] || vertWallMap[playerY + 1][playerX])
            {
                if (horizWallMap[playerY + 1][playerX] != 6 || vertWallMap[playerY][playerX+1] || vertWallMap[playerY + 1][playerX + 1])
                {
                    playerOrientation = 0;
                }
                else
                {
                    horizWallMap[playerY + 1][playerX] = 0;
                    horizWallMap[playerY + 1][playerX + 1] = 0;
                    vertWallMap[playerY][playerX + 1] = 7;
                    vertWallMap[playerY + 1][playerX + 1] = 9;
                    playerY++;
                    playerOrientation = 3;
                    playerState = 2;
                }
            }
            else
            {
                horizWallMap[playerY + 1][playerX] = 0;
                horizWallMap[playerY + 1][playerX - 1] = 0;
                vertWallMap[playerY][playerX] = 3;
                vertWallMap[playerY + 1][playerX] = 5;
                playerY++;
                playerOrientation = 3;
                playerState = 2;
            }
        }
        else
        {
            playerOrientation = 3;
            playerState = 2;
            playerY++;
        }
        gameCollectKeyHandle();
    }
}

//----- (0007DC2C) --------------------------------------------------------
void PutCollectible1(int i)
{
    if (enemyAndKeyPlacement[i].x > 0)
    {
        if (vertWallMap[enemyAndKeyPlacement [i].y][enemyAndKeyPlacement[i].x])
        {
            enemyAndKeyPlacement[i].type = 0;
        }
        else
        {
            enemyAndKeyPlacement[i].type = 1;
            enemyAndKeyPlacement[i].x--;
            enemyAndKeyPlacement[i].frame = 2;
        }
    }
}

//----- (0007DC68) --------------------------------------------------------
void PutCollectible2(int i)
{
    if (enemyAndKeyPlacement[i].x + 1 < 8)
    {
        if(vertWallMap[enemyAndKeyPlacement[i].y][enemyAndKeyPlacement[i].x])
        {
            enemyAndKeyPlacement[i].type = 0;
        }
        else
        {
            enemyAndKeyPlacement[i].type = 2;
            enemyAndKeyPlacement[i].x++;
            enemyAndKeyPlacement[i].frame = 2;
        }
    }
}

//----- (0007DCE8) --------------------------------------------------------
void PutCollectible3(int i)
{
    if (enemyAndKeyPlacement[i].x + 1 < 10)
    {
        if (vertWallMap[enemyAndKeyPlacement[i].y][enemyAndKeyPlacement[i].x])
        {
            enemyAndKeyPlacement[i].type = 0;
        }
        else
        {
            enemyAndKeyPlacement[i].type = 3;
            enemyAndKeyPlacement[i].x++;
            enemyAndKeyPlacement[i].frame = 2;
        }
    }
}

//----- (0007DCA8) --------------------------------------------------------
void PutCollectible4(int i)
{
    if (enemyAndKeyPlacement[i].y > 0)
    {
        if (horizWallMap[enemyAndKeyPlacement[i].y][enemyAndKeyPlacement[i].x])
        {
            enemyAndKeyPlacement[i].type = 0;
        }
        else
        {
            enemyAndKeyPlacement[i].type = 4;
            enemyAndKeyPlacement[i].y--;
            enemyAndKeyPlacement[i].frame = 2;
        }
    }
}

//----- (0007DD2C) --------------------------------------------------------
void gameTimeHandler()
{
    timeinMs += 200;
    if (timeinMs > 1000)
    {
        if (timedigit1)
        {
            if (!timedigit2)
            {
                --timedigit1;
                timedigit2 = 9;
            }
            else
            {
                timedigit2--;
            }
        }
        else
        {
            if (!timedigit2)
            {
                gameState = 7;
                introFrame = 0;
                mil_SaveLCD();
                gext_StartVib(2);
            }
            else
            {
                timedigit2--;
            }
        }
        timeinMs -= 1000;
    }
}
// 8: using guessed type int dword_8;
// 1090568: using guessed type char timedigit1;
// 1090569: using guessed type char timedigit2;

//----- (0007DD8C) --------------------------------------------------------
void gameStart()
{
    int curr_key;

    gameState = 4;
    playerOrientation = 0;
    setInteger(2, playerAllX);
    setInteger(1, playerAllY);
    playerX = 0;
    playerY = 0;
    playerState = 0;
    keys = 0;
    for (curr_key=0;curr_key<5;curr_key++)
    {
        enemyAndKeyPlacement[curr_key+3].type = 1;
    }
    timedigit1 = 6;
    timedigit2 = 0;
    timeinMs = 0;
    level = 0;
    gameDrawBackground();
    gameInitEnemies();
    gameInitKeys();
    gameDrawElement();
}
// 7DDDE: variable 'v2' is possibly undefined
// 7DDDE: variable 'v3' is possibly undefined
// 7DDDE: variable 'v4' is possibly undefined
// 7DDDE: variable 'v5' is possibly undefined
// 8: using guessed type int dword_8;
// 1090568: using guessed type char timedigit1;
// 1090569: using guessed type char timedigit2;
// 109056B: using guessed type char keys;

//----- (0007DDF0) --------------------------------------------------------
void gamePutRandCollectible()
{
    int i; // r7

    for (i = 0; i < 3; ++i)
    {
        if (!enemyAndKeyPlacement[i].type)
        {
            switch (gext_Random(0, 5))
            {
            case 1:
                PutCollectible1(i);
                break;
            case 2:
                PutCollectible2(i);
                break;
            case 3:
                PutCollectible3(i);
                break;
            case 4:
                PutCollectible4(i);
                break;
            default:
                continue;
            }
        }
    }
}

//----- (0007DE48) --------------------------------------------------------
void gameDrawIntroElements()
{
    mil_RestoreLCD();
    if (introFrame < 25)
    {
        mil_CopyImage(spaceshipIntoImage_0, spaceshipIntroX, spaceshipIntroY);
        spaceshipIntroX -= 5;
        if (playerFrame)
            spaceshipIntroY -= 5;
        else
            spaceshipIntroY += 5;
    }
    if (introFrame >= 25 && introFrame < 30)
    {
        mil_CopyImage(spaceshipIntoImage_1, spaceshipIntroX - 3, spaceshipIntroY);
        setInteger(spaceshipIntroX + 4, playerAllX);
        setInteger(spaceshipIntroY + 40, playerAllY);
    }
    if (introFrame >= 30 && introFrame < 35)
    {
        mil_CopyImage(spaceshipIntoImage_1, spaceshipIntroX - 3, spaceshipIntroY);
        mil_CopyImage(playerIntroImage_0, getInteger(playerAllX), getInteger(playerAllY));
        setInteger(getInteger(playerAllY) + 4, playerAllY);
    }
    if (introFrame >= 35 && introFrame < 50)
    {
        switch (introFrame & 3)
        {
        case 0:
        case 2:
            mil_CopyImage(playerIntroImage_3, getInteger(playerAllX), getInteger(playerAllY));
            setInteger(getInteger(playerAllX) + 3, playerAllX);
            break;
        case 1:
        case 3:
            mil_CopyImage(playerIntroImage_4, getInteger(playerAllX), getInteger(playerAllY));
            setInteger(getInteger(playerAllX) + 3, playerAllX);
            break;
        }
    }
    if (introFrame >= 50 && introFrame < 56)
    {
        if (playerFrame)
        {
            mil_CopyImage(playerIntroImage_2, getInteger(playerAllX), getInteger(playerAllY));
        }
        else
        {
            mil_CopyImage(playerIntroImage_1, getInteger(playerAllX), getInteger(playerAllY));
        }
    }
    if (introFrame >= 56 && introFrame < 68)
    {
        switch ((introFrame - 56 >= 0) ? ((introFrame - 56) & 3) : (-((3 * (introFrame - 56)) & 3)))
        {
        case 0:
        case 2:
            mil_CopyImage(playerIntroImage_3, getInteger(playerAllX), getInteger(playerAllY));
            setInteger(getInteger(playerAllX) + 4, playerAllX);
            break;
        case 1:
        case 3:
            mil_CopyImage(playerIntroImage_4, getInteger(playerAllX), getInteger(playerAllY));
            setInteger(getInteger(playerAllX) + 4, playerAllX);
            break;
            break;
        }
    }
    if (introFrame >= 68)
    {
        introFrame = 0;
        gameSetMap();
        gameStart();
    }
    playerFrame = !playerFrame; // toggle playerFrame between 0 and 1 for situation like spaceship go up and down
    introFrame++;
}
// 1090734: using guessed type int spaceshipIntroX;
// 1090738: using guessed type int spaceshipIntroY;
// 1090750: using guessed type int playerFrame;

//----- (0007E000) --------------------------------------------------------
void gameDrawSuccess()
{
    int v0; // r1
    char* v1; // r0
    int v2; // r7
    int v3; // r0
    int v4; // r7
    int v5; // r0
    int v6; // r0
    int v7; // r6
    int v8; // r0
    int v9; // r0

    mil_CopyImage(introBackgroundImage, 0, 0);
    if (GameLanguage)
    {
        mil_CopyImage(successChineseImage, SWAP_LCD_WIDTH / 2, 10);
    }
    else
    {
        mil_CopyImage(successEnglishImage, 0, 10);
    }
    
    if (introFrame < 2)
    {
        mil_CopyImage(playerSuccessImage_1, getInteger(playerAllX), getInteger(playerAllY));
    }
    if (introFrame >= 2 && introFrame < 7)
    {
        mil_CopyImage(playerSuccessImage_1, getInteger(playerAllX), getInteger(playerAllY));
        mil_CopyImage(spaceshipIntoImage_1, spaceshipIntroX, spaceshipIntroY);
        spaceshipIntroX += 8;
        if (playerFrame)
            spaceshipIntroY -= 5;
        else
            spaceshipIntroY += 5;
    }
    if (introFrame >= 7 && introFrame < 10)
    {
        mil_CopyImage(playerSuccessImage_0, getInteger(playerAllX), getInteger(playerAllY));
        mil_CopyImage(spaceshipIntoImage_1, spaceshipIntroX, spaceshipIntroY);
        setInteger(getInteger(playerAllY) - 15, playerAllY);
    }
    if (introFrame >= 10 && introFrame < 17)
    {
        mil_CopyImage(spaceshipIntoImage_1, spaceshipIntroX, spaceshipIntroY);
        spaceshipIntroX += 8;
        if (playerFrame)
            spaceshipIntroY -= 5;
        else
            spaceshipIntroY += 5;
    }
    if (introFrame >= 100)
    {
        gameSetMap();
        gameStart();
    }
    playerFrame = !playerFrame; // toggle playerFrame between 0 and 1 for situation like spaceship go up and down
    introFrame++;
}
// 1090734: using guessed type int spaceshipIntroX;
// 1090738: using guessed type int spaceshipIntroY;
// 1090748: using guessed type int GameLanguage;
// 1090750: using guessed type int playerFrame;
// 1090824: using guessed type int SWAP_LCD_WIDTH;

//----- (0007E13C) --------------------------------------------------------
void gameDrawFail()
{
    mil_RestoreLCD();
    if (playerFrame)
    {
        mil_CopyImage(playerAniTitleImage_0, getInteger(playerAllX), getInteger(playerAllY) + 1);
    }
    else
    {
        mil_CopyImage(playerAniTitleImage_1, getInteger(playerAllX), getInteger(playerAllY) + 1);
    }
}

int gameDrawHandle()
{
    int v4; // r0
    int v5; // r0
    int v6; // r1
    int v7; // r2
    unsigned int v8; // r3
    int v9; // r0
    int v10; // r2
    char* v11; // r0
    int v13; // r2
    char* v14; // r0
    char v15; // r0

    switch (gameState)
    {
    case 0:
        gameState = 1;
        introFrame = 0;
        goto LABEL_28;
    case 1:
        gameDrawIntroElements();
        goto LABEL_28;
    case 2:
        ++level;
        gameDrawSuccess();
        goto LABEL_28;
    case 4:
        gameTimeHandler();
        gamePutRandCollectible();
        gameDrawElement();
        v9 = 0;
        break;
    case 5:
        ++level;
        mil_Clear(0);
        mil_CopyImage(introBackgroundImage, 0, 0);
        if (GameLanguage)
        {
            mil_CopyImage(failChineseImage, SWAP_LCD_WIDTH / 2, 30);
        }
        else
        {
            mil_CopyImage(failEnglishImage, SWAP_LCD_WIDTH / 2, 20);
        }
        mil_CopyImage(playerGameOverAnimation[playerFrame], SWAP_LCD_WIDTH / 2, 70);
        goto LABEL_28;
    case 6:
        ++level;
        if (level > 10)
        {
            mil_Clear(0);
            gameDrawLogo();
            return g_CheckScore(gameScore);
        }
        mil_Clear(0);
        mil_CopyImage(introBackgroundImage, 0, 0);
        if (GameLanguage)
        {
            mil_CopyImage(failChineseImage, SWAP_LCD_WIDTH / 2, 30);
        }
        else
        {
            mil_CopyImage(failEnglishImage, SWAP_LCD_WIDTH / 2, 20);
        }
        mil_CopyImage(playerGameOverAnimation[playerFrame], SWAP_LCD_WIDTH / 2, 80);
        sprintf(strBuffer, "GAME OVER");
        mil_DrawString(SWAP_LCD_WIDTH / 2, 50, strBuffer, 2, 3, 1);
        goto LABEL_28;
    case 7:
        if (++introFrame >= 20)
        {
            if (--lives)
                gameState = 5;
            else
                gameState = 6;
            gext_StopSound();
            gext_PlaySound(failSound, 2249);
        }
        gameDrawFail();
        goto LABEL_28;
    default:
        goto LABEL_28;
    }
    while (playerX != enemyAndKeyPlacement[v9].x || playerY != enemyAndKeyPlacement[v9].y)
    {
        if (++v9 >= 3)
            goto LABEL_28;
    }
    gameState = 7;
    introFrame = 0;
    mil_SaveLCD();
    gext_StartVib(3);
LABEL_28:
    gext_DrawLcd(swLcdBuffer);
    return 0;
}
// 7E1DE: variable 'v4' is possibly undefined
// 7E1F4: variable 'v5' is possibly undefined
// 7E1F4: variable 'v6' is possibly undefined
// 7E1F4: variable 'v7' is possibly undefined
// 7E1F4: variable 'v8' is possibly undefined
// 8: using guessed type int dword_8;
// 109056A: using guessed type char lives;
// 1090748: using guessed type int GameLanguage;
// 1090750: using guessed type int playerFrame;
// 1090824: using guessed type int SWAP_LCD_WIDTH;

//----- (0007E3B8) --------------------------------------------------------
void gameInit()
{
    int sec;
    int min;
    int mon;
    int day;
    int hour;
    int year;

    gext_GetDate(&year, &mon, &day, &hour, &min, &sec);
    gext_RandomSeed(sec);
    introFrame = 0;
    spaceshipIntroX = 132;
    spaceshipIntroY = 5;
    gext_PlaySound(introSound, 2767);
    score = 0;
    introFrame = 0;
    playerIsMoving = 0;
    gameScore = 0;
    lives = 5;
    g_StartTimer(0, 200, 1);
}

int Gaza2Main(int nReason, int nData)
{
    switch (nReason)
    {
    case 0:
        mil_Clear(0);
        gameDrawLogo();
        return 0;
    case 1:
        gameInit();
        gameState = 0;
        introFrame = 0;
        gameDrawIntroBackground();
        break;
    case 2:
        if (nData)
            mil_RestoreLCD();
        else
            mil_SaveLCD();
        gm_DrawPauseMark(GameLanguage);
        gext_DrawLcd(swLcdBuffer);
        return 1;
    case 3:
        g_StartTimer(0, 200, 1);
        switch (gameState)
        {
        case 1:
            gameDrawIntroBackground();
            break;
        case 4:
            gameDrawBackground();
            break;
        case 7:
            gameDrawBackground();
            gameDrawElement();
            mil_SaveLCD();
            break;
        }
        return 0;
    case 4:
        return gameDrawHandle();
    case 5:
        switch (gameState)
        {
        case 1:
            introFrame = 0;
            gameSetMap();
            gext_StopSound();
            gameStart();
            return 0;
        case 2:
            if (level > 10)
            {
                introFrame = 100;
                level = 0;
            }
            return 0;
        case 4:
            switch (nData)
            {
            case 26:
            case 4:
                if (!playerState && !playerIsMoving)
                {
                    playerIsMoving = 1;
                    gext_PlaySound(moveSound, 1409);
                    playerMoveLeft();
                }
                break;
            case 27:
            case 5:
                if (!playerState && !playerIsMoving)
                {
                    playerIsMoving = 1;
                    gext_PlaySound(moveSound, 1409);
                    playerMoveRight();
                }
                break;
            case 28:
            case 1:
                if (!playerState && !playerIsMoving)
                {
                    playerIsMoving = 1;
                    gext_PlaySound(moveSound, 1409);
                    playerMoveUp();
                }
                break;
            case 29:
            case 7:
                if (!playerState && !playerIsMoving)
                {
                    playerIsMoving = 1;
                    gext_PlaySound(moveSound, 1409);
                    playerMoveDown();
                }
            default:
                break;
            }
            return 0;
        case 5:
            if (level > 10)
            {
                introFrame = 0;
                gameBackupMap();
                gameStart();
                level = 0;
            }
            return 0;
        case 6:
            if (level >= 10)
            {
                mil_Clear(0);
                gameDrawLogo();
                return g_CheckScore(gameScore);
            }
            else
            {
                return 0;
            }
            break;
        case 7:
            if (++introFrame >= 5)
            {
                if (--lives)
                    gameState = 5;
                else
                    gameState = 6;
                gext_StopSound();
                gext_PlaySound(failSound, 2249);
            }
            return 0;
        default:
            return 0;
        }
    case 6:
        mil_SaveLCD();
        return 1;
    case 7:
    case 8:
        mil_Clear(0);
        gameDrawLogo();
        return 0;
    case 9:
    case 10:
        mil_Clear(0);
        mil_CopyImage(introBackgroundImage, 0, 0);
        mil_CopyImage(helpMapImage, SWAP_LCD_WIDTH / 2, SWAP_LCD_HEIGHT / 2);
        if (GameLanguage)
        {
            mil_CopyImage(helpControlChineseImage, SWAP_LCD_WIDTH / 2, SWAP_LCD_HEIGHT / 2 - 40);
        }
        else
        {
            mil_CopyImage(helpControlEnglishImage, SWAP_LCD_WIDTH / 2, SWAP_LCD_HEIGHT / 2 - 40);
        }
        return 0;
    default:
        return 0;
    }
}
