#include <stdio.h> 

#include <string.h> 

#include <stdlib.h>

#include "GLib.h"

#if SWAP_AUDIO_TYPE == SWAP_AUDIO_CMX
#include "cmxFlyingBubble.cpp"
#else
#include "ma3FlyingBubble.cpp"
#endif

#include "mapFlyingBubble.cpp"

extern void gm_DrawPauseMark();

typedef __packed struct t_logoMap
{
	BYTE* image;
	DWORD x;
	DWORD y;
} logoMap;

typedef __packed struct t_bubbleMap
{
	BYTE state; //0 - exist, 1 - popped, 0xff - nonexistant
	INT4 x;
	INT4 y;
	INT4 endingx;
	INT4 endingy;
	INT4 currx;
	INT4 curry;
	BYTE direction; //0 - left, 1 - right
	BYTE frame;
} bubbleMap;

//each bubble for making logo is 20x20
//start at x4 y8

logoMap logoBubbles[] = { {(BYTE*)fb_titleImage_0, 4, 8},
						  {(BYTE*)fb_titleImage_1, 24, 8},
						  {(BYTE*)fb_titleImage_2, 44, 8},
						  {(BYTE*)fb_titleImage_3, 64, 8},
						  {(BYTE*)fb_titleImage_4, 84, 8},
						  {(BYTE*)fb_titleImage_5, 104, 8},
						  {(BYTE*)fb_titleImage_6, 4, 28},
						  {(BYTE*)fb_titleImage_7, 24, 28},
						  {(BYTE*)fb_titleImage_6, 44, 28},
						  {(BYTE*)fb_titleImage_6, 64, 28},
						  {(BYTE*)fb_titleImage_1, 84, 28},
						  {(BYTE*)fb_titleImage_8, 104, 28} };

//t and f
#define GAME_BOOL_T 1
#define GAME_BOOL_F 0

//state
#define GAME_STATE_TITLE 1
#define GAME_STATE_PLAY 2
#define GAME_STATE_OVER 3
#define GAME_STATE_WIN 4
#define GAME_STATE_FINISH 5

//intro
#define BUBBLES_INTRO_LOGO 12

//common
#define MAX_BUBBLES 50
#define MAX_BUBBLE_FRAME 9
#define MAX_BUBBLES_INTRO 10
#define MAX_LEVELS 10
#define GAMEOVER_WAIT_FRAMES 10

//graphics
#define BUBBLE_WIDTH 18
#define BUBBLE_HEIGHT 17

#define ARROW_WIDTH 7
#define ARROW_HEIGHT 24
#define ARROW_INIT_Y 110

#define BKG_HEIGHT 110 //excludes grass!!!

bubbleMap bubbles[MAX_BUBBLES];
DWORD bubbleIntroFrames[MAX_BUBBLES_INTRO] = { 0, 3, 6, 8, 11, 13, 14, 17, 20, 30 };
DWORD levelMaxArrow[MAX_LEVELS] = { 20, 30, 40, 50, 65, 85, 100, 120, 130, 150 };
DWORD levelScoreEnd[MAX_LEVELS] = { 100, 150, 200, 250, 300, 350, 400, 450, 500, 600};
BYTE* bubblePopAnimation[] = { fb_bubblePopImage_0, fb_bubblePopImage_1 };
static int modifierFrame;
static int gameState;
static INT1 isBubbleIntroInit;
static INT1 isBubbleInit;
static BYTE logoIntroBubbleCurrent;
static BYTE logoIntroBubbleTextState[BUBBLES_INTRO_LOGO];
static WORD gameScore;
static WORD gameTotalScore;
static BYTE gameArrows;
static BYTE gameLives;
static BYTE gameLevel;
static INT4 gameTime;
static INT4 gameTimeMs;
static BYTE strBuffer[10];
static INT4 arrowX;
static INT4 arrowY;
static BYTE arrowIsShooting;
static WORD randomFrameToPutNewBubble;
static BYTE gameOverWaitFrame;
static BYTE bubblePopFrame;
static BYTE bubblePopped;

static void DrawLogo()
{
	int i;

	for (i = 0; i < sizeof(logoBubbles) / sizeof(logoMap); i++)
	{
		mil_CopyImage(logoBubbles[i].image, logoBubbles[i].x, logoBubbles[i].y);
	}
}

static void DrawBackground()
{
	mil_CopyImage(fb_levelBkgImage, 0, 0);
}

void TimeHandler()
{
	gameTimeMs += 200;
	if (gameTimeMs >= 1000)
	{
		gameTime--;
		gameTimeMs -= 1000;
	}
}

static void InitBubbles()
{
	int bubble;
	for (bubble = 0; bubble < MAX_BUBBLES; bubble++)
	{
		bubbles[bubble].state = 0xff;
		bubbles[bubble].x = 0x7fffffff;
		bubbles[bubble].y = 0x7fffffff;
		bubbles[bubble].endingx = 0x7fffffff;
		bubbles[bubble].endingy = 0x7fffffff;
		bubbles[bubble].currx = 0x7fffffff;
		bubbles[bubble].curry = 0x7fffffff;
		bubbles[bubble].direction = 0xff;
		bubbles[bubble].frame = 0xff;
	}
}

static void InitGame()
{
	int year, month, day, hour, min, sec;
	int bubble;
	gext_GetDate(&year, &month, &day, &hour, &min, &sec);
	gext_RandomSeed(sec);
	gext_PlaySound((BYTE*)fb_TitleSound, sizeof(fb_TitleSound));
	modifierFrame = 0;
	logoIntroBubbleCurrent = 0;
	InitBubbles();
	for (bubble = 0; bubble < 12; bubble++)
	{
		logoIntroBubbleTextState[bubble] = 0;
	}
	gameLives = 5;
	gameScore = 0;
	gameTotalScore = 0;
	gameArrows = 0;
	gameLevel = 1;
	gameTime = 60;
	isBubbleInit = GAME_BOOL_F;
	isBubbleIntroInit = GAME_BOOL_F;
	gameState = GAME_STATE_TITLE;
	arrowX = (SWAP_LCD_WIDTH - ARROW_WIDTH)/2;
	arrowY = ARROW_INIT_Y;
	arrowIsShooting = GAME_BOOL_F;
	randomFrameToPutNewBubble = gext_Random(4, 10);
	gameOverWaitFrame = 0;
	bubblePopFrame = 0;
	bubblePopped = GAME_BOOL_F;
	gameTimeMs = 0;
}

static void InitStage()
{
	gameLives = 5;
	gameScore = 0;
	gameArrows = 0;
	gameTime = 60 + (15*(gameLevel-1));
	gameState = GAME_STATE_PLAY;
	arrowX = (SWAP_LCD_WIDTH - ARROW_WIDTH) / 2;
	arrowY = ARROW_INIT_Y;
	arrowIsShooting = GAME_BOOL_F;
	randomFrameToPutNewBubble = gext_Random(4, 10-((gameLevel-1)/2));
	gameOverWaitFrame = 0;
	bubblePopFrame = 0;
	bubblePopped = GAME_BOOL_F;
	gameTimeMs = 0;
	modifierFrame = 0;
}

void ArrowSetShoot(BYTE state)
{
	arrowIsShooting = state;
	if (state == GAME_BOOL_T)
	{
		gameArrows++;
	}
}

void AddBubble()
{
	int bubble;
	for (bubble = 0; bubble < MAX_BUBBLES; bubble++)
	{
		if (bubbles[bubble].state == 0xff)
		{
			bubbles[bubble].state = 0;
			bubbles[bubble].direction = gext_Random(0, 2);
			if (bubbles[bubble].direction == 0)
			{
				bubbles[bubble].x = SWAP_LCD_WIDTH + BUBBLE_WIDTH;
				bubbles[bubble].endingx = -BUBBLE_WIDTH;
			}
			else
			{
				bubbles[bubble].x = -BUBBLE_WIDTH;
				bubbles[bubble].endingx = SWAP_LCD_WIDTH + BUBBLE_WIDTH;
			}
			bubbles[bubble].currx = bubbles[bubble].x;
			bubbles[bubble].y = gext_Random(0, BKG_HEIGHT - BUBBLE_HEIGHT);
			bubbles[bubble].endingy = gext_Random(0, BKG_HEIGHT - BUBBLE_HEIGHT);
			bubbles[bubble].curry = bubbles[bubble].y;
			bubbles[bubble].frame = 0;
			break;
		}
	}
}

void PopBubble(int bubble)
{
	bubbles[bubble].state = 1;
	gameScore += 10 - ((gameLevel - 1) / 2);
	bubblePopped = GAME_BOOL_T;
	if (gameScore >= levelScoreEnd[gameLevel-1])
	{
		gameTotalScore += gameScore;
		gameLevel++;
		modifierFrame = 0;
		gext_PlaySound(fb_WinSound, sizeof(fb_WinSound));
		gameState = GAME_STATE_WIN;
	}
	else
	{
		gext_PlaySound(fb_PointSound, sizeof(fb_PointSound));
	}
}

void ArrowMoveLeft()
{
	if (arrowX - ARROW_WIDTH > ARROW_WIDTH)
	{
		arrowX -= ARROW_WIDTH;
	}
	else
	{
		arrowX = 0;
	}
}

void ArrowMoveRight()
{
	if (arrowX + ARROW_WIDTH < SWAP_LCD_WIDTH - ARROW_WIDTH)
	{
		arrowX += ARROW_WIDTH;
	}
	else
	{
		arrowX = SWAP_LCD_WIDTH - ARROW_WIDTH;
	}
}

void ArrowMoveUp()
{
	int bubble;

	if (arrowY - ARROW_HEIGHT > 0)
	{
		//check if arrow is where a bubble is, in case arrow encounters bubble it should pop...
		for (bubble = 0; bubble < MAX_BUBBLES; bubble++)
		{
			if (bubbles[bubble].state == 0)
			{
				if (arrowX >= bubbles[bubble].currx - ARROW_WIDTH && arrowX <= bubbles[bubble].currx + BUBBLE_WIDTH + ARROW_WIDTH &&
					arrowY >= bubbles[bubble].curry - ARROW_HEIGHT && arrowY <= bubbles[bubble].curry + BUBBLE_HEIGHT + ARROW_HEIGHT)
				{
					PopBubble(bubble);
					break;
				}
			}
		}
		arrowY -= ARROW_HEIGHT;
	}
	else
	{
		arrowY = ARROW_INIT_Y;
		arrowIsShooting = GAME_BOOL_F;
		if (bubblePopped == GAME_BOOL_F)
		{
			gext_PlaySound(fb_MissSound, sizeof(fb_MissSound));
			gameLives--;
		}
		if (bubblePopped == GAME_BOOL_T)
		{
			bubblePopped = GAME_BOOL_F;
		}
	}
}

static void DrawIntro()
{
	int bubble;
	int bubble2;

	DrawBackground();

	//logic:
	//1. Create 10 bubbles
	//1.1 Set all 10 bubble state to 0 (exists unpopped)
	//1.2 Randomize direction //0 - left, 1 - right
	//1.3 Randomize x and y and also end x and end y
	if (isBubbleIntroInit == GAME_BOOL_F)
	{
		for (bubble = 0; bubble < MAX_BUBBLES_INTRO; bubble++)
		{
			bubbles[bubble].state = 0x0;
			bubbles[bubble].direction = gext_Random(0, 2);
			if (bubbles[bubble].direction == 0)
			{
				bubbles[bubble].x = SWAP_LCD_WIDTH + BUBBLE_WIDTH;
				bubbles[bubble].endingx = -BUBBLE_WIDTH;
			}
			else
			{
				bubbles[bubble].x = -BUBBLE_WIDTH;
				bubbles[bubble].endingx = SWAP_LCD_WIDTH + BUBBLE_WIDTH;
			}
			bubbles[bubble].currx = bubbles[bubble].x;
			bubbles[bubble].y = gext_Random(0, BKG_HEIGHT-BUBBLE_HEIGHT);
			bubbles[bubble].endingy = gext_Random(0, BKG_HEIGHT-BUBBLE_HEIGHT);
			bubbles[bubble].curry = bubbles[bubble].y;
			bubbles[bubble].frame = 0;
		}
		isBubbleIntroInit = GAME_BOOL_T;
	}
	//2. draw bubbles...
	for (bubble = 0; bubble < MAX_BUBBLES_INTRO; bubble++)
	{
		if (bubbles[bubble].state == 0)
		{
			//draw bubble on specific frame range...
			if (modifierFrame >= bubbleIntroFrames[bubble] && modifierFrame <= bubbleIntroFrames[bubble]+MAX_BUBBLE_FRAME)
			{
				mil_CopyImage(fb_bubbleImage, bubbles[bubble].currx, bubbles[bubble].curry);
				bubbles[bubble].currx += (bubbles[bubble].endingx - bubbles[bubble].x) / MAX_BUBBLE_FRAME;
				bubbles[bubble].curry += (bubbles[bubble].endingy - bubbles[bubble].y) / MAX_BUBBLE_FRAME;
			}
		}
	}
	if (modifierFrame >= 8 && modifierFrame <= 45)
	{
		if (logoIntroBubbleCurrent < BUBBLES_INTRO_LOGO)
			logoIntroBubbleTextState[logoIntroBubbleCurrent++] = 1;
		bubble2 = 0;
		while (bubble2 < BUBBLES_INTRO_LOGO)
		{
			if (logoIntroBubbleTextState[bubble2] == 1)
			{
				mil_CopyImage(logoBubbles[bubble2].image, logoBubbles[bubble2].x, logoBubbles[bubble2].y);
			}
			bubble2++;
		}
	}
	if (modifierFrame >= 45)
	{
		gameState = GAME_STATE_PLAY;
	}
	modifierFrame++;
}

void DrawStatistics()
{
	mil_CopyImage(fb_statusBkgImage, 0, 0);
	mil_CopyImage(fb_livesImage, 2, 2);
	sprintf(strBuffer, "%d", gameLives);
	mil_DrawString(12, 3, strBuffer, S_FONT_MEDIUM, S_WHITE, S_TRANSPARENT);
	mil_CopyImage(fb_arrowsImage, 34, 2);
	sprintf(strBuffer, "%d", levelMaxArrow[gameLevel] - gameArrows);
	mil_DrawString(44, 3, strBuffer, S_FONT_MEDIUM, S_WHITE, S_TRANSPARENT);
	mil_CopyImage(fb_scoreImage, 70, 2);
	if (gameState == GAME_STATE_PLAY || gameState == GAME_STATE_OVER)
		sprintf(strBuffer, "%d", gameTotalScore + gameScore);
	else
		sprintf(strBuffer, "%d", gameTotalScore);
	mil_DrawString(79, 3, strBuffer, S_FONT_MEDIUM, S_WHITE, S_TRANSPARENT);
	mil_CopyImage(fb_timeImage, 105, 2);
	sprintf(strBuffer, "%d", gameTime);
	mil_DrawString(115, 3, strBuffer, S_FONT_MEDIUM, S_WHITE, S_TRANSPARENT);
}

void DrawArrow()
{
	mil_CopyImage(fb_arrowImage, arrowX, arrowY);
}

void DrawBubbles()
{
	int bubble;
	for (bubble = 0; bubble < MAX_BUBBLES; bubble++)
	{
		if (bubbles[bubble].state == 0)
		{
			mil_CopyImage(fb_bubbleImage, bubbles[bubble].currx, bubbles[bubble].curry);
			//move bubbles accordingly
			if (bubbles[bubble].currx >= bubbles[bubble].endingx && bubbles[bubble].curry >= bubbles[bubble].endingy)
			{
				bubbles[bubble].state = 0xff;
				bubbles[bubble].x = 0x7fffffff;
				bubbles[bubble].y = 0x7fffffff;
				bubbles[bubble].endingx = 0x7fffffff;
				bubbles[bubble].endingy = 0x7fffffff;
				bubbles[bubble].currx = 0x7fffffff;
				bubbles[bubble].curry = 0x7fffffff;
				bubbles[bubble].direction = 0xff;
				bubbles[bubble].frame = 0xff;
			}
			else
			{
				bubbles[bubble].currx += (bubbles[bubble].endingx - bubbles[bubble].x) / 10;
				bubbles[bubble].curry += (bubbles[bubble].endingy - bubbles[bubble].y) / 10;
			}
		}
		if (bubbles[bubble].state == 1)
		{
			mil_CopyImage(bubblePopAnimation[bubblePopFrame++], bubbles[bubble].currx, bubbles[bubble].curry);
			if (bubblePopFrame >= 2)
			{
				bubbles[bubble].state = 0xff;
				bubbles[bubble].x = 0x7fffffff;
				bubbles[bubble].y = 0x7fffffff;
				bubbles[bubble].endingx = 0x7fffffff;
				bubbles[bubble].endingy = 0x7fffffff;
				bubbles[bubble].currx = 0x7fffffff;
				bubbles[bubble].curry = 0x7fffffff;
				bubbles[bubble].direction = 0xff;
				bubbles[bubble].frame = 0xff;
				bubblePopFrame = 0;
			}
		}
	}
}

void DrawGamePlay()
{
	DrawBackground();
	if (bubblePopped == GAME_BOOL_T)
	{
		DrawArrow();
		DrawBubbles();
	}
	else
	{
		DrawBubbles();
		DrawArrow();
	}
	DrawStatistics();
}

void DrawGameWin()
{
	mil_CopyImage(fb_winImage, 22, SWAP_LCD_HEIGHT / 3);
	sprintf(strBuffer, "%d", gameTotalScore);
	mil_DrawString(74, 64, strBuffer, S_FONT_MEDIUM, S_WHITE, S_TRANSPARENT);
	sprintf(strBuffer, "%d", gameLevel);
	mil_DrawString(74, 78, strBuffer, S_FONT_MEDIUM, S_WHITE, S_TRANSPARENT);
}

int FlyingBubbleMain(int nReason, int nData)
{
	switch (nReason) {
	case GLIB_MENU:
		mil_Clear(S_WHITE);
		DrawLogo();
		break;
	case GLIB_START:
		InitGame();
		g_StartTimer(0, 200, 1);
		break;
	case GLIB_TIMEOUT:
		switch (gameState)
		{
		case GAME_STATE_TITLE:
			DrawIntro();
			break;
		case GAME_STATE_PLAY:
			TimeHandler();
			if (isBubbleInit == GAME_BOOL_F)
			{
				InitBubbles();
				isBubbleInit = GAME_BOOL_T;
			}
			if (arrowIsShooting == GAME_BOOL_T)
			{
				ArrowMoveUp();
			}
			randomFrameToPutNewBubble--;
			if (randomFrameToPutNewBubble <= 0)
			{
				AddBubble();
				randomFrameToPutNewBubble = gext_Random(4, 10);
			}
			if (gameLives <= 0 || gameArrows >= levelMaxArrow[gameLevel] || gameTime <= 0)
			{
				gameState = GAME_STATE_OVER;
				gameOverWaitFrame = GAMEOVER_WAIT_FRAMES;
			}
			DrawGamePlay();
			break;
		case GAME_STATE_WIN:
			DrawGameWin();
			modifierFrame++;
			if (modifierFrame >= 20)
			{
				gext_StopSound();
				InitStage();
				gameState = GAME_STATE_PLAY;
			}
			break;
		case GAME_STATE_OVER:
			gext_StopSound();
			mil_CopyImage(fb_gameOverImage, 0, SWAP_LCD_HEIGHT / 2);
			gameOverWaitFrame--;
			if (gameOverWaitFrame <= 0)
			{
				DrawBackground();
				mil_CopyImage(fb_scoreInfoImage, 0, 8);
				return g_CheckScore(gameTotalScore+gameScore);
			}
			break;
		default:
			break;
		}
		gext_DrawLcd((char*)swLcdBuffer);
		break;
	case GLIB_KEYPRESS:
		switch (nData)
		{
			case GLIB_KEY_5:
			case GLIB_KEY_OK:
				if (gameState == GAME_STATE_TITLE || gameState == GAME_STATE_WIN)
				{
					gext_StopSound();
					InitStage();
					gameState = GAME_STATE_PLAY;
				}
				break;
			case GLIB_KEY_4:
			case GLIB_KEY_LEFT:
				if (gameState == GAME_STATE_PLAY)
				{
					ArrowMoveLeft();
				}
				break;
			case GLIB_KEY_6:
			case GLIB_KEY_RIGHT:
				if (gameState == GAME_STATE_PLAY)
				{
					ArrowMoveRight();
				}
				break;
			case GLIB_KEY_2:
			case GLIB_KEY_UP:
				if (gameState == GAME_STATE_PLAY)
				{
					ArrowSetShoot(GAME_BOOL_T);
				}
				break;
		}
		break;
	case GLIB_PAUSE:
		gm_DrawPauseMark();
		gext_DrawLcd((char*)swLcdBuffer);
		return GRET_PAUSE;
	case GLIB_END:
		mil_SaveLCD();
		return GRET_PAUSE;
	case GLIB_MENU_SCORE:
	case GLIB_SCORE:
		DrawBackground();
		mil_CopyImage(fb_scoreInfoImage, 0, 8);
		break;
	case GLIB_HELP:
	case GLIB_HELP_TIMEOUT:
		DrawBackground();
		mil_CopyImage(fb_helpImage, 0, SWAP_LCD_HEIGHT / 4);
		break;
	}
	return GRET_NORMAL;
}