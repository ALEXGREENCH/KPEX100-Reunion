#include <windows.h>
#include "resource.h"
#include "GLib.h"
#include "GExt.h"
#include <stdio.h>

int whatGame = -1;

BOOL CALLBACK SimulatedDialogProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam);

HWND hWnd = NULL;

VOID SinjiGVMSim_ListGames(HWND hCombo)
{
    s_GameDefType* myGameDef = s_GameDef;
	while (myGameDef->GameMain != NULL)
	{
        SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)myGameDef->Description);
        myGameDef++;
	}
}

void DrawLCD(void* pLcdBuffer)
{
    int i;
    HDC hdc = GetDC(hWnd);  // Use GetDC() instead of BeginPaint() for drawing outside WM_PAINT
    WORD* pImage = (WORD*)pLcdBuffer;

    HDC memDC = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = SWAP_LCD_WIDTH;
    bmi.bmiHeader.biHeight = -SWAP_LCD_HEIGHT; // Negative for top-down DIB
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 24;
    bmi.bmiHeader.biCompression = BI_RGB;

    BYTE* pixelData;
    HBITMAP hDIB = CreateDIBSection(memDC, &bmi, DIB_RGB_COLORS, (void**)&pixelData, NULL, 0);
    if (!hDIB || !pixelData) {
        DeleteDC(memDC);
        ReleaseDC(hWnd, hdc);
        return;
    }

    SelectObject(memDC, hDIB);

    for (i = 0; i < SWAP_LCD_WIDTH * SWAP_LCD_HEIGHT; i++) {
        WORD pixel = pImage[i];
        BYTE r = (pixel >> 11) & 0x1F;
        BYTE g = (pixel >> 5) & 0x3F;
        BYTE b = pixel & 0x1F;

        pixelData[i * 3 + 2] = (r * 255) / 31;
        pixelData[i * 3 + 1] = (g * 255) / 63;
        pixelData[i * 3 + 0] = (b * 255) / 31;
    }
	StretchBlt(hdc, 0, 0, SWAP_LCD_WIDTH*2, SWAP_LCD_HEIGHT*2, memDC, 0, 0, SWAP_LCD_WIDTH, SWAP_LCD_HEIGHT, SRCCOPY);

    DeleteObject(hDIB);
    DeleteDC(memDC);
    ReleaseDC(hWnd, hdc);  // Use ReleaseDC() instead of EndPaint()
}

// Dialog Procedure
BOOL CALLBACK DialogProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_INITDIALOG: {
            HWND hCombo = GetDlgItem(hwndDlg, ID_COMBOBOX);
            SinjiGVMSim_ListGames(hCombo);
            SendMessage(hCombo, CB_SETCURSEL, 0, 0); // Set default selection
            return TRUE;
        }
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
            case ID_OKBUTTON: {
                HWND hCombo = GetDlgItem(hwndDlg, ID_COMBOBOX);
                int selIndex = SendMessage(hCombo, CB_GETCURSEL, 0, 0);
                if (selIndex != CB_ERR) {
                    whatGame = selIndex;
                    EndDialog(hwndDlg, 0);  // Close first dialog
                    DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_SIMULATOR), NULL, SimulatedDialogProc);
                }
                return TRUE;
            }
            case IDCANCEL:
                EndDialog(hwndDlg, 0);
                return TRUE;
            }
            break;
        case WM_CLOSE:
            EndDialog(hwndDlg, 0);
            return TRUE;
    }
    return FALSE;
}

BOOL CALLBACK SimulatedDialogProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_INITDIALOG: {
			hWnd = hwndDlg;
            PostMessage(hwndDlg, WM_USER + 100, 0, 0);
            return TRUE;
        }
        case WM_USER + 100: {
            glib_Init_SINJISOFT_Game();
            glib_GameEvent(GLIB_START_EVENT, whatGame);
            return TRUE;
        }
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
            case IDC_BUTTON_1:
			case IDC_BUTTON_2:
			case IDC_BUTTON_3:
			case IDC_BUTTON_4:
			case IDC_BUTTON_5:
			case IDC_BUTTON_6:
			case IDC_BUTTON_7:
			case IDC_BUTTON_8:
			case IDC_BUTTON_9:
			case IDC_BUTTON_0:
			case IDC_BUTTON_STAR:
			case IDC_BUTTON_POUND:
				glib_GameEvent(GLIB_KEY_EVENT, LOWORD(wParam)-IDC_BUTTON_1+GLIB_KEY_1);
				return TRUE;
            case IDC_BUTTON_CLEAR:
            case IDC_BUTTON_CALL:
			case IDC_BUTTON_POWER:
                glib_GameEvent(GLIB_KEY_EVENT, LOWORD(wParam)-IDC_BUTTON_CLEAR+GLIB_KEY_CLR);
				return TRUE;
            case IDC_BUTTON_LEFT:
			case IDC_BUTTON_RIGHT:
			case IDC_BUTTON_UP:
			case IDC_BUTTON_DOWN:
			case IDC_BUTTON_OK:
				glib_GameEvent(GLIB_KEY_EVENT, LOWORD(wParam)-IDC_BUTTON_LEFT+GLIB_KEY_LEFT);
				return TRUE;
            case IDC_BUTTON_CLOSE:
                glib_GameEvent(GLIB_KEY_EVENT, GLIB_KEY_END);
                glib_GameEvent(GLIB_END_EVENT, 0);
                EndDialog(hwndDlg, 0);
                return TRUE;
            }
            break;
        case WM_CLOSE:
            glib_GameEvent(GLIB_KEY_EVENT, GLIB_KEY_END);
            glib_GameEvent(GLIB_END_EVENT, 0);
            EndDialog(hwndDlg, 0);
            return TRUE;
    }
    return FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    AllocConsole();
    freopen("CONOUT$", "w", stdout);
    return DialogBox(hInstance, MAKEINTRESOURCE(IDD_CHOICE_DIALOG), NULL, DialogProc);
}
