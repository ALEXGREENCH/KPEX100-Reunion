# gvmcafe.com bounded archive index follow-up

One successful domain CDX request yielded400collapsed200-status URL rows (59170bytes, SHA256de9275391c61dd04c89a8496d423bfa626f30d820ca37a08babbe6998a02e954).

Most paths belong to archived emoticon-board navigation and Apache manual/icon assets; no direct recognizable SGS/SDK/archive/source filename suffix in this returned set. HTML records were not all inspected, so this is not proof that no binary was ever hosted.

The first ordinary replay, the exact recorded20020503132955 root capture, returnedHTTP429. All subsequent archive requests stopped; no host/URL variants, authentication or rate-limit bypass. No replay body/game/SDK was recovered in this pass.

Known gvmcafe.com FTP mention in library book TOC and relay host in zola source remain separate leads; a web-CDX index does not inventory FTP or uncaptured directories.
