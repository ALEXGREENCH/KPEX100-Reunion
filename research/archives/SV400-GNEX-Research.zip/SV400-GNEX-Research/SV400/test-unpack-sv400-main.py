from pathlib import Path
import importlib.util,json,sys,unittest
from unittest.mock import patch
import tempfile
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('extractor',R/'unpack-sv400-main.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
SOURCE=R.parent/'early-korean-oem-memory-next-pass/sv400-software/BIN/SV400005_03.bin'
DECODER=R.parent/'early-korean-oem-memory-next-pass/lglz-tool/decode-lglz.py'
class Checks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.raw=SOURCE.read_bytes()
 def test_truncated_source_rejected(self):
  with self.assertRaisesRegex(ValueError,'Unrecognized source'):m.recover(self.raw[:-1],lambda *_:self.fail('decoder called'))
 def test_mutated_source_rejected(self):
  altered=bytearray(self.raw);altered[0]^=1
  with self.assertRaisesRegex(ValueError,'Unrecognized source'):m.recover(altered,lambda *_:self.fail('decoder called'))
 def test_block_length_mismatch_rejected(self):
  with self.assertRaisesRegex(ValueError,'LGLZ length mismatch'):m.recover(self.raw,lambda stream,declared:(b'',1))
 def test_non_ff_remainder_rejected(self):
  with self.assertRaisesRegex(ValueError,'Unexpected LGLZ trailing'):m.recover(self.raw,lambda stream,declared:(b'\0'*declared,1))
 def test_existing_directory_unchanged(self):
  with tempfile.TemporaryDirectory(dir=R) as temp:
   output=Path(temp)/'output';output.mkdir();keep=output/'keep';keep.write_bytes(b'unchanged')
   with patch.object(sys,'argv',['unpack',str(SOURCE),str(output),'--lglz',str(DECODER)]),self.assertRaises(SystemExit):m.main()
   self.assertEqual(keep.read_bytes(),b'unchanged');self.assertEqual(list(output.iterdir()),[keep])
 def test_write_error_rolls_back_only_new_outputs(self):
  with tempfile.TemporaryDirectory(dir=R) as temp:
   output=Path(temp)/'output';old_open=Path.open
   def guarded(path,*args,**kwargs):
    if path==output/'evidence.json':raise OSError('simulated publication failure')
    return old_open(path,*args,**kwargs)
   with patch.object(sys,'argv',['unpack',str(SOURCE),str(output),'--lglz',str(DECODER)]),patch.object(m,'recover',return_value=(b'testfixture',{'blocks':[]})),patch.object(Path,'open',guarded),self.assertRaisesRegex(OSError,'simulated publication'):
    m.main()
   self.assertFalse(output.exists())
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
 (R/'wrapper-checks.json').write_text(json.dumps({'checksRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'notes':'Malformed source/block and existing-output preservation checks; rollback failure test uses an explicit tiny recovered-output test double, not a firmware decode claim.'},indent=2),encoding='utf8')
 sys.exit(not result.wasSuccessful())
