# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded original-Thumb GNEX dispatch probe; no phone boot or interpreter claim."""
from pathlib import Path
import hashlib,json,struct
import unicorn
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_HOOK_CODE,UC_HOOK_MEM_INVALID
from unicorn.arm_const import *
R=Path(__file__).resolve().parent
b=(R/'SV400005_03-main-reconstructed.elf').read_bytes()
assert hashlib.sha256(b).hexdigest()=='fb2b5e1abe3b9d8155e1f59f63e49434d77fcaade08ae9a27a6b006ea0447cbb'
ph=[dict(zip(('type','offset','vaddr','paddr','filesz','memsz','flags','align'),struct.unpack_from('<8I',b,0x1000+i*32))) for i in range(20)]
results=[]
for mime in ('application/x-gnex-sgs','application/x-wavelet-tcm','application/x-unknown'):
 u=Uc(UC_ARCH_ARM,UC_MODE_THUMB);u.mem_map(0x5a00000,0x2400000);u.mem_map(0x10000000,0x20000);u.mem_map(0x55bb000,0x1000);u.mem_map(0x55c3000,0x1000)
 for p in ph:
  if p['filesz'] and 0x5a00000<=p['vaddr']<0x7e00000:u.mem_write(p['vaddr'],b[p['offset']:p['offset']+p['filesz']])
 sp=0x10008000;mime_at=0x10001000
 u.mem_write(mime_at,mime.encode()+b'\0');u.mem_write(sp+0x8d4,b'CONTENT/probe.sgs\0')
 u.reg_write(UC_ARM_REG_SP,sp);u.reg_write(UC_ARM_REG_R4,mime_at);u.reg_write(UC_ARM_REG_R5,2);u.reg_write(UC_ARM_REG_R6,0x10010000);u.reg_write(UC_ARM_REG_LR,0x10000001)
 row={'mime':mime,'startAddress':'0x065da146','instructionLimit':50000,'timeLimitMicroseconds':2000000,'hooks':'observe every instruction; stop at app-execute entry or caller epilogue; no emulated library stubs','count':0,'reached':[]}
 def cstring(p):
  out=bytearray()
  for i in range(256):
   c=bytes(u.mem_read(p+i,1))
   if c==b'\0':return out.decode('ascii','backslashreplace')
   out+=c
  raise ValueError('unterminated observed argument')
 def code(uc,a,size,data):
  row['count']+=1
  if a in (0x65da148,0x65da15c,0x65da17e,0x65da1ae,0x6c66b28,0x6c66a84):row['reached'].append(hex(a))
  if a==0x72eab70:
   row['stop']='original app-execute entry';row['callbackAddress']=hex(a)
   row['args']={'r0_player':cstring(u.reg_read(UC_ARM_REG_R0)),'r1':u.reg_read(UC_ARM_REG_R1),'r2':cstring(u.reg_read(UC_ARM_REG_R2)),'r3':cstring(u.reg_read(UC_ARM_REG_R3))};uc.emu_stop()
  elif a==0x65da0ac:
   row['stop']='original failure epilogue';row['r0']=hex(u.reg_read(UC_ARM_REG_R0));uc.emu_stop()
 def invalid(uc,access,a,size,value,data):row['invalidMemory']={'access':access,'address':hex(a),'size':size};return False
 u.hook_add(UC_HOOK_CODE,code);u.hook_add(UC_HOOK_MEM_INVALID,invalid)
 try:u.emu_start(0x65da147,0,count=50000,timeout=2000000)
 except Exception as e:row['error']=str(e)
 row['lastPC']=hex(u.reg_read(UC_ARM_REG_PC));results.append(row)
 print(json.dumps(row))
assert results[0].get('args',{}).get('r0_player')=='GNEX'
assert results[1].get('args',{}).get('r0_player')=='TCMPLAYER'
assert results[2].get('stop')=='original failure epilogue'
(R/'gnex-dispatch-probe.json').write_text(json.dumps({'unicornVersion':unicorn.__version__,'sourceElfSha256':hashlib.sha256(b).hexdigest(),'bssZeroInitializedPages':['0x055bb000..0x055bbfff','0x055c3000..0x055c3fff'],'scope':'Original post-metadata dispatch fragment only. Content metadata already supplied as synthetic inputs; no interpreter, installer, file IO, network, complete boot or game execution. All original compare/copy/trampoline code executes without stubs. Callback intercepted before its body.','runs':results},indent=2),encoding='utf8')


