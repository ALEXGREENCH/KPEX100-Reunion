# SPDX-License-Identifier: GPL-3.0-or-later
"""Recover the exact SV400005_03 main software ELF; external GPL LGLZ decoder required.

No updater/phone code executes. No ECC correction, bad-block reordering or guessed
padding. Fixed hash restricts this research extractor to the verified build.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import struct

SOURCE_SIZE = 49277184
SOURCE_SHA = '136bcb212f86cda259c0ade0b3d2de4854ce6bcda8b5f27394f384e5fbd0b7d3'
UNWRAPPED_SHA = '31e90a58eafa8ed5cd447c3809e7d15c6e7182c029420699de3763c448dbc5fb'
PAYLOAD_SHA = 'e60e00048cc68d3f56ce4c745a57a95ebce2035d63cbfd5837acabb4f660da0a'
ELF_SHA = 'fb2b5e1abe3b9d8155e1f59f63e49434d77fcaade08ae9a27a6b006ea0447cbb'
DECODER_SHA = 'fa61eda87914a2130597dccb04770731c1d59ac5a80fe101ee9af5b82f608bc1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def recover(raw, decode_block):
    if len(raw) != SOURCE_SIZE or sha(raw) != SOURCE_SHA:
        raise ValueError('Unrecognized source; exact SV400005_03.bin required')
    image = b''.join(raw[p:p+464] + raw[p+466:p+514] for p in range(0,len(raw),528))
    if len(image) != 47783936 or sha(image) != UNWRAPPED_SHA:
        raise ValueError('NAND layout verification failed')
    parts, records = [], []
    position = 0
    for index in range(135):
        offset = 0x5c8000 + index * 0x20000
        block = image[offset:offset+0x20000]
        if len(block) != 0x20000:
            raise ValueError('Truncated LGLZ block')
        declared = struct.unpack_from('<I',block)[0]
        if not 1 <= declared <= 4*1024*1024 or position+declared > 64*1024*1024:
            raise ValueError('LGLZ output bound')
        data, consumed = decode_block(block[4:],declared)
        if len(data) != declared or not 1 <= consumed <= len(block)-4:
            raise ValueError('LGLZ length mismatch')
        if any(value != 255 for value in block[4+consumed:]):
            raise ValueError('Unexpected LGLZ trailing bytes')
        records.append({'index':index,'unwrappedOffset':offset,'storedBytes':len(block),'decodedOffset':position,'decodedBytes':len(data),'streamBytes':consumed,'paddingBytes':len(block)-4-consumed,'decodedSha256':sha(data)})
        parts.append(data)
        position += len(data)
    if image[0x5c8000+135*0x20000:0x5c8004+135*0x20000] != b'\xff'*4:
        raise ValueError('Unexpected block-chain continuation')
    payload = b''.join(parts)
    if len(payload) != 33960896 or sha(payload) != PAYLOAD_SHA:
        raise ValueError('Payload verification failed')
    elf = image[0x5c0000:0x5c8000] + payload
    if len(elf) != 33993664 or sha(elf) != ELF_SHA:
        raise ValueError('ELF verification failed')
    header = struct.unpack_from('<16sHHIIIIIHHHHHH',elf)
    if not (header[0][:4] == b'\x7fELF' and header[2] == 40 and header[5] == 0x1000 and header[9] == 32 and header[10] == 20):
        raise ValueError('Unexpected ELF program header layout')
    programs = []
    for index in range(20):
        p = struct.unpack_from('<8I',elf,0x1000+index*32)
        if p[0] != 1 or p[4] > p[5] or p[1]+p[4] > len(elf):
            raise ValueError('Invalid ELF program extent')
        programs.append(dict(zip(('type','offset','vaddr','paddr','filesz','memsz','flags','align'),p)))
    evidence = {'sourceBytes':len(raw),'sourceSha256':sha(raw),'unwrappedBytes':len(image),'unwrappedSha256':sha(image),'codewordStride':528,'dataSlices':[[0,464],[466,514]],'eccCorrection':False,'badBlockReordering':False,'elfHeaderUnwrappedRange':[0x5c0000,0x5c8000],'blocks':records,'decodedPayloadBytes':len(payload),'decodedPayloadSha256':sha(payload),'elfBytes':len(elf),'elfSha256':sha(elf),'programHeaders':programs,'paddingAdded':0,'sourcePrefixOutsideELFNotExported':True}
    return elf,evidence

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('output_directory',type=Path)
    parser.add_argument('--lglz',type=Path,required=True,help='Preserved GPL decode-lglz.py; see README')
    args=parser.parse_args()
    if args.output_directory.exists() or args.output_directory.is_symlink():
        parser.error('Output directory must not exist')
    info=args.input.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size != SOURCE_SIZE:
        parser.error('Expected a regular exact-size source file')
    raw=args.input.read_bytes()
    if sha(raw) != SOURCE_SHA:
        parser.error('Unrecognized source hash')
    decoder_bytes=args.lglz.read_bytes()
    if sha(decoder_bytes) != DECODER_SHA:
        parser.error('Unrecognized GPL decoder dependency')
    spec=importlib.util.spec_from_file_location('preserved_lglz',args.lglz)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    elf,evidence=recover(raw,module.decode_block)
    evidence['decoderSha256']=sha(decoder_bytes)
    encoded=(json.dumps(evidence,indent=2)+'\n').encode('utf8')
    # Publish only after all hash, block and bounds validations succeed.
    args.output_directory.mkdir()
    created=[]
    try:
        for name,data in [('SV400005_03-main-reconstructed.elf',elf),('evidence.json',encoded)]:
            target=args.output_directory/name
            with target.open('xb') as stream:
                created.append(target)
                stream.write(data)
    except BaseException:
        for target in reversed(created):target.unlink()
        args.output_directory.rmdir()
        raise
    print(json.dumps({'elfBytes':len(elf),'elfSha256':sha(elf),'blocks':len(evidence['blocks'])}))

if __name__=='__main__':
    main()

