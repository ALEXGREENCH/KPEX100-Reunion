# LG-SV400 main firmware / GNEX dispatch research

This pass reconstructs the compressed main software ELF from the exact public
`SV400005_03` update and verifies an original ARM/Thumb dispatch fragment that
selects a player named `GNEX` for `application/x-gnex-sgs`. It does **not** boot the
phone, load a real SGS, execute the player callback, or establish that a usable
GNEX interpreter is installed. No new game is promoted to the Reunion catalogue.

## Exact source and reconstruction

Source: https://archive.sunderland93.ru/Firmwares/LG/SV400%20%28Hotline%29/SV400005_03.7z

The earlier WDB recovery provenance is in the repository's
`validation/lg-sv400-game-evidence.json`. The internal model is `LG_SV400`, not
an inferred `SV4000` alias. This wrapper takes the extracted WDB member
`BIN/SV400005_03.bin` (49,277,184 bytes), SHA256:
`136bcb212f86cda259c0ade0b3d2de4854ce6bcda8b5f27394f384e5fbd0b7d3`.

The observed NAND layout is 528-byte codewords. Keep bytes `[0:464]` and
`[466:514]`; omit the internal two-byte marker and 14-byte trailing metadata.
No ECC correction or bad-block reordering is attempted. The result is
47,783,936 bytes, SHA256
`31e90a58eafa8ed5cd447c3809e7d15c6e7182c029420699de3763c448dbc5fb`.

The ELF header begins at unwrapped `0x5c0000`; retain its exact first `0x8000`
bytes. Starting at unwrapped `0x5c8000`, decode 135 consecutive `0x20000`-byte
blocks. Each has a little-endian decoded length, an LGLZ stream, and verified
all-FF remainder. Decoded lengths and terminators are checked. The next block
starts with `ffffffff`. Decoded payload: 33,960,896 bytes,
SHA256 `e60e00048cc68d3f56ce4c745a57a95ebce2035d63cbfd5837acabb4f660da0a`.
All 135 blocks independently match the preserved C reference decoder.

Concatenating the exact retained header and decoded payload yields:

- `SV400005_03-main-reconstructed.elf`: **33,993,664 bytes**.
- SHA256: `fb2b5e1abe3b9d8155e1f59f63e49434d77fcaade08ae9a27a6b006ea0447cbb`.
- ELF32 little-endian ARM, 20 bounded program headers, entry `0xf0000000`.
- Original zero section-header fields retained. The original 960-byte tail
  containing section names is retained; no invented section headers or padding.
- No raw source prefix/user partition exported by the wrapper.

The simple `[0:512]` page trial is wrong for this build: it retains the internal
marker, loses two data bytes, and corrupts program headers. Scratch files
`SV400005_03-main-data512.bin`, `page-layout-evidence.json`,
`elf-gnex-xrefs.json`, and `elf-segment-evidence.json` are superseded experiments;
do not use or package them as valid recovered software.

## Reproduction

Python 3.11+; `unpack-sv400-main.py` uses standard library plus the preserved
standalone **GPL-3.0-or-later** `decode-lglz.py`, supplied explicitly. Its exact
SHA256 is checked before import. It is not a vendor updater/DLL.

```powershell
python unpack-sv400-main.py SV400005_03.bin recovered --lglz lglz-tool/decode-lglz.py
```

The output directory must not exist. Output is written only after every source,
block, ELF extent and final checksum validates. Files created by a failed write
are rolled back. The exact-source restriction is intentional; this is not a
generic LG decoder. Six checks cover truncated/mutated input, malformed block
results, non-FF trailing bytes, no-overwrite and publication rollback. Those
wrapper checks use the separately available original source; the recorded result
is `wrapper-checks.json`. `test-unpack-sv400-main.py` is workspace QA, with paths
into the research source cache, not a source-free package test.

The existing GPL tool directory contains COPYING, original LGUI C++ source,
source archive/hash/revision provenance, Python translation, 64-bit-safe C
reference adaptation and its notice. Keep those together. GPL tool licensing
does not grant rights to firmware or game payloads. Do not move the derived
LGLZ decoder into the MIT runtime without retaining its licensing.

## Bounded original-code dispatch probe

Place `probe-gnex-dispatch.py` beside the exact reconstructed ELF, install the
recorded Unicorn version from `gnex-dispatch-probe.json`, and run:

```powershell
python -m pip install unicorn==2.1.4
python probe-gnex-dispatch.py
```

The probe starts at **VA `0x065da146`**, after content-metadata parsing, inside
the function whose apparent entry is `0x065da046`. Registers, stack, a synthetic
MIME string and `CONTENT/probe.sgs` name are supplied. Two required BSS pages at
`0x055bb000` and `0x055c3000` are zero-initialized. The original compare/copy
helpers, ARM/Thumb trampolines, and vtables execute without replacement stubs.
There is a 50,000-instruction / two-second bound. A hook stops **before** the
app-execute callback body, or at the original failure epilogue.

| Input MIME | Observed result | Instructions |
|---|---|---:|
| `application/x-gnex-sgs` | Callback `0x072eab70`, arguments `GNEX`, 4, `WAM`, `CONTENT/probe.sgs` | 231 |
| `application/x-wavelet-tcm` | Same callback, player `TCMPLAYER` | 327 |
| `application/x-unknown` | Original failure epilogue, return `0xffffffff` | 149 |

The callback pointer resolves through original data:
`[0x07a142b0] = 0x06ad8764`, `[0x06ad8764] = 0x060880f8`,
`[0x060880f8 + 0x0c] = 0x072eab71` (Thumb entry).
The original branch compares the SGS MIME at `0x065da148`, selects the `GNEX`
name at `0x065da15c`, and reaches the indirect call at `0x065da1ae`.
See `gnex-dispatch-thumb.txt` and `gnex-dispatch-probe.json`.

This establishes a real launch-dispatch consumer, stronger than an unused MIME
registration. It still does not locate the SGS bytecode interpreter or establish
successful installation/execution of that named player. The callback itself
starts by parsing a player name and resolving generic app-manager state; that
path is not fully emulated here.

## SGS scan and coverage limits

A scan of all 33,993,664 reconstructed bytes tests plain and XOR-A5 SGS v1/v2/v4/v36
layouts. It returns four overlapping structural candidates at `0x2013ed7`,
`0x2013eed`, `0x2013eef`, `0x2013ef1`. Their headers lie in one monotone integer
table; titles consist of alternating `02`/increasing values, and purported START
locations contain repetitive table bytes. They are **unconfirmed structural
false-positive suspects**, not four recovered games. No candidate is exported
or counted as a game. Preserve `reconstructed-sgs-scan.json` plus
`sgs-candidate-review.json`; do not report an unconditional zero scanner result.

Coverage includes the entire 135-block main chain and the earlier eight decoded
PXO modules. It does not prove absence of additional unknown packing or a player
installed through a separate downloadable package. Existing five native PXO
games remain a different format from Sinjisoft SGS.

Qualcomm layout references (the exact phone layout is established by source-byte
and ELF/code validation, not by inferring a chipset from a web page):

- https://github.com/ecsv/qcom-nandc-pagify
- https://android.googlesource.com/kernel/common/+/7fed98f4/drivers/mtd/nand/qcom_nandc.c
- https://git.zx2c4.com/wireguard-linux/tree/drivers/mtd/nand/raw/qcom_nandc.c

Primary compact result: `evidence.json`. Additional auditable detail:
`qcom-page-layout.json`, `lglz-chain-probe.json`, `main-reference-comparison.json`,
`reconstructed-elf-evidence.json`, `gnex-dispatch-probe.json`,
`reconstructed-gnex-xrefs.json`, and the bounded scanner review.
