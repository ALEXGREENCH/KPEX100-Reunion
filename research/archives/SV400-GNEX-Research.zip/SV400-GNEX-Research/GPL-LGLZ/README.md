# LG-LZ / SV400 PXO preservation decoder

This standalone research tool decodes the observed LG SV400005_03 PXO
wrapper without executing phone code. Python 3.11+ and its standard library
are sufficient. It is separate from Reunion's MIT-licensed code.

## Licence and attribution

- `decode-lglz.py` is a bounded Python translation of LGUI's
  `lgui/trunk/LGUI-KP500/lglz.cpp`, under **GPL-3.0-or-later**.
- The complete licence is in `COPYING`; the original file and SVN metadata
  are retained unchanged. The original source contains a GPL notice but no
  named copyright line. SVN records last file revision 2, author `Dyblast`,
  2010-05-18; directory revision 3. This is attribution from the archive,
  not an assertion that the committer is the only copyright holder.
- Source archive: https://storage.googleapis.com/google-code-archive-source/v2/code.google.com/lgui/source-archive.zip
  SHA-256 `2f8c708172d399485a13bf01868e9ba0b0c67ad78dc94d220cd952a0342d8814`.
- Original file SHA-256:
  `ae511cc35b70ce9e7847d6ccd9c7511ea974c8443b85f34a5291d9f4b57920f1`.
- Translation changes: explicit input/output and back-reference bounds;
  validated per-block sizes, terminal markers and `FF` padding; matching
  PXO4 internal size; exclusive output creation. This observed wrapper has
  a four-byte length on **each** 8192-byte physical block.
- `lglz-reference64.c` contains the original decompressor subset for
  independent comparison. Its only algorithm-host changes are replacing
  32-bit pointer casts/storage with `uintptr_t`, removing `stdafx.h` and
  exporting the function. It remains GPL-3.0-or-later.
- Original LG game files are separate proprietary software. The tool's
  GPL licence does not grant rights to those payloads.

## Decode one original file

Keep compressed originals and decoded representations in separate folders.
Create the output parent directory first, then run:

```text
mkdir ../replayed
python decode-lglz.py ../original/Game_ZooZooClub2.pxo ../replayed/Game_ZooZooClub2.pxo
```

The tool refuses an existing output. It validates the entire input before
creating the output. Input and decoded result are limited to 64 MiB.
Truncated streams, invalid backward references, non-FF trailing bytes and
size mismatches fail rather than receiving invented padding.

This is a format decoder, not an emulator, installer or phone flasher.
The original native games need their phone's PXO loader, relocation and host
API support. Recovered modules are not directly playable SGS games.

## Tests

```text
python test_decode_lglz.py
```

The two synthetic rejection tests always run. Four original-file checks
also run when `../original/Game_ZooZooClub2.pxo` is present. To point at the
same preserved sample elsewhere, set `LGLZ_TEST_SAMPLE` to its path.
For PowerShell:

```powershell
$env:LGLZ_TEST_SAMPLE = 'C:/path/to/Game_ZooZooClub2.pxo'
python test_decode_lglz.py
```

For a POSIX shell:

```sh
LGLZ_TEST_SAMPLE=/path/to/Game_ZooZooClub2.pxo python test_decode_lglz.py
```

All six tests passed on the preserved original: bad reference, declared
bound, truncation at four cut positions, exact known hash, unchanged
existing target and no output from a damaged source.

## Independent reference comparison

For the research result, all **401 blocks across eight modules** were also
decoded by the original C decompressor, compiled locally for a 64-bit
Windows host. All 7,106,628 decoded bytes matched the Python output.
The eight include five games and the three small Game/WIPISKT support modules;
do not count those support modules as additional games.

`reference-comparison.json` and `source-hashes.json` preserve those exact
results. On Windows with LLVM-MinGW or MinGW GCC, the reference can be built:

```text
gcc -shared -O2 lglz-reference64.c -o lglz-reference64.dll
python compare-reference.py ../original ./lglz-reference64.dll
```

The reference C function has the original unchecked-buffer contract. The
comparison script only accepts the eight recorded input hashes and first
validates each complete block with the bounded Python decoder. Do not use
the C function on malformed or unrelated inputs. All malformed-input tests
use Python only. The ordinary decoding workflow does not need a compiler
or this reference library.
