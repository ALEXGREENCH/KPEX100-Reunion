# SPDX-License-Identifier: GPL-3.0-or-later
import importlib.util
import os
from pathlib import Path
import struct
import tempfile
import unittest

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('decoder', BASE / 'decode-lglz.py')
decoder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(decoder)
SOURCE = Path(os.environ.get('LGLZ_TEST_SAMPLE', BASE.parent / 'original/Game_ZooZooClub2.pxo'))


class DecoderTests(unittest.TestCase):
    def test_bad_back_reference(self):
        with self.assertRaisesRegex(ValueError, 'back-reference'):
            decoder.decode_block(b'\x00\x00\x00\x00\x01', 16)

    def test_declared_bound(self):
        with self.assertRaisesRegex(ValueError, 'invalid total'):
            decoder.unpack(struct.pack('<I', decoder.MAX_BYTES + 1) + bytes(16))

    @unittest.skipUnless(SOURCE.is_file(), 'original preserved sample required')
    def test_truncated_stream(self):
        raw = SOURCE.read_bytes()
        for end in (1, 4, 8, len(raw)-1):
            with self.subTest(end=end), self.assertRaises(ValueError):
                decoder.unpack(raw[:end])

    @unittest.skipUnless(SOURCE.is_file(), 'original preserved sample required')
    def test_original_exact_hash(self):
        import hashlib
        decoded, blocks = decoder.unpack(SOURCE.read_bytes())
        self.assertEqual(hashlib.sha256(decoded).hexdigest(), '455ae8fb681f4a7ea27fe86ea89ef7f974da8898235840425c8f0a822c95ae97')
        self.assertEqual(len(blocks), 53)

    @unittest.skipUnless(SOURCE.is_file(), 'original preserved sample required')
    def test_existing_target_unchanged(self):
        with tempfile.TemporaryDirectory(dir=BASE) as temp:
            target = Path(temp) / 'kept.pxo'
            target.write_bytes(b'keep original target')
            with self.assertRaisesRegex(ValueError, 'already exists'):
                decoder.write_output(SOURCE, target)
            self.assertEqual(target.read_bytes(), b'keep original target')

    @unittest.skipUnless(SOURCE.is_file(), 'original preserved sample required')
    def test_damaged_input_creates_no_output(self):
        with tempfile.TemporaryDirectory(dir=BASE) as temp:
            source = Path(temp) / 'broken.pxo'
            target = Path(temp) / 'output.pxo'
            source.write_bytes(SOURCE.read_bytes()[:-1])
            with self.assertRaises(ValueError):
                decoder.write_output(source, target)
            self.assertFalse(target.exists())


if __name__ == '__main__':
    unittest.main()
