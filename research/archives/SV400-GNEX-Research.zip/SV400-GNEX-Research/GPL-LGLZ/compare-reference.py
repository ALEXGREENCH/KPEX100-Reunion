# SPDX-License-Identifier: GPL-3.0-or-later
"""Compare trusted preserved fixtures; never use the unchecked C decoder as a parser."""
import argparse
import ctypes
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('decoder', HERE / 'decode-lglz.py')
decoder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(decoder)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original_directory', type=Path)
    parser.add_argument('reference_library', type=Path)
    args = parser.parse_args()
    fixtures = json.loads((HERE / 'source-hashes.json').read_text('utf-8'))
    library = ctypes.CDLL(str(args.reference_library.resolve()))
    decompress = library.decompress
    decompress.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    decompress.restype = ctypes.c_int
    count = 0
    for item in fixtures:
        path = args.original_directory / item['file']
        if not path.is_file():
            continue
        if path.stat().st_size != item['bytes']:
            raise ValueError('recorded input size mismatch: ' + path.name)
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != item['sha256']:
            raise ValueError('unrecognized input: ' + path.name)
        expected, blocks = decoder.unpack(raw)
        pieces = []
        for block in blocks:
            at = block['offset']
            stream = raw[at + 4:at + block['stored_bytes']]
            destination = ctypes.create_string_buffer(block['decoded_bytes'] + 16)
            actual = decompress(stream, destination)
            if actual != block['decoded_bytes']:
                raise ValueError('reference output length mismatch')
            pieces.append(destination.raw[:actual])
        result = b''.join(pieces)
        if result != expected or hashlib.sha256(result).hexdigest() != item['decoded_sha256']:
            raise ValueError('reference mismatch: ' + path.name)
        print(path.name, len(result), 'bytes match across', len(blocks), 'blocks')
        count += 1
    if not count:
        raise ValueError('no recorded fixture found')


if __name__ == '__main__':
    main()
