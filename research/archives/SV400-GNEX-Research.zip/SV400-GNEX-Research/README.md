# SV400 GNEX and developer research

New research checkpoint,2026-11-05. This does not boot an LG phone or prove
that a usable GNEX interpreter is installed. The ordinary Reunion catalogue
remains55 apps. No new commercial SGS game is claimed.

SV400 contains the exact reconstructed ARM ELF (33993664 bytes), standalone
hash-locked unpacker, bounded original-code dispatcher probe and evidence.
The original SGS MIME branch selectsGNEX and reaches an app-execute callback;
the probe stops before that callback body. Its metadata/stack are synthetic.
Two controls selectTCMPLAYER/failure. SeeSV400/README.md for precise bounds.

To reproduce dispatch, first copySV400 to a scratch location so reference
reports stay intact. Install the recorded Unicorn2.1.4 and run:

    python -m pip install unicorn==2.1.4
    python SV400/probe-gnex-dispatch.py

To reproduce complete unpacking, obtain the exact public source archive linked
inSV400/README.md. ExtractBIN/SV400005_03.bin with Reunion's existing WDB tool.
The49MB original is not duplicated here. Pick a nonexistent output directory:

    python SV400/unpack-sv400-main.py /path/to/SV400005_03.bin /path/to/new-output --lglz GPL-LGLZ/decode-lglz.py

The wrapper accepts only the recorded sourceSHA256 and the exact preserved GPL
decoder. It verifies135block lengths, terminators,FF remainders,20program
headers and final hashes before publishing output. NoECC correction, bad-block
reordering or invented padding. No DLL or vendor updater is executed.

GPL-LGLZ preserves the original LGUI source notice/provenance, Python decoder,
C reference adaptation, COPYING and earlier eight-module research baseline.
Only one original PXO fixture is included here, for the six decoder unit tests:

    python GPL-LGLZ/test_decode_lglz.py

Other baseline module files remain in the earlier recovery bundle. The new
135block C-reference comparison isSV400/main-reference-comparison.json.
SV400/test-unpack-sv400-main.py is source-cache-based workspaceQA; its recorded
six-check result is included, but it is not a source-free package test.
These standalone tools retainGPL-3.0-or-later. The original firmware/PXO/Lala
payloads retain their own origins; the tools' licence does not relicense them.

Lala/original preserves the educational GNEX4 project and65210-byte SGS from
the public2006JZSDN post. The unrelated pixel-art collection andThumbs.db
caches are omitted. Every retained file is byte-exact; the original fullZIP
identity and member list are inLala/lala-extraction.json. No rebuild is claimed.
Using a configured Reunion source tree, replay the original with:

    node /path/to/KPEX100-Reunion/tools/replay-sgs.mjs --file Lala/original/lala.sgs Lala/lala-arrows.json /path/to/new-lala-replay

The128x146viewport is a research choice, not an identified phone. Same-time
control at300ms differs by817pixels under arrow input. This is an example,
not another recovered retail title. Replay plans/reports/PNGs are included.

repo-update contains documentation/evidence to merge into a complete current
Reunion checkout. Word/PPT findings name17historical test phones and six exact
SGS filename leads; those commercial binaries were not obtained. GrundigVP1000
hardware/CD lead remainsGNEX-unconfirmed; the recovered MPixx2000 disc is a
different product family and is not duplicated here.

review contains bounded independent audits. archive-route records a separate
400URL gvmcafe.com index and the first replay'sHTTP429; further archive calls
stopped, without bypass or software recovery. SHA256SUMS covers all entries
except itself. No scratch failed page-layout/xref trial is packaged.
