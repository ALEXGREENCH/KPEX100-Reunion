# Public Korean developer cafe follow-up

2026-11-05. Scratch-only. No Wayback/CDX calls, authentication, member-only attachments, contacts or old vendor executable execution.

## Actual new original bytes: Lala

Following the real **모바일: GVM / WAP** menu63 at [JZSDN](https://cafe.naver.com/jzsdn) exposed [캐릭터 움직이기, post8970](https://cafe.naver.com/jzsdn/8970), dated2006-10-10. Its logged-out response permits public reading and file download. The article shows a character-movement source example. The ZIP contains a slightly expanded project version with an obstacle and bottom-boundary check.

- Exact attachment: <https://download.blog.naver.com/2ebb328196c9ca163bd5be84b6552456f4a658ba5e/data23/2006/10/10/234/lala.zip>
- Archive: **1,224,627B**, SHA256 `2439ed27f789f4e651694412a46df1dada73d420e122c5ee19c767477223c6ae`; saved as `jzsdn-8970-lala.bin` (original ZIP bytes).
- **386 members, 2,206,332 uncompressed bytes; every ZIP CRC passed.** Original source, GNX project, assembly listing, build log, image definitions, compiled resources, images and pixel-art collection. No vendor program was executed. `lala-extraction.json` retains exact hashes and decoded names. The extracted subset omits the unrelated pixel collection and Explorer `Thumbs.db` caches.
- `extracted/lala/lala.sgs`: **65,210B**, SHA256 `0e5a8709be44788ae24b2557c75cbdb44749725110867b468a9a7d2a32acd747`.
- Strict parser: **GNEX4**, `lala GNEX App`, no wrapper/XOR, declared length equals exact EOF,25variable descriptors,3image resources. Entry points START0x182, TIMEOUT0xee, KEYPRESS0x82. Full original layout in `lala-sgs-layout.json`.
- Source supports separate `_GVM` SCRIPTVER2 and GNEX PLAYERVER4 branches; **only the GNEX4 binary is preserved**. Do not claim a recovered GVM2 build. `LCDCLASS255`; no model in the project. `lala.bld` corroborates65210B/25symbols/3images and original0errors/0warnings, but was not rebuilt.

This is an educational graphics/input example, **not a newly recovered complete retail game**.

## Unmodified replay and input proof

Existing repository `tools/replay-sgs.mjs --file` ran the unchanged SGS with an explicit test `phone128×146` viewport. This chosen viewport is not a handset attribution. Background and castle draw, then the character moves under arrow keys. All frames idle/error-null;4unique input-run frames.

`lala-arrows.json` uses tick1,right17,tick1,down19,tick1; `lala-idle.json` uses3ticks. Identical initial frames and equal final virtual time **300ms**; final frames differ by **817pixels**. Correct arrows follow the original source's SWAP_KEY names and SDK `SScript.h` values16–19. The initial numeric7/3 trial produced no movement and remains separately logged; no game bytes were patched.

Proof: `runtime/lala-control-proof.json`; reports and PNGs under `runtime/lala-arrows/` and `runtime/lala-idle/`. Useful final image: `runtime/lala-arrows/local-lala-4-tick1.png`. Exact hashes are in `evidence.json`.

## Other concrete public evidence and bounded negatives

- [JZSDN3354](https://cafe.naver.com/jzsdn/3354),2005-02-21, lists41SKT models by game-information-fee activity, including SD810/VK200C/ST2004/P1. **No VM/version/SGS/firmware mapping** appears; do not promote it into a GNEX support roster.
- [JZSDN2794](https://cafe.naver.com/jzsdn/2794),2004-12-22, is a repost explaining equal-priority queued KEYPRESS/TIMEOUT processing and timer delays caused by excessive input. Original authorship is not established.
- [JZSDN10078](https://cafe.naver.com/jzsdn/10078) preserves a long `Block Break GNEX App`/GVM2 source in a compiler-error question. No compiled SGS or attachment. It is source text needing debugging, not recovered executable gameplay.
- [Webmas990](https://cafe.naver.com/webmas/990) preserved exact historical developer-site URLs (GNEXClub, XCE, MobileTop, MagicN, ez-i, Webtlas), without binaries. We did not request Wayback copies of these.
- Fresh **icedesign1** menu31 has7GNEX project/source posts with attachment flags, but all `openArticle=false`. No article/attachment request made. menu30 likewise closed. **Cdirect** public menu indexes expose closed articles only; contents skipped.
- Direct indexed article **ealab91** and **webzero02034** returnedHTTP401; no retries or bypass.
- **Mobilecity1** attaches an addressbook XLS, not established software; attachment not downloaded.
- Exact Paladin title `접시의달인 GVM` and original filename `1060101FF0CFFFF` returned no public cafe result in this bounded search. `DISH.RES` matched unrelated text only. This does not establish global absence.

`receipts.json` retains raw response URL/status/size/SHA256; `evidence.json` is the compact machine-readable checkpoint. The traversal does not exhaust every forum or menu. No repository files were edited.
