///////////////////////////////////////////////////////////////////////////
// lala.mc - Auto Created by GNEX IDE
///////////////////////////////////////////////////////////////////////////

#ifdef _GVM
%{
	#DEFINE SCRIPTVER	2
	#DEFINE LCDCLASS	255
	#DEFINE IMAGETYPE	255
	#DEFINE AUDIOTYPE	255
	#DEFINE SCRIPTTYPE	1
	#DEFINE SCRIPTCPID	60000
	#DEFINE SCRIPTID	1
	#DEFINE SCRIPTNAME	"lala GVM2X App"
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM	255
%}
#else
%{
	#DEFINE PLAYERVER	4
	#DEFINE LCDCLASS	255
	#DEFINE IMAGETYPE	255
	#DEFINE AUDIOTYPE	255
	#DEFINE APPTYPE		1
	#DEFINE APPCPID		60000
	#DEFINE APPID		1
	#DEFINE APPNAME		"lala GNEX App"
	#DEFINE COMPTYPE	0
	#DEFINE AGENTTYPE	0
	#DEFINE VALIDCOUNT	255
	#DEFINE VALIDTERM	255
	#DEFINE DIRECTRUN	0
	#DEFINE APPVER		1
%}
#endif

#include   <SScript.h>

#include   "lala.sbm"

int   lala_x,   lala_y;

void   init()
{
            ClearWhite();   
          lala_x   =   swWidth/2-20;
          lala_y=   swHeight/2-20;
          CopyImage(0,   0,   background[0]);               //       �̹���       ���
          SaveLCD();

}
void   EVENT_KEYPRESS()
{
      switch(swData)
      {
            case   SWAP_KEY_UP   :   
                        lala_y   -=5;   
                        break;

            case   SWAP_KEY_DOWN   :   
                        lala_y   +=5;   
                        break;
            case   SWAP_KEY_RIGHT   :   
                        lala_x   +=5;   
                        break;   

            case   SWAP_KEY_LEFT   :   
                        lala_x   -=5;   
                        break;
      }

}

void   EVENT_TIMEOUT()
{
      RestoreLCD();
      CopyImage(lala_x,   lala_y,   lala[0]);               //       �̹���       ���
      Flush();
}

void   main()
{
      init();
      SetTimer(100,   S_TM_REPEAT);
} 