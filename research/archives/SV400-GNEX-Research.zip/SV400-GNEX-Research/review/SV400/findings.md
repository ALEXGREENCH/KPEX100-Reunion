# SV400 NAND/ELF/dispatch independent review

Bounded local review: **22/22 checks passed**, plus a final replay of the
updated self-contained, time-limited probe. No unresolved blocking finding.
No network, Office, vendor updater or downloaded vendor DLL was used.

- Reconstructed512data bytes independently from each of93328 exact528-byte
  source records: `[0:464] + [466:514]`. Source and47,783,936-byte result
  match their fixed identities. Naive first512-byte stripping differs.
- Decoded all135 bounded LGLZ slots independently through the preserved GPL
  Python decoder, checked declared lengths, terminators and everyFF tail.
  Concatenation is33,960,896 bytes, SHA256
  `e60e00048cc68d3f56ce4c745a57a95ebce2035d63cbfd5837acabb4f660da0a`.
- Also executed the separate locally compiled GPL C reference on all135
  already Python-validated streams; all33,960,896 bytes match. This is a
  research-built reference library, not a vendor DLL; malformed streams
  were not passed to its unchecked routine.
- Preserved32768bytes of original ELF header and added exactly the decoded
  stream, without padding. ReconstructedELF33,993,664 bytes hasSHA256
  `fb2b5e1abe3b9d8155e1f59f63e49434d77fcaade08ae9a27a6b006ea0447cbb`.
  ELF32/LE/ARM metadata, all20program extents and every segment hash match.
- Fresh portable-wrapper extraction from original rawBIN reproduced theELF.
  Short source, unknown decoder and existing-output-directory cases reject
  before output; existing sentinel remains intact.
- Verified the original vtable chain by actualELF words. A fresh original
  ARM/Thumb execution from post-metadata address`0x065da146` reproduced
  all three dispatch branches: SGS→GNEX231instructions; wavelet-tcm→
  TCMPLAYER327; unknownMIME→failure149. Final probe reads program headers
  directly from the hash-lockedELF and has2,000,000µs/50,000instruction limits.
  No memory errors or emulated libc/API stubs occurred. Originalraw/ELF stay
  byte-identical. Current probe hash and source snapshots are in evidence.

## Scope limits

The layout is verified for this exact update build only; no ECC repair,
bad-block reordering or universal Qualcomm format proof is supplied. The
source's other regions outside this reconstructedELF are not fully interpreted.

The dispatcher test **injects synthetic metadata/register/stack state after
metadata acquisition**, rather than invoking the complete routine at
`0x065da046`. It executes original comparison, string copy and trampoline
code and observes app-execute entry`0x072eab70` with playerGNEX, modeWAM and
`CONTENT/probe.sgs`; it stops **before that callback body**. This establishes
a real GNEX consumer/launch route, not an installed interpreter, realSGS
file loading, successful phone boot or gameplay.

Four overlapping table-like scanner candidates remain unvalidated suspects,
not four recovered games. They do not prove global absence of other games.
The GPL decoder/wrapper must retain their separate licence.

`evidence.json` includes exact block/segment identities and the final probe
recheck. `audit.py`, `audit-extra.py` and the small Thumb listing retain the
local method; no repository source was edited by this review.
