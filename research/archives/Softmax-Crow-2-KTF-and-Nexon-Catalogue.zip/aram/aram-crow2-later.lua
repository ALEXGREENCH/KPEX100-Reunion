aram.start()
aram.step(360)
aram.screenshot("crow2-long-title.png")
aram.tap("ok", 2)
aram.step(90)
aram.screenshot("crow2-long-menu.png")
aram.tap("up", 2)
aram.step(12)
aram.screenshot("crow2-long-new-game-selected.png")
aram.tap("ok", 2)
aram.step(600)
aram.screenshot("crow2-long-new-game.png")
aram.tap("ok", 2)
aram.step(60)
aram.screenshot("crow2-long-dialogue.png")
aram.tap("ok", 2)
aram.step(60)
aram.screenshot("crow2-long-dialogue-next.png")

for n = 1, 52 do
  aram.tap("ok", 2)
  aram.step(36)
  if n % 8 == 0 then
    aram.screenshot(string.format("crow2-later-%02d.png", n))
  end
end
aram.screenshot("crow2-later-before-move.png")
aram.tap("right", 15)
aram.step(20)
aram.screenshot("crow2-later-after-right.png")
aram.tap("down", 15)
aram.step(20)
aram.screenshot("crow2-later-after-down.png")

