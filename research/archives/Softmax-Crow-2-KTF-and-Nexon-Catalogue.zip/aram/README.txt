Crow 2 for KTF, version 01.00.06

ARAM source: https://github.com/mirusu400/aram-core
Commit: fea299cba15696ed1460f965b76626d6edab5e03
Build from that checkout: go build -o aram-debug ./cmd/aram-debug
Run from the extracted aram directory with that binary on PATH:
aram-debug lua --timeout 50s --run-budget 200000 ../original-games/Crow-2-KTF.zip aram-crow2-later.lua

Profile: wipi-1.2.1/ktf/generic, entry point 0x100001 (Thumb).
Two clean runs produced 15 byte-identical PNGs. The last three show the
first controllable scene, then movement right and down. This covers the
opening only. Audio and the remainder of the game were not checked.
