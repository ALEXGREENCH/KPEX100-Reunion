aram.start()
aram.step(510)
aram.screenshot("before.png")
aram.step(3)
aram.step(6)
aram.screenshot("after.png")

