# Sinjisoft2002: Mobile C and content catalogue

Exact anonymous public vendor HTML captures: mobilcsdk.html, mobilc.html,
embeded.html and example.html. All four byte payloads match their known
CDX SHA-1 digest. See manifest.json for original URLs, timestamps, sizes and
SHA-256. The June2002 archive dates are not the release dates of each product.

content-candidate-queue.json transcribes 24 numbered title/provider records:
18 with the original Stand-Alone category and six other content types. It
records all46 screenshot URI references. Those are source links, not images
included in this bundle. Three exact screenshot requests timed out during
TLS handshakes, and the limited pass stopped; no image format or dimensions
are claimed. The other43 URI references were not requested.

Entry21 is deliberately unresolved: its title says Moon Patrol (문패트롤),
while its description refers to Puzzle Bobble (퍼즐버블). No replacement title,
binary identity, compatible device or playable game is inferred.

В комплекте четыре исходные HTML и фактическая очередь из24 записей;
18пометок Stand-Alone не означают18 новых полученных игр. SDK, SGS,
прошивок и извлечённых изображений здесь нет. Страница embedded games
перечисляет марки и изготовителей, но не доказывает GVM у каждой модели.
Раннее описание Mobile C/SDK относится к этим историческим страницам,
а не ко всем поздним версиям GNEX.

Original Sinjisoft pages retain their original rights and notices. Reunion's
MIT licence does not relicense these pages. JavaScript, installers, SDKs and
phone/game code were not executed. Source HTML still references historical
external assets; it is not a complete offline website.
