# Independent early Korean firmware/source review

No blocking defect found. All 639 checks pass. This is a new local audit;
the previous 3,948-check historical roster audit was not repeated. The exact
reviewed validation JSON byte identities are recorded in evidence.json.
No repository file was modified and no network request or vendor executable
was run.

- Samsung: four source ZIPs match saved original IA size/SHA-1/MD5/CRC32 and
  local SHA-256; their ZIP CRC tests pass. Five nested 7z files match the
  original ZIP members byte for byte and pass fresh 7z integrity tests. Six
  raw images total 44,040,160 bytes and match declared size/SHA-256/CRC32.
  All 128 marker offsets and their occurrence counts, model/build strings,
  the X120 date literal and stored SGS scan source identities agree.
- E470 EADS: all three declared 48-byte headers and text extents, names,
  section hashes, guest address bounds and first Thumb halfwords agree with
  the original BIN. The extracted Bomb Link is exactly the declared 55,124
  bytes. It differs in both whole-module and text-section bytes/hash from the
  actual preserved 72,480-byte W210/W240 object. Rejected HEADSET matches are
  genuine substrings, not extra game records. No standalone-bundle or
  playability claim is supported or made by the reviewed document.
- Sanyo/Telson: three source archives pass fresh 7z integrity tests and match
  their declared hashes. Three original members total 17,760,244 bytes and
  match sizes/SHA-256/CRC32. All 91 generic marker offsets and 16 precise A011
  native literals agree. The A011 body CRC independently equals its stored
  four-byte little-endian footer; whole-file CRC is 2144df1c.
- Historical corroboration: 40 targeted XLS cells were checked directly in
  BIFF8, including Sanyo SKT row230 and C500 row217. Targeted guide text was
  checked on original pages43/81/82/98. Documentary runtime versions and
  application geometry remain separate from proof of actual VM execution.
- Nokia8887: the original PDF identity and 63-page count agree. PDF45/46
  printed39/40 visibly describe built-in SnakeII, Menu6 and controls;
  PDF35 printed29 visibly documents NATE downloads and retained content.
  This does not identify SnakeII's code format or establish a firmware dump.
- C500: original PDF/ZIP identities match; PDF has70 pages. Original text
  supports MagicBall on PDF33 printed62/63, retained downloads on PDF44
  printed84/85 and the menu tree on PDF57 printed110/111. The faithful
  page33 render was viewed; missing Korean glyph fallback remains disclosed.
  Both ZIP CRC levels pass. The PE's static MSZip CAB header has the declared
  offset, physical extent and nine-file count. All163 extracted-artifact
  identities match, totaling28,218,240 bytes (50 installed +113 expanded help
  files, deliberately counting compressed CHM and expanded contents). Scanner
  hash and stored negative-scan aggregation agree.
- Public player-game routes received only the requested bounded spot-check:
  six source hashes, three list counts totaling48 public metadata entries,
  the sanitized schema and first/last entry copy from each list. The record
  correctly contains no recovered game payload and classifies the MPIO404
  as a failed HTML response. This is not a review of all cached post bodies
  or independent evidence of files that were not downloaded.

Limits: the negative SGS scanners and InstallShield/CHM extraction were not
independently rerun. No firmware boot or game execution is covered. Native
Sanyo VM evidence was added later and is covered separately below. Adjacent
archive-index absence remains bounded to the fetched listings, as the
documents state.

## Separate final Sanyo native VM supplement

All659 supplementary checks pass in sanyo-supplement-evidence.json:
12 exact source spans and386 decoded source items, an independent raw Thumb1
constant decoder matching all758 initializer steps and240 dispatch stores,
explicit00..EF initialization with the unresolvedF0 guard gap, originalFF
termination, and the narrowly statedBA/C4 behavior. No public API name or
cross-device operation is inferred. The portable tool reproduces the final
UTF-8/LF trace byte for byte; wrong-size, wrong-hash and existing-output cases
reject safely. All four CLI cases were rerun into independent scratch paths.

Final canonical hashes for the five preceding validation inputs were refreshed
in evidence.json, retaining initial snapshots separately. The extra19 bounded
public-route checks pass in canonical-public-route-refresh.json. The original
639-source audit was not rerun or presented as covering the later native trace.
