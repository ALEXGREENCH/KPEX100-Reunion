Resumable public Wayback collection, PARTIAL snapshot.
collection/summary.json states which CDX scopes reached the end and which captures were verified. An indexed capture is NOT a recovered payload.
Original response bytes are in collection/objects/<SHA256-prefix>/<SHA256>. responses.jsonl records URL, UTC, status and headers. captures.jsonl records original CDX rows, digest checks and pending/mismatch/error states. membership.jsonl preserves the scope relation.
Cookie and authorization header values are redacted in the public snapshot. Response bodies are unchanged.
queue.sqlite3 is a consistent SQLite backup and can resume with: python tools/wayback-harvest.py collection --index --download --retry --repair-urls --archive-redirects
No domain/date/status/MIME collapse was requested. Duplicate identical CDX rows share a queue task; their original raw CDX response remains intact. UTF-8 URL quoting is recorded separately from the literal CDX original. Optional Korean transport variants and at most two same-resource raw replay redirects are explicitly recorded in resolution; they require the requested CDX payload digest. Actual redirected timestamps/headers are not metadata for the original requested timestamp. Redirects never lead into today's live websites.
This is NOT a complete WARC export or proof that missing/private files were archived. Error pages and unknown digests remain unverified. No historical code is executed. Original third-party content retains its existing rights; the MIT license covers Reunion tools only.
manifest.json covers all other members, excluding itself.

This delta requires the standalone snapshot GNEX-GVM-Wayback-Partial-Pass7-20261107.zip
SHA-256 f9a373528e4de958ac0a947b42613f652e98375503648748d7a5f373b71ff019
Verify that SHA-256, extract the base to an empty directory, then extract this delta into the same directory. The delta supplies the current queue, manifests and every referenced object missing from the base. The manifest below covers only this ZIP's members.
