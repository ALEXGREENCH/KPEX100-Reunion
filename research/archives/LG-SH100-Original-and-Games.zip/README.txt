Korean phone preservation, 2026-11-07 MSK.

Originals are unchanged received7z bodies. sources.json contains original URL,
HTTP headers, acquisition UTC, size/SHA256 and index identity. Extraction
reports distinguish originals and derived game PXO; original games remain
under extracted/. All7z CRC checks and selected member independent CRC passed.
No firmware or vendor DLL was executed. Folder/model labels and filenames do
not establish complete factory state, engine support or game playability.

See sibling Korean-Phone-Layer-Tools-and-Evidence.zip for complete scans,
all WDB file manifests, source indexes, GPL LZO sources and portable decoder.
The corresponding repository doc is doc/korean-phone-preservation-pass16.md.
No original firmware/game is relicensed under Reunion MIT.
manifest.json checks every other direct member by size/SHA256/CRC32.
