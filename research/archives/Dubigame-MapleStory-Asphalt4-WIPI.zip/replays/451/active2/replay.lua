aram.start()
aram.step(600)
aram.screenshot("opening.png")
aram.tap("ok", 3)
aram.step(180)
aram.screenshot("after-ok.png")
aram.tap("ok", 3)
aram.step(360)
aram.screenshot("after-second-ok.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-0.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-1.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-2.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-3.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-4.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-5.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-6.png")

aram.tap("ok",3)
aram.step(90)
aram.screenshot("next-7.png")

aram.screenshot("before.png")
aram.tap("ok", 3)
aram.step(45)
aram.screenshot("end.png")
