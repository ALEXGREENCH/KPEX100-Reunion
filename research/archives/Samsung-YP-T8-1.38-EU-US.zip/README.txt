Two original Samsung YP-T8 firmware update ZIPs.
See evidence.json for download URLs, checksums and the XOV scan.
The separately distributed game files are not included.
