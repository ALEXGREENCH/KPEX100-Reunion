Lionlogics website captures, 2003-2005.

The developer's page confirms Eternal Ranger for SKT GVM. The pack contains
the page and original capture bodies for the same site, including Pirate
King's two promotional SWF assets. No mobile game package was recovered.

See sources/receipts.json and validation/captures.json for provenance,
capture dates, status, hashes, SWF integrity and links extracted offline.
Historical HTML and SWF have been preserved byte for byte.

Full report:
https://github.com/ALEXGREENCH/KPEX100-Reunion/blob/main/doc/lionlogics-gvm-game-search.md
