  

<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='01_css/lion.css'>
<TITLE> �Ƣ� ���̿·������� �Բ�!! ����ϰ� �Բ�!! �Ƣ� </TITLE>
<!----- jump menu script start----->
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style>
A:link    {color:#7d7d7d;text-decoration:none;}
A:visited {color:#7d7d7d;text-decoration:none;}
A:active  {color:#229520;text-decoration:none;}
A:hover  {color:#229520;}
</style>
<!-- �̺�Ʈ�˾�--------------------------------------------
<script language="JavaScript">
<!--  
  function getCookie( name ){
    var nameOfCookie = name + "=";
    var x = 0;
    while( x <= document.cookie.length ) {
        var y = (x+nameOfCookie.length);
        if(document.cookie.substring(x, y) == nameOfCookie ) {
          if((endOfCookie = document.cookie.indexOf(";",y)) == -1 )
                   endOfCookie = document.cookie.length;
              return unescape(document.cookie.substring(y, endOfCookie));
    
        }
        x = document.cookie.indexOf(" ",x)+1;
        if(x == 0) break;
    }
    return "";
  }
  function popupopen(){
  	if ( getCookie( "Notice" ) != "done"){
  	window.open('07_popup/popup_dj2.htm','popup','width=350,height=395');
	}  	
  }
  popupopen()
  //-->
</script>

</HEAD>
<BODY leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_openBrWindow('etc/pop.htm','pkingopen','width=370,height=530')">
<table width="800" border="0" cellpadding="0" cellspacing="0">
<tr><td><!-- mainhome-top//-->
<table width="800" border="0" cellpadding="0" cellspacing="0">
	<tr>           
		<td height="177">
			<table width="800" height="177" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td>
						<table width="800" height="40" border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td width="134" height="40"><a onfocus="this,blur()" href="main.asp"><img src="img/top_logo.gif" width="134" height="40" border="0"></a></td>
								<td width="760" align="right" valign="top">
									<select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
									<option selected><font  color="">--�� ���ӹٷΰ��� ��--</font></option>
									<option value="11_coming/coming_040816.asp">�������� ���ӵ�</option>
									<option value="03_mobile/game3_04.asp">��� ����</option>
									<option value="03_mobile/game3_03.asp">���尳�� �Ϻ���</option>
									<option value="03_mobile/game1_07.asp">�����3-��������-</option>
									<option value="03_mobile/game3_02.asp">�����2-����̰�-</option>
									<option value="03_mobile/game1_06.asp">�����1-��������-</option>
									<option value="03_mobile/game1_01.asp">���ͳη�����</option>
									<option value="03_mobile/game1_02.asp">������ ���</option>
									<option value="03_mobile/game1_03.asp">���������</option>
									<option value="03_mobile/game1_04.asp">���� ����</option>
									<option value="03_mobile/game1_05.asp">���� ����</option>
									<option value="03_mobile/game2_01.asp">���罺ī��</option>
									<option value="03_mobile/game3_01.asp">��ϿͿ�!!</option>
									<option value="03_mobile/game4_01.asp">�������ä��I</option>
									</select></form>&nbsp;</td>
							</tr>
						</table>
					</td>						
				</tr>
				<tr>
					<td height="137">
						<table width="800" height="137" border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td width="10" height="137"></td>
								<td width="790"><embed src="img/main_img.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="137"></embed></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="11">
			<table width="800" height="11" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="10"><img src="img/bg002.gif" width="10" height="11" border="0"></td>
					<td width="780" bgcolor="#7D7D7D"></td>
					<td width="10"><img src="img/bg001.gif" width="10" height="11" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="113">
			<!--top menu-->
			<table width="800" height="113" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="790"><embed src="img/topmenu.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="113"></embed></td>
					<td width="10"><img src="img/bg003.gif" width="10" height="113" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>


</td></tr>
<tr><td>
<table width="800" border="0" cellpadding="0" cellspacing="0">
	<tr>           
		<td height="403">
			<table width="800" height="403" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="790">
						<table width="790" height="403" border="0" cellpadding="0" cellspacing="0">
							<tr><td height="3" colspan="2"></td></tr>
							<tr>
								<td width="350" height="397"><table width="350" border="0" cellpadding="0" cellspacing="0">
										<tr><td width="3"></td>
											<td width="344" height="392" valign="top">
												<table width="344" height="392" border="0" cellpadding="0" cellspacing="0" background="img/new001.gif">
        <tr> 
          <td colspan="3" height="25"></td>
        </tr>
        <tr > 
      <td ></td>
          <td></td>
        </tr>
        <tr bgcolor="#A7E855"> 
          <td width="5" height="362" bgcolor="#663300"></td>
          <td width="334" bgcolor="#663300"><img src="../img/newbanner-pking.gif" width="337" height="356" border="0" usemap="#Map"></td>
          <td width="5" bgcolor="#663300"></td>
        </tr>
        <tr bgcolor="#A7E855"> 
         
          <td bgcolor="#663300"></td>
          <td bgcolor="#663300"></td>
        </tr>
        
       
        <tr> 
          <td colspan="3" height="5"></td>
        </tr>
      </table>
											
											</td>
											<td width="3"></td>
										</tr>
										<tr><td height="5" colspan="3"></td></tr>
										<!--�̺�Ʈ���-->
										<tr><td width="3" height="55"></td><td height="55">
											<table width="344" height="0" border="0" cellpadding="0" cellspacing="0">
										
												</tr>
											</table>
										
									</table>
<map name="Map">
  <area shape="circle" coords="283,169,41" href="../pking/index.asp" target="_blank">
</map>
</td>
								<td width="437" valign="top">
									<table width="437" height="397" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="130" height="25"><img src="img/bar02_1.gif" width="130" height="25" border="0"></td>
											<td width="247" background="img/bar02_2.gif"></td>
											<td width="60"><a onfocus="this,blur()" href="04_news/news01.asp"><img src="img/bar02_3.gif" width="60" height="25" border="0"></a></td>
										</tr>
										<tr>
											<td height="214" colspan="3" bgcolor="#F7FBF0"><!--news---- �������� ����Ʈ ���̺� ����-->
												<table width="437" border="0" cellspacing="0" cellpadding="0">
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td></td>
														<td height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td colspan="2"><a onfocus="this,blur()" href="04_news/news_hot1.asp">���ͳη�����2 ������Ӽ� ���� �̺�Ʈ</a>
														</td>
														<td></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td></td>
														<td height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td colspan="2"><a onfocus="this,blur()" href="04_news/news_hot2.asp">���̿·����� WCG 2003�� ����</a>
														</td>
														<td></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td width="5"></td>
														<td width="22" height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td width="70">
															2004.03.06
														</td>
														<td width="335">
															<a onfocus="this,blur()" href='04_news/news01_read.asp?seq=14&subseq=0'>	���ʶ�~���ʶ�~��ǰ����! �̺�Ʈ ��÷�� ��ǥ!
															</a>	
														</td>
														<td width="5"></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td width="5"></td>
														<td width="22" height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td width="70">
															2004.03.05
														</td>
														<td width="335">
															<a onfocus="this,blur()" href='04_news/news01_read.asp?seq=13&subseq=0'>	���ʶ�~���ʶ�~��ǰ����! �̺�Ʈ ��ǥ �Ͻ� ���� �ȳ�
															</a>	
														</td>
														<td width="5"></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td width="5"></td>
														<td width="22" height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td width="70">
															2004.02.07
														</td>
														<td width="335">
															<a onfocus="this,blur()" href='04_news/news01_read.asp?seq=12&subseq=0'>	����� ����ö ���� �ȳ�!!
															</a>	
														</td>
														<td width="5"></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td width="5"></td>
														<td width="22" height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td width="70">
															2003.10.30
														</td>
														<td width="335">
															<a onfocus="this,blur()" href='04_news/news01_read.asp?seq=11&subseq=0'>	���̿·����� ���� ��ť������ ��ü�� ����!!
															</a>	
														</td>
														<td width="5"></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td width="5"></td>
														<td width="22" height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td width="70">
															2003.09.24
														</td>
														<td width="335">
															<a onfocus="this,blur()" href='04_news/news01_read.asp?seq=10&subseq=0'>	�����ͳη�����2 ������Ӽ� ����� ���ΰ��� ����?
															</a>	
														</td>
														<td width="5"></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
													<tr><td></td><td height="2" colspan="3"></td><td></td></tr>
													<tr>
														<td width="5"></td>
														<td width="22" height="20" align="center"><img src="img/front.gif" width="8" height="8"></td>
														<td width="70">
															2003.09.24
														</td>
														<td width="335">
															<a onfocus="this,blur()" href='04_news/news01_read.asp?seq=9&subseq=0'>	[�̺�Ʈ] "���� ����" ��Ī �̺�Ʈ�� �������Դϴ�.
															</a>	
														</td>
														<td width="5"></td>
													</tr>
													<tr><td></td><td height="1" colspan="3" background="img/dotline.gif"></td><td></td></tr>
													
												</table><!--�������� ����Ʈ ���̺� �� -->
											</td>
										</tr>
										<tr><td height="10" colspan="3" bgcolor="#F7FBF0"></td></tr>
										<tr><td height="3" colspan="3"></td></tr>
										<!--comming soon----------------------------------------//-->
										<tr>
											<td width="130" height="25"><img src="img/bar03.gif" width="130" height="25" border="0"></td>
											<td width="247" background="img/bar02_2.gif"></td>
											<td width="60"><a onfocus="this,blur()" href="11_coming/coming_040816.asp"><img src="img/bar02_3.gif" width="60" height="25" border="0"></a></td>
										</tr>
										<tr>
											<td height="110" colspan="3">
											<!--�������ΰ��ӵ�-->
												<img src="img/coming-soon.gif" width="437" height="110" border="0">
											<!-- ------------------------------// -->
											</td>
										</tr>
										<tr><td height="10" colspan="3"></td></tr>
									</table>
								</td>
								<td width="3"></td>
							</tr>
							<tr><td height="3" colspan="2"></td></tr>
						</table>
					</td>
					<td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="40">
			<!--bottom menu-->
			<table width="800" height="40" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="790" height="40"><embed src="img/bottom_menu.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="40"></embed></td>
		<td width="10" height="40"><img src="img/bg004.gif" width="10" height="40" border="0"></td>
	</tr>
</table>
		</td>
	</tr>
</td></tr>
</td></tr>
</td></tr>
</BODY>
</HTML>
