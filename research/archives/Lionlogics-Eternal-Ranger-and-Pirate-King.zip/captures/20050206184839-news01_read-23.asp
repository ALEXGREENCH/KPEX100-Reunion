
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='../01_css/lion.css'>
<TITLE> �Ƣ� ���̿·������� �Բ�!! ����ϰ� �Բ�!! �Ƣ� </TITLE>
<!----- jump menu script start----->
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style>
A:link    {color:#7d7d7d;text-decoration:none;}
A:visited {color:#7d7d7d;text-decoration:none;}
A:active  {color:#ED57A8;text-decoration:none;}
A:hover  {color:#ED57A8;}
</style>
</HEAD>
<BODY leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<!-- top menu including //-->
<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
	<tr>           
		<td height="40" background="../img/sub_img.gif">
			<table width="800" height="40" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="134" rowspan="2"><a onfocus="this,blur()" href="../main.asp"><img src="../img/top_logo.gif" width="134" height="40" border="0"></a></td>
					<td width="661" height="5"></td>
					<td width="5" height="5"></td>
				</tr>
				<tr>
					<td width="661" height="35" align="right" valign="top"><form name="form1">
									<select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
									<option selected><font  color="">--�� ���ӹٷΰ��� ��--</font></option>
									<option value="../11_coming/coming_040816.asp">�������� ���ӵ�</option>
									<option value="../03_mobile/game3_04.asp">��� ����</option>
									<option value="../03_mobile/game3_03.asp">���尳�� �Ϻ���</option>
									<option value="../03_mobile/game1_07.asp">�����3-��������-</option>
									<option value="../03_mobile/game3_02.asp">�����2-����̰�-</option>
									<option value="../03_mobile/game1_06.asp">�����1-��������-</option>
									<option value="../03_mobile/game1_01.asp">���ͳη�����</option>
									<option value="../03_mobile/game1_02.asp">������ ���</option>
									<option value="../03_mobile/game1_03.asp">���������</option>
									<option value="../03_mobile/game1_04.asp">���� ����</option>
									<option value="../03_mobile/game1_05.asp">���� ����</option>
									<option value="../03_mobile/game2_01.asp">���罺ī��</option>
									<option value="../03_mobile/game3_01.asp">��ϿͿ�!!</option>
									<option value="../03_mobile/game4_01.asp">�������ä��I</option>
									</select></form>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td width="5" height="35"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="11">
			<table width="800" height="11" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="10"><img src="../img/bg002.gif" width="10" height="11" border="0"></td>
					<td width="780" bgcolor="#7D7D7D"></td>
					<td width="10"><img src="../img/bg001.gif" width="10" height="11" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="113">
			<!--top menu-->
			<table width="800" height="113" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="790"><embed src="../img/topmenu1.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="113"></embed></td>
					<td width="10"><img src="../img/bg003.gif" width="10" height="113" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</td>
</tr>
<tr>
<td><!--main page--> 
<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
	<tr>     
		<td height="0">
			<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="120" valign="top" background="img/supbar_02.gif"><!--sub frame-->
						<!----- left menu table start ----->
						<!----- left menu table start ----->
						<SCRIPT language=javascript>
						<!-- //
						var isDOM = (document.getElementById ? true : false); 
						var isIE4 = ((document.all && !isDOM) ? true : false);
						var isNS4 = (document.layers ? true : false);
						function getRef(id) {
						if (isDOM) return document.getElementById(id);
						if (isIE4) return document.all[id];
						if (isNS4) return document.layers[id];
						}
						var isNS = navigator.appName == "Netscape";
						function moveRightEdge() {
						var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
						if (isNS4) {
						yMenuFrom   = divMenu.top;
						yMenuTo     = windows.pageYOffset+10;
						} else if (isDOM) {
						yMenuFrom   = parseInt (divMenu.style.top, 10);
						//yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop) + 154;
						yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop)+10;
						}
						if(yMenuTo<186) yMenuTo = 186; //�̵��İ�
						timeoutNextCheck = 500;
						if (yMenuFrom != yMenuTo) {
						yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 10);
						if (yMenuTo < yMenuFrom)
						yOffset = -yOffset;
						if (isNS4) divMenu.top += yOffset;
						else if (isDOM) divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
						timeoutNextCheck = 10;
						}
						setTimeout ("moveRightEdge()", timeoutNextCheck);
						}
						--> 
						</SCRIPT> 
						<div id=divMenu style="LEFT: 0px; VISIBILITY: visible; WIDTH: 120px; HEIGHT: 300px; POSITION: absolute"><!----- left menu table  -----> 
						<table width="120" height="0" border="0" cellpadding="0" cellspacing="0">
							<tr><td colspan="2"><img src="img/newsbar_01.gif" width="120" height="25" border="0"></td></tr>
							<tr>
								<td width="10"><td width="110" valign="top"><embed src="img/submenu03.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="109" height="300"></embed></td>
							</tr>
						</table><!----- left menu table  ----->
						</div>
						<SCRIPT language=javascript>
						<!-- //
						if (isNS4) {
						var divMenu = document["divMenu"];
						divMenu.top = top.pageYOffset + 120;
						divMenu.visibility = "visible";
						moveRightEdge();
						}
						else if (isDOM) {
						var divMenu = getRef('divMenu');
						divMenu.style.top = (isNS ? window.pageYOffset : document.body.scrollTop) + 165; //���۰�
						divMenu.style.visibility = "visible";
						moveRightEdge();
						}
						//-->
						</SCRIPT> 
						<!----- left menu table end ----->
						<!----- left menu table end ----->
					</td>
					<td width="670">
						<table width="670" height="0" border="0" cellpadding="0" cellspacing="0">
							<tr><td colspan="3"><img name="#1" src="img/main-top.gif" width="670" height="50" border="0"></td></tr>
							<tr>
								<td width="10" height="0" background="img/leftbg.gif"></td>
								<td width="650" height="0">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="350" height="0"><img src="img/title1.gif" width="350" height="30" border="0"></td>
											<td width="300" height="0" align="right" valign="bottom">
												
											</td>
										</tr>
									</table>
								</td>
								<td width="10" height="0"></td>
							</tr>
							<tr>
								<td width="10" height="0" background="img/leftbg.gif"></td>
								<td width="650" height="0">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="20" height="0"></td>
											<td width="610" height="0"><!-- hot--//-->
												<!-- hot--//-->
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="20" colspan="3"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="610" height="0">
												<table width="610" height="0" border="0" cellpadding="0" cellspacing="0">
													<tr>
														<td width="55" height="50"><img src="img/readtop1.gif" width="55" height="50" border="0"></td>
														<td width="555" height="50" background="img/readtop.gif" valign="bottom">
															<font color="#ffffff"><b>&nbsp;SKT �ڵ����KIN 2005�� 1�� 7�� ��Ī</b></font>
														</td>
													</tr>
												</table>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="610" height="0"><!-- �Խ���---------------------------------------  -->
												<table width="610" cellpadding="0" cellspacing="0">
													<tr>
														<td width="80" height="25" background="img/dotbg.gif">
															&nbsp;<img src="img/front03.gif" width="8" height="8" border="0">&nbsp;&nbsp;<b>��&nbsp;��&nbsp;ȣ :</b>
														</td>
														<td width="530" background="img/dotbg.gif">&nbsp;23</td>
													</tr>
													<tr>
														<td height="25" background="img/dotbg.gif">
															&nbsp;<img src="img/front03.gif" width="8" height="8" border="0">&nbsp;&nbsp;<b>��&nbsp;ȸ&nbsp;�� :</b>
														</td>
														<td background="img/dotbg.gif">&nbsp;80</td>
													</tr>
													<tr>
														<td height="25" background="img/dotbg.gif">
															&nbsp;<img src="img/front03.gif" width="8" height="8" border="0">&nbsp;&nbsp;<b>��&nbsp;&nbsp;&nbsp;&nbsp; �� :</b>
														</td>
														<td background="img/dotbg.gif">&nbsp;���</td>
													</tr>
													<tr>
														<td height="25" background="img/dotbg.gif">
															&nbsp;<img src="img/front03.gif" width="8" height="8" border="0">&nbsp;&nbsp;<b>��&nbsp;��&nbsp;�� :</b>
														</td>
														<td background="img/dotbg.gif">&nbsp;bini@lionlogics.com</td>
													</tr>
													<tr>
														<td height="25">
															&nbsp;<img src="img/front03.gif" width="8" height="8" border="0">&nbsp;&nbsp;<b>��&nbsp;��&nbsp;�� :</b>
														</td>	<td>&nbsp;2005.01.04</td>
													</tr>
													<tr>
														<td colspan="2">
															<table width="610" height="50" cellSpacing=0 cellPadding=0 border=0>
																<tr><td height="1" background="img/dotbg02.gif"></td></tr>
																<tr>
																	<td background="img/dotbg01.gif">
																		<table width="610" height="50" cellSpacing=0 cellPadding=0 border=0>
																			<tr><td width="10" height="10"></td>
																				<td width="590" height="10"></td>
																				<td width="10" height="10"></td>
																			</tr>
																			<tr><td></td>
																				<td>��2005 ���ο� �׼� �ڹ� ��庥ó�� ���� �ڵ���� KIN<br><br>�����ӹ�� : ����Ʈ���� -> 3. ������ -> �濵/����/��庥ó -> �׼Ǿ�庥�� -> 5. [New] �ڵ����KIN<br><br><BODY BGCOLOR=#000000 LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0><TABLE WIDTH=600 BORDER=0 align="center" CELLPADDING=0 CELLSPACING=0><TR><TD><IMG SRC="http://www.lionlogics.com/cnkin/handy/img/handy_01.gif" WIDTH=600 HEIGHT=225 ALT=""></TD></TR><TR><TD><table width="600" height="144" border="0" cellpadding="0" cellspacing="0"><tr><td><img SRC="http://www.lionlogics.com/cnkin/handy/img/handy_02_01.gif" width="161" height="144"></td><td><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="128" height="144"><param name="movie" value="http://www.lionlogics.com/cnkin/handy/img/kin.swf"><param name="quality" value="high"><embed SRC="http://www.lionlogics.com/cnkin/handy/img/kin.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="128" height="144"></embed></object></td><td><img SRC="http://www.lionlogics.com/cnkin/handy/img/handy_02_03.gif" width="311" height="144"></td></tr></table></TD></TR><TR><TD><IMG SRC="http://www.lionlogics.com/cnkin/handy/img/handy_03.gif" WIDTH=600 HEIGHT=537 ALT=""></TD></TR><TR><TD><IMG SRC="http://www.lionlogics.com/cnkin/handy/img/handy_04.gif" WIDTH=600 HEIGHT=855 ALT=""></TD></TR><TR><TD><IMG SRC="http://www.lionlogics.com/cnkin/handy/img/handy_05.gif" WIDTH=600 HEIGHT=1139 ALT=""></TD></TR></TABLE></BODY></HTML></td>
																				<td></td>
																			</tr>
																			<tr><td height="10"></td>
																				<td></td>
																				<td></td>
																			</tr>
																		</table>
																	</td>
																</tr>
																<tr><td height="1" background="img/dotbg02.gif"></td></tr>
															</table>
														</td>
													</tr>
												</table>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="20" colspan="3"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="610" height="0" align=center valign="middle"><!-- ��������Ͻ���--//-->
												 <TABLE width="610" height="50" cellSpacing=0 cellPadding=0 border=0>
													<TR> 
														<TD align=center> 
															<a href="news01.asp?ScrollAction=&keyword=&gubun_s="><img src="img/list.gif" width="50" height="25" border="0"></a> 
														</TD>
													</TR>
												</TABLE>
											</td>
											<td width="20" height="0"></td>
										</tr>
									</table>
								</td>
								<td width="10" height="0"></td>
							</tr>

							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
						</table>
					</td>
					<td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="1">
			<table width="800" height="1" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="120" height="1"><img src="img/supbar_03.gif" width="120" height="1" border="0"></td>
					<td width="670"></td>
					<td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="20">
			<table width="800" height="20" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="790"></td>
					<td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="40">
			<!--bottom menu-->
			<table width="800" height="40" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="790" height="40"><embed src="../img/bottom_menusub.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="40"></embed></td>
		<td width="10" height="40"><img src="../img/bg004.gif" width="10" height="40" border="0"></td>
	</tr>
</table>
		</td>
	</tr>
</table>
</td>
</tr>
</table>
</BODY>
</HTML>
