<HTML>
<HEAD>
<style>
A:link    {color:#869520;text-decoration:none;}
A:visited {color:#869520;text-decoration:none;}
A:active  {color:C0C23B;text-decoration:none;}
A:hover  {color:#C0C23B;}
</style>
<link rel='stylesheet' type='text/css' href='../01_css/lion.css'>
<TITLE> �Ƣ� ���̿·������� �Բ�!! ����ϰ� �Բ�!! �Ƣ� </TITLE>
<!----- jump menu script start----->
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>

</HEAD>
<BODY leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<!-- top menu including //-->
<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
	<tr>           
		<td height="40" background="../img/sub_img.gif">
			<table width="800" height="40" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="134" rowspan="2"><a onfocus="this,blur()" href="../main.asp"><img src="../img/top_logo.gif" width="134" height="40" border="0"></a></td>
					<td width="661" height="5"></td>
					<td width="5" height="5"></td>
				</tr>
				<tr>
					<td width="661" height="35" align="right" valign="top"><form name="form1">
									<select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
									<option selected><font  color="">--�� ���ӹٷΰ��� ��--</font></option>
									<option value="../11_coming/coming_040816.asp">�������� ���ӵ�</option>
									<option value="../03_mobile/game3_04.asp">��� ����</option>
									<option value="../03_mobile/game3_03.asp">���尳�� �Ϻ���</option>
									<option value="../03_mobile/game1_07.asp">�����3-��������-</option>
									<option value="../03_mobile/game3_02.asp">�����2-����̰�-</option>
									<option value="../03_mobile/game1_06.asp">�����1-��������-</option>
									<option value="../03_mobile/game1_01.asp">���ͳη�����</option>
									<option value="../03_mobile/game1_02.asp">������ ���</option>
									<option value="../03_mobile/game1_03.asp">���������</option>
									<option value="../03_mobile/game1_04.asp">���� ����</option>
									<option value="../03_mobile/game1_05.asp">���� ����</option>
									<option value="../03_mobile/game2_01.asp">���罺ī��</option>
									<option value="../03_mobile/game3_01.asp">��ϿͿ�!!</option>
									<option value="../03_mobile/game4_01.asp">�������ä��I</option>
									</select></form>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td width="5" height="35"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="11">
			<table width="800" height="11" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="10"><img src="../img/bg002.gif" width="10" height="11" border="0"></td>
					<td width="780" bgcolor="#7D7D7D"></td>
					<td width="10"><img src="../img/bg001.gif" width="10" height="11" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="113">
			<!--top menu-->
			<table width="800" height="113" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="790"><embed src="../img/topmenu1.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="113"></embed></td>
					<td width="10"><img src="../img/bg003.gif" width="10" height="113" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</td>
</tr>
<tr>
<td><!--main page--> 
<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
	<tr>      
		<td height="0">
			<table width="800" height="0" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="120" valign="top" background="img/mobar_02.gif"><!--sub frame-->
						<!----- left menu table start ----->
						<!----- left menu table start ----->
						<SCRIPT language=javascript>
						<!-- //
						var isDOM = (document.getElementById ? true : false); 
						var isIE4 = ((document.all && !isDOM) ? true : false);
						var isNS4 = (document.layers ? true : false);
						function getRef(id) {
						if (isDOM) return document.getElementById(id);
						if (isIE4) return document.all[id];
						if (isNS4) return document.layers[id];
						}
						var isNS = navigator.appName == "Netscape";
						function moveRightEdge() {
						var yMenuFrom, yMenuTo, yOffset, timeoutNextCheck;
						if (isNS4) {
						yMenuFrom   = divMenu.top;
						yMenuTo     = windows.pageYOffset+10;
						} else if (isDOM) {
						yMenuFrom   = parseInt (divMenu.style.top, 10);
						//yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop) + 154;
						yMenuTo     = (isNS ? window.pageYOffset : document.body.scrollTop)+10;
						}
						if(yMenuTo<186) yMenuTo = 186; //�̵��İ�
						timeoutNextCheck = 500;
						if (yMenuFrom != yMenuTo) {
						yOffset = Math.ceil(Math.abs(yMenuTo - yMenuFrom) / 10);
						if (yMenuTo < yMenuFrom)
						yOffset = -yOffset;
						if (isNS4) divMenu.top += yOffset;
						else if (isDOM) divMenu.style.top = parseInt (divMenu.style.top, 10) + yOffset;
						timeoutNextCheck = 10;
						}
						setTimeout ("moveRightEdge()", timeoutNextCheck);
						}
						--> 
						</SCRIPT> 
						<div id=divMenu style="LEFT: 0px; VISIBILITY: visible; WIDTH: 120px; HEIGHT: 300px; POSITION: absolute"><!----- left menu table  -----> 
						<table width="120" height="0" border="0" cellpadding="0" cellspacing="0">
							<tr><td colspan="2"><img src="img/mobar_01.gif" width="120" height="43" border="0"></td></tr>
							<tr>
								<td width="10"><td width="110" valign="top"><embed src="img/submenu02.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="109" height="400"></embed></td>
							</tr>
						</table><!----- left menu table  ----->
						</div>
						<SCRIPT language=javascript>
						<!-- //
						if (isNS4) {
						var divMenu = document["divMenu"];
						divMenu.top = top.pageYOffset + 120;
						divMenu.visibility = "visible";
						moveRightEdge();
						}
						else if (isDOM) {
						var divMenu = getRef('divMenu');
						divMenu.style.top = (isNS ? window.pageYOffset : document.body.scrollTop) + 165; //���۰�
						divMenu.style.visibility = "visible";
						moveRightEdge();
						}
						//-->
						</SCRIPT> 
						<!----- left menu table end ----->
						<!----- left menu table end ----->
					</td>
					<td width="670"><!-- submain start -->
						<table width="670" height="0" border="0" cellpadding="0" cellspacing="0">
							<tr><td colspan="3"><img name="#1" src="img/main-top1.gif" width="670" height="50" border="0"></td></tr>
							<tr>
								<td width="10" height="0" background="img/leftbg.gif"></td>
								<td width="650" height="0">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="350" height="0"><img src="img/title1_01.gif" width="350" height="30" border="0"></td>
											<td width="300" height="0" align="right" valign="bottom">
												<font color="#869520">
												<a onfocus="this,blur()" href="#2">��ũ����</a>&nbsp;&nbsp;|&nbsp;&nbsp;
												<a onfocus="this,blur()" href="#3">ĳ����</a>&nbsp;&nbsp;|&nbsp;&nbsp;
												<a onfocus="this,blur()" href="#4">���ӹ��</a>&nbsp;&nbsp;|&nbsp;&nbsp;
												<a onfocus="this,blur()" href="#5">���ӹ��</a>&nbsp;&nbsp;
												</font>
											</td>
										</tr>
									</table>
								</td>
								<td width="10" height="0"></td>
							</tr>
							
							<!-- banner -->
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650"><img src="img/er_banner01.gif" width="650" height="6" border="0"></td>
								<td width="10"></td>
							</tr>
							<tr><td width="10" background="img/leftbg.gif"></td><td width="650" bgcolor="#C0C23B"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650"><img src="img/er_banner.gif" width="650" height="80" border="0"></td>
								<td width="10"></td>
							</tr>
							<tr><td width="10" background="img/leftbg.gif"></td><td width="650" bgcolor="#C0C23B"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650"><img src="img/er_banner02.gif" width="650" height="6" border="0"></td>
								<td width="10"></td>
							</tr>
							<!-- submain1 -->
							<tr><td width="10" height="10" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650">
									<table width="650" height="50" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="55"><img src="img/mainbar01.gif" width="55" height="50" border="0"></td>
											<td width="70" background="img/mainbar03.gif"><img src="img/mainbar021.gif" width="70" height="50" border="0"></td>
											<td width="475" background="img/mainbar03.gif"></td>
											<td width="50"><img src="img/mainbar041.gif" width="50" height="50" border="0"></td>
										</tr>
									</table>
								</td>
								<td width="10"></td>
							</tr>
							
							<tr>
								<td width="10" height="50" background="img/leftbg.gif"></td>
								<td width="650" bgcolor="#F4F4F4">
									<table width="650" height="50" border="1" borderColorLight="#B4B4B4" borderColorDark="#ffffff" cellpadding="0" cellspacing="0">
													<tr>
														<td width="60" height="25" align="center"><strong>�� ��</strong></td>
														<td width="103" align="center">���÷���(RPG)</td>
														<td width="60" align="center"><strong>�÷���</strong></td>
														<td width="102" align="center">SKT GVM</td>
														<td width="60" align="center"><strong>�׷���</strong></td>
														<td width="102" align="center">color</td>
														<td width="60" align="center"><strong>����</strong></td>
														<td width="103" align="center">16Poly</td>
													</tr>
													<tr>
														<td width="60" height="25" align="center"><strong>����</td>
														<td colspan="7">&nbsp;&nbsp;���ͳη�����I - 2002�� 12�� 6�� / ���ͳη�����II - 2003�� 8�� 5��</td>
													</tr>
												</table>
								</td>
								<td width="10"></td>
							</tr>
							
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>

							<tr>
								<td width="10" height="0" background="img/leftbg.gif"></td>
								<td width="650" height="0">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="20" height="0"></td>
											<td width="200" height="0" valign="top"><br>
												<font size="3"><strong>��</strong></font>�ӿ� ���� ���� ����� ���� ���� ������ ������ ����<br><br>
												<font size="3"><strong>��</strong></font>������ �߻��ϴ� ¥�ӻ� �ִ� �̺�Ʈ �ó�����<br><br>
												<font size="3"><strong>ȭ</strong></font>���� �������� ����ũ �������� ȿ��<br><br>
												<font size="3"><strong>��</strong></font>�ͳη����� ����Į���� ���Ǽҵ� I�� �ش��ϴ� �ø���� ��ȹ<br><br>
												<font size="3"><strong>��</strong></font>���� RPG�� ����ž�� �̷��� ����, ���ͳη�����!<br><br>
											</td>
											<td width="10" height="0"></td>
											<td width="400" height="310">
												<img src="img/er_poster.gif" width="400" height="310" border="0">
											</td>
											<td width="20" height="0"></td>
										</tr>
									</table>
								</td>
								<td width="10" height="0"></td>
							</tr>							
							
							<!-- submain2 -->
							<tr><td width="10" height="10" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650">
									<table width="650" height="50" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="55"><img src="img/mainbar01.gif" width="55" height="50" border="0"></td>
											<td width="70" background="img/mainbar03.gif"><img name="#2" src="img/mainbar022.gif" width="70" height="50" border="0"></td>
											<td width="475" background="img/mainbar03.gif"></td>
											<td width="50"><a onfocus="this,blur()" href="#1"><img src="img/mainbar04.gif" width="50" height="50" border="0"></a></td>
										</tr>
									</table>
								</td>
								<td width="10"></td>
							</tr>
							
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>

							<tr>
								<td width="10" height="0" background="img/leftbg.gif"></td>
								<td width="650" height="0">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0" bgcolor="#F5F5F5">
										<tr>
											<td width="20" height="8"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="12"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="20"></td>
										</tr>
										<tr>
											<td width="20"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot01.gif" width="128" height="114" border="0"></td>
											<td width="11"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot02.gif" width="128" height="114" border="0"></td>
											<td width="12"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot03.gif" width="128" height="114" border="0"></td>
											<td width="11"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot04.gif" width="128" height="114" border="0"></td>
											<td width="20"></td>
										</tr>
										<tr>
											<td width="20" height="8"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="12"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="20"></td>
										</tr>
										<tr><td height="10" colspan="9"></td></tr>
										<tr>
											<td width="20" height="8"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="12"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="20"></td>
										</tr>
										<tr>
											<td width="20"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot05.gif" width="128" height="114" border="0"></td>
											<td width="11"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot06.gif" width="128" height="114" border="0"></td>
											<td width="12"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot07.gif" width="128" height="114" border="0"></td>
											<td width="11"></td>
											<td width="144" background="img/shot_bg02.gif" align="center"><img src="img/er_shot08.gif" width="128" height="114" border="0"></td>
											<td width="20"></td>
										</tr>
										<tr>
											<td width="20" height="8"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="12"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="20"></td>
										</tr>
									</table>
								<td width="10" height="0"></td>
							</tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							
							<!-- submain3 -->
							<tr><td width="10" height="10" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650">
									<table width="650" height="50" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="55"><img src="img/mainbar01.gif" width="55" height="50" border="0"></td>
											<td width="70" background="img/mainbar03.gif"><img name="#3" src="img/mainbar023.gif" width="70" height="50" border="0"></td>
											<td width="475" background="img/mainbar03.gif"></td>
											<td width="50"><a onfocus="this,blur()" href="#1"><img src="img/mainbar04.gif" width="50" height="50" border="0"></a></td>
										</tr>
									</table>
								</td>
								<td width="10"></td>
							</tr>
							
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>

							<tr>
								<td width="10" height="10" background="img/leftbg.gif"></td>
								<td width="650" height="10">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0" bgcolor="#F5F5F5">
										<tr>
											<td width="20"></td>
											<td width="144" align="center"><img src="img/er_ca01.gif" width="140" height="152" border="0"></td>
											<td width="11"></td>
											<td width="144" align="center"><img src="img/er_ca02.gif" width="140" height="152" border="0"></td>
											<td width="12"></td>
											<td width="144" align="center"><img src="img/er_ca03.gif" width="140" height="152" border="0"></td>
											<td width="11"></td>
											<td width="144" align="center"><img src="img/er_ca04.gif" width="140" height="152" border="0"></td>
											<td width="20"></td>
										</tr>
									</table>	
								</td>
								<td width="10" height="10"></td>
							</tr>

							<tr>
								<td width="10" height="10" background="img/leftbg.gif"></td>
								<td width="650" height="10">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0" bgcolor="#F5F5F5">
										<tr><td height="20" colspan="5"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="40" valign="top"><img src="img/er_ca001.gif" width="40" height="40" border="0"></td>
											<td width="10"></td>
											<td width="560">
												<strong>
												�̸� : ī�� ������Ʈ(Karu Selient)<br>
												���� : ��<br>
												���� : 22��<br>
												���� : �ձ� ������<br>
												���� : ��õ�� ������ ������<br>
												</strong>
												��Ű�Ͼ� ��ȭ���� ������ ������� �ƹ����� ������ ���� �ް� �ڶ���. �׷��� �ƹ����� ���� ����� ������ ũ��, ���� �������� ���� �ƹ����� ���� �� ������ ���ؼ� ������ ã�� ������ ������. ��õ���� ���������� �ϳ� ������ ���ϴ�. �������� Ư���� ���� �⵿���� �ſ� ũ�� �� �������� ��� ���ʺ��ٴ� Ȱ������ ���� ���� �Ƹ� ������ ��� �����Ѵ�. ���� �㸮�㿡 �ް� �ٴϱ� ���ϵ��� ������� ���� ����Ѵ�. ���󿡼� ��û�� �⵿�°� ���ǵ带 �ڶ������� ȸ�� �ɷ��� �پ��, ���� ���ݷ��� ����.<br>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="10" colspan="5"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="40" valign="top"><img src="img/er_ca002.gif" width="40" height="40" border="0"></td>
											<td width="10"></td>
											<td width="560">
												<strong>
												�̸� : ���̳� ������Ʈ(Jeina Selient)<br>
												���� : ��<br>
												���� : 20��<br>
												���� : �ձ� ��Ű��<br>
												���� : ��õ�� Ȱ����<br>
												</strong>
												��Ű�Ͼ� ��ȭ���� ��Ű���ν� � �� �� �� �� �ɷ��� ���� �޾ƿԴ�. ��� �ڽ��� ������ ī��� �� �ο����� ��� ���� ���̶�� �� ������ ����(?) �����̴�. �ƹ��� ���� ��ǿ� ������ ���� �����ϰ� �ȴ�. ��Ű���� Ư���� ���� �⵿���� ����, Ȱ�� �ַ� ����Ѵ�. Ȱ������ ���� ������ ���� �ƸӸ� ��� �����ϸ� ���� ������ ���õ� ��Ű����� �����̳� �Ϲ� Ȱ�� ���� ���� Ȱ�� �̿��Ͽ� ��� ���߽�Ų��. ����� ���� ��� ������ �� ������ �⵿�°� ���ǵ尡 ����, ȸ�� �ɷ��� ����.<br>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="10" colspan="5"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="40" valign="top"><img src="img/er_ca003.gif" width="40" height="40" border="0"></td>
											<td width="10"></td>
											<td width="560">
												<strong>
												�̸� : ���� �߷�Ÿ��(Cecil Valentine)<br>
												���� : ��<br>
												���� : 21��<br>
												���� : ���� �� ������<br>
												���� : ħ�� �ұ���<br>
												</strong>
												�̹� �������� �����׿��� ������� �ȴ�. ��ǻ� �Ϸ�̳�Ƽ���� ��ġ�Ǵ� ���̸� ��·�� 2�ο����� �������� �ʴ´�. ���п� 2�ο����� �׷��� ū ������ ���� ���� �ʴ´�.<br>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="10" colspan="5"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="40" valign="top"><img src="img/er_ca004.gif" width="40" height="40" border="0"></td>
											<td width="10"></td>
											<td width="560">
												<strong>
												�ϻ���<br>
												</strong>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="10" colspan="5"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="40" valign="top"><img src="img/er_ca005.gif" width="40" height="40" border="0"></td>
											<td width="10"></td>
											<td width="560">
												<strong>
												����<br>
												</strong>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="10" colspan="5"></td></tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="40" valign="top"><img src="img/er_ca006.gif" width="40" height="40" border="0"></td>
											<td width="10"></td>
											<td width="560">
												<strong>
												����<br>
												</strong>
											</td>
											<td width="20" height="0"></td>
										</tr>
										<tr><td height="10" colspan="5"></td></tr>
									</table>	
								</td>
								<td width="10" height="10"></td>
							</tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							
							<!-- submain4 -->
							<tr><td width="10" height="10" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650">
									<table width="650" height="50" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="55"><img src="img/mainbar01.gif" width="55" height="50" border="0"></td>
											<td width="70" background="img/mainbar03.gif"><img name="#4" src="img/mainbar024.gif" width="70" height="50" border="0"></td>
											<td width="475" background="img/mainbar03.gif"></td>
											<td width="50"><a onfocus="this,blur()" href="#1"><img src="img/mainbar04.gif" width="50" height="50" border="0"></a></td>
										</tr>
									</table>
								</td>
								<td width="10"></td>
							</tr>
							
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>
							<tr>
								<td width="10" height="10" background="img/leftbg.gif"></td>
								<td width="650" height="10">
									<table width="650" height="0" border="0" cellpadding="0" cellspacing="0" bgcolor="#F5F5F5">
										<tr>
											<td width="20"></td>
											<td width="610" colspan="7"><strong>SKT NATE�� ����&nbsp;>>>&nbsp;
											<a target=_blank href="http://mobile.ddangkong.nate.com/mobile/nateweb/34055/3405503031/index.jsp">��Playon���� �ٿ�ޱ�</a></strong></td>
											<td width="20"></td>
										</tr>
										<tr>
											<td width="20" height="0"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="12"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg01.gif" width="144" height="8" border="0"></td>
											<td width="20" height="0"></td>
										</tr>
										<tr>
											<td width="20"></td>
											<td width="144" background="img/shot_bg02.gif">
											&nbsp;&nbsp;1.��/�뷡��/����<br>
											&nbsp;&nbsp;2.�׸�/����/��Ÿ/ĳ��<br>
											&nbsp;&nbsp;<font class="lion05"><strong>�� 3.�ٿ�ε����</strong></font><br>
											&nbsp;&nbsp;4.����/ä��/�޽�¡<br>
											&nbsp;&nbsp;5.����/����/����/�Ӵ�<br>
											&nbsp;&nbsp;6.ģ��ã��/����/��ġ<br>
											&nbsp;&nbsp;7.���/����/������/��<br>
											&nbsp;&nbsp;8.����/�/���/��Ȱ<br>
											&nbsp;&nbsp;9.Adult Club(+19)<br>
											</td>
											<td width="11"></td>
											<td width="144" background="img/shot_bg02.gif">
											&nbsp;&nbsp;1.New/Hit20����<br>
											&nbsp;&nbsp;2.�� �ŴϾƿ� ������<br>
											&nbsp;&nbsp;3.����/�濵/�����̵�<br>
											&nbsp;&nbsp;4.����/�׼�<br>
											&nbsp;&nbsp;<font class="lion05"><strong>�� 5.����/����/RPG</strong></font><br>
											&nbsp;&nbsp;6.����/����<br>
											&nbsp;&nbsp;7.���/��ȭ/ĳ����<br>
											&nbsp;&nbsp;8.������<br>
											&nbsp;&nbsp;9.������/����/����<br>
											</td>
											<td width="12"></td>
											<td width="144" background="img/shot_bg02.gif">
											&nbsp;&nbsp;1.Hit ����<br>
											&nbsp;&nbsp;2.New ����<br>
											&nbsp;&nbsp;3.SRPG(����RPG)<br>
											&nbsp;&nbsp;<font class="lion05"><strong>�� 4.����RPG</strong></font><br>
											&nbsp;&nbsp;5.����/����<br>
											&nbsp;&nbsp;6.�����ù�/PC RPG<br>
											&nbsp;&nbsp;7.�׼�RPG<br>
											&nbsp;&nbsp;8.�¶��ΰ���RPG<br>
											&nbsp;&nbsp;<br>
											</td>
											<td width="11"></td>
											<td width="144" background="img/shot_bg02.gif">
											&nbsp;&nbsp;1.*****<br>
											&nbsp;&nbsp;2.*****<br>
											&nbsp;&nbsp;3.*****<br>
											&nbsp;&nbsp;4.*****<br>
											&nbsp;&nbsp;5.*****<br>
											&nbsp;&nbsp;<font class="lion05"><strong>�� 6.�����ͳη�����II</strong></font><br>
											&nbsp;&nbsp;7.*****<br>
											&nbsp;&nbsp;8.*****<br>
											&nbsp;&nbsp;9.*****<br>
											</td>
											<td width="20"></td>
										</tr>
										<tr>
											<td width="20" height="8"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="12"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="11"></td>
											<td width="144"><img src="img/shot_bg03.gif" width="144" height="8" border="0"></td>
											<td width="20"></td>
										</tr>
									</table>	
								</td>
								<td width="10" height="10"></td>
							</tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>

						<!-- submain5 -->
							<tr><td width="10" height="10" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr>
								<td width="10" background="img/leftbg.gif"></td>
								<td width="650">
									<table width="650" height="50" border="0" cellpadding="0" cellspacing="0">
										<tr>
											<td width="55"><img src="img/mainbar01.gif" width="55" height="50" border="0"></td>
											<td width="70" background="img/mainbar03.gif"><img name="#5" src="img/mainbar025.gif" width="70" height="50" border="0"></td>
											<td width="475" background="img/mainbar03.gif"></td>
											<td width="50"><a onfocus="this,blur()" href="#1"><img src="img/mainbar04.gif" width="50" height="50" border="0"></a></td>
										</tr>
									</table>
								</td>
								<td width="10"></td>
							</tr>
							
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>

							<tr><td width="10" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5">&nbsp;&nbsp;&nbsp;coming soon!</td><td width="10"></td></tr>


							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650" bgcolor="#F5F5F5"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
							<tr><td width="10" height="1" background="img/leftbg.gif"></td><td width="650" background="img/dotline.gif"></td><td width="10"></td></tr>
							<tr><td width="10" height="2" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>


							<tr><td width="10" height="20" background="img/leftbg.gif"></td><td width="650"></td><td width="10"></td></tr>
						</table>
					</td>
					<td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="120" height="1"><img src="img/mobar_03.gif" width="120" height="1" border="0"></td><td width="670"></td><td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="20">
			<table width="800" height="20" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="790"></td>
					<td width="10" bgcolor="#949494"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>           
		<td height="40">
			<!--bottom menu-->
			<table width="800" height="40" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="790" height="40"><embed src="../img/bottom_menusub.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="790" height="40"></embed></td>
		<td width="10" height="40"><img src="../img/bg004.gif" width="10" height="40" border="0"></td>
	</tr>
</table>
		</td>
	</tr>
</table>
</td>
</tr>
</table>
</BODY>
</HTML>
