

<HTML>
<HEAD>
<TITLE>�� -- ������ -- ��</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=euc-kr">
<link href="write.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY BGCOLOR=#FFFFFF background="img/back.gif" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<TABLE WIDTH=980 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="img/index_01.gif" WIDTH=95 HEIGHT=87 ALT=""></TD>
		
    <TD> <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="885" height="87">
        <param name="movie" value="img/menu.swf">
        <param name="quality" value="high">
        <embed src="img/menu.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="885" height="87"></embed></object></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="img/index_03.gif" WIDTH=95 HEIGHT=461 ALT=""></TD>
		
    <TD valign="top" background="img/index_04.gif"><table width="824" height="458" border="0" cellspacing="0">
        <tr>
          <td width="483"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="459" height="450">
              <param name="movie" value="img/index.swf">
              <param name="quality" value="high">
              <embed src="img/index.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="459" height="450"></embed></object></td>
          <td width="337" valign="top"><table width="378" height="337" border="0" cellspacing="0">
              <tr> 
                <td width="376" height="89"><br>
                  <br>
									<!--<div align="right">�ѹ湮�� : <strong><font color="#990000">6437</font></strong>��</div>-->
                  <br>
                  <table width="372" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td width="372" align="center"><img src="img/text.gif" width="332" height="31"></td>
                    </tr>
                  </table>
                  <br>
                  <img src="img/main_copy.gif" width="386" height="53"><br>
                  <table width="383" border="0">
                    <tr align="center"> 
                      <td colspan="2"><img src="img/text2.gif" width="332" height="62"></td>
                    </tr>
                   
                  </table>
                  
                </td>
              </tr>
              <tr>
                <td height="55"><table width="164" border="0">
                    <tr>
                      <td width="15">&nbsp;</td>
                      <td width="139" class="write"><img src="img/doun.gif" width="105" height="20"></td>
                    </tr>
                  </table>
                  <img src="img/down.gif" width="386" height="53"></td>
              </tr>
              <tr>
                <td height="136" align="center"><table width="265" border="0" class="write1">
                    <tr> 
                      <td width="74" bgcolor="#666666" class="write"><font color="#F1E3D6">&nbsp;<img src="img/arro.gif" width="7" height="8"> 
                        �����</font></td>
                      <td width="181" bgcolor="#CEC9C8" class="write1"><strong>SKT</strong></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#666666" class="write"><font color="#F1E3D6">&nbsp;<img src="img/arro.gif" width="7" height="8"> 
                        �帣</font></td>
                      <td bgcolor="#CEC9C8" class="write1"><strong>RPG (Semi-Network)</strong></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#666666" class="write"><font color="#F1E3D6">&nbsp;<img src="img/arro.gif" width="7" height="8"> 
                        �̿��</font></td>
                      <td bgcolor="#CEC9C8" class="write1"><strong>2000��</strong></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#666666" class="write"><font color="#F1E3D6">&nbsp;<img src="img/arro.gif" width="7" height="8"> 
                        �뷮</font></td>
                      <td bgcolor="#CEC9C8" class="write1"><strong>356KB</strong></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#666666" class="write"><font color="#F1E3D6">&nbsp;<img src="img/arro.gif" width="7" height="8"> 
                        ����</font></td>
                      <td bgcolor="#CEC9C8" class="write1"><strong>SK-VM</strong></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#666666" class="write"><font color="#F1E3D6">&nbsp;<img src="img/arro.gif" width="7" height="8"> 
                        �����</font></td>
                      <td bgcolor="#CEC9C8" class="write1"><strong>2004�� 11��</strong></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table> </TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="img/index_05.gif" WIDTH=95 HEIGHT=52 ALT=""></TD>
		<TD>
			<IMG SRC="img/index_06.gif" WIDTH=885 HEIGHT=52 ALT=""></TD>
	</TR>
</TABLE>
</BODY>
</HTML>