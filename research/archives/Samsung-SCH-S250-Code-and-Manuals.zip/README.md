# Samsung SCH-S250 code image and official manuals

Preserved as exact original files:
- S250MSM_CODE_YD01.7z from the public Sunderland firmware archive;
- both SCH-S250 manuals (Open 1.2 and SKT 1.3) and the quick guide, fetched
  directly from Samsung's official download server;
- original support HTML, its download UI JavaScript and Samsung's launch release.

The original 7z contains one 19,300,352-byte model-labelled code image. The
filename's YD01 label is not independently authenticated as an internal build
string. This is not a verified complete phone flash or an image booted by Reunion.
GNEX/SGS MIME routing exists, but a working GNEX interpreter is not established.
The Sinjisoft application metadata explicitly names NATEAIR; it is not relabelled
as the SGS interpreter. The two default game names are confirmed by the manual
and code-image menu, but no standalone game, game ABI or playable SGS was recovered.

derived/ contains an exact embedded ZIP (56 entries, CRC checked) with input-method
and UI resources, three explicitly bounded binary excerpts, and six rendered
manual verification pages. None is presented as a complete standalone game.
Both full manuals' cover and physical page90 (printed178-179) were reviewed;
the two quick-guide pages were also reviewed. Whole-document text searches are
limited by incomplete Korean font mappings.

audit/ and receipts/ contain the scoped findings, hashes, offsets and HTTP
provenance. SCH-S380 framebuffer-labelled input is separately recorded by hash;
its raw memory bytes are retained locally and are NOT in this public package.
The PC Link installers have their own preservation bundle and are not GNEX SDKs.

methods/ is a snapshot of the original workspace analysis script, with its
workspace-specific path assumptions retained. It is not a turnkey CLI or vendor
installer. No vendor executable, firmware or Office macro was executed.
Original rights/notices are retained; Reunion MIT does not relicense these files.
manifest.json hashes every other member; the outer ZIP hash is in the catalog.
