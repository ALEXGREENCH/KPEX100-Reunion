from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import re
import subprocess
import zlib

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
REPO = ROOT / 'outputs/KPEX100-Reunion'
SEVEN = r'C:\Program Files\7-Zip\7z.exe'

def run(args, name):
    result = subprocess.run(args, capture_output=True, encoding='utf-8', errors='replace')
    (HERE / name).write_text(result.stdout + result.stderr, encoding='utf-8')
    if result.returncode:
        raise ValueError('7z failure: ' + name)
    return result.stdout

spec = importlib.util.spec_from_file_location('scanner', REPO / 'tools/scan-firmware-games.py')
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
catalog = json.loads((REPO / 'web/data/catalog.json').read_text(encoding='utf-8'))
controls = scanner.check_controls(catalog)
assert controls['files'] == controls['passed'] == 68
inputs = json.loads((HERE / 'download-receipts.json').read_text(encoding='utf-8'))
records = []
terms = [b'SCH-S250', b'SCH-S380', b'S250', b'S380', b'YD01', b'GNEX', b'GVM', b'Sinjisoft', b'SINJISOFT', b'application/x-gnex-sgs', b'application/x-gvm-sgs', b'Haunted', b'Lost Planet', b'LOST PLANET', b'nvm/gvm', b'/fs/GNEX', b'EADS', b'WIPI', b'Swerve', b'PK\x03\x04', b'\x7fELF']
for source in inputs:
    assert source.get('status') == 200
    archive = HERE / source['file']
    assert archive.stat().st_size == source['bytes']
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == source['sha256']
    model = source['model']
    listing = run([SEVEN, 'l', '-slt', str(archive)], model + '-archive-list.txt')
    run([SEVEN, 't', str(archive)], model + '-archive-test.txt')
    files_part = listing.split('----------', 1)[1]
    blocks = [dict(line.split(' = ', 1) for line in block.splitlines() if ' = ' in line) for block in files_part.strip().split('\n\n')]
    file_rows = [b for b in blocks if b.get('Attributes', '').find('D') < 0 and b.get('Folder') != '+']
    assert file_rows and sum(int(b['Size']) for b in file_rows) <= 192*1024*1024
    for b in file_rows:
        name = b['Path'].replace('\\', '/')
        assert not name.startswith('/') and '..' not in name.split('/') and ':' not in name
    out = HERE / 'raw' / model
    assert not out.exists()
    run([SEVEN, 'x', '-y', '-o' + str(out), str(archive)], model + '-archive-extraction.txt')
    actual = sorted(x for x in out.rglob('*') if x.is_file())
    assert len(actual) == len(file_rows)
    for file in actual:
        raw = file.read_bytes()
        entry = next(b for b in file_rows if b['Path'].replace('\\', '/') == file.relative_to(out).as_posix())
        assert len(raw) == int(entry['Size'])
        assert f'{zlib.crc32(raw):08x}' == entry['CRC'].lower()
        markers = {}
        for term in terms:
            offsets = [m.start() for m in re.finditer(re.escape(term), raw)]
            if offsets:
                markers[repr(term)] = {'count': len(offsets), 'offsets': offsets[:100]}
        scan = scanner.scan_bytes(raw)
        row = {'model': model, 'file': file.relative_to(HERE).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'crc32': f'{zlib.crc32(raw):08x}', 'archiveCrcMatches': True, 'markers': markers, 'scan': scan}
        records.append(row)
        print(json.dumps({'model': model, 'file': row['file'], 'bytes': len(raw), 'sha256': row['sha256'], 'markers': markers, 'sgsCount': len(scan['containers'])}), flush=True)
        if scan['containers']:
            scanner.extract_hits(raw, scan['containers'], HERE / 'sgs-candidates' / model)
report = {'schema': 1, 'checkedUtc': datetime.now(timezone.utc).isoformat(), 'scope': 'Two newly acquired model-labelled Samsung archives. Static extraction and scan only. S380 source describes a framebuffer memory dump; no complete phone image claimed.', 'inputs': inputs, 'scannerSha256': hashlib.sha256((REPO/'tools/scan-firmware-games.py').read_bytes()).hexdigest(), 'positiveControls': controls, 'records': records, 'summary': {'inputs': len(inputs), 'files': len(records), 'bytes': sum(x['bytes'] for x in records), 'candidateOffsets': sum(x['scan']['candidate_offsets_tested'] for x in records), 'sgsOccurrences': sum(len(x['scan']['containers']) for x in records)}}
(HERE/'initial-scan.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(report['summary']))
