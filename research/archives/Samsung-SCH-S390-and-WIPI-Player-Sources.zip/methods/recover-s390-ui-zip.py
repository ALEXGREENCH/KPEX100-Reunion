"""Recover the exact audited UI ZIP from the SCH-S390 ZI15 image.

SPDX-License-Identifier: MIT
This is a fixed-image evidence tool, not a game or a general firmware decoder.
Usage: python recover-s390-ui-zip.py INPUT_BIN NEW_OUTPUT_ZIP
"""

from pathlib import Path
import hashlib
import io
import sys
import zipfile


def main():
    if len(sys.argv) != 3:
        raise ValueError("Expected INPUT_BIN and NEW_OUTPUT_ZIP")
    source, output = map(Path, sys.argv[1:])
    if source.stat().st_size != 23068672:
        raise ValueError("Not the audited SCH-S390 input size")
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
        "fcb68e71edea2e07e464f2ad41c805c01108d09cdb0ab3b6b0965b9c0fff29b2"
    ):
        raise ValueError("Not the audited SCH-S390 input SHA-256")
    recovered = raw[5523408:5565419]
    if hashlib.sha256(recovered).hexdigest() != (
        "e988c36b5a71c20824e3d07ce949d85325144aa6c034eba7a4adaaae9317553c"
    ):
        raise ValueError("Embedded ZIP identity mismatch")
    with zipfile.ZipFile(io.BytesIO(recovered)) as archive:
        if len(archive.infolist()) != 57 or archive.testzip() is not None:
            raise ValueError("Embedded ZIP structure/CRC mismatch")
    with output.open("xb") as stream:
        stream.write(recovered)
    print("Recovered 42011 unchanged bytes; UI resources, not a standalone game")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
