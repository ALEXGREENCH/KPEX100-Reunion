# Samsung SCH-S390 and the downloadable WIPI GNEX player

This package retains exact original bytes of SCH-S390_ZI15.7z from the public
Sunderland archive, the official Samsung manual1.2 and AC06 release-information
PDF, official support HTML and the primary SK Telecom2003 annual-report HTML
filed30March2004 at KRX. Sources, sizes and SHA256 identities are in receipts
and audit JSON. ZI15 is a source-filename label; full flash completeness and a
bootable phone are not established. The AC06 file is a PDF, not firmware bytes.

SCH-S390 model labels, GNEX/SGS MIME and a GNEX route label exist in the image.
The separate Sinjisoft record names NATEAIR001.001.008; it is not relabelled as
the GNEX interpreter. Bomb Link and Bejeweled menu names are present, but no
standalone game, executable ABI or callable GNEX interpreter has been recovered.
The operator filing explicitly describes GNEX as a downloadable WIPI game-player
application. This explains a separate deployment possibility, not proof of its
installation on this image or every WIPI phone.

The original7z passes7-Zip testing. Its single BIN is23,068,672 bytes with
matching declared CRC. SGS v1/v2/v4/v36 plain/XOR-A5 scan tested1,479,220
candidate offsets; all68 catalog positive controls passed, zero new SGS found.
The one embedded ZIP at5523408 is42,011 unchanged bytes,57 entries /53 files.
All ZIP CRCs passed and its132,366 payload bytes were scanned with zero SGS.
Those are input-method/UI resources, not identified as either built-in game.
Five raw FWS/CWS header matches were rejected; no exhaustive encoded SWF scan
or general SWF decoder is claimed.

Both official PDF lengths match Samsung support data. The full manual has110
pages; complete physical pages1,52,54,105 were rendered and reviewed. The one-page
AC06 release note was also fully reviewed. Whole-manual text search is not proof
of absence. The reused PC Link fileID214530 is already preserved in the separate
Samsung-PC-Link-2000-Originals.zip; only the prior capture was rehashed here,
not downloaded again or counted as new software.

To repeat the SGS scan after extracting the original7z:
  python /path/to/Reunion/tools/scan-firmware-games.py SCH-S390_ZI15.bin --check-controls --output new-scan.json
To reproduce the exact UI ZIP using the included fixed-image evidence helper:
  python methods/recover-s390-ui-zip.py SCH-S390_ZI15.bin new-ui.zip
The helper refuses other image identities and existing output files. It is not
a generic firmware/game decoder. No installer, firmware, macro or vendor program
was executed. Original rights/notices are retained; Reunion MIT does not relicense
historical files. manifest.json hashes every other direct member.
