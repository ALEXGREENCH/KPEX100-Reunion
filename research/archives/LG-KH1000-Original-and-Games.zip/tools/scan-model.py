from hashlib import sha256
import importlib.util
from io import BytesIO
import json
from pathlib import Path
import re
import struct
import sys
import zipfile
import zlib


model = sys.argv[1]
base = Path(f'{model}-software')
repo = Path('../../outputs/KPEX100-Reunion')
spec = importlib.util.spec_from_file_location('scanner', repo / 'tools/scan-firmware-games.py')
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)


def identity(data):
    return dict(bytes=len(data), sha256=sha256(data).hexdigest(), crc32=f'{zlib.crc32(data):08X}')


def complete_zips(raw):
    for found in re.finditer(rb'PK\x05\x06', raw):
        at = found.start()
        if at + 22 > len(raw):
            continue
        disk, central_disk, this_count, count, length, offset, comment = struct.unpack_from('<4H2IH', raw, at+4)
        end = at + 22 + comment
        start = at - length - offset
        if (disk or central_disk or this_count != count or not 0 < count <= 6000
            or end > len(raw) or start < 0 or raw[start:start+4] != b'PK\x03\x04'
            or raw[at-length:at-length+4] != b'PK\x01\x02'):
            continue
        try:
            with zipfile.ZipFile(BytesIO(raw[start:end])) as z:
                entries = z.infolist()
                if len(entries) != count or sum(i.file_size for i in entries) > 64 * 1024**2 or z.testzip() is not None:
                    continue
                names = {x.filename.upper(): x for x in entries}
                mf = names.get('META-INF/MANIFEST.MF')
                manifest = z.read(mf) if mf and mf.file_size <= 128 * 1024 else b''
                yield dict(offset=start, end=end, entries=count,
                           midlet=bool(re.search(rb'^MIDlet-[0-9]+:', manifest, re.M | re.I)) and any(n.endswith('.CLASS') for n in names),
                           **identity(raw[start:end]))
        except (RuntimeError, NotImplementedError, ValueError, zipfile.BadZipFile, zlib.error):
            continue


runtime_terms = (b'application/x-gnex-sgs', b'application/x-gvm-sgs', b'A000200001', b'GIGAVERSION',
                 b'Sinjisoft', b'GVMINFO', b'MIDlet-Name', b'com.aroma.ams.jam.Main', b'SKT_GVM', b'036.016.000')
files = []
sgs = []
zips = []
markers = []
candidates = 0
jad = []


def scan(path, raw, runtime=False):
    global candidates
    files.append(dict(path=path, **identity(raw)))
    result = scanner.scan_bytes(raw)
    candidates += result['candidate_offsets_tested']
    sgs.extend(dict(path=path, **row) for row in result['containers'])
    zips.extend(dict(path=path, **row) for row in complete_zips(raw))
    if re.search(rb'^MIDlet-1:[^\r\n]{1,256}', raw, re.M | re.I):
        jad.append(path)
    if runtime:
        matches = {term.decode(): [m.start() for m in re.finditer(re.escape(term), raw)] for term in runtime_terms}
        markers.append(dict(path=path, matches={k:v for k,v in matches.items() if v}))


for file in sorted(p for p in base.rglob('*') if p.is_file()):
    raw = file.read_bytes()
    path = file.relative_to(base).as_posix()
    scan(path, raw, file.parent.name == 'BIN' or file.suffix.lower() == '.pxo')
    if file.name == 'data.lkz':
        with zipfile.ZipFile(file) as z:
            assert z.testzip() is None
            for i in z.infolist():
                if not i.is_dir():
                    scan(f'{path}/{i.filename}', z.read(i))
    if file.suffix.lower() == '.gz':
        decoder = zlib.decompressobj(47)
        body = decoder.decompress(raw, 16 * 1024**2)
        assert decoder.eof and not decoder.unused_data, path
        scan(f'{path}/decoded', body)
    if file.suffix.lower() == '.swf' and raw[:3] == b'CWS':
        decoder = zlib.decompressobj()
        body = decoder.decompress(raw[8:], 16 * 1024**2)
        if decoder.eof and not decoder.unused_data and len(body) + 8 == int.from_bytes(raw[4:8], 'little'):
            scan(f'{path}/decoded', body)

for file in sorted(Path(f'{model}-decoded').glob('*/decoded.pxo')):
    scan(file.as_posix(), file.read_bytes(), runtime=True)
main = Path(f'{model}-main/main.bin')
if main.exists():
    scan(main.as_posix(), main.read_bytes(), runtime=True)

record = dict(model=model, files=files, candidates=candidates, sgs=sgs, zips=zips, jad=jad,
              markers=[r for r in markers if r['matches']])
Path(f'{model}-scan.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf8')
print(model, len(files), sum(x['bytes'] for x in files), candidates, 'SGS', sgs, 'ZIP', zips, 'JAD', jad)
for row in record['markers']:
    print(row)
