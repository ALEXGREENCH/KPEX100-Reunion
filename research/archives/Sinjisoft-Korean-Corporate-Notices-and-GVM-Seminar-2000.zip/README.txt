Sinjisoft Korean corporate notices and early GVM seminar PDFs. 2026-11-06.

28 selected original HTML responses: 25 board2 notices and three corporate pages.
Unmodified CDX records, replay receipts and raw bytes are retained. UTF-8 text
is a separate derivative. Posted date, embedded source date and capture timestamp
are distinct. This is not all Sinjisoft press releases or recovered SDK installers.
The 30 previously preserved Newswire releases remain a separate archive.

Two newly downloaded original PDFs match the exact requested CDX SHA-1:
- gvm1.pdf: 8 pages, SK Telecom, August 2000 CP and billing policy.
- gvm3.pdf: 24 pages, Sinjisoft Hellfire training, 17 August 2000.
Originals are unchanged. Extracted text, page boxes and six rendered review pages
are derivatives. These are seminar slides, not full Hellfire sources or a phone player.
gvm3 shows LockChatMode(0), SetTimer(300,1), key cases 3/1/7/4/5 and HellfireGray.
SCRIPTVER 0, CPID 100 and ID 71 on the slide differ from the archived WI-TOP v1
binary. A related example does not establish binary identity.

The offline text index covers 1,965 distinct verified HTTP200 HTML bodies from
the frozen collection of 53,659 capture tasks. It includes forms, reprints, spam
and historic error pages with HTTP200. Seven lossy decodings are explicit.
A text match is not a recovered binary. Search with the included
wayback-text-index.py and Korean or English terms.

The source snapshot is GNEX-GVM-Wayback-Partial-Pass4-20261106.zip; its size and
hash are in provenance/source-snapshot.json. The main collector continues separately.
Empty availability results and failed HTTP requests are preserved without
claiming missing files recovered. No forms or historical JavaScript or programs
were executed by this preservation pass. MIT covers the Reunion tools; existing
rights to third-party materials remain. manifest.json covers all other members.
