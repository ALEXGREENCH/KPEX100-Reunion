import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import time
import urllib.error
import urllib.request

root = Path(__file__).resolve().parent
targets = json.loads((root / 'seminar-availability-targets.json').read_text('utf8'))
out = root / 'seminar-availability'
out.mkdir(exist_ok=True)
for index, target in enumerate(targets):
    receipt = dict(target, utc=datetime.now(timezone.utc).isoformat())
    try:
        req = urllib.request.Request(target['url'], headers={'User-Agent': 'KPEX100-Reunion-preservation/1.0', 'Accept-Encoding': 'identity'})
        try:
            response = urllib.request.urlopen(req, timeout=20)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            body = response.read()
            receipt.update(status=response.status, finalUrl=response.url, headers=list(response.headers.items()))
        name = f'{index:02}.response'
        (out/name).write_bytes(body)
        receipt.update(path=name, bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if response.status == 200:
            try:
                receipt['availability'] = json.loads(body)
            except (ValueError, UnicodeDecodeError):
                receipt['parseError'] = 'Not valid JSON'
    except OSError as error:
        receipt.update(status=0, error=str(error))
    (out/f'{index:02}.receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    print(json.dumps({k:v for k,v in receipt.items() if k in ('original','status','availability','error')}), flush=True)
    time.sleep(1.5)
