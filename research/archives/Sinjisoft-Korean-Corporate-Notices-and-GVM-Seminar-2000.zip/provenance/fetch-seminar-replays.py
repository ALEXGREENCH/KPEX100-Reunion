import importlib.util
import json
from pathlib import Path
import re
import urllib.parse

root = Path(__file__).resolve().parent
repo = root.parents[1] / 'outputs/KPEX100-Reunion'
spec = importlib.util.spec_from_file_location('harvest', repo/'tools/wayback-harvest.py')
harvest = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harvest)
collector = harvest.Collector(root/'seminar-replays', 1.5, 25)
results = []
try:
    for file in sorted((root/'seminar-availability').glob('*.receipt.json')):
        source = json.loads(file.read_text('utf8'))
        closest = source.get('availability', {}).get('archived_snapshots', {}).get('closest')
        if not closest or closest.get('status') != '200' or closest.get('available') is not True:
            continue
        observed = closest['url']
        parsed = urllib.parse.urlsplit(observed)
        assert parsed.hostname == 'web.archive.org'
        match = re.fullmatch(r'/web/(\d{14})/(http://www\.sinjisoft\.com:80/HP/data/(gvm[13]\.pdf))', parsed.path)
        assert match and match[1] == closest['timestamp']
        raw = 'https://web.archive.org/web/' + match[1] + 'id_/' + match[2]
        receipt, body = collector.request(raw, 'observed-seminar-attachment:'+match[3])
        result = {'availabilityReceipt':file.name, 'original':source['original'], 'observedReplay':observed, 'rawReceipt':receipt, 'pdfMagic':bool(body and body.startswith(b'%PDF-'))}
        if receipt['status'] == 200 and result['pdfMagic']:
            (root/match[3]).write_bytes(body)
        results.append(result)
        print(json.dumps(result), flush=True)
    for result in results:
        params = urllib.parse.urlencode({'url':result['original'], 'output':'json', 'fl':','.join(harvest.FIELDS)})
        receipt, body = collector.request('https://web.archive.org/cdx/search/cdx?'+params, 'seminar-attachment-cdx')
        result['cdxReceipt'] = receipt
        if receipt['status'] == 200:
            try:
                records, resume = harvest.parse_cdx(body)
                result['cdxRecords'] = records
                result['cdxResume'] = resume
            except ValueError as error:
                result['cdxParseError'] = str(error)
        print(json.dumps({'original':result['original'],'cdxStatus':receipt['status'],'records':len(result.get('cdxRecords',[]))}), flush=True)
finally:
    collector.export()
    collector.db.close()
    (root/'seminar-replay-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
