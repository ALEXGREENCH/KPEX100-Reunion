from pathlib import Path
import hashlib
import json
import re
import zipfile
import zlib

base = Path(__file__).resolve().parent
repo = base.parent.parent / 'outputs/KPEX100-Reunion'
sha = lambda data: hashlib.sha256(data).hexdigest()
js = lambda value: (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()
with zipfile.ZipFile(repo/'research/archives/GNEX-GVM-Wayback-Partial-Pass5-20261107.zip') as old, zipfile.ZipFile(repo/'research/archives/GNEX-GVM-Wayback-Partial-Pass6-20261107.zip') as new:
    read = lambda z: {r['id']:r for line in z.read('collection/captures.jsonl').splitlines() if (r:=json.loads(line))}
    before,after=read(old),read(new)
    assert len(before)==len(after)==53659 and before.keys()==after.keys()
    assert all(before[k]['record']==after[k]['record'] for k in before)
    assert all(after[k]['state']=='verified' and after[k]['payload']==r['payload'] for k,r in before.items() if r['state']=='verified')
    delta={'literalCdxRecordsUnchanged':53659,'previousVerifiedRetained':sum(r['state']=='verified' for r in before.values()),'newlyVerifiedCaptures':sum(r['state']=='verified' and before[k]['state']!='verified' for k,r in after.items())}
entries={}
for directory in ['articles','indexes']:
    for p in (base/directory).rglob('*'):
        if p.is_file():entries[directory+'/'+p.relative_to(base/directory).as_posix()]=p.read_bytes()
sources=json.loads(entries['articles/sources.json'])
for r in sources:
    assert r['verified'] and not r['decoding']['lossy'] and r['receipt']['status']==200
    data=entries['articles/'+r['receipt']['path']]
    assert sha(data)==r['receipt']['sha256'] and len(data)==r['receipt']['bytes']
    text=entries['articles/'+r['textPath']].decode()
    r['publishedAsDisplayed']=re.search(r'발행일\s*:\s*([0-9-]+\s+[0-9:]+)',text)[1]
    if r['kind']=='company-authored-column':assert 'choicy@sinjisoft.com' in text
entries['derived/article-register.json']=js(sources)
entries['derived/wayback-pass6-text-index.json']=(base/'wayback-pass6-text-index.json').read_bytes()
entries['provenance/pass5-comparison.json']=js(delta)
entries['provenance/wayback-pass6.json']=(repo/'validation/wayback-partial-pass6.json').read_bytes()
for name in ['article-seeds.json','index-seeds.json','package-press.py']:
    entries['provenance/'+name]=(base/name).read_bytes()
for name in ['tools/preserve-platform-pages.py','tools/wayback-text-index.py','tests/python/test_preserve_platform_pages.py','LICENSE']:
    entries[name]=(repo/name).read_bytes()
entries['README.txt']=b'''Sinjisoft Korean authored columns and publisher sources. 2026-11-07 (MSK).

Nine unchanged original ETNews HTML responses: four autobiographical columns
by Sinjisoft CEO Choi Chung-yup, one other signed column, four interviews or
publisher reports. These are NOT nine corporate press releases or SDK binaries.
Eight complete daily publisher indexes are preserved as discovery provenance.
All nine article responses are HTTP200; text was decoded without loss. Displayed
publication dates are recorded separately from numeric URLs and retrieval UTC.
Current navigation/advertising is part of the unchanged HTML response. External
scripts, advertisements, remote images and the rest of the publisher website
are not downloaded. Separate UTF8 text is a derivative, never the original.

The offline text index covers 2794 unique verified HTTP200 HTML bodies from
GNEX-GVM-Wayback-Partial-Pass6-20261107.zip (a separate immutable download).
11 lossy decodings are explicit. The index also includes forms, reprints, spam
and historical error pages. A text match does not establish a recovered file.
Pass6 retains all 53659 literal CDX records and previous 2952 verified captures;
423 more captures verified, 3375 total. It is still a partial download queue.

Original response bytes, URLs, HTTP headers, UTC receipts, sizes and SHA256
are preserved; manifest covers every other file with SHA256 and CRC32.
No page JavaScript, historical form, executable or downloaded program was run.
No GNEX1.20/1.40 or phone GNEX player is claimed recovered by this package.
MIT covers Reunion code only; original third-party rights remain separate.
'''
manifest=[{'path':n,'bytes':len(b),'sha256':sha(b),'crc32':f'{zlib.crc32(b):08x}'} for n,b in sorted(entries.items())]
entries['manifest.json']=js({'schema':1,'selfExcluded':True,'files':manifest})
out=repo/'research/archives/Sinjisoft-Korean-Authored-Columns-and-Corpus-Pass6.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for r in manifest:
        body=z.read(r['path']);assert len(body)==r['bytes'] and sha(body)==r['sha256'] and f'{zlib.crc32(body):08x}'==r['crc32']
report={'schema':1,'archive':out.name,'archiveBytes':out.stat().st_size,'archiveSha256':sha(out.read_bytes()),'members':len(entries),'manifestMembersVerified':len(manifest),'crcPassed':True,'articles':[{k:v for k,v in r.items() if k not in ['links']} for r in sources],'publisherIndexes':8,'allArticleTextLossless':True,'snapshotComparison':delta,'textIndexCounts':json.loads(entries['derived/wayback-pass6-text-index.json'])['counts'],'limits':'Partial collection; editorials/interviews distinguished from corporate releases; no rare SDK or phone player recovered.'}
(repo/'validation/sinjisoft-authored-columns-preservation.json').write_bytes(js(report))
print(json.dumps({k:v for k,v in report.items() if k!='articles'}))
