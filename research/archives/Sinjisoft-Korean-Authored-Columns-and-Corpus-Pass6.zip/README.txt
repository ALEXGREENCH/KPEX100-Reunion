Sinjisoft Korean authored columns and publisher sources. 2026-11-07 (MSK).

Nine unchanged original ETNews HTML responses: four autobiographical columns
by Sinjisoft CEO Choi Chung-yup, one other signed column, four interviews or
publisher reports. These are NOT nine corporate press releases or SDK binaries.
Eight complete daily publisher indexes are preserved as discovery provenance.
All nine article responses are HTTP200; text was decoded without loss. Displayed
publication dates are recorded separately from numeric URLs and retrieval UTC.
Current navigation/advertising is part of the unchanged HTML response. External
scripts, advertisements, remote images and the rest of the publisher website
are not downloaded. Separate UTF8 text is a derivative, never the original.

The offline text index covers 2794 unique verified HTTP200 HTML bodies from
GNEX-GVM-Wayback-Partial-Pass6-20261107.zip (a separate immutable download).
11 lossy decodings are explicit. The index also includes forms, reprints, spam
and historical error pages. A text match does not establish a recovered file.
Pass6 retains all 53659 literal CDX records and previous 2952 verified captures;
423 more captures verified, 3375 total. It is still a partial download queue.

Original response bytes, URLs, HTTP headers, UTC receipts, sizes and SHA256
are preserved; manifest covers every other file with SHA256 and CRC32.
No page JavaScript, historical form, executable or downloaded program was run.
No GNEX1.20/1.40 or phone GNEX player is claimed recovered by this package.
MIT covers Reunion code only; original third-party rights remain separate.
