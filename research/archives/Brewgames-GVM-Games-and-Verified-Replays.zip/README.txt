Brewgames Korean GVM games, preservation pass17, 2026-11-07 MSK.

Nine unchanged ZIP attachments, 605851 bytes; every advertised size matches,
all ZIP CRC checks pass on all 30 members. Original pages, RSS, retrieval UTC,
HTTP receipts, SHA256 and original member names are retained. Numeric extracted
filenames prevent archive-path writes. Vendor authenticity is not established.
Sidecar registry/data/INF/RES/MOD and historical saves are preserved as data,
not automatically installed or treated as executable dependencies.

Seven unchanged SGS added to Reunion: six new titles and one eight-byte
alternative Zzayo Tycoon build. Nom decoded body and Avatar original duplicate
the existing collection. Detailed hashes, all 8 differing positions and limits
are in validation/brewgames-game-recovery.json. No original SGS byte was edited.

All7 input/control pairs return idle. Matching common prefixes and virtual
frame deadlines, original ARM interpreter, selected scene/frame hashes in
validation/brewgames-gameplay.json. Both full JSON replay traces and 14 reviewed
input/control PNG frames accompany the 14 public JSON action plans. These are
short real menus/game scenes/controls, not full game/network/audio/save tests.
Source documents 128x160/176x220 GVM2X display settings; Reunion checks 128x160
with generic phone profile, not an attributed physical handset.

Ragnarok original has 130024 bytes, complete resource end 130022, then 0D0A.
Its full original is retained. A separately labelled derived 130022-byte prefix
is a research control, never the library replacement. The parser admits only
exact CRLF after complete v2 resources. Four original ARM runs compare original
and control, exact/guarded,87 action-state samples and388 events each. Variables,
all resource payloads, frames, registers/CPSR, timers, held keys and PC/status
match. Native hooks observed no access to the suffix in this bounded scenario.
This neither establishes CRLF provenance nor every possible game path.

Reproduce with a full Reunion checkout:
 node tools/verify-legacy-suffix.mjs --output ../NEW-suffix-report.json
 node --test tests/brewgames-games.test.mjs
 node tools/replay-sgs.mjs ID validation/brewgames-replays/ID.json NEW-directory
The renderer/runtime depend on the verified original Kingston 2.12 ROM and repo
modules; included tool snapshots alone are not a standalone emulator.

Public mobile API returned 403; public RSS and all 9 linked game posts/ZIPs were
obtained. Category response was a shell, not a full proven blog inventory.
No historical executable was launched or phone flashed. Original historical
files retain original rights, not Reunion MIT. MIT covers own tools only.
manifest.json checks all other direct members by size/SHA256/CRC32.
