aram.start()
aram.step(300)
aram.screenshot("first.png")
for i=1,4 do
 aram.tap("ok", 3)
 aram.step(210)
 aram.screenshot("phase-"..i..".png")
end
