GVM / GNEX preservation follow-up, 6 November 2026

Original binary downloads: two Samsung firmware archives and one byte-identical mirror of the previously preserved modified GVM2X emulator. Original bytes are unchanged.
source-index.json maps every URL, retrieval UTC, HTTP status and hash to a saved member. One failed connection has no invented body. HTML wrappers and errors retain that status; they are not phone player/SDK finds.

reports/ contains derived static analysis and archive checks. derived/outgoing/ contains extracted link lists. No vendor executable, installer, firmware or phone game has been executed on the host. Use trusted archive tools to inspect original-downloads; there is no autorun.

Neither early SDK 1.20/1.40, GVM SDK v1.52 nor a standalone phone GNEX player was recovered in this pass. No new runnable SGS was added.
Original pages/binaries retain their owners rights. Reunion does not grant a license for them.

manifest.json covers all other members, excluding itself.
