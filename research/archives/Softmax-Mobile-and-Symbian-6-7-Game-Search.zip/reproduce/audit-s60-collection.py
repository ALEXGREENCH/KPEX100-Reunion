"""Scan a verified Symbian game archive, its SIS payloads, and nested ZIPs."""

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import struct
import sys
import zipfile
import zlib

import numpy as np
import py7zr


BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
REPO = Path(os.environ.get("REUNION_AUDIT_REPO", ROOT / "outputs/KPEX100-Reunion"))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_text("utf8"))


def write(path, payload):
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", "utf8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


sis = load("old_sis", REPO / "tools/extract-old-sis.py")
sgs = load("sgs_scanner", REPO / "tools/scan-firmware-games.py")


def fast_scan(raw):
    """Lossless vectorized necessary-condition prefilter; original parser decides hits."""
    assert len(raw) <= sgs.MAX_INPUT_BYTES
    hits = []
    candidate_count = 0
    prefilter_count = 0
    for mask in (0, 165):
        decoded = raw.translate(sgs.XOR_TABLE) if mask else raw
        a8 = np.frombuffer(decoded, dtype=np.uint8)
        for v in sgs.VERSIONS:
            o = np.flatnonzero(a8 == v)
            candidate_count += len(o)
            header = 128 if v >= 4 else (52 if v == 1 else 100)
            o = o[o <= len(raw) - header]
            if not len(o):
                continue

            def at(k, n=4):
                val = a8[o + k].astype(np.uint32)
                for i in range(1, n):
                    val |= a8[o + k + i].astype(np.uint32) << (8 * i)
                return val

            if v >= 4:
                a, b, c, d, size = at(72), at(76), at(80), at(84), at(120)
                good = (
                    (a >= header + 16)
                    & (a < b)
                    & (b <= c)
                    & (c < d)
                    & (d <= size)
                    & (size <= len(raw) - o)
                    & ((b - a) % 8 == 0)
                    & ((d - c) % 12 == 0)
                )
            else:
                a, b, c, d = at(44, 2), at(46, 2), at(48, 2), at(50, 2)
                good = (
                    (a >= header + 16)
                    & (a < b)
                    & (b <= c)
                    & (c < d)
                    & (d <= len(raw) - o)
                    & ((b - a) % 4 == 0)
                    & ((d - c) % 4 == 0)
                )
            for off in o[good].tolist():
                prefilter_count += 1
                hit = sgs.parse_candidate(decoded, off)
                if not hit:
                    continue
                wrapper = (
                    32 if off >= 32 and raw[off - 32 : off - 28] == b" \0\0\0" else 0
                )
                start = off - wrapper
                end = off + hit["declared_body_bytes"]
                hit.update(
                    source_offset=start,
                    body_offset=off,
                    wrapper_bytes=wrapper,
                    xor_mask=mask,
                    extracted_bytes=end - start,
                    raw_sha256=sha(raw[start:end]),
                    decoded_body_sha256=sha(decoded[off:end]),
                )
                hits.append(hit)
    return {
        "bytes": len(raw),
        "sha256": sha(raw),
        "candidate_offsets_tested": candidate_count,
        "vectorizedPrefilterPasses": prefilter_count,
        "containers": sorted(hits, key=lambda r: r["body_offset"]),
    }


def main():
    archive_path = Path(sys.argv[1]).resolve(strict=True)
    member_directory = Path(sys.argv[2]).resolve(strict=True)
    meta = read(BASE / "s60-item-metadata.json")
    source = next(f for f in meta["files"] if f["name"] == "Symbian 6 & 7 Games.7z")
    source_hashes = (hashlib.sha1(), hashlib.md5(), hashlib.sha256())
    crc = 0
    with archive_path.open("rb") as stream:
        while block := stream.read(2 * 1024 * 1024):
            crc = zlib.crc32(block, crc)
            for h in source_hashes:
                h.update(block)
    identities = [h.hexdigest() for h in source_hashes]
    assert (
        archive_path.stat().st_size,
        identities[0],
        identities[1],
        f"{crc:08x}",
    ) == (int(source["size"]), source["sha1"], source["md5"], source["crc32"])

    header = BASE / "s60-archive-header.json"
    if not header.exists():
        header = ROOT / "work/symbian-header-followup/2-real-header.json"
    expected = read(header)
    archive_expected = {
        x["name"]: x["size"] for x in expected["files"] if not x["directory"]
    }
    assert len(archive_expected) == 1043
    catalogue = read(REPO / "web/data/catalog.json")
    known = defaultdict(list)
    for entry in catalogue["games"]:
        data = (REPO / "web" / entry["url"]).read_bytes()
        assert sha(data) == entry["sha256"]
        reference, fast = sgs.scan_bytes(data), fast_scan(data)
        assert (
            reference["containers"] == fast["containers"]
            and len(fast["containers"]) == 1
        )
        assert reference["candidate_offsets_tested"] == fast["candidate_offsets_tested"]
        known[fast["containers"][0]["decoded_body_sha256"]].append(entry["id"])

    output = BASE / "s60-audit-complete"
    output.mkdir(exist_ok=False)
    log = (output / "member-audit.jsonl").open("x", encoding="utf8", newline="\n")
    seen, stats, rejected, hits, opaque, candidates = (
        {},
        Counter(),
        Counter(),
        [],
        [],
        {},
    )
    keep = output / "candidate-objects"
    keep.mkdir()
    native = (
        []
    )  # Only E32 files with a Sinjisoft marker or a structurally validated SGS.

    def preserve(data):
        ident = sha(data)
        dest = keep / ident
        if not dest.exists():
            with dest.open("xb") as stream:
                stream.write(data)
        return ident

    def inspect(data, lineage, events, top, depth=0):
        if len(data) > sgs.MAX_INPUT_BYTES or depth > 5:
            raise ValueError("Payload bound exceeded")
        stats["scannedOccurrences"] += 1
        stats["expandedBytes"] += len(data)
        if stats["expandedBytes"] > 2 * 1024**3:
            raise ValueError("Expanded aggregate bound exceeded")
        identity = sha(data)
        if identity not in seen:
            seen[identity] = fast_scan(data)
        scanned = seen[identity]
        name = lineage[-1]
        extension = PurePosixPath(name).suffix.lower()
        epoc = len(data) >= 20 and data[16:20] == b"EPOC"
        marker = (
            b"sinjisoft" in data.lower()
            or "sinjisoft".encode("utf-16le") in data.lower()
        )
        if epoc and (marker or scanned["containers"]):
            native.append(
                {
                    "path": lineage,
                    "sha256": identity,
                    "bytes": len(data),
                    "sinjisoftMarker": marker,
                    "uid1": data[:4].hex(),
                }
            )
        for hit in scanned["containers"]:
            start = hit["source_offset"]
            extracted = data[start : start + hit["extracted_bytes"]]
            assert sha(extracted) == hit["raw_sha256"]
            record = {
                "path": lineage,
                "memberSha256": sha(top),
                "payloadSha256": identity,
                "existingIds": known.get(hit["decoded_body_sha256"], []),
                **hit,
            }
            hits.append(record)
            events.append({"kind": "sgs", "hit": record})
            preserve(top)
            preserve(data)
            preserve(extracted)

        maybe_sis = (
            extension == ".sis" or data[4:12] == b"\x12\x3a\x00\x10\x19\x04\x00\x10"
        )
        if maybe_sis:
            stats["sisSeen"] += 1
            try:
                manifest, outputs = sis.parse_sis(data)
            except (ValueError, struct.error, UnicodeError, zlib.error) as error:
                rejected[str(error)] += 1
                events.append(
                    {
                        "kind": "sis-rejected",
                        "path": lineage,
                        "sha256": identity,
                        "reason": str(error),
                    }
                )
                if (
                    marker
                    or 0x10272E30 <= int.from_bytes(data[:4], "little") <= 0x10272E50
                ):
                    preserve(top)
                    candidates[identity] = {
                        "path": lineage,
                        "status": "sis-parse-rejected",
                    }
            else:
                stats["sisParsed"] += 1
                stats["sisDecodedPayloads"] += len(outputs)
                offset = len(hits)
                for filename, payload in outputs:
                    inspect(payload, [*lineage, filename], events, top, depth + 1)
                if len(hits) > offset:
                    events.append(
                        {
                            "kind": "sis-hit-parent",
                            "path": lineage,
                            "manifest": manifest,
                        }
                    )
                    preserve(data)
                    candidates[identity] = {
                        "path": lineage,
                        "status": "parsed-with-sgs",
                    }

        if extension in (".zip", ".jar") or data.startswith(b"PK\x03\x04"):
            if zipfile.is_zipfile(io.BytesIO(data)):
                stats["zipContainers"] += 1
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    members = archive.infolist()
                    if (
                        len(members) > 1000
                        or sum(m.file_size for m in members) > 128 * 1024**2
                    ):
                        raise ValueError("Nested ZIP bound exceeded")
                    for member in members:
                        if not member.is_dir():
                            try:
                                child = archive.read(member)
                            except (
                                RuntimeError,
                                zipfile.BadZipFile,
                                NotImplementedError,
                            ) as error:
                                opaque.append(
                                    {
                                        "path": [*lineage, member.filename],
                                        "error": str(error),
                                    }
                                )
                            else:
                                inspect(
                                    child,
                                    [*lineage, member.filename],
                                    events,
                                    top,
                                    depth + 1,
                                )
            else:
                opaque.append({"path": lineage, "error": "Invalid ZIP magic/container"})
        if extension in (".rar", ".pak", ".7z", ".cab") and depth < 5:
            preserve(data)
            opaque.append(
                {
                    "path": lineage,
                    "sha256": identity,
                    "bytes": len(data),
                    "error": "Container expanded only if separately audited",
                }
            )

    with archive_path.open("rb") as stream, py7zr.SevenZipFile(
        stream, mode="r"
    ) as archive:
        items = archive.list()
        assert not archive.password_protected
        assert len(items) == len(expected["files"])
        entries = {}
        for item in items:
            path = PurePosixPath(item.filename)
            assert not path.is_absolute() and not ({"..", "."} & set(path.parts))
            assert "\\" not in item.filename and ":" not in item.filename
            assert item.is_directory or item.is_file
            if item.is_file:
                assert item.filename not in entries
                assert 0 <= item.uncompressed <= sgs.MAX_INPUT_BYTES
                entries[item.filename] = item
        assert {n: m.uncompressed for n, m in entries.items()} == archive_expected
    found_names = {
        path.relative_to(member_directory).as_posix()
        for path in member_directory.rglob("*")
        if path.is_file()
    }
    excluded = {
        name for name in entries if PurePosixPath(name).suffix.lower() == ".exe"
    }
    assert len(excluded) == 17
    assert not found_names - entries.keys()
    assert found_names.issuperset(entries.keys() - excluded)
    for filename, record in entries.items():
        if filename in excluded:
            continue
        path = member_directory.joinpath(*PurePosixPath(filename).parts)
        assert not path.is_symlink() and path.resolve().is_relative_to(member_directory)
        data = path.read_bytes()
        assert len(data) == record.uncompressed
        computed = zlib.crc32(data)
        if record.crc32 is not None:
            assert computed == record.crc32
            stats["matched7zMemberCrc"] += 1
        events = []
        inspect(data, [filename], events, data)
        stats["topFiles"] += 1
        stats["topBytes"] += len(data)
        log.write(
            json.dumps(
                {
                    "path": filename,
                    "bytes": len(data),
                    "sha256": sha(data),
                    "crc32": f"{computed:08x}",
                    "crcIn7zHeader": record.crc32 is not None,
                    "events": events,
                },
                ensure_ascii=False,
            )
            + "\n"
        )
        if stats["topFiles"] % 100 == 0:
            log.flush()
            print(dict(stats), flush=True)
    log.close()
    assert stats["topFiles"] == len(archive_expected) - len(excluded)
    assert stats["topBytes"] == sum(
        size for name, size in archive_expected.items() if name not in excluded
    )
    result = {
        "schema": 1,
        "checkedUtc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "archiveItem": "https://archive.org/details/symbian-6-7-games.-7z",
            "filename": source["name"],
            "bytes": int(source["size"]),
            "sha1": identities[0],
            "md5": identities[1],
            "sha256": identities[2],
            "crc32": f"{crc:08x}",
        },
        "scope": "All non-EXE regular members of the verified 7z and every decoded supported SIS/ZIP payload. Opaque files and rejected installers are listed separately. No guest executable code ran.",
        "excludedHostExecutables": sorted(excluded),
        "counts": dict(stats),
        "positiveControls": len(catalogue["games"]),
        "uniqueScannedBodies": len(seen),
        "candidateOffsetsTested": sum(
            s["candidate_offsets_tested"] for s in seen.values()
        ),
        "prefilterPassed": sum(s["vectorizedPrefilterPasses"] for s in seen.values()),
        "rejections": dict(rejected),
        "hits": hits,
        "nativeCandidates": native,
        "opaqueContainers": opaque,
        "preservedCandidates": candidates,
    }
    write(output / "summary.json", result)
    print(
        json.dumps(
            {
                "counts": dict(stats),
                "uniqueScannedBodies": len(seen),
                "sgsHits": len(hits),
                "newBodies": len(
                    {h["decoded_body_sha256"] for h in hits if not h["existingIds"]}
                ),
                "opaqueContainers": len(opaque),
            },
            ensure_ascii=False,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
