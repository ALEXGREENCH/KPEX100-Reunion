"""Check RAR payloads retained by the Symbian corpus audit without extracting paths."""

from collections import Counter
import json
from pathlib import Path, PurePosixPath
import re
from runpy import run_path
import subprocess
import sys
import zlib

base = Path(__file__).resolve().parent
m = run_path(str(base / "audit-s60-collection.py"))
sis, fast_scan = m["sis"], m["fast_scan"]
read, write = m["read"], m["write"]
root = base / "s60-audit-complete"
seven = Path(sys.argv[1]).resolve(strict=True)
audit = read(root / "summary.json")
selected = [
    item
    for item in audit["opaqueContainers"]
    if PurePosixPath(item["path"][-1]).suffix.lower() == ".rar" and "sha256" in item
]
assert len(selected) <= 12
results, errors, found = [], [], []
counts = Counter()


def invoke(*args):
    return subprocess.run(
        [str(seven), *args], check=True, capture_output=True, timeout=45
    ).stdout


def inspect(raw, path, depth=0):
    counts["payloads"] += 1
    counts["bytes"] += len(raw)
    scan = fast_scan(raw)
    for hit in scan["containers"]:
        found.append({"path": path, **hit})
    if depth < 3 and (
        path[-1].lower().endswith(".sis")
        or raw[4:12] == b"\x12\x3a\x00\x10\x19\x04\x00\x10"
    ):
        counts["sis"] += 1
        try:
            manifest, payloads = sis.parse_sis(raw)
        except ValueError as e:
            errors.append({"path": path, "error": str(e)})
        else:
            counts["sisParsed"] += 1
            for name, data in payloads:
                inspect(data, [*path, name], depth + 1)
    return scan["sha256"]


for item in selected:
    archive = root / "candidate-objects" / item["sha256"]
    raw = archive.read_bytes()
    assert m["sha"](raw) == item["sha256"] and raw.startswith(b"Rar!\x1a\x07")
    listing = invoke("l", "-slt", "-sccUTF-8", "--", str(archive)).decode("utf8")
    header, sep, entries = listing.replace("\r\n", "\n").partition("\n----------\n")
    assert sep and re.search(r"\nType = Rar5?\n", header)
    records = [
        dict(line.split(" = ", 1) for line in chunk.splitlines() if " = " in line)
        for chunk in entries.strip().split("\n\n")
    ]
    paths = [r["Path"] for r in records]
    assert len(set(paths)) == len(paths) <= 1000
    total = sum(int(r.get("Size", "0")) for r in records)
    assert total <= 64 * 1024 * 1024
    for r in records:
        assert (
            r.get("Encrypted") != "+"
            and "Symbolic Link" not in r
            and "Hard Link" not in r
        )
    contents = invoke("x", "-so", "--", str(archive))
    assert len(contents) == total
    members = []
    offset = 0
    for r in records:
        name = r["Path"]
        p = PurePosixPath(name.replace("\\", "/"))
        assert not p.is_absolute() and ".." not in p.parts and ":" not in name
        assert (
            r.get("Encrypted") != "+"
            and "Symbolic Link" not in r
            and "Hard Link" not in r
        )
        if r.get("Folder") == "+" or r.get("Attributes", "").startswith("D"):
            continue
        size = int(r["Size"])
        raw = contents[offset : offset + size]
        offset += size
        crc = f"{zlib.crc32(raw):08X}"
        assert not r.get("CRC") or crc == r["CRC"]
        digest = inspect(raw, [*item["path"], name])
        members.append(
            {"path": name, "bytes": len(raw), "sha256": digest, "crc32": crc}
        )
    assert offset == total
    results.append({"archive": item, "members": members})
report = {
    "rarArchives": results,
    "counts": dict(counts),
    "errors": errors,
    "sgsHits": found,
}
write(base / "s60-rar-audit.json", report)
print(
    json.dumps(
        {
            "rar": len(results),
            "counts": dict(counts),
            "rejections": len(errors),
            "hits": len(found),
        }
    )
)
