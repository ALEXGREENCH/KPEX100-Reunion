Softmax mobile sources and Symbian 6/7 acquisition audit.
The package preserves the exact KTF Magna Carta M BREW download, historical
source snapshots, and audit evidence. The exact 239683863-byte 7z is available
at the source named in the report. The five checked SGS occurrences are
already in the library. Host EXE files were excluded from the SGS audit.

To repeat the 7z audit, download and verify the source archive. Inspect its
member list, then extract it with 7-Zip to a new working directory as data.
Set REUNION_AUDIT_REPO to a full Reunion checkout and install numpy and py7zr.
Run python reproduce/audit-s60-collection.py SOURCE_7Z EXTRACTED_DIRECTORY
and python reproduce/audit-s60-rar.py PATH_TO_7Z. The scripts run no games.
The manifest checks every other package member by CRC32, SHA-256, and size.
