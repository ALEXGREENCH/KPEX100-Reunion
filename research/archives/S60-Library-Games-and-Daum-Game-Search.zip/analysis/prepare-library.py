from pathlib import Path
from datetime import datetime, timezone
import json
import zipfile
import hashlib
import struct
import shutil
from PIL import Image, ImageChops

base = Path(__file__).resolve().parent
repo = base.parent.parent / "outputs/KPEX100-Reunion"
read = lambda p: json.loads(p.read_text("utf8"))
write = lambda p, o: p.write_text(
    json.dumps(o, ensure_ascii=False, indent=2) + "\n", "utf8"
)
sha = lambda b: hashlib.sha256(b).hexdigest()
specs = [
    {
        "id": "world-league-2005-soccer-s60",
        "title": "World League 2005 Soccer (S60)",
        "file": "world-league-2005-soccer-full-s60.sgs",
        "folders": ["world-full-current-input", "world-full-current-control"],
        "plan": "world",
        "prefix": 45,
        "sourceName": "WorldLeague.app",
        "sourceUrl": "https://archive.org/details/dertz-part-5-s-z",
        "hash": "439c7c59850dd58b265512a157ae65e67602055e01b2891dc0b3743046a38e08",
        "hint": "Для первой игры выберите Practice. Движение — стрелки, действие — 5. Некоторые подписи меню отображаются неверно.",
        "scene": "Practice match on the pitch; recorded direction inputs and numeric5 at fixed virtual deadlines. Tournament completion not tested.",
    },
    {
        "id": "world-league-2005-soccer-demo-s60",
        "title": "World League 2005 Soccer Demo (S60)",
        "file": "world-league-2005-soccer-demo-s60.sgs",
        "folders": ["world-demo-current-input", "world-demo-current-control"],
        "plan": "world",
        "prefix": 45,
        "sourceName": "WorldLeagueDemo.app",
        "sourceUrl": "https://archive.org/details/largest-j2me-and-symbian-collection",
        "hash": "c3ec24942285cb181e6243efef73c3450d2916d8feaf2e7cf1e2ad96bc55adf0",
        "hint": "Демо: доступен Practice; New Game закрыт самой игрой. Движение — стрелки, действие — 5. Некоторые подписи меню отображаются неверно.",
        "scene": "Practice match on the pitch. Demo restriction on New Game is documented in the earlier preserved pass8 evidence; no retail-unlock patch.",
    },
    {
        "id": "bounce-rubberball-story-s60",
        "title": "Bounce! Rubberball Story (S60)",
        "file": "bounce-rubberball-story-s60.sgs",
        "folders": ["bounce-final-input", "bounce-final-control"],
        "plan": "bounce",
        "prefix": 27,
        "sourceName": "Bounce.app",
        "sourceUrl": "https://archive.org/details/dertz-part-5-s-z",
        "hash": "e646fa49a6cef04971dad124c55bc9506a152a9d1f457e39db9b239c6ed06594",
        "hint": "GameStart → New Game → 1 (Yes). Вступление и подсказки — OK. В игре нажимайте OK в ритм отскоков.",
        "scene": "First rhythm stage; two OK taps compared with idle. Reviewed input frame shows COOL and a higher LIFE bar; control shows BAD. Not a full playthrough.",
    },
]
catalog = read(repo / "web/data/catalog.json")
assert len(catalog["games"]) == 76
old_entries = {g["id"]: g for g in catalog["games"]}
games = {}
sources = []
runtime_files = [
    "tools/replay-sgs.mjs",
    "web/engine/gnex.js",
    "web/engine/cpu.js",
    "web/engine/sgs.js",
    "web/engine/timers.js",
    "web/engine/rom-accelerators.js",
]
for spec in specs:
    identifier = spec["id"]
    raw = (base / spec["file"]).read_bytes()
    assert sha(raw) == spec["hash"]
    assert identifier not in old_entries
    target = repo / "web/data/games" / (identifier + ".sgs")
    assert not target.exists()
    target.write_bytes(raw)
    plans = []
    runs = []
    for label, folder in zip(["input", "control"], spec["folders"]):
        src = base / folder
        run = read(next(src.glob("*.json")))
        assert all(t["status"] == "idle" and t["error"] is None for t in run["trace"])
        assert (
            run["runtime"]["profile"] == "phone"
            and run["runtime"]["width"] == 176
            and run["runtime"]["height"] == 208
        )
        if spec["plan"] == "world":
            plan = read(
                repo
                / "validation"
                / (
                    "replay-world-league-demo-s60"
                    + ("-control" if label == "control" else "")
                    + ".json"
                )
            )
        else:
            plan = read(base / ("bounce-final-" + label + "-plan.json"))
        assert plan["actions"] == run["actions"]
        name = (
            "replay-"
            + identifier
            + ("-control" if label == "control" else "")
            + ".json"
        )
        write(repo / "validation" / name, plan)
        plans.append(name)
        runs.append(run)
        dest = repo / "validation/gameplay" / identifier / label
        dest.mkdir(parents=True, exist_ok=True)
        frame = run["trace"][-1]["filename"]
        shutil.copyfile(src / frame, dest / frame)
    assert plans[0] != plans[1] and len(runs[0]["trace"]) == len(runs[1]["trace"])
    assert runs[0]["actions"][: spec["prefix"]] == runs[1]["actions"][: spec["prefix"]]
    comparisons = []
    for index, (inp, ctrl) in enumerate(zip(runs[0]["trace"], runs[1]["trace"])):
        assert inp["timeMs"] == ctrl["timeMs"]
        images = [
            Image.open(base / folder / trace["filename"]).convert("RGBA")
            for folder, trace in zip(spec["folders"], [inp, ctrl])
        ]
        assert images[0].size == images[1].size == (176, 208)
        pixels = list(zip(images[0].tobytes()[::4], images[1].tobytes()[::4]))
        aa, bb = [im.tobytes() for im in images]
        different = sum(aa[n : n + 4] != bb[n : n + 4] for n in range(0, len(aa), 4))
        if index <= spec["prefix"]:
            assert different == 0
        comparisons.append(
            {
                "index": index,
                "timeMs": inp["timeMs"],
                "inputEvents": inp["events"],
                "controlEvents": ctrl["events"],
                "differingPixels": different,
                "inputRgbaSha256": sha(aa),
                "controlRgbaSha256": sha(bb),
            }
        )
    assert comparisons[-1]["differingPixels"] > 0
    # Any held input in these finite plans must end released.
    for run in runs:
        held = set()
        for kind, value in run["actions"]:
            if kind == "hold":
                held.add(value)
            elif kind == "release":
                held.discard(value)
        assert not held
    frames = [
        (
            repo
            / "validation/gameplay"
            / identifier
            / label
            / run["trace"][-1]["filename"]
        )
        .relative_to(repo / "validation")
        .as_posix()
        for label, run in zip(["input", "control"], runs)
    ]
    games[identifier] = {
        "id": identifier,
        "title": spec["title"],
        "sgsSha256": spec["hash"],
        "replay": plans[0],
        "controlReplay": plans[1],
        "status": "idle",
        "error": None,
        "runtime": runs[0]["runtime"],
        "frame": frames[0],
        "controlFrame": frames[1],
        "frameSha256": sha((repo / "validation" / frames[0]).read_bytes()),
        "controlFrameSha256": sha((repo / "validation" / frames[1]).read_bytes()),
        "commonPrefixActions": spec["prefix"],
        "reviewedTraceIndex": len(comparisons) - 1,
        "controlProof": comparisons,
        "evidence": spec["scene"],
        "limits": [
            "External Symbian WAV/MIDI not connected.",
            "Full Symbian APP/OS not executed; original SGS runs in the Kingston interpreter.",
        ]
        + (
            ["Some Formation/Time menu labels render incorrectly."]
            if spec["plan"] == "world"
            else []
        ),
    }
    a, b, c, d = struct.unpack_from("<4I", raw, 72)
    entry = {
        "id": identifier,
        "title": spec["title"],
        "nativeTitle": spec["title"].replace(" (S60)", ""),
        "url": "data/games/" + identifier + ".sgs",
        "sha256": spec["hash"],
        "bytes": len(raw),
        "format": 4,
        "resources": (d - c) // 12,
        "platform": "mobile",
        "compatibility": "playable",
        "runtime": {"profile": "phone", "width": 176, "height": 208},
        "sourceName": spec["sourceName"],
        "sourceUrl": spec["sourceUrl"],
        "provenance": "Unchanged embedded SGS from the already preserved native Symbian S60 application. Added to the library after current paired scene/control checks; not a new Internet recovery or full Symbian emulation. External WAV/MIDI are not connected.",
        "startHint": spec["hint"],
    }
    catalog["games"].append(entry)
    sources.append(spec)
write(repo / "web/data/catalog.json", catalog)
proof = {
    "schema": 1,
    "checkedUtc": datetime.now(timezone.utc).isoformat(),
    "scope": "Three previously archived S60 SGS builds newly exposed in the launch library. Two titles, one demo variant. Current original ARM interpreter; matched-time input/idle pairs, not complete games or Symbian OS parity.",
    "firmwareSha256": sha((repo / "web/data/firmware/Kingston-2.12.rom").read_bytes()),
    "engineFiles": [
        {"path": name, "sha256": sha((repo / name).read_bytes())}
        for name in runtime_files
    ],
    "newInternetRecoveries": 0,
    "games": games,
}
write(repo / "validation/s60-library-gameplay.json", proof)
write(base / "library-additions.json", sources)
print(
    json.dumps(
        {
            "games": len(catalog["games"]),
            "addedBuilds": len(games),
            "newInternetRecoveries": 0,
            "pairs": {k: v["controlProof"][-1] for k, v in games.items()},
        }
    )
)
