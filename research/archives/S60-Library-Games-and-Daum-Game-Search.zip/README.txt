S60 library completion and Daum game-source research, pass19, 2026-11-07.

THREE PREVIOUSLY PRESERVED SGS newly exposed in the Reunion library:
World League2005Soccer full, itsdemo, Bounce!RubberballStory. Two titles and
one demo variant, NOT three new Internet recoveries. SourceSIS originals,
39freshdecoded payloads, exact unchanged APP->SGS slices and original notices
retained. Signature authenticity and factory-handset provenance not asserted.
No native Symbian app, installer, Java or Flash code executed.

Three fixed-time input/idle pairs use the current original Kingston ARM VM.
Navigation prefixes match all pixels. Selected game scenes differ by8018,
3831 and342pixels at matching deadlines. WorldLeague Practice works; demo
NewGame locked by original game. Formation/Time labels have rendering issues.
Bounce first rhythm stage reacts to OK timing (COOL vs BAD and LIFE change).
Six reviewed finalPNG, six plans and six full traces included. These are
short scenes/controls, not complete games, save cycles or Symbian OS parity.
External S60 WAV/MIDI are preserved but not connected in Reunion.

With a full Reunion checkout including its archived source originals:
 node --test tests/s60-library-games.test.mjs
 python tools/verify-s60-library.py --output NEW_source_check.json
 node tools/replay-sgs.mjs bounce-rubberball-story-s60 validation/replay-bounce-rubberball-story-s60.json NEW_frames
The included tool snapshots alone are not a standalone emulator.

Network research recovered ZERO newSGS. Daum board titles/menu metadata,
membership/admin notices, ineffective pagination probes,19selected Wayback
article requests and6exactframeCDXrequests retained with UTC/status/size/hash.
Only13of14HTTP200Wayback bodies match requestedCDXSHA1; remaining errors,
timeouts and mismatch are not recovered articles. Five cafe search responses
are tinyJSredirects, not search results. GVM vs gvm are different communities;
GVMC was a carclub. Do not widen CDX scope or count neighboring clubs as GVM.
The public article list bodies are not proof of readable article attachments.
No login, messages, membership requests or private-content bypass attempted.
Keyword-match downloader metadata is superseded by game-hunt-pass19.json's
explicit response assessments. This is not a fullforum/Wayback crawl.

Original games/resources/vendor files retain their original rights. Reunion
MIT covers own code, not historical content. manifest.json verifies every
other direct ZIPmember by SHA256/size/CRC32; self excluded intentionally.
